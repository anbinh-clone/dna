package lf

import (
	"dna"
)

type Artist struct {
	Id         dna.Int
	Name       dna.String
	Genres     dna.StringArray
	Popularity dna.Int
	Image      dna.String
}

func NewArtist() *Artist {
	artist := new(Artist)
	artist.Id = 0
	artist.Name = ""
	artist.Genres = dna.StringArray{}
	artist.Popularity = 0
	artist.Image = ""
	return artist
}

func (artist *Artist) Equal(cprArtist *Artist) dna.Bool {
	if artist.Id == cprArtist.Id {
		return true
	} else {
		return false
	}
}
