package lf

import (
	"dna"
	"dna/http"
	"dna/utils"
	"encoding/json"
	"errors"
	"time"
)

// http://api.lyricfind.com/metadata.do?apikey=4b59d60b5b74512a662b89dfb1b28680&reqtype=availablelyrics&artistid=amg:7362&offset=0&limit=10&displaykey=ccabb2c8bf7302e1d8c9b87be793bfb0&output=json
// METADATA

type APIFullSong struct {
	Response struct {
		Code        dna.Int    `json:"code"`
		Description dna.String `json:"description"`
	} `json:"response"`
	Track struct {
		Id           dna.Int    `json:"amg"`
		Title        dna.String `json:"title"`
		Instrumental dna.Bool   `json:"instrumental"`
		Viewable     dna.Bool   `json:"viewable"`
		HasLrc       dna.Bool   `json:"has_lrc"`
		LrcVerified  dna.Bool   `json:"lrc_verified"`

		Duration dna.String `json:"duration"`
		Lyricid  dna.Int    `json:"lyric"`
		Album    struct {
			Id         dna.Int    `json:"amg"`
			Year       dna.String `json:"year"`
			Image      dna.String `json:"image"`
			Largeimage dna.String `json:"largeimage"`
			Importance dna.Int    `json:"importance"`
			Title      dna.String `json:"title"`
			Artist     struct {
				Id         dna.Int    `json:"amg"`
				Image      dna.String `json:"image"`
				Genre      dna.String `json:"genre"`
				Popularity dna.Int    `json:"popularity"`
				Name       dna.String `json:"name"`
			} `json:"artist"`
		} `json:"album"`
		Artists []struct {
			Id         dna.Int    `json:"amg"`
			Image      dna.String `json:"image"`
			Genre      dna.String `json:"genre"`
			Popularity dna.Int    `json:"popularity"`
			Name       dna.String `json:"name"`
		} `json:"artists"`
		LastUpdate dna.String `json:"last_update"`
		Lyrics     dna.String `json:"lyrics"`
		Copyright  dna.String `json:"copyright"`
		Writer     dna.String `json:"writer"`
	} `json:"track"`
}

func (apiSong *APIFullSong) ToArtists() []*Artist {
	artists := []*Artist{}

	// Getting artist from album
	albumArtist := NewArtist()
	albumArtist.Id = apiSong.Track.Album.Artist.Id
	albumArtist.Name = apiSong.Track.Album.Artist.Name
	albumArtist.Genres = apiSong.Track.Album.Artist.Genre.ToStringArray()
	albumArtist.Popularity = apiSong.Track.Album.Artist.Popularity
	albumArtist.Image = apiSong.Track.Album.Artist.Image
	artists = append(artists, albumArtist)

	// Getting artists from song
	for _, artist := range apiSong.Track.Artists {
		// dna.Log(artist)
		// Only get new artists
		if artist.Id != albumArtist.Id {
			trackArtist := NewArtist()
			trackArtist.Id = artist.Id
			trackArtist.Name = artist.Name
			trackArtist.Genres = artist.Genre.ToStringArray()
			trackArtist.Popularity = artist.Popularity
			trackArtist.Image = artist.Image
			artists = append(artists, trackArtist)
		}
	}
	return artists
}

func (apiSong *APIFullSong) ToAlbum() *Album {
	// dna.Log(apiSong.Track.Album)
	album := NewAlbum()
	album.Id = apiSong.Track.Album.Id
	album.Title = apiSong.Track.Album.Title
	album.Artistid = apiSong.Track.Album.Artist.Id
	album.Artists = apiSong.Track.Album.Artist.Name.ToStringArray()
	album.Year = apiSong.Track.Album.Year
	album.Importance = apiSong.Track.Album.Importance
	album.Image = apiSong.Track.Album.Image
	album.LargeImage = apiSong.Track.Album.Largeimage
	return album
}

func (apiSong *APIFullSong) FillSong(song *Song) {
	song.Id = apiSong.Track.Id
	song.Title = apiSong.Track.Title

	artists := dna.StringArray{}
	for _, artist := range apiSong.Track.Artists {
		artists.Push(artist.Name)
	}
	song.Artists = artists
	artistids := dna.IntArray{}
	for _, artist := range apiSong.Track.Artists {
		artistids.Push(artist.Id)
	}

	song.Artistids = artistids
	song.Albumid = apiSong.Track.Album.Id
	song.AlbumTitle = apiSong.Track.Album.Title
	song.Duration = utils.ToSeconds(apiSong.Track.Duration)
	song.Instrumental = apiSong.Track.Instrumental
	song.Viewable = apiSong.Track.Viewable
	song.HasLrc = apiSong.Track.HasLrc
	song.LrcVerified = apiSong.Track.LrcVerified
	song.Lyricid = apiSong.Track.Lyricid
	song.Lyric = apiSong.Track.Lyrics
	song.Copyright = apiSong.Track.Copyright
	song.Writers = apiSong.Track.Writer
	// Mon Jan 2 15:04:05 MST 2006
	if apiSong.Track.LastUpdate != "" {
		lastUpdate, err := time.Parse("2006-01-02 15:04:05", apiSong.Track.LastUpdate.String())
		if err == nil {
			song.DateUpdated = lastUpdate
		} else {
			dna.Log(err.Error(), " Song ID:", song.Id, " GOT:", apiSong.Track.LastUpdate, "\n\n")
		}
	}
	song.Done = true
}

func GetAPIFullSong(id dna.Int) (*APIFullSong, error) {
	var apisong = new(APIFullSong)
	// USING METADATA
	// link := "https://api.lyricfind.com/lyric.do?apikey=" + API_KEY + "&reqtype=default&trackid=amg:" + id.ToString().String() + "&output=json"

	link := "http://api.lyricfind.com/metadata.do?apikey=" + METADATA_KEY + "&reqtype=metadata&trackid=amg:" + id.ToString().String() + "&displaykey=" + API_KEY + "&output=json"
	// result, err := GetProxy(dna.String(link), 0)
	result, err := http.Get(dna.String(link))
	if err == nil {
		data := &result.Data
		json.Unmarshal([]byte(*data), apisong)
		switch apisong.Response.Code {
		case 100, 101, 111, 102:
			return apisong, nil
		default:
			return nil, errors.New(dna.Sprintf("LyricFind - Song ID: %v - %v %v", id, apisong.Response.Code, apisong.Response.Description).String())
		}
		return apisong, nil
	} else {
		return nil, err
	}
}
