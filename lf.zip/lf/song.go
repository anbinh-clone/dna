package lf

import (
	"dna"
	"dna/item"
	"dna/sqlpg"
	"os"
	"sync"
	"time"
)

// Song defines a song struct whose ID is form AMG.
type Song struct {
	Id           dna.Int
	Title        dna.String
	Artistids    dna.IntArray // New
	Artists      dna.StringArray
	Albumid      dna.Int    // New
	AlbumTitle   dna.String // New
	Instrumental dna.Bool
	Viewable     dna.Bool
	HasLrc       dna.Bool
	LrcVerified  dna.Bool
	Lyricid      dna.Int // New
	Lyric        dna.String
	Duration     dna.Int // New
	Copyright    dna.String
	Writers      dna.String
	DateUpdated  time.Time
	Checktime    time.Time
	Done         dna.Bool
}

func NewSong() *Song {
	song := new(Song)
	song.Id = 0
	song.Title = ""
	song.Artistids = dna.IntArray{}
	song.Artists = dna.StringArray{}
	song.Albumid = 0
	song.AlbumTitle = ""
	song.Instrumental = false
	song.Viewable = false
	song.HasLrc = false
	song.LrcVerified = false
	song.Lyricid = 0
	song.Lyric = ""
	song.Duration = 0
	song.Copyright = ""
	song.Writers = ""
	song.DateUpdated = time.Time{}
	song.Checktime = time.Now()
	song.Done = false
	return song
}

// func GetSong(id dna.Int) (*Song, error) {
// 	apisong, err := GetAPISong(id)
// 	if err != nil {
// 		return nil, err
// 	} else {
// 		song := NewSong()
// 		apisong.FillSong(song)
// 		return song, nil
// 	}
// }

// Fetch implements item.Item interface.
// Returns error if can not get item
func (song *Song) Fetch() error {
	_song, err := GetSong(song.Id)
	if err != nil {
		return err
	} else {
		*song = *_song
		return nil
	}
}

// GetId implements GetId methods of item.Item interface
func (song *Song) GetId() dna.Int {
	return song.Id
}

// New implements item.Item interface
// Returns new item.Item interface
func (song *Song) New() item.Item {
	return item.Item(NewSong())
}

// Init implements item.Item interface.
// It sets Id or key.
// dna.Interface v has type int or dna.Int, it calls Id field.
// Otherwise if v has type string or dna.String, it calls Key field.
func (song *Song) Init(v interface{}) {
	switch v.(type) {
	case int:
		song.Id = dna.Int(v.(int))
	case dna.Int:
		song.Id = v.(dna.Int)
	default:
		panic("Interface v has to be int")
	}
}

var (
	mutex      = &sync.Mutex{}
	SongFile   *os.File
	TotalBytes dna.Int
)

func GetSong(id dna.Int) (*Song, error) {
	apiSong, err := GetAPIFullSong(id)
	if err != nil {
		return nil, err
	} else {
		song := NewSong()
		apiSong.FillSong(song)
		var queries dna.String
		queries, err := sqlpg.GetUpdateStatement("lfsongs", song, "id", "artistids", "albumid", "album_title", "duration", "lyricid", "done")
		if err != nil {
			panic(err.Error())
		}
		queries += "\n"
		artists := apiSong.ToArtists()
		for _, artist := range artists {
			queries += sqlpg.GetInsertStatement("lfartists", artist, false) + "\n"
		}

		queries += sqlpg.GetInsertStatement("lfalbums", apiSong.ToAlbum(), false) + "\n"
		mutex.Lock()
		n, err := SongFile.WriteString(queries.String())
		TotalBytes += dna.Int(n)
		mutex.Unlock()
		return song, nil
	}
}

func (song *Song) Save(db *sqlpg.DB) error {
	return nil
	// insertStmt := sqlpg.GetInsertStatement("lfsongs", song, false) + "\n"
	// mutex.Lock()
	// n, err := SongFile.WriteString(insertStmt.String())
	// TotalBytes += dna.Int(n)
	// mutex.Unlock()
	// if err == nil {
	// 	return nil
	// } else {
	// 	return err
	// }
}
