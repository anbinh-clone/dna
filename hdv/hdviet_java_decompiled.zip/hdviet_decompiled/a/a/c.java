package a.a;

import java.io.StringWriter;
import java.util.Collection;
import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;

public final class c
{
    public static final Object a;
    private final Map b;
    
    static {
        a = new d(0);
    }
    
    public c() {
        super();
        this.b = new HashMap();
    }
    
    public c(final f f) {
        this();
        if (f.c() != '{') {
            throw f.a("A JSONObject text must begin with '{'");
        }
        Label_0024: {
            break Label_0024;
            do {
                f.a();
                switch (f.c()) {
                    default: {
                        f.a();
                        final String string = f.d().toString();
                        final char c = f.c();
                        if (c == '=') {
                            if (f.b() != '>') {
                                f.a();
                            }
                        }
                        else if (c != ':') {
                            throw f.a("Expected a ':' after a key");
                        }
                        final Object d = f.d();
                        if (string != null && d != null) {
                            if (this.m(string) != null) {
                                throw new b("Duplicate key \"" + string + "\"");
                            }
                            this.a(string, d);
                        }
                        switch (f.c()) {
                            default: {
                                throw f.a("Expected a ',' or '}'");
                            }
                            case ',':
                            case ';': {
                                continue;
                            }
                            case '}': {
                                break Label_0024;
                            }
                        }
                        break;
                    }
                    case '\0': {
                        throw f.a("A JSONObject text must end with '}'");
                    }
                    case '}': {
                        break Label_0024;
                    }
                }
            } while (f.c() != '}');
        }
    }
    
    private c(final Object o) {
        int i = 0;
        this();
        final Class<?> class1 = o.getClass();
        int n;
        if (class1.getClassLoader() != null) {
            n = 1;
        }
        else {
            n = 0;
        }
        Method[] array;
        if (n != 0) {
            array = class1.getMethods();
        }
        else {
            array = class1.getDeclaredMethods();
            i = 0;
        }
        while (i < array.length) {
            while (true) {
                while (true) {
                    Label_0287: {
                        try {
                            final Method method = array[i];
                            if (!Modifier.isPublic(method.getModifiers())) {
                                break;
                            }
                            final String name = method.getName();
                            String s = "";
                            if (name.startsWith("get")) {
                                if ("getClass".equals(name)) {
                                    break Label_0287;
                                }
                                if ("getDeclaringClass".equals(name)) {
                                    break Label_0287;
                                }
                                s = name.substring(3);
                            }
                            else if (name.startsWith("is")) {
                                s = name.substring(2);
                            }
                            if (s.length() <= 0 || !Character.isUpperCase(s.charAt(0)) || method.getParameterTypes().length != 0) {
                                break;
                            }
                            if (s.length() == 1) {
                                s = s.toLowerCase();
                            }
                            else if (!Character.isUpperCase(s.charAt(1))) {
                                s = String.valueOf(s.substring(0, 1).toLowerCase()) + s.substring(1);
                            }
                            final Object invoke = method.invoke(o, (Object[])null);
                            if (invoke != null) {
                                this.b.put(s, b(invoke));
                                break;
                            }
                            break;
                        }
                        catch (Exception ex) {
                            break;
                        }
                    }
                    String s = "";
                    continue;
                }
            }
            ++i;
        }
    }
    
    public c(final String s) {
        this(new f(s));
    }
    
    public c(final Map map) {
        super();
        this.b = new HashMap();
        if (map != null) {
            for (final Map.Entry<K, Object> entry : map.entrySet()) {
                final Object value = entry.getValue();
                if (value != null) {
                    this.b.put(entry.getKey(), b(value));
                }
            }
        }
    }
    
    private Writer a(final Writer writer, final int n, final int n2) {
        while (true) {
            int b = 0;
            Iterator a;
            Object next;
            Object next2;
            int n3;
            int n4;
            Block_8_Outer:Label_0087_Outer:
            while (true) {
                while (true) {
                    Label_0216: {
                        try {
                            b = this.b();
                            a = this.a();
                            writer.write(123);
                            if (b == 1) {
                                next = a.next();
                                writer.write(n(next.toString()));
                                writer.write(58);
                                if (n > 0) {
                                    writer.write(32);
                                }
                                a(writer, this.b.get(next), n, n2);
                                writer.write(125);
                                return writer;
                            }
                            break Label_0216;
                            // iftrue(Label_0107:, n <= 0)
                            // iftrue(Label_0127:, a.hasNext())
                            while (true) {
                                Block_9: {
                                    while (true) {
                                        break Block_9;
                                        continue Label_0087_Outer;
                                    }
                                    a(writer, n2);
                                    continue Block_8_Outer;
                                }
                                writer.write(10);
                                continue;
                            }
                        }
                        catch (IOException ex) {
                            throw new b(ex);
                        }
                        Label_0127: {
                            next2 = a.next();
                        }
                        if (n3 != 0) {
                            writer.write(44);
                        }
                        if (n > 0) {
                            writer.write(10);
                        }
                        a(writer, n4);
                        writer.write(n(next2.toString()));
                        writer.write(58);
                        if (n > 0) {
                            writer.write(32);
                        }
                        a(writer, this.b.get(next2), n, n4);
                        n3 = 1;
                        continue;
                    }
                    if (b != 0) {
                        n4 = n2 + n;
                        n3 = 0;
                        continue;
                    }
                    break;
                }
                continue Label_0087_Outer;
            }
        }
    }
    
    static final Writer a(final Writer writer, final Object o, final int n, final int n2) {
        if (o == null || o.equals(null)) {
            writer.write("null");
            return writer;
        }
        if (o instanceof c) {
            ((c)o).a(writer, n, n2);
            return writer;
        }
        if (o instanceof a) {
            ((a)o).a(writer, n, n2);
            return writer;
        }
        if (o instanceof Map) {
            new c((Map)o).a(writer, n, n2);
            return writer;
        }
        if (o instanceof Collection) {
            new a((Collection)o).a(writer, n, n2);
            return writer;
        }
        if (o.getClass().isArray()) {
            new a(o).a(writer, n, n2);
            return writer;
        }
        if (o instanceof Number) {
            writer.write(a((Number)o));
            return writer;
        }
        if (o instanceof Boolean) {
            writer.write(o.toString());
            return writer;
        }
        if (!(o instanceof e)) {
            a(o.toString(), writer);
            return writer;
        }
        while (true) {
            while (true) {
                try {
                    final String a = ((e)o).a();
                    if (a != null) {
                        final String s = a.toString();
                        writer.write(s);
                        return writer;
                    }
                }
                catch (Exception ex) {
                    throw new b(ex);
                }
                final String s = n(o.toString());
                continue;
            }
        }
    }
    
    private static Writer a(final String s, final Writer writer) {
        int i = 0;
        if (s == null || s.length() == 0) {
            writer.write("\"\"");
            return writer;
        }
        final int length = s.length();
        writer.write(34);
        int n = 0;
    Label_0227_Outer:
        while (i < length) {
            final char char1 = s.charAt(i);
            while (true) {
                Label_0243: {
                    switch (char1) {
                        default: {
                            if (char1 < ' ' || (char1 >= '\u0080' && char1 < '?') || (char1 >= '\u2000' && char1 < '\u2100')) {
                                final String string = "000" + Integer.toHexString(char1);
                                writer.write("\\u" + string.substring(-4 + string.length()));
                                break;
                            }
                            break Label_0243;
                        }
                        case 34:
                        case 92: {
                            writer.write(92);
                            break Label_0243;
                        }
                        case 47: {
                            if (n == 60) {
                                writer.write(92);
                            }
                            writer.write(char1);
                            break;
                        }
                        case 8: {
                            writer.write("\\b");
                            break;
                        }
                        case 9: {
                            writer.write("\\t");
                            break;
                        }
                        case 10: {
                            writer.write("\\n");
                            break;
                        }
                        case 12: {
                            writer.write("\\f");
                            break;
                        }
                        case 13: {
                            writer.write("\\r");
                            break;
                        }
                    }
                    ++i;
                    n = char1;
                    continue Label_0227_Outer;
                }
                writer.write(char1);
                continue;
            }
        }
        writer.write(34);
        return writer;
    }
    
    private String a(final int n) {
        final StringWriter stringWriter = new StringWriter();
        synchronized (stringWriter.getBuffer()) {
            return this.a(stringWriter, 0, 0).toString();
        }
    }
    
    private static String a(final Number n) {
        if (n == null) {
            throw new b("Null pointer");
        }
        c(n);
        String s = n.toString();
        if (s.indexOf(46) > 0 && s.indexOf(101) < 0 && s.indexOf(69) < 0) {
            while (s.endsWith("0")) {
                s = s.substring(0, -1 + s.length());
            }
            if (s.endsWith(".")) {
                s = s.substring(0, -1 + s.length());
            }
        }
        return s;
    }
    
    public static String a(final Object o) {
        if (o == null || o.equals(null)) {
            return "null";
        }
        if (o instanceof e) {
            String a;
            try {
                a = ((e)o).a();
                if (a instanceof String) {
                    return a;
                }
            }
            catch (Exception ex) {
                throw new b(ex);
            }
            throw new b("Bad value from toJSONString: " + (Object)a);
        }
        if (o instanceof Number) {
            return a((Number)o);
        }
        if (o instanceof Boolean || o instanceof c || o instanceof a) {
            return o.toString();
        }
        if (o instanceof Map) {
            return new c((Map)o).toString();
        }
        if (o instanceof Collection) {
            return new a((Collection)o).toString();
        }
        if (o.getClass().isArray()) {
            return new a(o).toString();
        }
        return n(o.toString());
    }
    
    static final void a(final Writer writer, final int n) {
        for (int i = 0; i < n; ++i) {
            writer.write(32);
        }
    }
    
    public static Object b(Object o) {
        while (true) {
            if (o == null) {
            Label_0183_Outer:
                while (true) {
                Label_0183:
                    while (true) {
                        try {
                            return c.a;
                            Label_0218: {
                                return new c(o);
                            }
                            // iftrue(Label_0128:, !o instanceof Collection)
                            // iftrue(Label_0218:, !name.startsWith("java.") && !name.startsWith("javax.") && o.getClass().getClassLoader() != null)
                            // iftrue(Label_0147:, !o.getClass().isArray())
                            // iftrue(Label_0236:, package1 == null)
                            // iftrue(Label_0234:, o instanceof c || o instanceof a || c.a.equals(o) || o instanceof e || o instanceof Byte || o instanceof Character || o instanceof Short || o instanceof Integer || o instanceof Long || o instanceof Boolean || o instanceof Float || o instanceof Double || o instanceof String || o instanceof Enum)
                            while (true) {
                                return new a((Collection)o);
                                return o.toString();
                                Label_0128:
                                return new a(o);
                                while (true) {
                                    final Package package1;
                                    final String name = package1.getName();
                                    continue Label_0183;
                                    Label_0166:
                                    package1 = o.getClass().getPackage();
                                    continue;
                                }
                                continue Label_0183_Outer;
                            }
                            Label_0147:
                            // iftrue(Label_0166:, !o instanceof Map)
                            return new c((Map)o);
                        }
                        catch (Exception ex) {
                            o = null;
                        }
                        break;
                        Label_0236: {
                            final String name = "";
                        }
                        continue Label_0183;
                    }
                }
                Label_0234: {
                    return o;
                }
            }
            continue;
        }
    }
    
    private static void c(final Object o) {
        if (o != null) {
            if (o instanceof Double) {
                if (((Double)o).isInfinite() || ((Double)o).isNaN()) {
                    throw new b("JSON does not allow non-finite numbers.");
                }
            }
            else if (o instanceof Float && (((Float)o).isInfinite() || ((Float)o).isNaN())) {
                throw new b("JSON does not allow non-finite numbers.");
            }
        }
    }
    
    public static Object k(final String s) {
        if (!s.equals("")) {
            if (s.equalsIgnoreCase("true")) {
                return Boolean.TRUE;
            }
            if (s.equalsIgnoreCase("false")) {
                return Boolean.FALSE;
            }
            if (s.equalsIgnoreCase("null")) {
                return c.a;
            }
            final char char1 = s.charAt(0);
            if ((char1 < '0' || char1 > '9') && char1 != '.' && char1 != '-') {
                if (char1 != '+') {
                    return s;
                }
            }
            try {
                if (s.indexOf(46) >= 0 || s.indexOf(101) >= 0 || s.indexOf(69) >= 0) {
                    final Double value = Double.valueOf(s);
                    if (!value.isInfinite() && !value.isNaN()) {
                        return value;
                    }
                }
                else {
                    final Long n = new Long(s);
                    if (n == (int)(Object)n) {
                        return new Integer((int)(Object)n);
                    }
                    return n;
                }
            }
            catch (Exception ex) {
                return s;
            }
        }
        return s;
    }
    
    private Object l(final String s) {
        if (s == null) {
            throw new b("Null key.");
        }
        final Object m = this.m(s);
        if (m == null) {
            throw new b("JSONObject[" + n(s) + "] not found.");
        }
        return m;
    }
    
    private Object m(final String s) {
        if (s == null) {
            return null;
        }
        return this.b.get(s);
    }
    
    private static String n(final String s) {
        final StringWriter stringWriter = new StringWriter();
        synchronized (stringWriter.getBuffer()) {
            try {
                return a(s, stringWriter).toString();
            }
            catch (IOException ex) {
                return "";
            }
        }
    }
    
    public final c a(final String s, final Object o) {
        if (s == null) {
            throw new b("Null key.");
        }
        if (o != null) {
            c(o);
            this.b.put(s, o);
            return this;
        }
        this.b.remove(s);
        return this;
    }
    
    public final String a(final String s, final String s2) {
        final Object m = this.m(s);
        if (c.a.equals(m)) {
            return null;
        }
        return m.toString();
    }
    
    public final Iterator a() {
        return this.b.keySet().iterator();
    }
    
    public final boolean a(final String s) {
        final Object l = this.l(s);
        if (l.equals(Boolean.FALSE) || (l instanceof String && ((String)l).equalsIgnoreCase("false"))) {
            return false;
        }
        if (l.equals(Boolean.TRUE) || (l instanceof String && ((String)l).equalsIgnoreCase("true"))) {
            return true;
        }
        throw new b("JSONObject[" + n(s) + "] is not a Boolean.");
    }
    
    public final double b(final String s) {
        final Object l = this.l(s);
        try {
            if (l instanceof Number) {
                return ((Number)l).doubleValue();
            }
            return Double.parseDouble((String)l);
        }
        catch (Exception ex) {
            throw new b("JSONObject[" + n(s) + "] is not a number.");
        }
    }
    
    public final int b() {
        return this.b.size();
    }
    
    public final int c(final String s) {
        final Object l = this.l(s);
        try {
            if (l instanceof Number) {
                return ((Number)l).intValue();
            }
            return Integer.parseInt((String)l);
        }
        catch (Exception ex) {
            throw new b("JSONObject[" + n(s) + "] is not an int.");
        }
    }
    
    public final a c() {
        a a = new a();
        final Iterator a2 = this.a();
        while (a2.hasNext()) {
            a.a(a2.next());
        }
        if (a.a.size() == 0) {
            a = null;
        }
        return a;
    }
    
    public final a d(final String s) {
        final Object l = this.l(s);
        if (l instanceof a) {
            return (a)l;
        }
        throw new b("JSONObject[" + n(s) + "] is not a JSONArray.");
    }
    
    public final c e(final String s) {
        final Object l = this.l(s);
        if (l instanceof c) {
            return (c)l;
        }
        throw new b("JSONObject[" + n(s) + "] is not a JSONObject.");
    }
    
    public final long f(final String s) {
        final Object l = this.l(s);
        try {
            if (l instanceof Number) {
                return ((Number)l).longValue();
            }
            return Long.parseLong((String)l);
        }
        catch (Exception ex) {
            throw new b("JSONObject[" + n(s) + "] is not a long.");
        }
    }
    
    public final String g(final String s) {
        final Object l = this.l(s);
        if (l instanceof String) {
            return (String)l;
        }
        throw new b("JSONObject[" + n(s) + "] not a string.");
    }
    
    public final boolean h(final String s) {
        return this.b.containsKey(s);
    }
    
    public final a i(final String s) {
        final Object m = this.m(s);
        if (m instanceof a) {
            return (a)m;
        }
        return null;
    }
    
    public final c j(final String s) {
        final Object m = this.m(s);
        if (m instanceof c) {
            return (c)m;
        }
        return null;
    }
    
    @Override
    public final String toString() {
        try {
            return this.a(0);
        }
        catch (Exception ex) {
            return null;
        }
    }
}
