package a.a;

import java.io.IOException;
import java.io.StringReader;
import java.io.BufferedReader;
import java.io.Reader;

public final class f
{
    private long a;
    private boolean b;
    private long c;
    private long d;
    private char e;
    private Reader f;
    private boolean g;
    
    private f(Reader f) {
        super();
        if (!f.markSupported()) {
            f = new BufferedReader(f);
        }
        this.f = f;
        this.b = false;
        this.g = false;
        this.e = '\0';
        this.c = 0L;
        this.a = 1L;
        this.d = 1L;
    }
    
    public f(final String s) {
        this(new StringReader(s));
    }
    
    private String a(final int n) {
        final char[] array = new char[4];
        for (int i = 0; i < 4; ++i) {
            array[i] = this.b();
            int n2;
            if (this.b && !this.g) {
                n2 = 1;
            }
            else {
                n2 = 0;
            }
            if (n2 != 0) {
                throw this.a("Substring bounds error");
            }
        }
        return new String(array);
    }
    
    public final b a(final String s) {
        return new b(String.valueOf(s) + this.toString());
    }
    
    public final void a() {
        if (this.g || this.c <= 0L) {
            throw new b("Stepping back two steps is not supported");
        }
        --this.c;
        --this.a;
        this.g = true;
        this.b = false;
    }
    
    public final char b() {
        while (true) {
            Label_0107: {
                int n = 0;
                Label_0017: {
                    if (!this.g) {
                        try {
                            n = this.f.read();
                            if (n <= 0) {
                                this.b = true;
                                n = 0;
                            }
                            break Label_0017;
                        }
                        catch (IOException ex) {
                            throw new b(ex);
                        }
                        break Label_0107;
                    }
                    this.g = false;
                    n = this.e;
                }
                this.c += 1L;
                final int n2;
                if (this.e == '\r') {
                    this.d += 1L;
                    n2 = 0;
                    if (n != 10) {
                        break Label_0107;
                    }
                }
                else {
                    if (n == 10) {
                        this.d += 1L;
                        this.a = 0L;
                        return this.e = (char)n;
                    }
                    this.a += 1L;
                    return this.e = (char)n;
                }
                this.a = n2;
                return this.e = (char)n;
            }
            int n2 = 1;
            continue;
        }
    }
    
    public final char c() {
        char b;
        do {
            b = this.b();
        } while (b != '\0' && b <= ' ');
        return b;
    }
    
    public final Object d() {
        char c = this.c();
        switch (c) {
            default: {
                final StringBuffer sb = new StringBuffer();
                while (c >= ' ' && ",:]}/\\\"[{;=#".indexOf(c) < 0) {
                    sb.append(c);
                    c = this.b();
                }
                this.a();
                final String trim = sb.toString().trim();
                if ("".equals(trim)) {
                    throw this.a("Missing value");
                }
                return c.k(trim);
            }
            case 34:
            case 39: {
                final StringBuffer sb2 = new StringBuffer();
                while (true) {
                    final char b = this.b();
                    switch (b) {
                        default: {
                            if (b == c) {
                                return sb2.toString();
                            }
                            sb2.append(b);
                            continue;
                        }
                        case '\0':
                        case '\n':
                        case '\r': {
                            throw this.a("Unterminated string");
                        }
                        case '\\': {
                            final char b2 = this.b();
                            switch (b2) {
                                default: {
                                    throw this.a("Illegal escape.");
                                }
                                case 98: {
                                    sb2.append('\b');
                                    continue;
                                }
                                case 116: {
                                    sb2.append('\t');
                                    continue;
                                }
                                case 110: {
                                    sb2.append('\n');
                                    continue;
                                }
                                case 102: {
                                    sb2.append('\f');
                                    continue;
                                }
                                case 114: {
                                    sb2.append('\r');
                                    continue;
                                }
                                case 117: {
                                    sb2.append((char)Integer.parseInt(this.a(4), 16));
                                    continue;
                                }
                                case 34:
                                case 39:
                                case 47:
                                case 92: {
                                    sb2.append(b2);
                                    continue;
                                }
                            }
                            break;
                        }
                    }
                }
                break;
            }
            case 123: {
                this.a();
                return new c(this);
            }
            case 91: {
                this.a();
                return new a(this);
            }
        }
    }
    
    @Override
    public final String toString() {
        return " at " + this.c + " [character " + this.a + " line " + this.d + "]";
    }
}
