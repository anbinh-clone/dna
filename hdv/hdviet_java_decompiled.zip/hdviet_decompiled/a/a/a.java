package a.a;

import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;
import java.util.Collection;
import java.lang.reflect.Array;
import java.util.ArrayList;

public final class a
{
    public final ArrayList a;
    
    public a() {
        super();
        this.a = new ArrayList();
    }
    
    public a(final f f) {
        this();
        if (f.c() != '[') {
            throw f.a("A JSONArray text must start with '['");
        }
        Label_0131: {
            if (f.c() != ']') {
                f.a();
                while (true) {
                    if (f.c() == ',') {
                        f.a();
                        this.a.add(c.a);
                    }
                    else {
                        f.a();
                        this.a.add(f.d());
                    }
                    switch (f.c()) {
                        default: {
                            throw f.a("Expected a ',' or ']'");
                        }
                        case ',':
                        case ';': {
                            if (f.c() == ']') {
                                break Label_0131;
                            }
                            f.a();
                            continue;
                        }
                        case ']': {
                            break Label_0131;
                        }
                    }
                }
            }
        }
    }
    
    public a(final Object o) {
        this();
        if (o.getClass().isArray()) {
            for (int length = Array.getLength(o), i = 0; i < length; ++i) {
                this.a(c.b(Array.get(o, i)));
            }
            return;
        }
        throw new b("JSONArray initial value should be a string or collection or array.");
    }
    
    public a(final Collection collection) {
        super();
        this.a = new ArrayList();
        if (collection != null) {
            final Iterator<Object> iterator = collection.iterator();
            while (iterator.hasNext()) {
                this.a.add(c.b(iterator.next()));
            }
        }
    }
    
    private String a(final String s) {
        final int size = this.a.size();
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < size; ++i) {
            if (i > 0) {
                sb.append(s);
            }
            sb.append(c.a(this.a.get(i)));
        }
        return sb.toString();
    }
    
    public final a a(final Object o) {
        this.a.add(o);
        return this;
    }
    
    final Writer a(final Writer writer, final int n, final int n2) {
        while (true) {
            int size = 0;
            int n3;
            int n4;
            int n5;
            Label_0061_Outer:Block_6_Outer:Label_0044_Outer:
            while (true) {
                while (true) {
                    Label_0134: {
                        try {
                            size = this.a.size();
                            writer.write(91);
                            if (size == 1) {
                                c.a(writer, this.a.get(0), n, n2);
                                writer.write(93);
                                return writer;
                            }
                            break Label_0134;
                            // iftrue(Label_0061:, n <= 0)
                            while (true) {
                                while (true) {
                                    c.a(writer, n2);
                                    continue Label_0061_Outer;
                                    writer.write(10);
                                    continue Block_6_Outer;
                                }
                                continue Label_0044_Outer;
                            }
                        }
                        // iftrue(Label_0081:, n3 < size)
                        catch (IOException ex) {
                            throw new b(ex);
                        }
                        Label_0081: {
                            if (n4 != 0) {
                                writer.write(44);
                            }
                        }
                        if (n > 0) {
                            writer.write(10);
                        }
                        c.a(writer, n5);
                        c.a(writer, this.a.get(n3), n, n5);
                        ++n3;
                        n4 = 1;
                        continue;
                    }
                    if (size != 0) {
                        n5 = n2 + n;
                        n3 = 0;
                        n4 = 0;
                        continue;
                    }
                    break;
                }
                continue Label_0044_Outer;
            }
        }
    }
    
    public final Object a(final int n) {
        Object value;
        if (n < 0 || n >= this.a.size()) {
            value = null;
        }
        else {
            value = this.a.get(n);
        }
        if (value == null) {
            throw new b("JSONArray[" + n + "] not found.");
        }
        return value;
    }
    
    public final c b(final int n) {
        final Object a = this.a(n);
        if (a instanceof c) {
            return (c)a;
        }
        throw new b("JSONArray[" + n + "] is not a JSONObject.");
    }
    
    public final String c(final int n) {
        final Object a = this.a(n);
        if (a instanceof String) {
            return (String)a;
        }
        throw new b("JSONArray[" + n + "] not a string.");
    }
    
    @Override
    public final String toString() {
        try {
            return String.valueOf('[') + this.a(",") + ']';
        }
        catch (Exception ex) {
            return null;
        }
    }
}
