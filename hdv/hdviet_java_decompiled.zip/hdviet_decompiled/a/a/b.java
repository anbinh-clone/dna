package a.a;

public final class b extends Exception
{
    private static final long serialVersionUID;
    private Throwable a;
    
    public b(final String s) {
        super(s);
    }
    
    public b(final Throwable a) {
        super(a.getMessage());
        this.a = a;
    }
    
    @Override
    public final Throwable getCause() {
        return this.a;
    }
}
