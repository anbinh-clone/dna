package a.a;

public interface e
{
    String a();
}
