package a.a;

final class d
{
    @Override
    protected final Object clone() {
        return this;
    }
    
    @Override
    public final boolean equals(final Object o) {
        return o == null || o == this;
    }
    
    @Override
    public final String toString() {
        return "null";
    }
}
