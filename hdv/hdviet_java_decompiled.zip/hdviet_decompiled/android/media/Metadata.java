package android.media;

import java.util.Calendar;
import java.util.TimeZone;
import java.util.Date;
import android.util.Log;
import java.util.Collections;
import android.os.Parcel;
import java.util.HashMap;
import java.util.Set;

public class Metadata
{
    public static final int ALBUM = 4;
    public static final int ALBUM_ART = 14;
    public static final int ANY = 0;
    public static final int ARTIST = 5;
    public static final int AUDIO_BIT_RATE = 18;
    public static final int AUDIO_CODEC = 23;
    public static final int AUDIO_SAMPLE_RATE = 20;
    public static final int AUTHOR = 6;
    public static final int BIT_RATE = 17;
    public static final int BOOLEAN_VAL = 3;
    public static final int BYTE_ARRAY_VAL = 8;
    public static final int CAPTION = 16;
    public static final int CD_TRACK_MAX = 12;
    public static final int CD_TRACK_NUM = 11;
    public static final int COMMENT = 2;
    public static final int COMPOSER = 7;
    public static final int COPYRIGHT = 3;
    public static final int DATE = 9;
    public static final int DATE_VAL = 7;
    public static final int DOUBLE_VAL = 5;
    public static final int DRM_CRIPPLED = 28;
    public static final int DURATION = 10;
    private static final int FIRST_CUSTOM = 8192;
    public static final int GENRE = 8;
    public static final int INTEGER_VAL = 2;
    private static final int LAST_SYSTEM = 32;
    private static final int LAST_TYPE = 8;
    public static final int LONG_VAL = 4;
    public static final Set MATCH_ALL;
    public static final Set MATCH_NONE;
    public static final int MIME_TYPE = 22;
    public static final int NUM_TRACKS = 27;
    public static final int PAUSE_AVAILABLE = 29;
    public static final int RATING = 13;
    public static final int SEEK_AVAILABLE = 32;
    public static final int SEEK_BACKWARD_AVAILABLE = 30;
    public static final int SEEK_FORWARD_AVAILABLE = 31;
    public static final int STRING_VAL = 1;
    private static final String TAG = "media.Metadata";
    public static final int TIMED_TEXT_VAL = 6;
    public static final int TITLE = 1;
    public static final int VIDEO_BIT_RATE = 19;
    public static final int VIDEO_CODEC = 24;
    public static final int VIDEO_FRAME = 15;
    public static final int VIDEO_FRAME_RATE = 21;
    public static final int VIDEO_HEIGHT = 25;
    public static final int VIDEO_WIDTH = 26;
    private static final int kInt32Size = 4;
    private static final int kMetaHeaderSize = 8;
    private static final int kMetaMarker = 1296389185;
    private static final int kRecordHeaderSize = 12;
    private final HashMap mKeyToPosMap;
    private Parcel mParcel;
    
    static {
        MATCH_NONE = Collections.EMPTY_SET;
        MATCH_ALL = Collections.singleton(0);
    }
    
    public Metadata() {
        super();
        this.mKeyToPosMap = new HashMap();
    }
    
    private boolean checkMetadataId(final int n) {
        if (n <= 0 || (32 < n && n < 8192)) {
            Log.e("media.Metadata", "Invalid metadata ID " + n);
            return false;
        }
        return true;
    }
    
    private void checkType(final int n, final int n2) {
        this.mParcel.setDataPosition((int)this.mKeyToPosMap.get(n));
        final int int1 = this.mParcel.readInt();
        if (int1 != n2) {
            return;
        }
        throw new IllegalStateException("Wrong type " + n2 + " but got " + int1);
    }
    
    public static int firstCustomId() {
        return 8192;
    }
    
    public static int lastSytemId() {
        return 32;
    }
    
    public static int lastType() {
        return 8;
    }
    
    private boolean scanAllRecords(final Parcel parcel, int i) {
        boolean b = true;
        this.mKeyToPosMap.clear();
        int n = 0;
        while (true) {
            while (i > 12) {
                final int dataPosition = parcel.dataPosition();
                final int int1 = parcel.readInt();
                int n2;
                if (int1 <= 12) {
                    Log.e("media.Metadata", "Record is too short");
                    n2 = (b ? 1 : 0);
                }
                else {
                    final int int2 = parcel.readInt();
                    if (!this.checkMetadataId(int2)) {
                        n2 = (b ? 1 : 0);
                    }
                    else if (this.mKeyToPosMap.containsKey(int2)) {
                        Log.e("media.Metadata", "Duplicate metadata ID found");
                        n2 = (b ? 1 : 0);
                    }
                    else {
                        this.mKeyToPosMap.put(int2, parcel.dataPosition());
                        final int int3 = parcel.readInt();
                        if (int3 > 0 && int3 <= 8) {
                            parcel.setDataPosition(dataPosition + int1);
                            i -= int1;
                            ++n;
                            continue;
                        }
                        Log.e("media.Metadata", "Invalid metadata type " + int3);
                        n2 = (b ? 1 : 0);
                    }
                }
                if (i != 0 || n2 != 0) {
                    Log.e("media.Metadata", "Ran out of data or error on record " + n);
                    this.mKeyToPosMap.clear();
                    b = false;
                }
                return b;
            }
            int n2 = 0;
            continue;
        }
    }
    
    public boolean getBoolean(final int n) {
        this.checkType(n, 3);
        return this.mParcel.readInt() == 1;
    }
    
    public byte[] getByteArray(final int n) {
        this.checkType(n, 8);
        return this.mParcel.createByteArray();
    }
    
    public Date getDate(final int n) {
        this.checkType(n, 7);
        final long long1 = this.mParcel.readLong();
        final String string = this.mParcel.readString();
        if (string.length() == 0) {
            return new Date(long1);
        }
        final Calendar instance = Calendar.getInstance(TimeZone.getTimeZone(string));
        instance.setTimeInMillis(long1);
        return instance.getTime();
    }
    
    public double getDouble(final int n) {
        this.checkType(n, 5);
        return this.mParcel.readDouble();
    }
    
    public int getInt(final int n) {
        this.checkType(n, 2);
        return this.mParcel.readInt();
    }
    
    public long getLong(final int n) {
        this.checkType(n, 4);
        return this.mParcel.readLong();
    }
    
    public String getString(final int n) {
        this.checkType(n, 1);
        return this.mParcel.readString();
    }
    
    public Metadata$TimedText getTimedText(final int n) {
        this.checkType(n, 6);
        return new Metadata$TimedText(this, new Date(this.mParcel.readLong()), this.mParcel.readInt(), this.mParcel.readString());
    }
    
    public boolean has(final int n) {
        if (!this.checkMetadataId(n)) {
            throw new IllegalArgumentException("Invalid key: " + n);
        }
        return this.mKeyToPosMap.containsKey(n);
    }
    
    public Set keySet() {
        return this.mKeyToPosMap.keySet();
    }
    
    public boolean parse(final Parcel mParcel) {
        if (mParcel.dataAvail() < 8) {
            Log.e("media.Metadata", "Not enough data " + mParcel.dataAvail());
            return false;
        }
        final int dataPosition = mParcel.dataPosition();
        final int int1 = mParcel.readInt();
        if (4 + mParcel.dataAvail() < int1 || int1 < 8) {
            Log.e("media.Metadata", "Bad size " + int1 + " avail " + mParcel.dataAvail() + " position " + dataPosition);
            mParcel.setDataPosition(dataPosition);
            return false;
        }
        final int int2 = mParcel.readInt();
        if (int2 != 1296389185) {
            Log.e("media.Metadata", "Marker missing " + Integer.toHexString(int2));
            mParcel.setDataPosition(dataPosition);
            return false;
        }
        if (!this.scanAllRecords(mParcel, int1 - 8)) {
            mParcel.setDataPosition(dataPosition);
            return false;
        }
        this.mParcel = mParcel;
        return true;
    }
}
