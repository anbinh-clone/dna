package com.hdvietnam.android.a;

import com.hdvietnam.android.video.I;
import java.util.ArrayList;

public final class p
{
    public String a;
    public String b;
    public String c;
    public int d;
    public ArrayList e;
    public ArrayList f;
    public int g;
    public String h;
    public String i;
    
    public p(final String a, final String h, final String s, final String b, final String c, final int g, final int d) {
        super();
        this.f = null;
        this.i = null;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = new ArrayList();
        this.f = new ArrayList();
        this.g = g;
        this.h = h;
        this.i = null;
    }
    
    public final void a(final String b, final String a) {
        final I i = new I();
        i.b = b;
        i.a = a;
        i.c = false;
        this.e.add(i);
    }
    
    public final void a(final String b, final String a, final String e, final int g) {
        final I i = new I();
        i.b = b;
        i.a = a;
        i.c = false;
        i.e = e;
        i.g = g;
        this.e.add(i);
    }
}
