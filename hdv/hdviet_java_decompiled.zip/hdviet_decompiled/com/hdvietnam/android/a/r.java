package com.hdvietnam.android.a;

public final class r
{
    private static final int BLOCK_SIZE = 1;
    public static final int DECRYPT = 2;
    public static final int ENCRYPT = 1;
    public static final int UNINITIALIZED;
    public int a;
    private int[] b;
    private int c;
    private int d;
    private String e;
    
    public r() {
        super();
        this.b = new int[256];
        this.e = "RC4";
    }
    
    private void a(final byte[] array, int n, final int n2, final byte[] array2, int n3) {
        int n6;
        int n7;
        for (int i = 0; i < n2; ++i, n3 = n6, n = n7) {
            this.c = (0xFF & 1 + this.c);
            this.d = (0xFF & this.b[this.c] + this.d);
            final int n4 = this.b[this.c];
            this.b[this.c] = this.b[this.d];
            this.b[this.d] = n4;
            final int n5 = 0xFF & this.b[this.c] + this.b[this.d];
            n6 = n3 + 1;
            n7 = n + 1;
            array2[n3] = (byte)(0xFF & (array[n] ^ this.b[n5]));
        }
    }
    
    public void a(final byte[] array) {
        int i = 0;
        if (array == null) {
            throw new j(String.valueOf(this.e) + ": Null user key");
        }
        final int length = array.length;
        if (length == 0) {
            throw new j(String.valueOf(this.e) + ": Invalid user key length");
        }
        this.d = 0;
        this.c = 0;
        for (int j = 0; j < 256; ++j) {
            this.b[j] = j;
        }
        int n = 0;
        int n2 = 0;
        while (i < 256) {
            n = (0xFF & n + ((0xFF & array[n2]) + this.b[i]));
            final int n3 = this.b[i];
            this.b[i] = this.b[n];
            this.b[n] = n3;
            n2 = (n2 + 1) % length;
            ++i;
        }
    }
    
    public final byte[] b(final byte[] array) {
        final byte[] array2 = new byte[array.length];
        final int length = array.length;
        if (length < 0) {
            throw new IllegalArgumentException("inLen < 0");
        }
        final int a = this.a;
        byte[] array3;
        if (array == array2 && (length + 0 > 0 || length + 0 > 0)) {
            array3 = new byte[length];
            System.arraycopy(array, 0, array3, 0, length);
        }
        else {
            array3 = array;
        }
        this.a(array3, 0, length, array2, 0);
        return array2;
    }
    
    public final Object clone() {
        throw new CloneNotSupportedException();
    }
}
