package com.hdvietnam.android.a;

import java.util.ArrayList;
import com.hdvietnam.android.b.a;

final class b implements Runnable
{
    @Override
    public final void run() {
        if (a.g != null) {
            for (int i = 0; i < a.g.size(); ++i) {
                new a((String)a.g.get(i)).a();
            }
        }
        final ArrayList h = a.h;
        int j = 0;
        if (h != null) {
            while (j < a.h.size()) {
                new a((String)a.h.get(j)).a();
                ++j;
            }
        }
    }
}
