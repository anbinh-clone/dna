package com.hdvietnam.android.a;

final class n
{
    int[] a;
    long b;
    byte[] c;
    
    public n() {
        super();
        this.c = new byte[64];
        this.b = 0L;
        (this.a = new int[4])[0] = 1732584193;
        this.a[1] = -271733879;
        this.a[2] = -1732584194;
        this.a[3] = 271733878;
    }
    
    public n(final n n) {
        this();
        int n2 = 0;
        int i;
        while (true) {
            final int length = this.c.length;
            i = 0;
            if (n2 >= length) {
                break;
            }
            this.c[n2] = n.c[n2];
            ++n2;
        }
        while (i < this.a.length) {
            this.a[i] = n.a[i];
            ++i;
        }
        this.b = n.b;
    }
}
