package com.hdvietnam.android.a;

public final class j extends Exception
{
    public j() {
        super();
    }
    
    public j(final String s) {
        super(s);
    }
}
