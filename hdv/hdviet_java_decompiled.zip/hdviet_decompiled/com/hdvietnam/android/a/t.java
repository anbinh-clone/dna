package com.hdvietnam.android.a;

import android.content.SharedPreferences;
import android.content.Context;
import java.util.ArrayList;

public final class t
{
    public int a;
    public String b;
    public int c;
    public int d;
    public ArrayList e;
    public Context f;
    
    public t(final Context f, final int a, final String b) {
        super();
        this.f = f;
        this.a = a;
        this.b = b;
        this.c = 1;
        this.d = 0;
        this.e = new ArrayList();
    }
    
    public final int a(final int n, final String s, final String s2) {
        if (this.a == Integer.parseInt(s) && s2.equals(this.b)) {
            for (int i = 0; i < this.e.size(); ++i) {
                final s s3 = this.e.get(i);
                if (s3.a == n) {
                    this.d = s3.b;
                    this.c = n;
                    this.d -= 90000;
                    if (this.d < 0) {
                        this.d = 0;
                    }
                    return this.d;
                }
            }
        }
        final SharedPreferences sharedPreferences = this.f.getSharedPreferences("Movie_" + (String.valueOf(this.a) + "_" + this.b), 0);
        this.c = n;
        this.d = sharedPreferences.getInt("Seek_" + this.c, 0);
        this.d -= 90000;
        if (this.d < 0) {
            this.d = 0;
        }
        return this.d;
    }
    
    public final void a() {
        final SharedPreferences sharedPreferences = this.f.getSharedPreferences("Movie_" + (String.valueOf(this.a) + "_" + this.b), 0);
        this.c = sharedPreferences.getInt("CurEp_", 1);
        this.d = sharedPreferences.getInt("Seek_" + this.c, 0);
        this.d -= 90000;
        if (this.d < 0) {
            this.d = 0;
        }
    }
}
