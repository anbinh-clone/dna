package com.hdvietnam.android.a;

public final class v
{
    public static final int DEFALT_SIZE_SUB = 6;
    public static final int MAX_ID_TV = 100;
    public static final int MAX_INCREASE_SIZE_SUB = 50;
    public static final int MIN_SIZE_SUB = 17;
    public static final String NAME_NOTE_WIDGET = "NameNoteWidget";
    public static final String NameBright = "Brightting";
    public static final String NameHD = "HD";
    public static final String NameSizeSub = "SizeSub";
    public static final String NameVolumeLevel = "VolumeLevel";
    public static final String PREFS_NAME = "MyPrefsFile";
    public static final String PRE_CUR_EP_NAME = "CurEp_";
    public static final String PRE_MOVIE_NAME = "Movie_";
    public static final String PRE_SEEK_NAME = "Seek_";
    public static final int SCREEN_ORIENTATION_SENSOR_LANDSCAPE = 6;
    public static final boolean USE_DEBUG = false;
    public static final boolean USE_DEBUG_TEMP = false;
    public static final String WIDGETS_NAME = "MyWidget";
    public static boolean a;
    public static String b;
    public static float c;
    public static int d;
    public static int e;
    public static int f;
    public static boolean g;
    public static boolean h;
    
    static {
        v.a = false;
        v.b = "software";
        v.h = false;
    }
    
    public static void a() {
    }
}
