package com.hdvietnam.android.a;

public final class m
{
    private static final char[] a;
    private static final byte[] d;
    private n b;
    private n c;
    
    static {
        a = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
        final byte[] d2 = new byte[64];
        d2[0] = Byte.MIN_VALUE;
        d = d2;
    }
    
    private m(final byte[] array) {
        super();
        this.b = new n();
        this.c = null;
        if (array != null) {
            this.a(this.b = new n(), array, 0, array.length);
        }
    }
    
    public static String a(final String s) {
        System.out.println("VALUE OF e.a() " + e.a());
        System.out.println("VALUE OF e.b() " + e.b());
        return a(new m((String.valueOf(s) + e.a()).getBytes()).a());
    }
    
    private static String a(final byte[] array) {
        System.out.println("CALLE ME 1");
        int n = 0;
        final char[] array2 = new char[2 * array.length];
        for (int i = 0; i < array.length; ++i) {
            final int n2 = n + 1;
            array2[n] = m.a[0xF & array[i] >>> 4];
            n = n2 + 1;
            array2[n2] = m.a[0xF & array[i]];
        }
        return new String(array2);
    }
    
    private final void a(final n n, final byte[] array, final int n2, int n3) {
         System.out.println("CALLE ME 2");
        this.c = null;
        if (n3 + 0 > array.length) {
            n3 = 0 + array.length;
        }
        int n4 = (int)(0x3FL & n.b);
        n.b += n3;
        int n5 = 64 - n4;
        int n6 = 0;
        if (n3 >= n5) {
            final int[] array2 = new int[16];
            if (n5 == 64) {
                n5 = 0;
            }
            else {
                for (int i = 0; i < n5; ++i) {
                    n.c[i + n4] = array[i + 0];
                }
                this.a(n, n.c, 0, array2);
            }
            while (n5 + 63 < n3) {
                this.a(n, array, n5 + 0, array2);
                n5 += 64;
            }
            n4 = 0;
            n6 = n5;
        }
        if (n6 < n3) {
            for (int j = n6; j < n3; ++j) {
                n.c[n4 + j - n6] = array[j + 0];
            }
        }
    }
    
    private final void a(final n n, final byte[] array, final int n2, final int[] array2) {
         System.out.println("CALLE ME 3");
        final int n3 = n.a[0];
        final int n4 = n.a[1];
        final int n5 = n.a[2];
        final int n6 = n.a[3];
        array2[0] = ((0xFF & array[n2]) | (0xFF & array[n2 + 1]) << 8 | (0xFF & array[n2 + 2]) << 16 | array[n2 + 3] << 24);
        array2[1] = ((0xFF & array[n2 + 4]) | (0xFF & array[n2 + 5]) << 8 | (0xFF & array[n2 + 6]) << 16 | array[n2 + 7] << 24);
        array2[2] = ((0xFF & array[n2 + 8]) | (0xFF & array[n2 + 9]) << 8 | (0xFF & array[n2 + 10]) << 16 | array[n2 + 11] << 24);
        array2[3] = ((0xFF & array[n2 + 12]) | (0xFF & array[n2 + 13]) << 8 | (0xFF & array[n2 + 14]) << 16 | array[n2 + 15] << 24);
        array2[4] = ((0xFF & array[n2 + 16]) | (0xFF & array[n2 + 17]) << 8 | (0xFF & array[n2 + 18]) << 16 | array[n2 + 19] << 24);
        array2[5] = ((0xFF & array[n2 + 20]) | (0xFF & array[n2 + 21]) << 8 | (0xFF & array[n2 + 22]) << 16 | array[n2 + 23] << 24);
        array2[6] = ((0xFF & array[n2 + 24]) | (0xFF & array[n2 + 25]) << 8 | (0xFF & array[n2 + 26]) << 16 | array[n2 + 27] << 24);
        array2[7] = ((0xFF & array[n2 + 28]) | (0xFF & array[n2 + 29]) << 8 | (0xFF & array[n2 + 30]) << 16 | array[n2 + 31] << 24);
        array2[8] = ((0xFF & array[n2 + 32]) | (0xFF & array[n2 + 33]) << 8 | (0xFF & array[n2 + 34]) << 16 | array[n2 + 35] << 24);
        array2[9] = ((0xFF & array[n2 + 36]) | (0xFF & array[n2 + 37]) << 8 | (0xFF & array[n2 + 38]) << 16 | array[n2 + 39] << 24);
        array2[10] = ((0xFF & array[n2 + 40]) | (0xFF & array[n2 + 41]) << 8 | (0xFF & array[n2 + 42]) << 16 | array[n2 + 43] << 24);
        array2[11] = ((0xFF & array[n2 + 44]) | (0xFF & array[n2 + 45]) << 8 | (0xFF & array[n2 + 46]) << 16 | array[n2 + 47] << 24);
        array2[12] = ((0xFF & array[n2 + 48]) | (0xFF & array[n2 + 49]) << 8 | (0xFF & array[n2 + 50]) << 16 | array[n2 + 51] << 24);
        array2[13] = ((0xFF & array[n2 + 52]) | (0xFF & array[n2 + 53]) << 8 | (0xFF & array[n2 + 54]) << 16 | array[n2 + 55] << 24);
        array2[14] = ((0xFF & array[n2 + 56]) | (0xFF & array[n2 + 57]) << 8 | (0xFF & array[n2 + 58]) << 16 | array[n2 + 59] << 24);
        array2[15] = ((0xFF & array[n2 + 60]) | (0xFF & array[n2 + 61]) << 8 | (0xFF & array[n2 + 62]) << 16 | array[n2 + 63] << 24);
        final int n7 = n3 + (-680876936 + (((n4 & n5) | (n6 & (n4 ^ -1))) + array2[0]));
        final int n8 = n4 + (n7 << 7 | n7 >>> 25);
        final int n9 = n6 + (-389564586 + (((n8 & n4) | (n5 & (n8 ^ -1))) + array2[1]));
        final int n10 = n8 + (n9 << 12 | n9 >>> 20);
        final int n11 = n5 + (606105819 + (((n10 & n8) | (n4 & (n10 ^ -1))) + array2[2]));
        final int n12 = n10 + (n11 << 17 | n11 >>> 15);
        final int n13 = n4 + (-1044525330 + (((n12 & n10) | (n8 & (n12 ^ -1))) + array2[3]));
        final int n14 = n12 + (n13 << 22 | n13 >>> 10);
        final int n15 = n8 + (-176418897 + (((n14 & n12) | (n10 & (n14 ^ -1))) + array2[4]));
        final int n16 = n14 + (n15 << 7 | n15 >>> 25);
        final int n17 = n10 + (1200080426 + (((n16 & n14) | (n12 & (n16 ^ -1))) + array2[5]));
        final int n18 = n16 + (n17 << 12 | n17 >>> 20);
        final int n19 = n12 + (-1473231341 + (((n18 & n16) | (n14 & (n18 ^ -1))) + array2[6]));
        final int n20 = n18 + (n19 << 17 | n19 >>> 15);
        final int n21 = n14 + (-45705983 + (((n20 & n18) | (n16 & (n20 ^ -1))) + array2[7]));
        final int n22 = n20 + (n21 << 22 | n21 >>> 10);
        final int n23 = n16 + (1770035416 + (((n22 & n20) | (n18 & (n22 ^ -1))) + array2[8]));
        final int n24 = n22 + (n23 << 7 | n23 >>> 25);
        final int n25 = n18 + (-1958414417 + (((n24 & n22) | (n20 & (n24 ^ -1))) + array2[9]));
        final int n26 = n24 + (n25 << 12 | n25 >>> 20);
        final int n27 = n20 + (-42063 + (((n26 & n24) | (n22 & (n26 ^ -1))) + array2[10]));
        final int n28 = n26 + (n27 << 17 | n27 >>> 15);
        final int n29 = n22 + (-1990404162 + (((n28 & n26) | (n24 & (n28 ^ -1))) + array2[11]));
        final int n30 = n28 + (n29 << 22 | n29 >>> 10);
        final int n31 = n24 + (1804603682 + (((n30 & n28) | (n26 & (n30 ^ -1))) + array2[12]));
        final int n32 = n30 + (n31 << 7 | n31 >>> 25);
        final int n33 = n26 + (-40341101 + (((n32 & n30) | (n28 & (n32 ^ -1))) + array2[13]));
        final int n34 = n32 + (n33 << 12 | n33 >>> 20);
        final int n35 = n28 + (-1502002290 + (((n34 & n32) | (n30 & (n34 ^ -1))) + array2[14]));
        final int n36 = n34 + (n35 << 17 | n35 >>> 15);
        final int n37 = n30 + (1236535329 + (((n36 & n34) | (n32 & (n36 ^ -1))) + array2[15]));
        final int n38 = n36 + (n37 << 22 | n37 >>> 10);
        final int n39 = n32 + (-165796510 + (((n38 & n34) | (n36 & (n34 ^ -1))) + array2[1]));
        final int n40 = n38 + (n39 << 5 | n39 >>> 27);
        final int n41 = n34 + (-1069501632 + (((n40 & n36) | (n38 & (n36 ^ -1))) + array2[6]));
        final int n42 = n40 + (n41 << 9 | n41 >>> 23);
        final int n43 = n36 + (643717713 + (((n42 & n38) | (n40 & (n38 ^ -1))) + array2[11]));
        final int n44 = n42 + (n43 << 14 | n43 >>> 18);
        final int n45 = n38 + (-373897302 + (((n44 & n40) | (n42 & (n40 ^ -1))) + array2[0]));
        final int n46 = n44 + (n45 << 20 | n45 >>> 12);
        final int n47 = n40 + (-701558691 + (((n46 & n42) | (n44 & (n42 ^ -1))) + array2[5]));
        final int n48 = n46 + (n47 << 5 | n47 >>> 27);
        final int n49 = n42 + (38016083 + (((n48 & n44) | (n46 & (n44 ^ -1))) + array2[10]));
        final int n50 = n48 + (n49 << 9 | n49 >>> 23);
        final int n51 = n44 + (-660478335 + (((n50 & n46) | (n48 & (n46 ^ -1))) + array2[15]));
        final int n52 = n50 + (n51 << 14 | n51 >>> 18);
        final int n53 = n46 + (-405537848 + (((n52 & n48) | (n50 & (n48 ^ -1))) + array2[4]));
        final int n54 = n52 + (n53 << 20 | n53 >>> 12);
        final int n55 = n48 + (568446438 + (((n54 & n50) | (n52 & (n50 ^ -1))) + array2[9]));
        final int n56 = n54 + (n55 << 5 | n55 >>> 27);
        final int n57 = n50 + (-1019803690 + (((n56 & n52) | (n54 & (n52 ^ -1))) + array2[14]));
        final int n58 = n56 + (n57 << 9 | n57 >>> 23);
        final int n59 = n52 + (-187363961 + (((n58 & n54) | (n56 & (n54 ^ -1))) + array2[3]));
        final int n60 = n58 + (n59 << 14 | n59 >>> 18);
        final int n61 = n54 + (1163531501 + (((n60 & n56) | (n58 & (n56 ^ -1))) + array2[8]));
        final int n62 = n60 + (n61 << 20 | n61 >>> 12);
        final int n63 = n56 + (-1444681467 + (((n62 & n58) | (n60 & (n58 ^ -1))) + array2[13]));
        final int n64 = n62 + (n63 << 5 | n63 >>> 27);
        final int n65 = n58 + (-51403784 + (((n64 & n60) | (n62 & (n60 ^ -1))) + array2[2]));
        final int n66 = n64 + (n65 << 9 | n65 >>> 23);
        final int n67 = n60 + (1735328473 + (((n66 & n62) | (n64 & (n62 ^ -1))) + array2[7]));
        final int n68 = n66 + (n67 << 14 | n67 >>> 18);
        final int n69 = n62 + (-1926607734 + (((n68 & n64) | (n66 & (n64 ^ -1))) + array2[12]));
        final int n70 = n68 + (n69 << 20 | n69 >>> 12);
        final int n71 = n64 + (-378558 + ((n66 ^ (n70 ^ n68)) + array2[5]));
        final int n72 = n70 + (n71 << 4 | n71 >>> 28);
        final int n73 = n66 + (-2022574463 + ((n68 ^ (n72 ^ n70)) + array2[8]));
        final int n74 = n72 + (n73 << 11 | n73 >>> 21);
        final int n75 = n68 + (1839030562 + ((n70 ^ (n74 ^ n72)) + array2[11]));
        final int n76 = n74 + (n75 << 16 | n75 >>> 16);
        final int n77 = n70 + (-35309556 + ((n72 ^ (n76 ^ n74)) + array2[14]));
        final int n78 = n76 + (n77 << 23 | n77 >>> 9);
        final int n79 = n72 + (-1530992060 + ((n74 ^ (n78 ^ n76)) + array2[1]));
        final int n80 = n78 + (n79 << 4 | n79 >>> 28);
        final int n81 = n74 + (1272893353 + ((n76 ^ (n80 ^ n78)) + array2[4]));
        final int n82 = n80 + (n81 << 11 | n81 >>> 21);
        final int n83 = n76 + (-155497632 + ((n78 ^ (n82 ^ n80)) + array2[7]));
        final int n84 = n82 + (n83 << 16 | n83 >>> 16);
        final int n85 = n78 + (-1094730640 + ((n80 ^ (n84 ^ n82)) + array2[10]));
        final int n86 = n84 + (n85 << 23 | n85 >>> 9);
        final int n87 = n80 + (681279174 + ((n82 ^ (n86 ^ n84)) + array2[13]));
        final int n88 = n86 + (n87 << 4 | n87 >>> 28);
        final int n89 = n82 + (-358537222 + ((n84 ^ (n88 ^ n86)) + array2[0]));
        final int n90 = n88 + (n89 << 11 | n89 >>> 21);
        final int n91 = n84 + (-722521979 + ((n86 ^ (n90 ^ n88)) + array2[3]));
        final int n92 = n90 + (n91 << 16 | n91 >>> 16);
        final int n93 = n86 + (76029189 + ((n88 ^ (n92 ^ n90)) + array2[6]));
        final int n94 = n92 + (n93 << 23 | n93 >>> 9);
        final int n95 = n88 + (-640364487 + ((n90 ^ (n94 ^ n92)) + array2[9]));
        final int n96 = n94 + (n95 << 4 | n95 >>> 28);
        final int n97 = n90 + (-421815835 + ((n92 ^ (n96 ^ n94)) + array2[12]));
        final int n98 = n96 + (n97 << 11 | n97 >>> 21);
        final int n99 = n92 + (530742520 + ((n94 ^ (n98 ^ n96)) + array2[15]));
        final int n100 = n98 + (n99 << 16 | n99 >>> 16);
        final int n101 = n94 + (-995338651 + ((n96 ^ (n100 ^ n98)) + array2[2]));
        final int n102 = n100 + (n101 << 23 | n101 >>> 9);
        final int n103 = n96 + (-198630844 + ((n100 ^ (n102 | (n98 ^ -1))) + array2[0]));
        final int n104 = n102 + (n103 << 6 | n103 >>> 26);
        final int n105 = n98 + (1126891415 + ((n102 ^ (n104 | (n100 ^ -1))) + array2[7]));
        final int n106 = n104 + (n105 << 10 | n105 >>> 22);
        final int n107 = n100 + (-1416354905 + ((n104 ^ (n106 | (n102 ^ -1))) + array2[14]));
        final int n108 = n106 + (n107 << 15 | n107 >>> 17);
        final int n109 = n102 + (-57434055 + ((n106 ^ (n108 | (n104 ^ -1))) + array2[5]));
        final int n110 = n108 + (n109 << 21 | n109 >>> 11);
        final int n111 = n104 + (1700485571 + ((n108 ^ (n110 | (n106 ^ -1))) + array2[12]));
        final int n112 = n110 + (n111 << 6 | n111 >>> 26);
        final int n113 = n106 + (-1894986606 + ((n110 ^ (n112 | (n108 ^ -1))) + array2[3]));
        final int n114 = n112 + (n113 << 10 | n113 >>> 22);
        final int n115 = n108 + (-1051523 + ((n112 ^ (n114 | (n110 ^ -1))) + array2[10]));
        final int n116 = n114 + (n115 << 15 | n115 >>> 17);
        final int n117 = n110 + (-2054922799 + ((n114 ^ (n116 | (n112 ^ -1))) + array2[1]));
        final int n118 = n116 + (n117 << 21 | n117 >>> 11);
        final int n119 = n112 + (1873313359 + ((n116 ^ (n118 | (n114 ^ -1))) + array2[8]));
        final int n120 = n118 + (n119 << 6 | n119 >>> 26);
        final int n121 = n114 + (-30611744 + ((n118 ^ (n120 | (n116 ^ -1))) + array2[15]));
        final int n122 = n120 + (n121 << 10 | n121 >>> 22);
        final int n123 = n116 + (-1560198380 + ((n120 ^ (n122 | (n118 ^ -1))) + array2[6]));
        final int n124 = n122 + (n123 << 15 | n123 >>> 17);
        final int n125 = n118 + (1309151649 + ((n122 ^ (n124 | (n120 ^ -1))) + array2[13]));
        final int n126 = n124 + (n125 << 21 | n125 >>> 11);
        final int n127 = n120 + (-145523070 + ((n124 ^ (n126 | (n122 ^ -1))) + array2[4]));
        final int n128 = n126 + (n127 << 6 | n127 >>> 26);
        final int n129 = n122 + (-1120210379 + ((n126 ^ (n128 | (n124 ^ -1))) + array2[11]));
        final int n130 = n128 + (n129 << 10 | n129 >>> 22);
        final int n131 = n124 + (718787259 + ((n128 ^ (n130 | (n126 ^ -1))) + array2[2]));
        final int n132 = n130 + (n131 << 15 | n131 >>> 17);
        final int n133 = n126 + (-343485551 + ((n130 ^ (n132 | (n128 ^ -1))) + array2[9]));
        final int n134 = n132 + (n133 << 21 | n133 >>> 11);
        final int[] a = n.a;
        a[0] += n128;
        final int[] a2 = n.a;
        a2[1] += n134;
        final int[] a3 = n.a;
        a3[2] += n132;
        final int[] a4 = n.a;
        a4[3] += n130;
        System.gc();
    }
    
    private byte[] a() {
         System.out.println("CALLE ME 4");
        synchronized (this) {
            if (this.c == null) {
                final n c = new n(this.b);
                final byte[] a = a(new int[] { (int)(c.b << 3), (int)(c.b >> 29) }, 8);
                final int n = (int)(0x3FL & c.b);
                int n2;
                if (n < 56) {
                    n2 = 56 - n;
                }
                else {
                    n2 = 120 - n;
                }
                this.a(c, m.d, 0, n2);
                this.a(c, a, 0, 8);
                this.c = c;
            }
            return a(this.c.a, 16);
        }
    }
    
    private static final byte[] a(final int[] array, final int n) {
         System.out.println("CALLE ME 5");
        final byte[] array2 = new byte[n];
        int i = 0;
        int n2 = 0;
        while (i < n) {
            array2[i] = (byte)(0xFF & array[n2]);
            array2[i + 1] = (byte)(0xFF & array[n2] >>> 8);
            array2[i + 2] = (byte)(0xFF & array[n2] >>> 16);
            array2[i + 3] = (byte)(0xFF & array[n2] >>> 24);
            ++n2;
            i += 4;
        }
        return array2;
    }
}
