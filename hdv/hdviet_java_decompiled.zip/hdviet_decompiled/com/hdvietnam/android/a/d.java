package com.hdvietnam.android.a;

import java.io.IOException;
import java.net.MalformedURLException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import a.a.c;
import com.hdvietnam.android.b.a;
import java.util.Date;
import java.util.ArrayList;

public final class d
{
    private static String A;
    private static String B;
    private static String C;
    private static String D;
    private static String E;
    private static String F;
    private static String G;
    private static ArrayList H;
    private static String I;
    private static String J;
    private static String K;
    private static String L;
    private static String M;
    private static String N;
    private static String O;
    private static String P;
    private static String Q;
    private static String R;
    private static String S;
    private static String T;
    private static String U;
    private static final boolean USE_DEBUG;
    private static String V;
    private static String W;
    private static String X;
    private static String Y;
    private static String Z;
    public static int a;
    private static String aA;
    private static String aB;
    private static String aC;
    private static String aD;
    private static String aE;
    private static String aF;
    private static String aG;
    private static String aH;
    private static String aI;
    private static String aJ;
    private static String aK;
    private static String aL;
    private static String aM;
    private static String aN;
    private static String aO;
    private static String aP;
    private static String aQ;
    private static String aR;
    private static String aS;
    private static String aT;
    private static String aU;
    private static String aV;
    private static String aW;
    private static String aX;
    private static String aY;
    private static String aZ;
    private static String aa;
    private static String ab;
    private static String ac;
    private static String ad;
    private static boolean ae;
    private static String af;
    private static String ag;
    private static String ah;
    private static String ai;
    private static String aj;
    private static String ak;
    private static String al;
    private static String am;
    private static String an;
    private static String ao;
    private static String ap;
    private static String aq;
    private static String ar;
    private static String as;
    private static String at;
    private static String au;
    private static String av;
    private static String aw;
    private static String ax;
    private static String ay;
    private static String az;
    public static String b;
    private static String ba;
    private static String bb;
    private static String bc;
    private static String bd;
    private static String be;
    public static int c;
    public static String d;
    public static int e;
    public static String f;
    public static int g;
    public static String h;
    public static int i;
    public static String j;
    public static String k;
    public static String l;
    public static String m;
    public static String n;
    public static String o;
    public static String p;
    public static String q;
    public static ArrayList r;
    public static int s;
    public static l t;
    public static ArrayList u;
    public static ArrayList v;
    public static h w;
    public static p x;
    private static String y;
    private static String z;
    
    static {
        d.a = 0;
        d.b = null;
        d.c = 0;
        d.d = null;
        d.e = 0;
        d.f = null;
        d.g = 0;
        d.h = null;
        d.i = 0;
        d.j = null;
        d.y = "e";
        d.z = "r";
        d.k = "system/logout";
        d.l = "hdviet://";
        d.m = "http://m.movies.";
        d.n = "http://m.tv.";
        d.o = "/tim-kiem.html?key=";
        d.p = "/dang-nhap.html";
        d.A = "width=";
        d.q = "UID";
        d.B = "osversion=";
        d.C = "https://api.hdviet.com/config.txt";
        d.r = new ArrayList();
        d.D = "https://api.hdviet.com/user/getuseritem?";
        d.E = "dc=";
        d.F = "UserItemID";
        d.G = "ItemID";
        d.H = new ArrayList();
        d.I = "https://api.hdviet.com/config?";
        d.J = "2.1.6";
        d.K = "version=";
        d.L = "2.1.6";
        d.M = "isGP=";
        d.N = "sign=";
        d.O = "Category";
        d.P = "Subtitles";
        d.Q = "Episode";
        d.R = "Episodes";
        d.S = "Profile";
        d.T = "Movies";
        d.U = "TV";
        d.V = "Channels";
        d.W = "SignOut";
        d.X = "Exit";
        d.Y = "ConfirmSignOut";
        d.Z = "ConfirmExit";
        d.aa = "WapLink";
        d.ab = "ChannelLink";
        d.ac = "LogLink";
        d.ad = "AdverLink";
        d.s = 92;
        d.ae = false;
        d.af = "Adver";
        d.ag = "DropboxBanner";
        d.ah = "Preroll";
        d.ai = "Midroll";
        d.aj = "Duration";
        d.ak = "Link";
        d.al = "Frequency";
        d.am = "CountView";
        d.an = "MaxFaile";
        d.ao = "TimeOut";
        d.t = null;
        d.ap = "https://api.hdviet.com/category?";
        d.aq = "CategoryID";
        d.ar = "CategoryMap";
        d.as = "CategoryName";
        d.at = "CategoryOrder";
        d.au = "CategoryLink";
        d.u = null;
        d.av = "https://api.hdviet.com/channel?";
        d.aw = "ChannelName";
        d.ax = "ChannelImage";
        d.ay = "ChannelID";
        d.v = null;
        d.w = null;
        d.az = "https://api.hdviet.com/movie/play?";
        d.aA = "movieid=";
        d.aB = "accesstokenkey=";
        d.aC = "ep=";
        d.aD = "ua=";
        d.aE = "MovieName";
        d.aF = "LinkPlay";
        d.aG = "LinkPlayBackup";
        d.aH = "Subtitle";
        d.aI = "SubtitleExt";
        d.aJ = "SubtitleExtSe";
        d.aK = "ENG";
        d.aL = "VIE";
        d.aM = "Episode";
        d.aN = "Adver";
        d.aO = "Label";
        d.aP = "Source";
        d.aQ = "Source";
        d.aR = "Time";
        d.aS = "Link";
        d.aT = "S3";
        d.aU = "S4";
        d.aV = "Message";
        d.x = null;
        d.aW = "http://logs-staging.vn-hd.com/logs.php?";
        d.aX = "userid=";
        d.aY = "uniqueid=";
        d.aZ = "manufacture=";
        d.ba = "model=";
        d.bb = "systemversion=";
        d.bc = "mcc=";
        d.bd = "mnc=";
        d.be = "time=";
    }
    
    public static int a(final int p0, final String p1, final int p2, final int p3) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: new             Ljava/lang/StringBuilder;
        //     3: dup            
        //     4: getstatic       com/hdvietnam/android/a/e.b:Ljava/lang/String;
        //     7: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    10: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    13: iload_0        
        //    14: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    17: ldc_w           "&"
        //    20: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    23: getstatic       com/hdvietnam/android/a/e.c:Ljava/lang/String;
        //    26: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    29: aload_1        
        //    30: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    33: ldc_w           "&"
        //    36: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    39: getstatic       com/hdvietnam/android/a/d.A:Ljava/lang/String;
        //    42: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    45: iload_2        
        //    46: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    49: ldc_w           "&"
        //    52: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    55: getstatic       com/hdvietnam/android/a/d.B:Ljava/lang/String;
        //    58: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    61: iload_3        
        //    62: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    65: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    68: astore          4
        //    70: aload           4
        //    72: invokestatic    com/hdvietnam/android/a/f.a:(Ljava/lang/String;)Ljava/lang/String;
        //    75: invokestatic    com/hdvietnam/android/a/m.a:(Ljava/lang/String;)Ljava/lang/String;
        //    78: astore          5
        //    80: new             Lcom/hdvietnam/android/b/a;
        //    83: dup            
        //    84: new             Ljava/lang/StringBuilder;
        //    87: dup            
        //    88: getstatic       com/hdvietnam/android/a/e.a:Ljava/lang/String;
        //    91: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    94: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    97: aload           4
        //    99: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   102: ldc_w           "&"
        //   105: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   108: getstatic       com/hdvietnam/android/a/d.N:Ljava/lang/String;
        //   111: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   114: aload           5
        //   116: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   119: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   122: invokespecial   com/hdvietnam/android/b/a.<init>:(Ljava/lang/String;)V
        //   125: invokevirtual   com/hdvietnam/android/b/a.a:()Ljava/lang/String;
        //   128: astore          6
        //   130: new             La/a/c;
        //   133: dup            
        //   134: aload           6
        //   136: invokespecial   a/a/c.<init>:(Ljava/lang/String;)V
        //   139: astore          7
        //   141: aload           7
        //   143: getstatic       com/hdvietnam/android/a/d.y:Ljava/lang/String;
        //   146: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   149: istore          9
        //   151: iload           9
        //   153: ifeq            170
        //   156: aload           7
        //   158: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   161: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   164: putstatic       com/hdvietnam/android/a/d.j:Ljava/lang/String;
        //   167: iload           9
        //   169: ireturn        
        //   170: aload           7
        //   172: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   175: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   178: astore          10
        //   180: aload           10
        //   182: getstatic       com/hdvietnam/android/a/d.aw:Ljava/lang/String;
        //   185: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   188: astore          11
        //   190: aload           10
        //   192: getstatic       com/hdvietnam/android/a/d.ax:Ljava/lang/String;
        //   195: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   198: astore          12
        //   200: aload           10
        //   202: getstatic       com/hdvietnam/android/a/e.d:Ljava/lang/String;
        //   205: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   208: astore          13
        //   210: aload           13
        //   212: astore          14
        //   214: aload           10
        //   216: getstatic       com/hdvietnam/android/a/e.e:Ljava/lang/String;
        //   219: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   222: astore          17
        //   224: aload           17
        //   226: astore          16
        //   228: aload           14
        //   230: ldc_w           "?DVR"
        //   233: invokevirtual   java/lang/String.indexOf:(Ljava/lang/String;)I
        //   236: ifle            255
        //   239: aload           14
        //   241: iconst_0       
        //   242: bipush          -4
        //   244: aload           14
        //   246: invokevirtual   java/lang/String.length:()I
        //   249: iadd           
        //   250: invokevirtual   java/lang/String.substring:(II)Ljava/lang/String;
        //   253: astore          14
        //   255: aload           16
        //   257: ifnull          287
        //   260: aload           16
        //   262: ldc_w           "?DVR"
        //   265: invokevirtual   java/lang/String.indexOf:(Ljava/lang/String;)I
        //   268: ifle            287
        //   271: aload           14
        //   273: iconst_0       
        //   274: bipush          -4
        //   276: aload           14
        //   278: invokevirtual   java/lang/String.length:()I
        //   281: iadd           
        //   282: invokevirtual   java/lang/String.substring:(II)Ljava/lang/String;
        //   285: astore          16
        //   287: new             Lcom/hdvietnam/android/a/h;
        //   290: dup            
        //   291: iload_0        
        //   292: aload           11
        //   294: aload           12
        //   296: aload           14
        //   298: aload           16
        //   300: invokespecial   com/hdvietnam/android/a/h.<init>:(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   303: putstatic       com/hdvietnam/android/a/d.w:Lcom/hdvietnam/android/a/h;
        //   306: iconst_0       
        //   307: ireturn        
        //   308: astore          8
        //   310: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //   313: new             Ljava/lang/StringBuilder;
        //   316: dup            
        //   317: ldc_w           "Ex GetChannelPlay::"
        //   320: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   323: aload           8
        //   325: invokevirtual   java/lang/Exception.toString:()Ljava/lang/String;
        //   328: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   331: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   334: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   337: iconst_m1      
        //   338: ireturn        
        //   339: astore          15
        //   341: aconst_null    
        //   342: astore          16
        //   344: goto            228
        //   347: astore          18
        //   349: iload           9
        //   351: ireturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  130    151    308    339    Ljava/lang/Exception;
        //  156    167    347    352    Ljava/lang/Exception;
        //  170    210    308    339    Ljava/lang/Exception;
        //  214    224    339    347    Ljava/lang/Exception;
        //  228    255    308    339    Ljava/lang/Exception;
        //  260    287    308    339    Ljava/lang/Exception;
        //  287    306    308    339    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0170:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: new             Ljava/lang/StringBuilder;
        //     3: dup            
        //     4: getstatic       com/hdvietnam/android/a/e.b:Ljava/lang/String;
        //     7: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    10: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    13: iload_0        
        //    14: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    17: ldc_w           "&"
        //    20: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    23: getstatic       com/hdvietnam/android/a/e.c:Ljava/lang/String;
        //    26: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    29: aload_1        
        //    30: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    33: ldc_w           "&"
        //    36: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    39: getstatic       com/hdvietnam/android/a/d.A:Ljava/lang/String;
        //    42: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    45: iload_2        
        //    46: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    49: ldc_w           "&"
        //    52: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    55: getstatic       com/hdvietnam/android/a/d.B:Ljava/lang/String;
        //    58: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    61: iload_3        
        //    62: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    65: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    68: astore          4
        //    70: aload           4
        //    72: invokestatic    com/hdvietnam/android/a/f.a:(Ljava/lang/String;)Ljava/lang/String;
        //    75: invokestatic    com/hdvietnam/android/a/m.a:(Ljava/lang/String;)Ljava/lang/String;
        //    78: astore          5
        //    80: new             Lcom/hdvietnam/android/b/a;
        //    83: dup            
        //    84: new             Ljava/lang/StringBuilder;
        //    87: dup            
        //    88: getstatic       com/hdvietnam/android/a/e.a:Ljava/lang/String;
        //    91: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    94: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    97: aload           4
        //    99: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   102: ldc_w           "&"
        //   105: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   108: getstatic       com/hdvietnam/android/a/d.N:Ljava/lang/String;
        //   111: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   114: aload           5
        //   116: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   119: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   122: invokespecial   com/hdvietnam/android/b/a.<init>:(Ljava/lang/String;)V
        //   125: invokevirtual   com/hdvietnam/android/b/a.a:()Ljava/lang/String;
        //   128: astore          6
        //   130: new             La/a/c;
        //   133: dup            
        //   134: aload           6
        //   136: invokespecial   a/a/c.<init>:(Ljava/lang/String;)V
        //   139: astore          7
        //   141: aload           7
        //   143: getstatic       com/hdvietnam/android/a/d.y:Ljava/lang/String;
        //   146: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   149: istore          9
        //   151: iload           9
        //   153: ifeq            170
        //   156: aload           7
        //   158: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   161: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   164: putstatic       com/hdvietnam/android/a/d.j:Ljava/lang/String;
        //   167: iload           9
        //   169: ireturn        
        //   170: aload           7
        //   172: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   175: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   178: astore          10
        //   180: aload           10
        //   182: getstatic       com/hdvietnam/android/a/d.aw:Ljava/lang/String;
        //   185: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   188: astore          11
        //   190: aload           10
        //   192: getstatic       com/hdvietnam/android/a/d.ax:Ljava/lang/String;
        //   195: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   198: astore          12
        //   200: aload           10
        //   202: getstatic       com/hdvietnam/android/a/e.d:Ljava/lang/String;
        //   205: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   208: astore          13
        //   210: aload           13
        //   212: astore          14
        //   214: aload           10
        //   216: getstatic       com/hdvietnam/android/a/e.e:Ljava/lang/String;
        //   219: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   222: astore          17
        //   224: aload           17
        //   226: astore          16
        //   228: aload           14
        //   230: ldc_w           "?DVR"
        //   233: invokevirtual   java/lang/String.indexOf:(Ljava/lang/String;)I
        //   236: ifle            255
        //   239: aload           14
        //   241: iconst_0       
        //   242: bipush          -4
        //   244: aload           14
        //   246: invokevirtual   java/lang/String.length:()I
        //   249: iadd           
        //   250: invokevirtual   java/lang/String.substring:(II)Ljava/lang/String;
        //   253: astore          14
        //   255: aload           16
        //   257: ifnull          287
        //   260: aload           16
        //   262: ldc_w           "?DVR"
        //   265: invokevirtual   java/lang/String.indexOf:(Ljava/lang/String;)I
        //   268: ifle            287
        //   271: aload           14
        //   273: iconst_0       
        //   274: bipush          -4
        //   276: aload           14
        //   278: invokevirtual   java/lang/String.length:()I
        //   281: iadd           
        //   282: invokevirtual   java/lang/String.substring:(II)Ljava/lang/String;
        //   285: astore          16
        //   287: new             Lcom/hdvietnam/android/a/h;
        //   290: dup            
        //   291: iload_0        
        //   292: aload           11
        //   294: aload           12
        //   296: aload           14
        //   298: aload           16
        //   300: invokespecial   com/hdvietnam/android/a/h.<init>:(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   303: putstatic       com/hdvietnam/android/a/d.w:Lcom/hdvietnam/android/a/h;
        //   306: iconst_0       
        //   307: ireturn        
        //   308: astore          8
        //   310: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //   313: new             Ljava/lang/StringBuilder;
        //   316: dup            
        //   317: ldc_w           "Ex GetChannelPlay::"
        //   320: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   323: aload           8
        //   325: invokevirtual   java/lang/Exception.toString:()Ljava/lang/String;
        //   328: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   331: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   334: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   337: iconst_m1      
        //   338: ireturn        
        //   339: astore          15
        //   341: aconst_null    
        //   342: astore          16
        //   344: goto            228
        //   347: astore          18
        //   349: iload           9
        //   351: ireturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  130    151    308    339    Ljava/lang/Exception;
        //  156    167    347    352    Ljava/lang/Exception;
        //  170    210    308    339    Ljava/lang/Exception;
        //  214    224    339    347    Ljava/lang/Exception;
        //  228    255    308    339    Ljava/lang/Exception;
        //  260    287    308    339    Ljava/lang/Exception;
        //  287    306    308    339    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0170:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static int a(final String p0, final String p1, final int p2, final int p3, final int p4, final String p5) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: new             Ljava/lang/StringBuilder;
        //     3: dup            
        //     4: getstatic       com/hdvietnam/android/a/d.aA:Ljava/lang/String;
        //     7: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    10: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    13: aload_0        
        //    14: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    17: ldc_w           "&"
        //    20: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    23: getstatic       com/hdvietnam/android/a/d.aB:Ljava/lang/String;
        //    26: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    29: aload_1        
        //    30: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    33: ldc_w           "&"
        //    36: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    39: getstatic       com/hdvietnam/android/a/d.aC:Ljava/lang/String;
        //    42: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    45: iload_2        
        //    46: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    49: ldc_w           "&"
        //    52: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    55: getstatic       com/hdvietnam/android/a/d.A:Ljava/lang/String;
        //    58: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    61: iload_3        
        //    62: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    65: ldc_w           "&"
        //    68: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    71: getstatic       com/hdvietnam/android/a/d.B:Ljava/lang/String;
        //    74: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    77: iload           4
        //    79: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    82: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    85: astore          6
        //    87: new             Ljava/lang/StringBuilder;
        //    90: dup            
        //    91: aload           6
        //    93: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    96: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    99: ldc_w           "&"
        //   102: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   105: getstatic       com/hdvietnam/android/a/d.aD:Ljava/lang/String;
        //   108: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   111: aload           5
        //   113: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   116: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   119: invokestatic    com/hdvietnam/android/a/f.a:(Ljava/lang/String;)Ljava/lang/String;
        //   122: invokestatic    com/hdvietnam/android/a/m.a:(Ljava/lang/String;)Ljava/lang/String;
        //   125: astore          7
        //   127: new             Lcom/hdvietnam/android/b/a;
        //   130: dup            
        //   131: new             Ljava/lang/StringBuilder;
        //   134: dup            
        //   135: getstatic       com/hdvietnam/android/a/d.az:Ljava/lang/String;
        //   138: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   141: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   144: aload           6
        //   146: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   149: ldc_w           "&"
        //   152: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   155: getstatic       com/hdvietnam/android/a/d.aD:Ljava/lang/String;
        //   158: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   161: aload           5
        //   163: invokestatic    java/net/URLEncoder.encode:(Ljava/lang/String;)Ljava/lang/String;
        //   166: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   169: ldc_w           "&"
        //   172: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   175: getstatic       com/hdvietnam/android/a/d.N:Ljava/lang/String;
        //   178: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   181: aload           7
        //   183: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   186: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   189: invokespecial   com/hdvietnam/android/b/a.<init>:(Ljava/lang/String;)V
        //   192: invokevirtual   com/hdvietnam/android/b/a.a:()Ljava/lang/String;
        //   195: astore          8
        //   197: new             La/a/c;
        //   200: dup            
        //   201: aload           8
        //   203: invokespecial   a/a/c.<init>:(Ljava/lang/String;)V
        //   206: astore          9
        //   208: aload           9
        //   210: getstatic       com/hdvietnam/android/a/d.y:Ljava/lang/String;
        //   213: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   216: istore          11
        //   218: iload           11
        //   220: ifeq            237
        //   223: aload           9
        //   225: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   228: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   231: putstatic       com/hdvietnam/android/a/d.h:Ljava/lang/String;
        //   234: iload           11
        //   236: ireturn        
        //   237: aload           9
        //   239: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   242: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   245: astore          12
        //   247: aload           12
        //   249: getstatic       com/hdvietnam/android/a/d.aE:Ljava/lang/String;
        //   252: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   255: astore          13
        //   257: aload           12
        //   259: getstatic       com/hdvietnam/android/a/d.aF:Ljava/lang/String;
        //   262: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   265: astore          14
        //   267: aload           12
        //   269: getstatic       com/hdvietnam/android/a/d.aG:Ljava/lang/String;
        //   272: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   275: astore          56
        //   277: aload           56
        //   279: astore          16
        //   281: aload           16
        //   283: ifnonnull       290
        //   286: aload           14
        //   288: astore          16
        //   290: new             Lcom/hdvietnam/android/a/p;
        //   293: dup            
        //   294: aload           13
        //   296: aload_0        
        //   297: aload_1        
        //   298: aload           14
        //   300: aload           16
        //   302: iload_2        
        //   303: aload           12
        //   305: getstatic       com/hdvietnam/android/a/d.aM:Ljava/lang/String;
        //   308: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   311: invokespecial   com/hdvietnam/android/a/p.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;II)V
        //   314: putstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   317: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   320: aload           12
        //   322: getstatic       com/hdvietnam/android/a/d.aV:Ljava/lang/String;
        //   325: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   328: putfield        com/hdvietnam/android/a/p.i:Ljava/lang/String;
        //   331: aload           12
        //   333: getstatic       com/hdvietnam/android/a/d.aJ:Ljava/lang/String;
        //   336: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   339: astore          55
        //   341: aload           55
        //   343: astore          21
        //   345: aload           21
        //   347: ifnull          528
        //   350: aload           21
        //   352: getstatic       com/hdvietnam/android/a/d.aL:Ljava/lang/String;
        //   355: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   358: astore          52
        //   360: aload           52
        //   362: astore          36
        //   364: aload           36
        //   366: ifnull          434
        //   369: aload           36
        //   371: getstatic       com/hdvietnam/android/a/d.aO:Ljava/lang/String;
        //   374: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   377: astore          46
        //   379: aload           36
        //   381: getstatic       com/hdvietnam/android/a/d.aP:Ljava/lang/String;
        //   384: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   387: astore          47
        //   389: aload           36
        //   391: getstatic       com/hdvietnam/android/a/d.aT:Ljava/lang/String;
        //   394: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   397: astore          50
        //   399: aload           36
        //   401: getstatic       com/hdvietnam/android/a/d.aU:Ljava/lang/String;
        //   404: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   407: istore          51
        //   409: iload           51
        //   411: istore          49
        //   413: aload           50
        //   415: ifnull          424
        //   418: iload           49
        //   420: iconst_m1      
        //   421: if_icmpne       672
        //   424: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   427: aload           46
        //   429: aload           47
        //   431: invokevirtual   com/hdvietnam/android/a/p.a:(Ljava/lang/String;Ljava/lang/String;)V
        //   434: aload           21
        //   436: getstatic       com/hdvietnam/android/a/d.aK:Ljava/lang/String;
        //   439: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   442: astore          45
        //   444: aload           45
        //   446: astore          38
        //   448: aload           38
        //   450: ifnull          518
        //   453: aload           38
        //   455: getstatic       com/hdvietnam/android/a/d.aO:Ljava/lang/String;
        //   458: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   461: astore          39
        //   463: aload           38
        //   465: getstatic       com/hdvietnam/android/a/d.aP:Ljava/lang/String;
        //   468: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   471: astore          40
        //   473: aload           38
        //   475: getstatic       com/hdvietnam/android/a/d.aT:Ljava/lang/String;
        //   478: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   481: astore          43
        //   483: aload           38
        //   485: getstatic       com/hdvietnam/android/a/d.aU:Ljava/lang/String;
        //   488: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   491: istore          44
        //   493: iload           44
        //   495: istore          42
        //   497: aload           43
        //   499: ifnull          508
        //   502: iload           42
        //   504: iconst_m1      
        //   505: if_icmpne       689
        //   508: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   511: aload           39
        //   513: aload           40
        //   515: invokevirtual   com/hdvietnam/android/a/p.a:(Ljava/lang/String;Ljava/lang/String;)V
        //   518: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   521: ldc_w           "Off"
        //   524: aconst_null    
        //   525: invokevirtual   com/hdvietnam/android/a/p.a:(Ljava/lang/String;Ljava/lang/String;)V
        //   528: aload           12
        //   530: getstatic       com/hdvietnam/android/a/d.aN:Ljava/lang/String;
        //   533: invokevirtual   a/a/c.d:(Ljava/lang/String;)La/a/a;
        //   536: astore          23
        //   538: iconst_0       
        //   539: istore          24
        //   541: aload           23
        //   543: getfield        a/a/a.a:Ljava/util/ArrayList;
        //   546: invokevirtual   java/util/ArrayList.size:()I
        //   549: istore          25
        //   551: iload           24
        //   553: iload           25
        //   555: if_icmplt       706
        //   558: iconst_0       
        //   559: ireturn        
        //   560: astore          17
        //   562: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   565: aconst_null    
        //   566: putfield        com/hdvietnam/android/a/p.i:Ljava/lang/String;
        //   569: goto            331
        //   572: astore          10
        //   574: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //   577: new             Ljava/lang/StringBuilder;
        //   580: dup            
        //   581: ldc_w           "Ex GetPlayMovie::"
        //   584: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   587: aload           10
        //   589: invokevirtual   java/lang/Exception.toString:()Ljava/lang/String;
        //   592: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   595: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   598: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   601: aconst_null    
        //   602: putstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   605: iconst_m1      
        //   606: ireturn        
        //   607: astore          18
        //   609: aload           12
        //   611: getstatic       com/hdvietnam/android/a/d.aI:Ljava/lang/String;
        //   614: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   617: astore          54
        //   619: aload           54
        //   621: astore          21
        //   623: goto            345
        //   626: astore          19
        //   628: aload           12
        //   630: getstatic       com/hdvietnam/android/a/d.aH:Ljava/lang/String;
        //   633: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   636: astore          53
        //   638: aload           53
        //   640: astore          21
        //   642: goto            345
        //   645: astore          20
        //   647: aconst_null    
        //   648: astore          21
        //   650: goto            345
        //   653: astore          35
        //   655: aconst_null    
        //   656: astore          36
        //   658: goto            364
        //   661: astore          48
        //   663: iconst_m1      
        //   664: istore          49
        //   666: aconst_null    
        //   667: astore          50
        //   669: goto            413
        //   672: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   675: aload           46
        //   677: aload           47
        //   679: aload           50
        //   681: iload           49
        //   683: invokevirtual   com/hdvietnam/android/a/p.a:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
        //   686: goto            434
        //   689: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   692: aload           39
        //   694: aload           40
        //   696: aload           43
        //   698: iload           42
        //   700: invokevirtual   com/hdvietnam/android/a/p.a:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
        //   703: goto            518
        //   706: aload           23
        //   708: iload           24
        //   710: invokevirtual   a/a/a.b:(I)La/a/c;
        //   713: astore          26
        //   715: aload           26
        //   717: getstatic       com/hdvietnam/android/a/d.aS:Ljava/lang/String;
        //   720: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   723: pop            
        //   724: aload           26
        //   726: getstatic       com/hdvietnam/android/a/d.aQ:Ljava/lang/String;
        //   729: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   732: pop            
        //   733: aload           26
        //   735: getstatic       com/hdvietnam/android/a/d.aR:Ljava/lang/String;
        //   738: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   741: pop            
        //   742: iinc            24, 1
        //   745: goto            541
        //   748: astore          27
        //   750: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   753: astore          29
        //   755: new             Lcom/hdvietnam/android/a/c;
        //   758: dup            
        //   759: aload           26
        //   761: getstatic       com/hdvietnam/android/a/d.aS:Ljava/lang/String;
        //   764: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   767: aload           26
        //   769: getstatic       com/hdvietnam/android/a/d.aQ:Ljava/lang/String;
        //   772: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   775: iconst_m1      
        //   776: invokespecial   com/hdvietnam/android/a/c.<init>:(Ljava/lang/String;Ljava/lang/String;I)V
        //   779: astore          30
        //   781: aload           29
        //   783: getfield        com/hdvietnam/android/a/p.f:Ljava/util/ArrayList;
        //   786: aload           30
        //   788: invokevirtual   java/util/ArrayList.add:(Ljava/lang/Object;)Z
        //   791: pop            
        //   792: goto            742
        //   795: astore          28
        //   797: goto            742
        //   800: astore          22
        //   802: goto            558
        //   805: astore          15
        //   807: aconst_null    
        //   808: astore          16
        //   810: goto            281
        //   813: astore          57
        //   815: iload           11
        //   817: ireturn        
        //   818: astore          37
        //   820: aconst_null    
        //   821: astore          38
        //   823: goto            448
        //   826: astore          41
        //   828: iconst_m1      
        //   829: istore          42
        //   831: aconst_null    
        //   832: astore          43
        //   834: goto            497
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  197    218    572    607    Ljava/lang/Exception;
        //  223    234    813    818    Ljava/lang/Exception;
        //  237    267    572    607    Ljava/lang/Exception;
        //  267    277    805    813    Ljava/lang/Exception;
        //  290    317    572    607    Ljava/lang/Exception;
        //  317    331    560    572    Ljava/lang/Exception;
        //  331    341    607    653    Ljava/lang/Exception;
        //  350    360    653    661    Ljava/lang/Exception;
        //  369    389    572    607    Ljava/lang/Exception;
        //  389    409    661    672    Ljava/lang/Exception;
        //  424    434    572    607    Ljava/lang/Exception;
        //  434    444    818    826    Ljava/lang/Exception;
        //  453    473    572    607    Ljava/lang/Exception;
        //  473    493    826    837    Ljava/lang/Exception;
        //  508    518    572    607    Ljava/lang/Exception;
        //  518    528    572    607    Ljava/lang/Exception;
        //  528    538    800    805    Ljava/lang/Exception;
        //  541    551    800    805    Ljava/lang/Exception;
        //  562    569    572    607    Ljava/lang/Exception;
        //  609    619    626    653    Ljava/lang/Exception;
        //  628    638    645    653    Ljava/lang/Exception;
        //  672    686    572    607    Ljava/lang/Exception;
        //  689    703    572    607    Ljava/lang/Exception;
        //  706    715    800    805    Ljava/lang/Exception;
        //  715    742    748    800    Ljava/lang/Exception;
        //  750    792    795    800    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index: 351, Size: 351
        //     at java.util.ArrayList.rangeCheck(ArrayList.java:635)
        //     at java.util.ArrayList.get(ArrayList.java:411)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(Unknown Source)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(Unknown Source)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(Unknown Source)
        //     at com.strobel.decompiler.ast.AstBuilder.build(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: new             Ljava/lang/StringBuilder;
        //     3: dup            
        //     4: getstatic       com/hdvietnam/android/a/d.aA:Ljava/lang/String;
        //     7: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    10: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    13: aload_0        
        //    14: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    17: ldc_w           "&"
        //    20: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    23: getstatic       com/hdvietnam/android/a/d.aB:Ljava/lang/String;
        //    26: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    29: aload_1        
        //    30: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    33: ldc_w           "&"
        //    36: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    39: getstatic       com/hdvietnam/android/a/d.aC:Ljava/lang/String;
        //    42: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    45: iload_2        
        //    46: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    49: ldc_w           "&"
        //    52: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    55: getstatic       com/hdvietnam/android/a/d.A:Ljava/lang/String;
        //    58: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    61: iload_3        
        //    62: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    65: ldc_w           "&"
        //    68: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    71: getstatic       com/hdvietnam/android/a/d.B:Ljava/lang/String;
        //    74: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    77: iload           4
        //    79: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //    82: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    85: astore          6
        //    87: new             Ljava/lang/StringBuilder;
        //    90: dup            
        //    91: aload           6
        //    93: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    96: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    99: ldc_w           "&"
        //   102: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   105: getstatic       com/hdvietnam/android/a/d.aD:Ljava/lang/String;
        //   108: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   111: aload           5
        //   113: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   116: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   119: invokestatic    com/hdvietnam/android/a/f.a:(Ljava/lang/String;)Ljava/lang/String;
        //   122: invokestatic    com/hdvietnam/android/a/m.a:(Ljava/lang/String;)Ljava/lang/String;
        //   125: astore          7
        //   127: new             Lcom/hdvietnam/android/b/a;
        //   130: dup            
        //   131: new             Ljava/lang/StringBuilder;
        //   134: dup            
        //   135: getstatic       com/hdvietnam/android/a/d.az:Ljava/lang/String;
        //   138: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   141: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   144: aload           6
        //   146: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   149: ldc_w           "&"
        //   152: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   155: getstatic       com/hdvietnam/android/a/d.aD:Ljava/lang/String;
        //   158: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   161: aload           5
        //   163: invokestatic    java/net/URLEncoder.encode:(Ljava/lang/String;)Ljava/lang/String;
        //   166: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   169: ldc_w           "&"
        //   172: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   175: getstatic       com/hdvietnam/android/a/d.N:Ljava/lang/String;
        //   178: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   181: aload           7
        //   183: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   186: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   189: invokespecial   com/hdvietnam/android/b/a.<init>:(Ljava/lang/String;)V
        //   192: invokevirtual   com/hdvietnam/android/b/a.a:()Ljava/lang/String;
        //   195: astore          8
        //   197: new             La/a/c;
        //   200: dup            
        //   201: aload           8
        //   203: invokespecial   a/a/c.<init>:(Ljava/lang/String;)V
        //   206: astore          9
        //   208: aload           9
        //   210: getstatic       com/hdvietnam/android/a/d.y:Ljava/lang/String;
        //   213: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   216: istore          11
        //   218: iload           11
        //   220: ifeq            237
        //   223: aload           9
        //   225: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   228: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   231: putstatic       com/hdvietnam/android/a/d.h:Ljava/lang/String;
        //   234: iload           11
        //   236: ireturn        
        //   237: aload           9
        //   239: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   242: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   245: astore          12
        //   247: aload           12
        //   249: getstatic       com/hdvietnam/android/a/d.aE:Ljava/lang/String;
        //   252: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   255: astore          13
        //   257: aload           12
        //   259: getstatic       com/hdvietnam/android/a/d.aF:Ljava/lang/String;
        //   262: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   265: astore          14
        //   267: aload           12
        //   269: getstatic       com/hdvietnam/android/a/d.aG:Ljava/lang/String;
        //   272: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   275: astore          56
        //   277: aload           56
        //   279: astore          16
        //   281: aload           16
        //   283: ifnonnull       290
        //   286: aload           14
        //   288: astore          16
        //   290: new             Lcom/hdvietnam/android/a/p;
        //   293: dup            
        //   294: aload           13
        //   296: aload_0        
        //   297: aload_1        
        //   298: aload           14
        //   300: aload           16
        //   302: iload_2        
        //   303: aload           12
        //   305: getstatic       com/hdvietnam/android/a/d.aM:Ljava/lang/String;
        //   308: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   311: invokespecial   com/hdvietnam/android/a/p.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;II)V
        //   314: putstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   317: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   320: aload           12
        //   322: getstatic       com/hdvietnam/android/a/d.aV:Ljava/lang/String;
        //   325: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   328: putfield        com/hdvietnam/android/a/p.i:Ljava/lang/String;
        //   331: aload           12
        //   333: getstatic       com/hdvietnam/android/a/d.aJ:Ljava/lang/String;
        //   336: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   339: astore          55
        //   341: aload           55
        //   343: astore          21
        //   345: aload           21
        //   347: ifnull          528
        //   350: aload           21
        //   352: getstatic       com/hdvietnam/android/a/d.aL:Ljava/lang/String;
        //   355: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   358: astore          52
        //   360: aload           52
        //   362: astore          36
        //   364: aload           36
        //   366: ifnull          434
        //   369: aload           36
        //   371: getstatic       com/hdvietnam/android/a/d.aO:Ljava/lang/String;
        //   374: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   377: astore          46
        //   379: aload           36
        //   381: getstatic       com/hdvietnam/android/a/d.aP:Ljava/lang/String;
        //   384: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   387: astore          47
        //   389: aload           36
        //   391: getstatic       com/hdvietnam/android/a/d.aT:Ljava/lang/String;
        //   394: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   397: astore          50
        //   399: aload           36
        //   401: getstatic       com/hdvietnam/android/a/d.aU:Ljava/lang/String;
        //   404: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   407: istore          51
        //   409: iload           51
        //   411: istore          49
        //   413: aload           50
        //   415: ifnull          424
        //   418: iload           49
        //   420: iconst_m1      
        //   421: if_icmpne       672
        //   424: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   427: aload           46
        //   429: aload           47
        //   431: invokevirtual   com/hdvietnam/android/a/p.a:(Ljava/lang/String;Ljava/lang/String;)V
        //   434: aload           21
        //   436: getstatic       com/hdvietnam/android/a/d.aK:Ljava/lang/String;
        //   439: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   442: astore          45
        //   444: aload           45
        //   446: astore          38
        //   448: aload           38
        //   450: ifnull          518
        //   453: aload           38
        //   455: getstatic       com/hdvietnam/android/a/d.aO:Ljava/lang/String;
        //   458: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   461: astore          39
        //   463: aload           38
        //   465: getstatic       com/hdvietnam/android/a/d.aP:Ljava/lang/String;
        //   468: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   471: astore          40
        //   473: aload           38
        //   475: getstatic       com/hdvietnam/android/a/d.aT:Ljava/lang/String;
        //   478: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   481: astore          43
        //   483: aload           38
        //   485: getstatic       com/hdvietnam/android/a/d.aU:Ljava/lang/String;
        //   488: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   491: istore          44
        //   493: iload           44
        //   495: istore          42
        //   497: aload           43
        //   499: ifnull          508
        //   502: iload           42
        //   504: iconst_m1      
        //   505: if_icmpne       689
        //   508: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   511: aload           39
        //   513: aload           40
        //   515: invokevirtual   com/hdvietnam/android/a/p.a:(Ljava/lang/String;Ljava/lang/String;)V
        //   518: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   521: ldc_w           "Off"
        //   524: aconst_null    
        //   525: invokevirtual   com/hdvietnam/android/a/p.a:(Ljava/lang/String;Ljava/lang/String;)V
        //   528: aload           12
        //   530: getstatic       com/hdvietnam/android/a/d.aN:Ljava/lang/String;
        //   533: invokevirtual   a/a/c.d:(Ljava/lang/String;)La/a/a;
        //   536: astore          23
        //   538: iconst_0       
        //   539: istore          24
        //   541: aload           23
        //   543: getfield        a/a/a.a:Ljava/util/ArrayList;
        //   546: invokevirtual   java/util/ArrayList.size:()I
        //   549: istore          25
        //   551: iload           24
        //   553: iload           25
        //   555: if_icmplt       706
        //   558: iconst_0       
        //   559: ireturn        
        //   560: astore          17
        //   562: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   565: aconst_null    
        //   566: putfield        com/hdvietnam/android/a/p.i:Ljava/lang/String;
        //   569: goto            331
        //   572: astore          10
        //   574: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //   577: new             Ljava/lang/StringBuilder;
        //   580: dup            
        //   581: ldc_w           "Ex GetPlayMovie::"
        //   584: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   587: aload           10
        //   589: invokevirtual   java/lang/Exception.toString:()Ljava/lang/String;
        //   592: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   595: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   598: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   601: aconst_null    
        //   602: putstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   605: iconst_m1      
        //   606: ireturn        
        //   607: astore          18
        //   609: aload           12
        //   611: getstatic       com/hdvietnam/android/a/d.aI:Ljava/lang/String;
        //   614: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   617: astore          54
        //   619: aload           54
        //   621: astore          21
        //   623: goto            345
        //   626: astore          19
        //   628: aload           12
        //   630: getstatic       com/hdvietnam/android/a/d.aH:Ljava/lang/String;
        //   633: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   636: astore          53
        //   638: aload           53
        //   640: astore          21
        //   642: goto            345
        //   645: astore          20
        //   647: aconst_null    
        //   648: astore          21
        //   650: goto            345
        //   653: astore          35
        //   655: aconst_null    
        //   656: astore          36
        //   658: goto            364
        //   661: astore          48
        //   663: iconst_m1      
        //   664: istore          49
        //   666: aconst_null    
        //   667: astore          50
        //   669: goto            413
        //   672: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   675: aload           46
        //   677: aload           47
        //   679: aload           50
        //   681: iload           49
        //   683: invokevirtual   com/hdvietnam/android/a/p.a:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
        //   686: goto            434
        //   689: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   692: aload           39
        //   694: aload           40
        //   696: aload           43
        //   698: iload           42
        //   700: invokevirtual   com/hdvietnam/android/a/p.a:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
        //   703: goto            518
        //   706: aload           23
        //   708: iload           24
        //   710: invokevirtual   a/a/a.b:(I)La/a/c;
        //   713: astore          26
        //   715: aload           26
        //   717: getstatic       com/hdvietnam/android/a/d.aS:Ljava/lang/String;
        //   720: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   723: pop            
        //   724: aload           26
        //   726: getstatic       com/hdvietnam/android/a/d.aQ:Ljava/lang/String;
        //   729: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   732: pop            
        //   733: aload           26
        //   735: getstatic       com/hdvietnam/android/a/d.aR:Ljava/lang/String;
        //   738: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   741: pop            
        //   742: iinc            24, 1
        //   745: goto            541
        //   748: astore          27
        //   750: getstatic       com/hdvietnam/android/a/d.x:Lcom/hdvietnam/android/a/p;
        //   753: astore          29
        //   755: new             Lcom/hdvietnam/android/a/c;
        //   758: dup            
        //   759: aload           26
        //   761: getstatic       com/hdvietnam/android/a/d.aS:Ljava/lang/String;
        //   764: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   767: aload           26
        //   769: getstatic       com/hdvietnam/android/a/d.aQ:Ljava/lang/String;
        //   772: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   775: iconst_m1      
        //   776: invokespecial   com/hdvietnam/android/a/c.<init>:(Ljava/lang/String;Ljava/lang/String;I)V
        //   779: astore          30
        //   781: aload           29
        //   783: getfield        com/hdvietnam/android/a/p.f:Ljava/util/ArrayList;
        //   786: aload           30
        //   788: invokevirtual   java/util/ArrayList.add:(Ljava/lang/Object;)Z
        //   791: pop            
        //   792: goto            742
        //   795: astore          28
        //   797: goto            742
        //   800: astore          22
        //   802: goto            558
        //   805: astore          15
        //   807: aconst_null    
        //   808: astore          16
        //   810: goto            281
        //   813: astore          57
        //   815: iload           11
        //   817: ireturn        
        //   818: astore          37
        //   820: aconst_null    
        //   821: astore          38
        //   823: goto            448
        //   826: astore          41
        //   828: iconst_m1      
        //   829: istore          42
        //   831: aconst_null    
        //   832: astore          43
        //   834: goto            497
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  197    218    572    607    Ljava/lang/Exception;
        //  223    234    813    818    Ljava/lang/Exception;
        //  237    267    572    607    Ljava/lang/Exception;
        //  267    277    805    813    Ljava/lang/Exception;
        //  290    317    572    607    Ljava/lang/Exception;
        //  317    331    560    572    Ljava/lang/Exception;
        //  331    341    607    653    Ljava/lang/Exception;
        //  350    360    653    661    Ljava/lang/Exception;
        //  369    389    572    607    Ljava/lang/Exception;
        //  389    409    661    672    Ljava/lang/Exception;
        //  424    434    572    607    Ljava/lang/Exception;
        //  434    444    818    826    Ljava/lang/Exception;
        //  453    473    572    607    Ljava/lang/Exception;
        //  473    493    826    837    Ljava/lang/Exception;
        //  508    518    572    607    Ljava/lang/Exception;
        //  518    528    572    607    Ljava/lang/Exception;
        //  528    538    800    805    Ljava/lang/Exception;
        //  541    551    800    805    Ljava/lang/Exception;
        //  562    569    572    607    Ljava/lang/Exception;
        //  609    619    626    653    Ljava/lang/Exception;
        //  628    638    645    653    Ljava/lang/Exception;
        //  672    686    572    607    Ljava/lang/Exception;
        //  689    703    572    607    Ljava/lang/Exception;
        //  706    715    800    805    Ljava/lang/Exception;
        //  715    742    748    800    Ljava/lang/Exception;
        //  750    792    795    800    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index: 351, Size: 351
        //     at java.util.ArrayList.rangeCheck(ArrayList.java:635)
        //     at java.util.ArrayList.get(ArrayList.java:411)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(Unknown Source)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(Unknown Source)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(Unknown Source)
        //     at com.strobel.decompiler.ast.AstBuilder.build(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static int a(final String s, final String s2, final String s3, final String s4, final String s5, final String s6, final String s7) {
        if (d.t == null) {
            return 0;
        }
        final Date date = new Date(System.currentTimeMillis());
        final String string = String.valueOf(d.aX) + s + "&" + d.aY + s2 + "&" + d.aZ + s3 + "&" + d.ba + s4 + "&" + d.bb + s5 + "&" + d.bc + s6 + "&" + d.bd + s7 + "&" + d.be + (String.valueOf(1900 + date.getYear()) + "-" + (1 + date.getMonth()) + "-" + date.getDate() + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds());
        final String a = new a(String.valueOf(l.o) + string.replace(" ", "%20") + "&" + d.N + m.a(f.a(string))).a();
        try {
            return new c(a).c(d.y);
        }
        catch (Exception ex) {
            return 0;
        }
    }
    
    public static void a() {
        d.r.clear();
        try {
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new URL(d.C).openStream()));
            while (true) {
                final String line = bufferedReader.readLine();
                if (line == null) {
                    break;
                }
                d.r.add(line.toUpperCase());
            }
            bufferedReader.close();
        }
        catch (MalformedURLException ex) {}
        catch (IOException ex2) {}
    }
    
    public static boolean a(final String s) {
        boolean b;
        while (true) {
            b = false;
            final String string = String.valueOf(d.aX) + s + "&" + d.E + "1";
            final String a = new a(String.valueOf(d.D) + string + "&" + d.N + m.a(f.a(string))).a();
            d.H.clear();
            while (true) {
                Label_0228: {
                    try {
                        final c c = new c(a);
                        if (c.c(d.y) != 0) {
                            return false;
                        }
                        final a.a.a d = c.d(d.z);
                        boolean b2;
                        for (int i = 0; i < d.a.size(); ++i, b = b2) {
                            final c c2 = (c)d.a(i);
                            final u u = new u(c2.c(d.G), c2.c(d.F));
                            d.H.add(u);
                            if (u.a != 2) {
                                break Label_0228;
                            }
                            b2 = true;
                        }
                        break;
                    }
                    catch (Exception ex) {
                        return b;
                    }
                }
                boolean b2 = b;
                continue;
            }
        }
        return b;
    }
    
    public static int b() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: new             Ljava/lang/StringBuilder;
        //     3: dup            
        //     4: getstatic       com/hdvietnam/android/a/d.K:Ljava/lang/String;
        //     7: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    10: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    13: getstatic       com/hdvietnam/android/a/d.J:Ljava/lang/String;
        //    16: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    19: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    22: pop            
        //    23: new             Ljava/lang/StringBuilder;
        //    26: dup            
        //    27: getstatic       com/hdvietnam/android/a/d.K:Ljava/lang/String;
        //    30: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    33: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    36: getstatic       com/hdvietnam/android/a/d.L:Ljava/lang/String;
        //    39: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    42: ldc_w           "&"
        //    45: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    48: getstatic       com/hdvietnam/android/a/d.M:Ljava/lang/String;
        //    51: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    54: iconst_1       
        //    55: invokevirtual   java/lang/StringBuilder.append:(Z)Ljava/lang/StringBuilder;
        //    58: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    61: astore_1       
        //    62: aload_1        
        //    63: invokestatic    com/hdvietnam/android/a/f.a:(Ljava/lang/String;)Ljava/lang/String;
        //    66: invokestatic    com/hdvietnam/android/a/m.a:(Ljava/lang/String;)Ljava/lang/String;
        //    69: astore_2       
        //    70: new             Lcom/hdvietnam/android/b/a;
        //    73: dup            
        //    74: new             Ljava/lang/StringBuilder;
        //    77: dup            
        //    78: getstatic       com/hdvietnam/android/a/d.I:Ljava/lang/String;
        //    81: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    84: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    87: aload_1        
        //    88: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    91: ldc_w           "&"
        //    94: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    97: getstatic       com/hdvietnam/android/a/d.N:Ljava/lang/String;
        //   100: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   103: aload_2        
        //   104: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   107: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   110: invokespecial   com/hdvietnam/android/b/a.<init>:(Ljava/lang/String;)V
        //   113: invokevirtual   com/hdvietnam/android/b/a.a:()Ljava/lang/String;
        //   116: astore_3       
        //   117: aload_3        
        //   118: bipush          123
        //   120: invokevirtual   java/lang/String.indexOf:(I)I
        //   123: istore          5
        //   125: iload           5
        //   127: ifle            137
        //   130: aload_3        
        //   131: iload           5
        //   133: invokevirtual   java/lang/String.substring:(I)Ljava/lang/String;
        //   136: astore_3       
        //   137: new             La/a/c;
        //   140: dup            
        //   141: aload_3        
        //   142: invokespecial   a/a/c.<init>:(Ljava/lang/String;)V
        //   145: astore          6
        //   147: aload           6
        //   149: getstatic       com/hdvietnam/android/a/d.y:Ljava/lang/String;
        //   152: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   155: istore          7
        //   157: iload           7
        //   159: getstatic       com/hdvietnam/android/a/d.s:I
        //   162: if_icmpne       174
        //   165: aload           6
        //   167: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   170: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   173: pop            
        //   174: iload           7
        //   176: ifeq            193
        //   179: aload           6
        //   181: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   184: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   187: putstatic       com/hdvietnam/android/a/d.b:Ljava/lang/String;
        //   190: iload           7
        //   192: ireturn        
        //   193: aload           6
        //   195: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   198: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   201: astore          8
        //   203: aload           8
        //   205: getstatic       com/hdvietnam/android/a/d.O:Ljava/lang/String;
        //   208: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   211: astore          9
        //   213: aload           8
        //   215: getstatic       com/hdvietnam/android/a/d.P:Ljava/lang/String;
        //   218: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   221: astore          10
        //   223: aload           8
        //   225: getstatic       com/hdvietnam/android/a/d.Q:Ljava/lang/String;
        //   228: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   231: astore          11
        //   233: aload           8
        //   235: getstatic       com/hdvietnam/android/a/d.R:Ljava/lang/String;
        //   238: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   241: astore          12
        //   243: aload           8
        //   245: getstatic       com/hdvietnam/android/a/d.S:Ljava/lang/String;
        //   248: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   251: astore          13
        //   253: aload           8
        //   255: getstatic       com/hdvietnam/android/a/d.T:Ljava/lang/String;
        //   258: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   261: astore          14
        //   263: aload           8
        //   265: getstatic       com/hdvietnam/android/a/d.U:Ljava/lang/String;
        //   268: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   271: astore          15
        //   273: aload           8
        //   275: getstatic       com/hdvietnam/android/a/d.V:Ljava/lang/String;
        //   278: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   281: astore          16
        //   283: aload           8
        //   285: getstatic       com/hdvietnam/android/a/d.W:Ljava/lang/String;
        //   288: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   291: astore          17
        //   293: aload           8
        //   295: getstatic       com/hdvietnam/android/a/d.X:Ljava/lang/String;
        //   298: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   301: astore          18
        //   303: aload           8
        //   305: getstatic       com/hdvietnam/android/a/d.Y:Ljava/lang/String;
        //   308: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   311: astore          19
        //   313: aload           8
        //   315: getstatic       com/hdvietnam/android/a/d.Z:Ljava/lang/String;
        //   318: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   321: astore          20
        //   323: aload           8
        //   325: getstatic       com/hdvietnam/android/a/d.aa:Ljava/lang/String;
        //   328: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   331: astore          21
        //   333: aload           8
        //   335: getstatic       com/hdvietnam/android/a/d.ab:Ljava/lang/String;
        //   338: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   341: astore          22
        //   343: aload           8
        //   345: getstatic       com/hdvietnam/android/a/d.ac:Ljava/lang/String;
        //   348: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   351: astore          23
        //   353: aload           23
        //   355: ifnull          366
        //   358: aload           23
        //   360: ldc_w           ""
        //   363: if_acmpne       673
        //   366: getstatic       com/hdvietnam/android/a/d.aW:Ljava/lang/String;
        //   369: astore          24
        //   371: new             Lcom/hdvietnam/android/a/l;
        //   374: dup            
        //   375: aload           9
        //   377: aload           10
        //   379: aload           11
        //   381: aload           12
        //   383: aload           13
        //   385: aload           14
        //   387: aload           15
        //   389: aload           16
        //   391: aload           17
        //   393: aload           18
        //   395: aload           19
        //   397: aload           20
        //   399: aload           21
        //   401: aload           22
        //   403: aload           24
        //   405: invokespecial   com/hdvietnam/android/a/l.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   408: putstatic       com/hdvietnam/android/a/d.t:Lcom/hdvietnam/android/a/l;
        //   411: aload           8
        //   413: getstatic       com/hdvietnam/android/a/d.ad:Ljava/lang/String;
        //   416: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   419: astore          44
        //   421: aload           44
        //   423: astore          26
        //   425: aload           26
        //   427: ifnull          455
        //   430: aload           26
        //   432: ldc_w           ","
        //   435: invokevirtual   java/lang/String.split:(Ljava/lang/String;)[Ljava/lang/String;
        //   438: astore          38
        //   440: iconst_0       
        //   441: istore          39
        //   443: aload           38
        //   445: arraylength    
        //   446: istore          40
        //   448: iload           39
        //   450: iload           40
        //   452: if_icmplt       703
        //   455: aload           8
        //   457: getstatic       com/hdvietnam/android/a/d.af:Ljava/lang/String;
        //   460: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   463: astore          28
        //   465: aload           28
        //   467: getstatic       com/hdvietnam/android/a/d.ah:Ljava/lang/String;
        //   470: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   473: astore          37
        //   475: new             Lcom/hdvietnam/android/a/q;
        //   478: dup            
        //   479: aload           37
        //   481: getstatic       com/hdvietnam/android/a/d.ak:Ljava/lang/String;
        //   484: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   487: ldc_w           "[timestamp]"
        //   490: ldc_w           ""
        //   493: invokevirtual   java/lang/String.replace:(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
        //   496: aload           37
        //   498: getstatic       com/hdvietnam/android/a/d.am:Ljava/lang/String;
        //   501: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   504: aload           37
        //   506: getstatic       com/hdvietnam/android/a/d.an:Ljava/lang/String;
        //   509: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   512: invokespecial   com/hdvietnam/android/a/q.<init>:(Ljava/lang/String;II)V
        //   515: putstatic       com/hdvietnam/android/a/a.a:Lcom/hdvietnam/android/a/q;
        //   518: aload           28
        //   520: getstatic       com/hdvietnam/android/a/d.ai:Ljava/lang/String;
        //   523: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   526: astore          36
        //   528: new             Lcom/hdvietnam/android/a/o;
        //   531: dup            
        //   532: aload           36
        //   534: getstatic       com/hdvietnam/android/a/d.ak:Ljava/lang/String;
        //   537: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   540: ldc_w           "[timestamp]"
        //   543: ldc_w           ""
        //   546: invokevirtual   java/lang/String.replace:(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
        //   549: aload           36
        //   551: getstatic       com/hdvietnam/android/a/d.am:Ljava/lang/String;
        //   554: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   557: aload           36
        //   559: getstatic       com/hdvietnam/android/a/d.an:Ljava/lang/String;
        //   562: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   565: sipush          1000
        //   568: aload           36
        //   570: getstatic       com/hdvietnam/android/a/d.al:Ljava/lang/String;
        //   573: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   576: imul           
        //   577: invokespecial   com/hdvietnam/android/a/o.<init>:(Ljava/lang/String;III)V
        //   580: putstatic       com/hdvietnam/android/a/a.b:Lcom/hdvietnam/android/a/o;
        //   583: aload           28
        //   585: getstatic       com/hdvietnam/android/a/d.ag:Ljava/lang/String;
        //   588: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   591: astore          32
        //   593: aload           32
        //   595: getstatic       com/hdvietnam/android/a/d.aj:Ljava/lang/String;
        //   598: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   601: istore          35
        //   603: iload           35
        //   605: sipush          1000
        //   608: imul           
        //   609: istore          34
        //   611: new             Lcom/hdvietnam/android/a/k;
        //   614: dup            
        //   615: aload           32
        //   617: getstatic       com/hdvietnam/android/a/d.ak:Ljava/lang/String;
        //   620: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   623: ldc_w           "[timestamp]"
        //   626: ldc_w           ""
        //   629: invokevirtual   java/lang/String.replace:(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
        //   632: iload           34
        //   634: aload           32
        //   636: getstatic       com/hdvietnam/android/a/d.an:Ljava/lang/String;
        //   639: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   642: sipush          1000
        //   645: aload           32
        //   647: getstatic       com/hdvietnam/android/a/d.al:Ljava/lang/String;
        //   650: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   653: imul           
        //   654: invokespecial   com/hdvietnam/android/a/k.<init>:(Ljava/lang/String;III)V
        //   657: putstatic       com/hdvietnam/android/a/a.c:Lcom/hdvietnam/android/a/k;
        //   660: aload           28
        //   662: getstatic       com/hdvietnam/android/a/d.ao:Ljava/lang/String;
        //   665: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   668: putstatic       com/hdvietnam/android/a/a.i:I
        //   671: iconst_0       
        //   672: ireturn        
        //   673: new             Ljava/lang/StringBuilder;
        //   676: dup            
        //   677: aload           23
        //   679: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   682: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   685: astore          45
        //   687: aload           45
        //   689: ldc_w           "?"
        //   692: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   695: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   698: astore          24
        //   700: goto            371
        //   703: getstatic       com/hdvietnam/android/a/d.t:Lcom/hdvietnam/android/a/l;
        //   706: pop            
        //   707: aload           38
        //   709: iload           39
        //   711: aaload         
        //   712: astore          42
        //   714: getstatic       com/hdvietnam/android/a/l.p:Ljava/util/ArrayList;
        //   717: aload           42
        //   719: invokevirtual   java/util/ArrayList.add:(Ljava/lang/Object;)Z
        //   722: pop            
        //   723: iinc            39, 1
        //   726: goto            443
        //   729: astore          33
        //   731: iconst_m1      
        //   732: istore          34
        //   734: goto            611
        //   737: astore          31
        //   739: aconst_null    
        //   740: putstatic       com/hdvietnam/android/a/a.c:Lcom/hdvietnam/android/a/k;
        //   743: goto            660
        //   746: astore          27
        //   748: sipush          10000
        //   751: putstatic       com/hdvietnam/android/a/a.i:I
        //   754: goto            671
        //   757: astore          4
        //   759: aconst_null    
        //   760: putstatic       com/hdvietnam/android/a/d.t:Lcom/hdvietnam/android/a/l;
        //   763: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //   766: new             Ljava/lang/StringBuilder;
        //   769: dup            
        //   770: ldc_w           "Ex GetConfig::"
        //   773: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   776: aload           4
        //   778: invokevirtual   java/lang/Exception.toString:()Ljava/lang/String;
        //   781: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   784: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   787: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   790: iconst_m1      
        //   791: ireturn        
        //   792: astore          30
        //   794: goto            583
        //   797: astore          29
        //   799: goto            518
        //   802: astore          46
        //   804: iload           7
        //   806: ireturn        
        //   807: astore          25
        //   809: aconst_null    
        //   810: astore          26
        //   812: goto            425
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  117    125    757    792    Ljava/lang/Exception;
        //  130    137    757    792    Ljava/lang/Exception;
        //  137    174    757    792    Ljava/lang/Exception;
        //  179    190    802    807    Ljava/lang/Exception;
        //  193    353    757    792    Ljava/lang/Exception;
        //  366    371    757    792    Ljava/lang/Exception;
        //  371    411    757    792    Ljava/lang/Exception;
        //  411    421    807    815    Ljava/lang/Exception;
        //  430    440    757    792    Ljava/lang/Exception;
        //  443    448    757    792    Ljava/lang/Exception;
        //  455    465    746    757    Ljava/lang/Exception;
        //  465    518    797    802    Ljava/lang/Exception;
        //  518    583    792    797    Ljava/lang/Exception;
        //  583    593    737    746    Ljava/lang/Exception;
        //  593    603    729    737    Ljava/lang/Exception;
        //  611    660    737    746    Ljava/lang/Exception;
        //  660    671    746    757    Ljava/lang/Exception;
        //  673    700    757    792    Ljava/lang/Exception;
        //  703    723    757    792    Ljava/lang/Exception;
        //  739    743    746    757    Ljava/lang/Exception;
        //  748    754    757    792    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index: 339, Size: 339
        //     at java.util.ArrayList.rangeCheck(ArrayList.java:635)
        //     at java.util.ArrayList.get(ArrayList.java:411)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(Unknown Source)
        //     at com.strobel.decompiler.ast.AstBuilder.build(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: new             Ljava/lang/StringBuilder;
        //     3: dup            
        //     4: getstatic       com/hdvietnam/android/a/d.K:Ljava/lang/String;
        //     7: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    10: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    13: getstatic       com/hdvietnam/android/a/d.J:Ljava/lang/String;
        //    16: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    19: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    22: pop            
        //    23: new             Ljava/lang/StringBuilder;
        //    26: dup            
        //    27: getstatic       com/hdvietnam/android/a/d.K:Ljava/lang/String;
        //    30: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    33: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    36: getstatic       com/hdvietnam/android/a/d.L:Ljava/lang/String;
        //    39: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    42: ldc_w           "&"
        //    45: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    48: getstatic       com/hdvietnam/android/a/d.M:Ljava/lang/String;
        //    51: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    54: iconst_1       
        //    55: invokevirtual   java/lang/StringBuilder.append:(Z)Ljava/lang/StringBuilder;
        //    58: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    61: astore_1       
        //    62: aload_1        
        //    63: invokestatic    com/hdvietnam/android/a/f.a:(Ljava/lang/String;)Ljava/lang/String;
        //    66: invokestatic    com/hdvietnam/android/a/m.a:(Ljava/lang/String;)Ljava/lang/String;
        //    69: astore_2       
        //    70: new             Lcom/hdvietnam/android/b/a;
        //    73: dup            
        //    74: new             Ljava/lang/StringBuilder;
        //    77: dup            
        //    78: getstatic       com/hdvietnam/android/a/d.I:Ljava/lang/String;
        //    81: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    84: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    87: aload_1        
        //    88: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    91: ldc_w           "&"
        //    94: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    97: getstatic       com/hdvietnam/android/a/d.N:Ljava/lang/String;
        //   100: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   103: aload_2        
        //   104: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   107: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   110: invokespecial   com/hdvietnam/android/b/a.<init>:(Ljava/lang/String;)V
        //   113: invokevirtual   com/hdvietnam/android/b/a.a:()Ljava/lang/String;
        //   116: astore_3       
        //   117: aload_3        
        //   118: bipush          123
        //   120: invokevirtual   java/lang/String.indexOf:(I)I
        //   123: istore          5
        //   125: iload           5
        //   127: ifle            137
        //   130: aload_3        
        //   131: iload           5
        //   133: invokevirtual   java/lang/String.substring:(I)Ljava/lang/String;
        //   136: astore_3       
        //   137: new             La/a/c;
        //   140: dup            
        //   141: aload_3        
        //   142: invokespecial   a/a/c.<init>:(Ljava/lang/String;)V
        //   145: astore          6
        //   147: aload           6
        //   149: getstatic       com/hdvietnam/android/a/d.y:Ljava/lang/String;
        //   152: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   155: istore          7
        //   157: iload           7
        //   159: getstatic       com/hdvietnam/android/a/d.s:I
        //   162: if_icmpne       174
        //   165: aload           6
        //   167: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   170: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   173: pop            
        //   174: iload           7
        //   176: ifeq            193
        //   179: aload           6
        //   181: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   184: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   187: putstatic       com/hdvietnam/android/a/d.b:Ljava/lang/String;
        //   190: iload           7
        //   192: ireturn        
        //   193: aload           6
        //   195: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   198: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   201: astore          8
        //   203: aload           8
        //   205: getstatic       com/hdvietnam/android/a/d.O:Ljava/lang/String;
        //   208: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   211: astore          9
        //   213: aload           8
        //   215: getstatic       com/hdvietnam/android/a/d.P:Ljava/lang/String;
        //   218: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   221: astore          10
        //   223: aload           8
        //   225: getstatic       com/hdvietnam/android/a/d.Q:Ljava/lang/String;
        //   228: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   231: astore          11
        //   233: aload           8
        //   235: getstatic       com/hdvietnam/android/a/d.R:Ljava/lang/String;
        //   238: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   241: astore          12
        //   243: aload           8
        //   245: getstatic       com/hdvietnam/android/a/d.S:Ljava/lang/String;
        //   248: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   251: astore          13
        //   253: aload           8
        //   255: getstatic       com/hdvietnam/android/a/d.T:Ljava/lang/String;
        //   258: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   261: astore          14
        //   263: aload           8
        //   265: getstatic       com/hdvietnam/android/a/d.U:Ljava/lang/String;
        //   268: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   271: astore          15
        //   273: aload           8
        //   275: getstatic       com/hdvietnam/android/a/d.V:Ljava/lang/String;
        //   278: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   281: astore          16
        //   283: aload           8
        //   285: getstatic       com/hdvietnam/android/a/d.W:Ljava/lang/String;
        //   288: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   291: astore          17
        //   293: aload           8
        //   295: getstatic       com/hdvietnam/android/a/d.X:Ljava/lang/String;
        //   298: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   301: astore          18
        //   303: aload           8
        //   305: getstatic       com/hdvietnam/android/a/d.Y:Ljava/lang/String;
        //   308: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   311: astore          19
        //   313: aload           8
        //   315: getstatic       com/hdvietnam/android/a/d.Z:Ljava/lang/String;
        //   318: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   321: astore          20
        //   323: aload           8
        //   325: getstatic       com/hdvietnam/android/a/d.aa:Ljava/lang/String;
        //   328: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   331: astore          21
        //   333: aload           8
        //   335: getstatic       com/hdvietnam/android/a/d.ab:Ljava/lang/String;
        //   338: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   341: astore          22
        //   343: aload           8
        //   345: getstatic       com/hdvietnam/android/a/d.ac:Ljava/lang/String;
        //   348: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   351: astore          23
        //   353: aload           23
        //   355: ifnull          366
        //   358: aload           23
        //   360: ldc_w           ""
        //   363: if_acmpne       673
        //   366: getstatic       com/hdvietnam/android/a/d.aW:Ljava/lang/String;
        //   369: astore          24
        //   371: new             Lcom/hdvietnam/android/a/l;
        //   374: dup            
        //   375: aload           9
        //   377: aload           10
        //   379: aload           11
        //   381: aload           12
        //   383: aload           13
        //   385: aload           14
        //   387: aload           15
        //   389: aload           16
        //   391: aload           17
        //   393: aload           18
        //   395: aload           19
        //   397: aload           20
        //   399: aload           21
        //   401: aload           22
        //   403: aload           24
        //   405: invokespecial   com/hdvietnam/android/a/l.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   408: putstatic       com/hdvietnam/android/a/d.t:Lcom/hdvietnam/android/a/l;
        //   411: aload           8
        //   413: getstatic       com/hdvietnam/android/a/d.ad:Ljava/lang/String;
        //   416: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   419: astore          44
        //   421: aload           44
        //   423: astore          26
        //   425: aload           26
        //   427: ifnull          455
        //   430: aload           26
        //   432: ldc_w           ","
        //   435: invokevirtual   java/lang/String.split:(Ljava/lang/String;)[Ljava/lang/String;
        //   438: astore          38
        //   440: iconst_0       
        //   441: istore          39
        //   443: aload           38
        //   445: arraylength    
        //   446: istore          40
        //   448: iload           39
        //   450: iload           40
        //   452: if_icmplt       703
        //   455: aload           8
        //   457: getstatic       com/hdvietnam/android/a/d.af:Ljava/lang/String;
        //   460: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   463: astore          28
        //   465: aload           28
        //   467: getstatic       com/hdvietnam/android/a/d.ah:Ljava/lang/String;
        //   470: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   473: astore          37
        //   475: new             Lcom/hdvietnam/android/a/q;
        //   478: dup            
        //   479: aload           37
        //   481: getstatic       com/hdvietnam/android/a/d.ak:Ljava/lang/String;
        //   484: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   487: ldc_w           "[timestamp]"
        //   490: ldc_w           ""
        //   493: invokevirtual   java/lang/String.replace:(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
        //   496: aload           37
        //   498: getstatic       com/hdvietnam/android/a/d.am:Ljava/lang/String;
        //   501: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   504: aload           37
        //   506: getstatic       com/hdvietnam/android/a/d.an:Ljava/lang/String;
        //   509: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   512: invokespecial   com/hdvietnam/android/a/q.<init>:(Ljava/lang/String;II)V
        //   515: putstatic       com/hdvietnam/android/a/a.a:Lcom/hdvietnam/android/a/q;
        //   518: aload           28
        //   520: getstatic       com/hdvietnam/android/a/d.ai:Ljava/lang/String;
        //   523: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   526: astore          36
        //   528: new             Lcom/hdvietnam/android/a/o;
        //   531: dup            
        //   532: aload           36
        //   534: getstatic       com/hdvietnam/android/a/d.ak:Ljava/lang/String;
        //   537: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   540: ldc_w           "[timestamp]"
        //   543: ldc_w           ""
        //   546: invokevirtual   java/lang/String.replace:(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
        //   549: aload           36
        //   551: getstatic       com/hdvietnam/android/a/d.am:Ljava/lang/String;
        //   554: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   557: aload           36
        //   559: getstatic       com/hdvietnam/android/a/d.an:Ljava/lang/String;
        //   562: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   565: sipush          1000
        //   568: aload           36
        //   570: getstatic       com/hdvietnam/android/a/d.al:Ljava/lang/String;
        //   573: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   576: imul           
        //   577: invokespecial   com/hdvietnam/android/a/o.<init>:(Ljava/lang/String;III)V
        //   580: putstatic       com/hdvietnam/android/a/a.b:Lcom/hdvietnam/android/a/o;
        //   583: aload           28
        //   585: getstatic       com/hdvietnam/android/a/d.ag:Ljava/lang/String;
        //   588: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   591: astore          32
        //   593: aload           32
        //   595: getstatic       com/hdvietnam/android/a/d.aj:Ljava/lang/String;
        //   598: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   601: istore          35
        //   603: iload           35
        //   605: sipush          1000
        //   608: imul           
        //   609: istore          34
        //   611: new             Lcom/hdvietnam/android/a/k;
        //   614: dup            
        //   615: aload           32
        //   617: getstatic       com/hdvietnam/android/a/d.ak:Ljava/lang/String;
        //   620: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   623: ldc_w           "[timestamp]"
        //   626: ldc_w           ""
        //   629: invokevirtual   java/lang/String.replace:(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
        //   632: iload           34
        //   634: aload           32
        //   636: getstatic       com/hdvietnam/android/a/d.an:Ljava/lang/String;
        //   639: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   642: sipush          1000
        //   645: aload           32
        //   647: getstatic       com/hdvietnam/android/a/d.al:Ljava/lang/String;
        //   650: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   653: imul           
        //   654: invokespecial   com/hdvietnam/android/a/k.<init>:(Ljava/lang/String;III)V
        //   657: putstatic       com/hdvietnam/android/a/a.c:Lcom/hdvietnam/android/a/k;
        //   660: aload           28
        //   662: getstatic       com/hdvietnam/android/a/d.ao:Ljava/lang/String;
        //   665: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   668: putstatic       com/hdvietnam/android/a/a.i:I
        //   671: iconst_0       
        //   672: ireturn        
        //   673: new             Ljava/lang/StringBuilder;
        //   676: dup            
        //   677: aload           23
        //   679: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   682: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   685: astore          45
        //   687: aload           45
        //   689: ldc_w           "?"
        //   692: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   695: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   698: astore          24
        //   700: goto            371
        //   703: getstatic       com/hdvietnam/android/a/d.t:Lcom/hdvietnam/android/a/l;
        //   706: pop            
        //   707: aload           38
        //   709: iload           39
        //   711: aaload         
        //   712: astore          42
        //   714: getstatic       com/hdvietnam/android/a/l.p:Ljava/util/ArrayList;
        //   717: aload           42
        //   719: invokevirtual   java/util/ArrayList.add:(Ljava/lang/Object;)Z
        //   722: pop            
        //   723: iinc            39, 1
        //   726: goto            443
        //   729: astore          33
        //   731: iconst_m1      
        //   732: istore          34
        //   734: goto            611
        //   737: astore          31
        //   739: aconst_null    
        //   740: putstatic       com/hdvietnam/android/a/a.c:Lcom/hdvietnam/android/a/k;
        //   743: goto            660
        //   746: astore          27
        //   748: sipush          10000
        //   751: putstatic       com/hdvietnam/android/a/a.i:I
        //   754: goto            671
        //   757: astore          4
        //   759: aconst_null    
        //   760: putstatic       com/hdvietnam/android/a/d.t:Lcom/hdvietnam/android/a/l;
        //   763: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //   766: new             Ljava/lang/StringBuilder;
        //   769: dup            
        //   770: ldc_w           "Ex GetConfig::"
        //   773: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   776: aload           4
        //   778: invokevirtual   java/lang/Exception.toString:()Ljava/lang/String;
        //   781: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   784: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   787: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   790: iconst_m1      
        //   791: ireturn        
        //   792: astore          30
        //   794: goto            583
        //   797: astore          29
        //   799: goto            518
        //   802: astore          46
        //   804: iload           7
        //   806: ireturn        
        //   807: astore          25
        //   809: aconst_null    
        //   810: astore          26
        //   812: goto            425
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  117    125    757    792    Ljava/lang/Exception;
        //  130    137    757    792    Ljava/lang/Exception;
        //  137    174    757    792    Ljava/lang/Exception;
        //  179    190    802    807    Ljava/lang/Exception;
        //  193    353    757    792    Ljava/lang/Exception;
        //  366    371    757    792    Ljava/lang/Exception;
        //  371    411    757    792    Ljava/lang/Exception;
        //  411    421    807    815    Ljava/lang/Exception;
        //  430    440    757    792    Ljava/lang/Exception;
        //  443    448    757    792    Ljava/lang/Exception;
        //  455    465    746    757    Ljava/lang/Exception;
        //  465    518    797    802    Ljava/lang/Exception;
        //  518    583    792    797    Ljava/lang/Exception;
        //  583    593    737    746    Ljava/lang/Exception;
        //  593    603    729    737    Ljava/lang/Exception;
        //  611    660    737    746    Ljava/lang/Exception;
        //  660    671    746    757    Ljava/lang/Exception;
        //  673    700    757    792    Ljava/lang/Exception;
        //  703    723    757    792    Ljava/lang/Exception;
        //  739    743    746    757    Ljava/lang/Exception;
        //  748    754    757    792    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index: 339, Size: 339
        //     at java.util.ArrayList.rangeCheck(ArrayList.java:635)
        //     at java.util.ArrayList.get(ArrayList.java:411)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(Unknown Source)
        //     at com.strobel.decompiler.ast.AstBuilder.build(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static int c() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: ldc_w           ""
        //     3: invokestatic    com/hdvietnam/android/a/m.a:(Ljava/lang/String;)Ljava/lang/String;
        //     6: astore_0       
        //     7: new             Lcom/hdvietnam/android/b/a;
        //    10: dup            
        //    11: new             Ljava/lang/StringBuilder;
        //    14: dup            
        //    15: getstatic       com/hdvietnam/android/a/d.ap:Ljava/lang/String;
        //    18: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    21: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    24: getstatic       com/hdvietnam/android/a/d.N:Ljava/lang/String;
        //    27: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    30: aload_0        
        //    31: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    34: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    37: invokespecial   com/hdvietnam/android/b/a.<init>:(Ljava/lang/String;)V
        //    40: invokevirtual   com/hdvietnam/android/b/a.a:()Ljava/lang/String;
        //    43: astore_1       
        //    44: aload_1        
        //    45: bipush          123
        //    47: invokevirtual   java/lang/String.indexOf:(I)I
        //    50: istore_3       
        //    51: iload_3        
        //    52: ifle            61
        //    55: aload_1        
        //    56: iload_3        
        //    57: invokevirtual   java/lang/String.substring:(I)Ljava/lang/String;
        //    60: astore_1       
        //    61: new             La/a/c;
        //    64: dup            
        //    65: aload_1        
        //    66: invokespecial   a/a/c.<init>:(Ljava/lang/String;)V
        //    69: astore          4
        //    71: aload           4
        //    73: getstatic       com/hdvietnam/android/a/d.y:Ljava/lang/String;
        //    76: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //    79: istore          5
        //    81: iload           5
        //    83: ifeq            100
        //    86: aload           4
        //    88: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //    91: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //    94: putstatic       com/hdvietnam/android/a/d.d:Ljava/lang/String;
        //    97: iload           5
        //    99: ireturn        
        //   100: getstatic       com/hdvietnam/android/a/d.u:Ljava/util/ArrayList;
        //   103: ifnonnull       144
        //   106: new             Ljava/util/ArrayList;
        //   109: dup            
        //   110: invokespecial   java/util/ArrayList.<init>:()V
        //   113: putstatic       com/hdvietnam/android/a/d.u:Ljava/util/ArrayList;
        //   116: aload           4
        //   118: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   121: invokevirtual   a/a/c.d:(Ljava/lang/String;)La/a/a;
        //   124: astore          6
        //   126: iconst_0       
        //   127: istore          7
        //   129: iload           7
        //   131: aload           6
        //   133: getfield        a/a/a.a:Ljava/util/ArrayList;
        //   136: invokevirtual   java/util/ArrayList.size:()I
        //   139: if_icmplt       186
        //   142: iconst_0       
        //   143: ireturn        
        //   144: getstatic       com/hdvietnam/android/a/d.u:Ljava/util/ArrayList;
        //   147: invokevirtual   java/util/ArrayList.clear:()V
        //   150: goto            116
        //   153: astore_2       
        //   154: aconst_null    
        //   155: putstatic       com/hdvietnam/android/a/d.u:Ljava/util/ArrayList;
        //   158: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //   161: new             Ljava/lang/StringBuilder;
        //   164: dup            
        //   165: ldc_w           "Ex GetListCategory::"
        //   168: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   171: aload_2        
        //   172: invokevirtual   java/lang/Exception.toString:()Ljava/lang/String;
        //   175: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   178: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   181: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   184: iconst_m1      
        //   185: ireturn        
        //   186: aload           6
        //   188: iload           7
        //   190: invokevirtual   a/a/a.b:(I)La/a/c;
        //   193: astore          8
        //   195: aload           8
        //   197: getstatic       com/hdvietnam/android/a/d.aq:Ljava/lang/String;
        //   200: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   203: istore          9
        //   205: aload           8
        //   207: getstatic       com/hdvietnam/android/a/d.ar:Ljava/lang/String;
        //   210: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   213: astore          16
        //   215: aload           16
        //   217: astore          11
        //   219: aload           8
        //   221: getstatic       com/hdvietnam/android/a/d.at:Ljava/lang/String;
        //   224: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   227: astore          18
        //   229: aload           18
        //   231: astore          13
        //   233: aload           11
        //   235: astore          12
        //   237: new             Lcom/hdvietnam/android/a/g;
        //   240: dup            
        //   241: iload           9
        //   243: aload           12
        //   245: aload           8
        //   247: getstatic       com/hdvietnam/android/a/d.as:Ljava/lang/String;
        //   250: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   253: aload           13
        //   255: aload           8
        //   257: getstatic       com/hdvietnam/android/a/d.au:Ljava/lang/String;
        //   260: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   263: invokespecial   com/hdvietnam/android/a/g.<init>:(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   266: astore          14
        //   268: getstatic       com/hdvietnam/android/a/d.u:Ljava/util/ArrayList;
        //   271: aload           14
        //   273: invokevirtual   java/util/ArrayList.add:(Ljava/lang/Object;)Z
        //   276: pop            
        //   277: iinc            7, 1
        //   280: goto            129
        //   283: astore          10
        //   285: aconst_null    
        //   286: astore          11
        //   288: aload           11
        //   290: astore          12
        //   292: aconst_null    
        //   293: astore          13
        //   295: goto            237
        //   298: astore          17
        //   300: goto            288
        //   303: astore          19
        //   305: iload           5
        //   307: ireturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  44     51     153    186    Ljava/lang/Exception;
        //  55     61     153    186    Ljava/lang/Exception;
        //  61     81     153    186    Ljava/lang/Exception;
        //  86     97     303    308    Ljava/lang/Exception;
        //  100    116    153    186    Ljava/lang/Exception;
        //  116    126    153    186    Ljava/lang/Exception;
        //  129    142    153    186    Ljava/lang/Exception;
        //  144    150    153    186    Ljava/lang/Exception;
        //  186    205    153    186    Ljava/lang/Exception;
        //  205    215    283    288    Ljava/lang/Exception;
        //  219    229    298    303    Ljava/lang/Exception;
        //  237    277    153    186    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0100:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: ldc_w           ""
        //     3: invokestatic    com/hdvietnam/android/a/m.a:(Ljava/lang/String;)Ljava/lang/String;
        //     6: astore_0       
        //     7: new             Lcom/hdvietnam/android/b/a;
        //    10: dup            
        //    11: new             Ljava/lang/StringBuilder;
        //    14: dup            
        //    15: getstatic       com/hdvietnam/android/a/d.ap:Ljava/lang/String;
        //    18: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    21: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    24: getstatic       com/hdvietnam/android/a/d.N:Ljava/lang/String;
        //    27: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    30: aload_0        
        //    31: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    34: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    37: invokespecial   com/hdvietnam/android/b/a.<init>:(Ljava/lang/String;)V
        //    40: invokevirtual   com/hdvietnam/android/b/a.a:()Ljava/lang/String;
        //    43: astore_1       
        //    44: aload_1        
        //    45: bipush          123
        //    47: invokevirtual   java/lang/String.indexOf:(I)I
        //    50: istore_3       
        //    51: iload_3        
        //    52: ifle            61
        //    55: aload_1        
        //    56: iload_3        
        //    57: invokevirtual   java/lang/String.substring:(I)Ljava/lang/String;
        //    60: astore_1       
        //    61: new             La/a/c;
        //    64: dup            
        //    65: aload_1        
        //    66: invokespecial   a/a/c.<init>:(Ljava/lang/String;)V
        //    69: astore          4
        //    71: aload           4
        //    73: getstatic       com/hdvietnam/android/a/d.y:Ljava/lang/String;
        //    76: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //    79: istore          5
        //    81: iload           5
        //    83: ifeq            100
        //    86: aload           4
        //    88: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //    91: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //    94: putstatic       com/hdvietnam/android/a/d.d:Ljava/lang/String;
        //    97: iload           5
        //    99: ireturn        
        //   100: getstatic       com/hdvietnam/android/a/d.u:Ljava/util/ArrayList;
        //   103: ifnonnull       144
        //   106: new             Ljava/util/ArrayList;
        //   109: dup            
        //   110: invokespecial   java/util/ArrayList.<init>:()V
        //   113: putstatic       com/hdvietnam/android/a/d.u:Ljava/util/ArrayList;
        //   116: aload           4
        //   118: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   121: invokevirtual   a/a/c.d:(Ljava/lang/String;)La/a/a;
        //   124: astore          6
        //   126: iconst_0       
        //   127: istore          7
        //   129: iload           7
        //   131: aload           6
        //   133: getfield        a/a/a.a:Ljava/util/ArrayList;
        //   136: invokevirtual   java/util/ArrayList.size:()I
        //   139: if_icmplt       186
        //   142: iconst_0       
        //   143: ireturn        
        //   144: getstatic       com/hdvietnam/android/a/d.u:Ljava/util/ArrayList;
        //   147: invokevirtual   java/util/ArrayList.clear:()V
        //   150: goto            116
        //   153: astore_2       
        //   154: aconst_null    
        //   155: putstatic       com/hdvietnam/android/a/d.u:Ljava/util/ArrayList;
        //   158: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //   161: new             Ljava/lang/StringBuilder;
        //   164: dup            
        //   165: ldc_w           "Ex GetListCategory::"
        //   168: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   171: aload_2        
        //   172: invokevirtual   java/lang/Exception.toString:()Ljava/lang/String;
        //   175: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   178: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   181: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   184: iconst_m1      
        //   185: ireturn        
        //   186: aload           6
        //   188: iload           7
        //   190: invokevirtual   a/a/a.b:(I)La/a/c;
        //   193: astore          8
        //   195: aload           8
        //   197: getstatic       com/hdvietnam/android/a/d.aq:Ljava/lang/String;
        //   200: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   203: istore          9
        //   205: aload           8
        //   207: getstatic       com/hdvietnam/android/a/d.ar:Ljava/lang/String;
        //   210: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   213: astore          16
        //   215: aload           16
        //   217: astore          11
        //   219: aload           8
        //   221: getstatic       com/hdvietnam/android/a/d.at:Ljava/lang/String;
        //   224: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   227: astore          18
        //   229: aload           18
        //   231: astore          13
        //   233: aload           11
        //   235: astore          12
        //   237: new             Lcom/hdvietnam/android/a/g;
        //   240: dup            
        //   241: iload           9
        //   243: aload           12
        //   245: aload           8
        //   247: getstatic       com/hdvietnam/android/a/d.as:Ljava/lang/String;
        //   250: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   253: aload           13
        //   255: aload           8
        //   257: getstatic       com/hdvietnam/android/a/d.au:Ljava/lang/String;
        //   260: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   263: invokespecial   com/hdvietnam/android/a/g.<init>:(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   266: astore          14
        //   268: getstatic       com/hdvietnam/android/a/d.u:Ljava/util/ArrayList;
        //   271: aload           14
        //   273: invokevirtual   java/util/ArrayList.add:(Ljava/lang/Object;)Z
        //   276: pop            
        //   277: iinc            7, 1
        //   280: goto            129
        //   283: astore          10
        //   285: aconst_null    
        //   286: astore          11
        //   288: aload           11
        //   290: astore          12
        //   292: aconst_null    
        //   293: astore          13
        //   295: goto            237
        //   298: astore          17
        //   300: goto            288
        //   303: astore          19
        //   305: iload           5
        //   307: ireturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  44     51     153    186    Ljava/lang/Exception;
        //  55     61     153    186    Ljava/lang/Exception;
        //  61     81     153    186    Ljava/lang/Exception;
        //  86     97     303    308    Ljava/lang/Exception;
        //  100    116    153    186    Ljava/lang/Exception;
        //  116    126    153    186    Ljava/lang/Exception;
        //  129    142    153    186    Ljava/lang/Exception;
        //  144    150    153    186    Ljava/lang/Exception;
        //  186    205    153    186    Ljava/lang/Exception;
        //  205    215    283    288    Ljava/lang/Exception;
        //  219    229    298    303    Ljava/lang/Exception;
        //  237    277    153    186    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0100:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static int d() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: ldc_w           ""
        //     3: invokestatic    com/hdvietnam/android/a/m.a:(Ljava/lang/String;)Ljava/lang/String;
        //     6: astore_0       
        //     7: new             Lcom/hdvietnam/android/b/a;
        //    10: dup            
        //    11: new             Ljava/lang/StringBuilder;
        //    14: dup            
        //    15: getstatic       com/hdvietnam/android/a/d.av:Ljava/lang/String;
        //    18: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    21: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    24: getstatic       com/hdvietnam/android/a/d.N:Ljava/lang/String;
        //    27: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    30: aload_0        
        //    31: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    34: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    37: invokespecial   com/hdvietnam/android/b/a.<init>:(Ljava/lang/String;)V
        //    40: invokevirtual   com/hdvietnam/android/b/a.a:()Ljava/lang/String;
        //    43: astore_1       
        //    44: aload_1        
        //    45: bipush          123
        //    47: invokevirtual   java/lang/String.indexOf:(I)I
        //    50: istore_3       
        //    51: iload_3        
        //    52: ifle            61
        //    55: aload_1        
        //    56: iload_3        
        //    57: invokevirtual   java/lang/String.substring:(I)Ljava/lang/String;
        //    60: astore_1       
        //    61: new             La/a/c;
        //    64: dup            
        //    65: aload_1        
        //    66: invokespecial   a/a/c.<init>:(Ljava/lang/String;)V
        //    69: astore          4
        //    71: aload           4
        //    73: getstatic       com/hdvietnam/android/a/d.y:Ljava/lang/String;
        //    76: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //    79: istore          5
        //    81: iload           5
        //    83: ifeq            100
        //    86: aload           4
        //    88: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //    91: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //    94: putstatic       com/hdvietnam/android/a/d.f:Ljava/lang/String;
        //    97: iload           5
        //    99: ireturn        
        //   100: aload           4
        //   102: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   105: invokevirtual   a/a/c.d:(Ljava/lang/String;)La/a/a;
        //   108: astore          6
        //   110: getstatic       com/hdvietnam/android/a/d.v:Ljava/util/ArrayList;
        //   113: ifnonnull       144
        //   116: new             Ljava/util/ArrayList;
        //   119: dup            
        //   120: invokespecial   java/util/ArrayList.<init>:()V
        //   123: putstatic       com/hdvietnam/android/a/d.v:Ljava/util/ArrayList;
        //   126: goto            248
        //   129: iload           7
        //   131: aload           6
        //   133: getfield        a/a/a.a:Ljava/util/ArrayList;
        //   136: invokevirtual   java/util/ArrayList.size:()I
        //   139: if_icmplt       186
        //   142: iconst_0       
        //   143: ireturn        
        //   144: getstatic       com/hdvietnam/android/a/d.v:Ljava/util/ArrayList;
        //   147: invokevirtual   java/util/ArrayList.clear:()V
        //   150: goto            248
        //   153: astore_2       
        //   154: aconst_null    
        //   155: putstatic       com/hdvietnam/android/a/d.v:Ljava/util/ArrayList;
        //   158: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //   161: new             Ljava/lang/StringBuilder;
        //   164: dup            
        //   165: ldc_w           "Ex GetListChannel::"
        //   168: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   171: aload_2        
        //   172: invokevirtual   java/lang/Exception.toString:()Ljava/lang/String;
        //   175: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   178: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   181: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   184: iconst_m1      
        //   185: ireturn        
        //   186: aload           6
        //   188: iload           7
        //   190: invokevirtual   a/a/a.b:(I)La/a/c;
        //   193: astore          8
        //   195: new             Lcom/hdvietnam/android/a/i;
        //   198: dup            
        //   199: aload           8
        //   201: getstatic       com/hdvietnam/android/a/d.ay:Ljava/lang/String;
        //   204: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   207: aload           8
        //   209: getstatic       com/hdvietnam/android/a/d.aw:Ljava/lang/String;
        //   212: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   215: aload           8
        //   217: getstatic       com/hdvietnam/android/a/d.ax:Ljava/lang/String;
        //   220: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   223: invokespecial   com/hdvietnam/android/a/i.<init>:(ILjava/lang/String;Ljava/lang/String;)V
        //   226: astore          9
        //   228: getstatic       com/hdvietnam/android/a/d.v:Ljava/util/ArrayList;
        //   231: aload           9
        //   233: invokevirtual   java/util/ArrayList.add:(Ljava/lang/Object;)Z
        //   236: pop            
        //   237: iinc            7, 1
        //   240: goto            129
        //   243: astore          11
        //   245: iload           5
        //   247: ireturn        
        //   248: iconst_0       
        //   249: istore          7
        //   251: goto            129
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  44     51     153    186    Ljava/lang/Exception;
        //  55     61     153    186    Ljava/lang/Exception;
        //  61     81     153    186    Ljava/lang/Exception;
        //  86     97     243    248    Ljava/lang/Exception;
        //  100    126    153    186    Ljava/lang/Exception;
        //  129    142    153    186    Ljava/lang/Exception;
        //  144    150    153    186    Ljava/lang/Exception;
        //  186    237    153    186    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0100:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: ldc_w           ""
        //     3: invokestatic    com/hdvietnam/android/a/m.a:(Ljava/lang/String;)Ljava/lang/String;
        //     6: astore_0       
        //     7: new             Lcom/hdvietnam/android/b/a;
        //    10: dup            
        //    11: new             Ljava/lang/StringBuilder;
        //    14: dup            
        //    15: getstatic       com/hdvietnam/android/a/d.av:Ljava/lang/String;
        //    18: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //    21: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    24: getstatic       com/hdvietnam/android/a/d.N:Ljava/lang/String;
        //    27: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    30: aload_0        
        //    31: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    34: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    37: invokespecial   com/hdvietnam/android/b/a.<init>:(Ljava/lang/String;)V
        //    40: invokevirtual   com/hdvietnam/android/b/a.a:()Ljava/lang/String;
        //    43: astore_1       
        //    44: aload_1        
        //    45: bipush          123
        //    47: invokevirtual   java/lang/String.indexOf:(I)I
        //    50: istore_3       
        //    51: iload_3        
        //    52: ifle            61
        //    55: aload_1        
        //    56: iload_3        
        //    57: invokevirtual   java/lang/String.substring:(I)Ljava/lang/String;
        //    60: astore_1       
        //    61: new             La/a/c;
        //    64: dup            
        //    65: aload_1        
        //    66: invokespecial   a/a/c.<init>:(Ljava/lang/String;)V
        //    69: astore          4
        //    71: aload           4
        //    73: getstatic       com/hdvietnam/android/a/d.y:Ljava/lang/String;
        //    76: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //    79: istore          5
        //    81: iload           5
        //    83: ifeq            100
        //    86: aload           4
        //    88: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //    91: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //    94: putstatic       com/hdvietnam/android/a/d.f:Ljava/lang/String;
        //    97: iload           5
        //    99: ireturn        
        //   100: aload           4
        //   102: getstatic       com/hdvietnam/android/a/d.z:Ljava/lang/String;
        //   105: invokevirtual   a/a/c.d:(Ljava/lang/String;)La/a/a;
        //   108: astore          6
        //   110: getstatic       com/hdvietnam/android/a/d.v:Ljava/util/ArrayList;
        //   113: ifnonnull       144
        //   116: new             Ljava/util/ArrayList;
        //   119: dup            
        //   120: invokespecial   java/util/ArrayList.<init>:()V
        //   123: putstatic       com/hdvietnam/android/a/d.v:Ljava/util/ArrayList;
        //   126: goto            248
        //   129: iload           7
        //   131: aload           6
        //   133: getfield        a/a/a.a:Ljava/util/ArrayList;
        //   136: invokevirtual   java/util/ArrayList.size:()I
        //   139: if_icmplt       186
        //   142: iconst_0       
        //   143: ireturn        
        //   144: getstatic       com/hdvietnam/android/a/d.v:Ljava/util/ArrayList;
        //   147: invokevirtual   java/util/ArrayList.clear:()V
        //   150: goto            248
        //   153: astore_2       
        //   154: aconst_null    
        //   155: putstatic       com/hdvietnam/android/a/d.v:Ljava/util/ArrayList;
        //   158: getstatic       java/lang/System.out:Ljava/io/PrintStream;
        //   161: new             Ljava/lang/StringBuilder;
        //   164: dup            
        //   165: ldc_w           "Ex GetListChannel::"
        //   168: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   171: aload_2        
        //   172: invokevirtual   java/lang/Exception.toString:()Ljava/lang/String;
        //   175: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   178: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   181: invokevirtual   java/io/PrintStream.println:(Ljava/lang/String;)V
        //   184: iconst_m1      
        //   185: ireturn        
        //   186: aload           6
        //   188: iload           7
        //   190: invokevirtual   a/a/a.b:(I)La/a/c;
        //   193: astore          8
        //   195: new             Lcom/hdvietnam/android/a/i;
        //   198: dup            
        //   199: aload           8
        //   201: getstatic       com/hdvietnam/android/a/d.ay:Ljava/lang/String;
        //   204: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   207: aload           8
        //   209: getstatic       com/hdvietnam/android/a/d.aw:Ljava/lang/String;
        //   212: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   215: aload           8
        //   217: getstatic       com/hdvietnam/android/a/d.ax:Ljava/lang/String;
        //   220: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   223: invokespecial   com/hdvietnam/android/a/i.<init>:(ILjava/lang/String;Ljava/lang/String;)V
        //   226: astore          9
        //   228: getstatic       com/hdvietnam/android/a/d.v:Ljava/util/ArrayList;
        //   231: aload           9
        //   233: invokevirtual   java/util/ArrayList.add:(Ljava/lang/Object;)Z
        //   236: pop            
        //   237: iinc            7, 1
        //   240: goto            129
        //   243: astore          11
        //   245: iload           5
        //   247: ireturn        
        //   248: iconst_0       
        //   249: istore          7
        //   251: goto            129
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  44     51     153    186    Ljava/lang/Exception;
        //  55     61     153    186    Ljava/lang/Exception;
        //  61     81     153    186    Ljava/lang/Exception;
        //  86     97     243    248    Ljava/lang/Exception;
        //  100    126    153    186    Ljava/lang/Exception;
        //  129    142    153    186    Ljava/lang/Exception;
        //  144    150    153    186    Ljava/lang/Exception;
        //  186    237    153    186    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0100:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
