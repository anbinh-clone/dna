package com.hdvietnam.android.a;

public final class c
{
    public String a;
    public String b;
    public int c;
    
    public c(final String a, final String b, final int c) {
        super();
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
