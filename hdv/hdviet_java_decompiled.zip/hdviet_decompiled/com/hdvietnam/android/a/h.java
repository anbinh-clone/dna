package com.hdvietnam.android.a;

public final class h
{
    public String a;
    public String b;
    public String c;
    public int d;
    
    public h(final int d, final String c, final String s, final String a, final String b) {
        super();
        this.d = d;
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
