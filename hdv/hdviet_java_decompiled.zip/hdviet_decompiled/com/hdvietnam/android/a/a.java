package com.hdvietnam.android.a;

import org.w3c.dom.NodeList;
import org.w3c.dom.Element;
import javax.xml.parsers.DocumentBuilder;
import java.io.IOException;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import android.util.Log;
import java.io.Reader;
import java.io.StringReader;
import org.xml.sax.InputSource;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.Context;
import com.hdvietnam.android.b.a;
import java.util.ArrayList;

public final class a
{
    public static q a;
    public static o b;
    public static k c;
    public static String d;
    public static int e;
    public static int f;
    public static ArrayList g;
    public static ArrayList h;
    public static int i;
    private static ArrayList j;
    private static ArrayList k;
    
    static {
        a.i = 15000;
    }
    
    public static String a(final String s) {
        a.d = null;
        a.j = new ArrayList();
        a.k = new ArrayList();
        a.g = new ArrayList();
        a.h = new ArrayList();
        if (s == null || s.length() == 0) {
            return null;
        }
        return c(s);
    }
    
    public static void a() {
        for (int i = 0; i < a.j.size(); ++i) {
            new a((String)a.j.get(i)).a();
        }
    }
    
    public static void a(final Context context) {
        if (a.c != null && a.c.e) {
            a.c.e = false;
            new Thread(new b()).start();
            if (a.h != null && a.h.size() > 0) {
                ((Activity)context).startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)a.h.get(-1 + a.h.size()))));
            }
        }
    }
    
    private static Document b(final String s) {
        final DocumentBuilderFactory instance = DocumentBuilderFactory.newInstance();
        try {
            final DocumentBuilder documentBuilder = instance.newDocumentBuilder();
            final InputSource inputSource = new InputSource();
            inputSource.setCharacterStream(new StringReader(s));
            return documentBuilder.parse(inputSource);
        }
        catch (ParserConfigurationException ex) {
            Log.e("Error: ", ex.getMessage());
            return null;
        }
        catch (SAXException ex2) {
            Log.e("Error: ", ex2.getMessage());
            return null;
        }
        catch (IOException ex3) {
            Log.e("Error: ", ex3.getMessage());
            return null;
        }
    }
    
    private static String c(final String s) {
        final String a = new a(s).a();
        if (a == null) {
            return null;
        }
        try {
            final Document b = b(a);
            final NodeList elementsByTagName = b.getElementsByTagName("VASTAdTagURI");
            final NodeList elementsByTagName2 = b.getElementsByTagName("Error");
            if (elementsByTagName2.getLength() > 0) {
                a.k.add(elementsByTagName2.item(0).getTextContent());
            }
            final NodeList elementsByTagName3 = b.getElementsByTagName("Impression");
            if (elementsByTagName3.getLength() > 0) {
                a.j.add(elementsByTagName3.item(0).getTextContent());
            }
            final NodeList elementsByTagName4 = b.getElementsByTagName("NonLinearClickThrough");
            if (elementsByTagName4.getLength() > 0) {
                a.h.add(elementsByTagName4.item(0).getTextContent());
            }
            if (elementsByTagName.getLength() > 0) {
                return c(elementsByTagName.item(0).getChildNodes().item(0).getTextContent().replace("[timestamp]", String.valueOf(System.currentTimeMillis())));
            }
            final NodeList elementsByTagName5 = b.getElementsByTagName("NonLinear");
            if (elementsByTagName5 == null) {
                return null;
            }
            final Element element = (Element)elementsByTagName5.item(0);
            if (element == null) {
                return null;
            }
            a.e = Integer.parseInt(element.getAttribute("width"));
            a.f = Integer.parseInt(element.getAttribute("height"));
            final NodeList elementsByTagName6 = b.getElementsByTagName("StaticResource");
            if (elementsByTagName6.getLength() > 0) {
                return a.d = elementsByTagName6.item(0).getTextContent();
            }
        }
        catch (Exception ex) {
            System.out.println("eeeeeee drop box" + ex.toString());
            return null;
        }
        return null;
    }
}
