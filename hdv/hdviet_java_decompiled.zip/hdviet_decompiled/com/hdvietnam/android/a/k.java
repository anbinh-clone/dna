package com.hdvietnam.android.a;

public final class k
{
    public String a;
    public int b;
    public int c;
    public long d;
    public boolean e;
    
    public k(final String a, final int b, final int n, final int c) {
        super();
        this.d = 0L;
        this.e = false;
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
