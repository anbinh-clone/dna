package com.hdvietnam.android.a;

public final class f
{
    public static final String NONMULTIPLE4 = "NON-MULTIPLE-4";
    private static char[] a;
    private static byte[] b;
    
    static {
        f.a = new char[64];
        char c = 'A';
        int n = 0;
        while (c <= 'Z') {
            final char[] a = f.a;
            final int n2 = n + 1;
            a[n] = c;
            ++c;
            n = n2;
        }
        int n3;
        for (char c2 = 'a'; c2 <= 'z'; ++c2, n = n3) {
            final char[] a2 = f.a;
            n3 = n + 1;
            a2[n] = c2;
        }
        int n4;
        for (char c3 = '0'; c3 <= '9'; ++c3, n = n4) {
            final char[] a3 = f.a;
            n4 = n + 1;
            a3[n] = c3;
        }
        final char[] a4 = f.a;
        final int n5 = n + 1;
        a4[n] = '+';
        f.a[n5] = '/';
        f.b = new byte[128];
        int n6 = 0;
        int i;
        while (true) {
            final int length = f.b.length;
            i = 0;
            if (n6 >= length) {
                break;
            }
            f.b[n6] = -1;
            ++n6;
        }
        while (i < 64) {
            f.b[f.a[i]] = (byte)i;
            ++i;
        }
    }
    
    public static String a(final String s) {
        final byte[] bytes = s.getBytes();
        return new String(a(bytes, bytes.length));
    }
    
    private static char[] a(final byte[] array, final int n) {
        final int n2 = (2 + n * 4) / 3;
        final char[] array2 = new char[4 * ((n + 2) / 3)];
        int n3 = 0;
        int i = 0;
        while (i < n) {
            int n4 = i + 1;
            final int n5 = 0xFF & array[i];
            int n7;
            if (n4 < n) {
                final int n6 = n4 + 1;
                n7 = (0xFF & array[n4]);
                n4 = n6;
            }
            else {
                n7 = 0;
            }
            int n8;
            if (n4 < n) {
                i = n4 + 1;
                n8 = (0xFF & array[n4]);
            }
            else {
                i = n4;
                n8 = 0;
            }
            final int n9 = n5 >>> 2;
            final int n10 = (n5 & 0x3) << 4 | n7 >>> 4;
            final int n11 = (n7 & 0xF) << 2 | n8 >>> 6;
            final int n12 = n8 & 0x3F;
            final int n13 = n3 + 1;
            array2[n3] = f.a[n9];
            final int n14 = n13 + 1;
            array2[n13] = f.a[n10];
            char c;
            if (n14 < n2) {
                c = f.a[n11];
            }
            else {
                c = '=';
            }
            array2[n14] = c;
            final int n15 = n14 + 1;
            char c2;
            if (n15 < n2) {
                c2 = f.a[n12];
            }
            else {
                c2 = '=';
            }
            array2[n15] = c2;
            n3 = n15 + 1;
        }
        return array2;
    }
}
