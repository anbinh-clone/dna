package com.hdvietnam.android.a;

import java.util.ArrayList;

public final class l
{
    public static String a;
    public static String b;
    public static String c;
    public static String d;
    public static String e;
    public static String f;
    public static String g;
    public static String h;
    public static String i;
    public static String j;
    public static String k;
    public static String l;
    public static String m;
    public static String n;
    public static String o;
    public static ArrayList p;
    
    public l(final String a, final String b, final String c, final String d, final String e, final String f, final String g, final String h, final String i, final String j, final String k, final String l, final String m, final String n, final String o) {
        super();
        l.a = a;
        l.b = b;
        l.c = c;
        l.d = d;
        l.e = e;
        l.f = f;
        l.g = g;
        l.h = h;
        l.i = i;
        l.j = j;
        l.k = k;
        l.l = l;
        l.m = m;
        l.n = n;
        l.o = o;
        l.p = new ArrayList();
    }
}
