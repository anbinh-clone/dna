package com.hdvietnam.android.a;

public final class q
{
    public String a;
    public int b;
    public int c;
    
    public q(final String a, final int b, final int c) {
        super();
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
