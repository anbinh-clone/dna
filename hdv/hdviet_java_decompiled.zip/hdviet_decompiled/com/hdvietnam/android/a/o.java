package com.hdvietnam.android.a;

public final class o
{
    public String a;
    public int b;
    public int c;
    public int d;
    
    public o(final String a, final int b, final int c, final int d) {
        super();
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
}
