package com.hdvietnam.android.a;

public final class i
{
    public int a;
    public String b;
    
    public i(final int a, final String b, final String s) {
        super();
        this.a = a;
        this.b = b;
    }
}
