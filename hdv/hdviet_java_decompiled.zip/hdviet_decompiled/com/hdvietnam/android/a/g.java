package com.hdvietnam.android.a;

public final class g
{
    public int a;
    public String b;
    public String c;
    
    public g(final int a, final String s, final String b, final String s2, final String c) {
        super();
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
