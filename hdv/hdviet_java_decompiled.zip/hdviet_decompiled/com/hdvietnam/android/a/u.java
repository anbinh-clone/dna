package com.hdvietnam.android.a;

public final class u
{
    int a;
    
    public u(final int a, final int n) {
        super();
        this.a = a;
    }
}
