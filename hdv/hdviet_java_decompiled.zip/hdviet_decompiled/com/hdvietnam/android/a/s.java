package com.hdvietnam.android.a;

public final class s
{
    public int a;
    public int b;
    
    public s(final int a, final int b) {
        super();
        this.a = a;
        this.b = b;
    }
}
