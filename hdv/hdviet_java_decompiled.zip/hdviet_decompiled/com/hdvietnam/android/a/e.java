package com.hdvietnam.android.a;

public final class e
{
    static final boolean DEBUG = false;
    public static String a;
    public static String b;
    public static String c;
    public static String d;
    public static String e;
    private static int[] f;
    private static int g;
    private static int[] h;
    private static int i;
    
    static {
        f = new int[] { 94, 107, 65, 111, 108, 102, 97, 101, 97, 115, 46, 98, 113, 47, 45, 46, 48, 45, 54, 47, 49 };
        g = 21;
        final int[] array = { 71, 67, 85, 77, 63, 83, 63, 110, 96, 109, 75, 63, 98 };
        h = new int[] { 53, 100, 49, 55, 98, 100, 98, 47, 49, 52, 96, 101, 51, 101, 101, 54, 56, 47, 98, 55, 50, 50, 54, 99, 52, 48, 56, 47, 48, 55, 51, 100 };
        i = 32;
        a = "https://api.hdviet.com/channel/play?";
        b = "channelid=";
        c = "accesstokenkey=";
        d = "LinkPlay";
        e = "LinkPlayBackup";
    }
    
    public static String a() {
        String string = "";
        for (int i = 0; i < g; ++i) {
            string = String.valueOf(string) + (char)(3 + f[i]);
        }
        return string;
    }
    
    public static String b() {
        String string = "";
        for (int i = 0; i < i; ++i) {
            string = String.valueOf(string) + (char)(1 + h[i]);
        }
        return string;
    }
}
