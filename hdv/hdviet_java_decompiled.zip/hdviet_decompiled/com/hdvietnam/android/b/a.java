package com.hdvietnam.android.b;

import java.io.ByteArrayOutputStream;
import org.apache.http.client.methods.HttpUriRequest;
import java.io.InputStream;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.BasicHttpParams;
import java.net.URI;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.HttpClient;

public final class a
{
    private static final int TIMEOUT_CONNECTION = 5000;
    private static final int TIMEOUT_SOCKET = 5000;
    private static HttpClient b;
    private static int c;
    private HttpGet a;
    
    static {
        a.b = null;
        a.c = 614400;
    }
    
    public a(final String s) {
        super();
        while (true) {
            try {
                new URI(s);
                this.a = new HttpGet(s);
                final BasicHttpParams basicHttpParams = new BasicHttpParams();
                HttpConnectionParams.setConnectionTimeout((HttpParams)basicHttpParams, 5000);
                HttpConnectionParams.setSoTimeout((HttpParams)basicHttpParams, 5000);
                if (a.b == null) {
                    a.b = (HttpClient)new DefaultHttpClient((HttpParams)basicHttpParams);
                }
            }
            catch (Exception ex) {
                System.out.println("Error url:" + ex.toString());
                continue;
            }
            break;
        }
    }
    
    private InputStream b() {
        try {
            return a.b.execute((HttpUriRequest)this.a).getEntity().getContent();
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    public final String a() {
        int i = 0;
        int j = 0;
        InputStream b;
        do {
            b = this.b();
            ++j;
            if (b == null) {
                continue;
            }
            break;
        } while (j < 4);
    Label_0132_Outer:
        while (true) {
            while (true) {
                byte[] byteArray = null;
            Label_0243:
                while (true) {
                    try {
                        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        final byte[] array = new byte[a.c];
                        while (i != -1) {
                            i = b.read(array, 0, a.c);
                            if (i != -1) {
                                byteArrayOutputStream.write(array, 0, i);
                            }
                        }
                        byteArray = byteArrayOutputStream.toByteArray();
                        if (byteArray[0] == 0 && byteArray[1] == 0 && byteArray[2] == -2 && byteArray[2] == -1) {
                            new String(byteArray, "UTF-32");
                            if (byteArray[0] == -17 && byteArray[1] == -69 && byteArray[2] == -65) {
                                final String s = new String(byteArray, "UTF-8");
                                b.close();
                                return s;
                            }
                            break Label_0243;
                        }
                    }
                    catch (Exception ex) {
                        System.out.println("errrrrrrrrrr" + ex.toString());
                        return null;
                    }
                    if (byteArray[0] == -1 && byteArray[1] == -2 && byteArray[2] == 0 && byteArray[2] == 0) {
                        new String(byteArray, "UTF-32");
                        continue Label_0132_Outer;
                    }
                    continue Label_0132_Outer;
                }
                if (byteArray[0] == -2 && byteArray[1] == -1) {
                    final String s = new String(byteArray, "UTF-16");
                    continue;
                }
                if (byteArray[0] == -1 && byteArray[1] == -2) {
                    final String s = new String(byteArray, "UTF-16");
                    continue;
                }
                final String s = new String(byteArray);
                continue;
            }
        }
    }
}
