package com.hdvietnam.android.verticalslidevar;

import android.os.Parcel;
import android.os.Parcelable$Creator;

final class b implements Parcelable$Creator
{
}
