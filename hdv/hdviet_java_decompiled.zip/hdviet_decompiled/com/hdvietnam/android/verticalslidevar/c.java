package com.hdvietnam.android.verticalslidevar;

public interface c
{
    void a();
    
    void a(int p0, boolean p1);
    
    void b();
}
