package com.hdvietnam.android.verticalslidevar;

import android.graphics.drawable.Drawable$Callback;
import android.os.Parcelable;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.ViewDebug$ExportedProperty;
import android.graphics.RectF;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.LayerDrawable;
import android.content.res.TypedArray;
import com.hdvietnam.app.android.R$styleable;
import android.util.AttributeSet;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.widget.RemoteViews$RemoteView;
import android.view.View;

final class a implements Runnable
{
    private int a;
    private int b;
    private boolean c;
    private /* synthetic */ VerticalProgressBar d;
    
    a(final VerticalProgressBar d, final int a, final int b, final boolean c) {
        this.d = d;
        super();
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public final void a(final int a, final int b, final boolean c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    @Override
    public final void run() {
        this.d.a(this.a, this.b, this.c);
        VerticalProgressBar.a(this.d, this);
    }
}
