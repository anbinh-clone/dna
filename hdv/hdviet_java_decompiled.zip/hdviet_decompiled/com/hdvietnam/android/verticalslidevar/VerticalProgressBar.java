package com.hdvietnam.android.verticalslidevar;

import android.graphics.drawable.Drawable$Callback;
import android.os.Parcelable;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.ViewDebug$ExportedProperty;
import android.graphics.RectF;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.LayerDrawable;
import android.content.res.TypedArray;
import com.hdvietnam.app.android.R$styleable;
import android.util.AttributeSet;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.widget.RemoteViews$RemoteView;
import android.view.View;

@RemoteViews$RemoteView
public class VerticalProgressBar extends View
{
    private static final int MAX_LEVEL = 10000;
    int a;
    int b;
    int c;
    int d;
    private int e;
    private int f;
    private int g;
    private Drawable h;
    private Drawable i;
    private Bitmap j;
    private boolean k;
    private a l;
    private long m;
    
    public VerticalProgressBar(final Context context) {
        this(context, null);
    }
    
    public VerticalProgressBar(final Context context, final AttributeSet set) {
        this(context, set, 16842871);
    }
    
    public VerticalProgressBar(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.m = Thread.currentThread().getId();
        this.g = 100;
        this.e = 0;
        this.f = 0;
        this.a = 24;
        this.b = 48;
        this.c = 24;
        this.d = 48;
        final TypedArray obtainStyledAttributes = context.obtainStyledAttributes(set, R$styleable.ProgressBar, n, 0);
        this.k = true;
        final Drawable drawable = obtainStyledAttributes.getDrawable(5);
        if (drawable != null) {
            this.setProgressDrawable(this.a(drawable, false));
        }
        this.a = obtainStyledAttributes.getDimensionPixelSize(6, this.a);
        this.b = obtainStyledAttributes.getDimensionPixelSize(0, this.b);
        this.c = obtainStyledAttributes.getDimensionPixelSize(7, this.c);
        this.d = obtainStyledAttributes.getDimensionPixelSize(1, this.d);
        this.setMax(obtainStyledAttributes.getInt(2, this.g));
        this.setProgress(obtainStyledAttributes.getInt(3, this.e));
        this.setSecondaryProgress(obtainStyledAttributes.getInt(4, this.f));
        this.k = false;
        obtainStyledAttributes.recycle();
    }
    
    private Drawable a(Drawable drawable, final boolean b) {
        int i = 0;
        if (drawable instanceof LayerDrawable) {
            final LayerDrawable layerDrawable = (LayerDrawable)drawable;
            final int numberOfLayers = layerDrawable.getNumberOfLayers();
            final Drawable[] array = new Drawable[numberOfLayers];
            for (int j = 0; j < numberOfLayers; ++j) {
                final int id = layerDrawable.getId(j);
                array[j] = this.a(layerDrawable.getDrawable(j), id == 16908301 || id == 16908303);
            }
            final Object o = new LayerDrawable(array);
            while (i < numberOfLayers) {
                ((LayerDrawable)o).setId(i, layerDrawable.getId(i));
                ++i;
            }
            drawable = (Drawable)o;
        }
        else if (drawable instanceof BitmapDrawable) {
            final Bitmap bitmap = ((BitmapDrawable)drawable).getBitmap();
            if (this.j == null) {
                this.j = bitmap;
            }
            final ShapeDrawable shapeDrawable = new ShapeDrawable(this.getDrawableShape());
            if (b) {
                return (Drawable)new ClipDrawable((Drawable)shapeDrawable, 3, 1);
            }
            return (Drawable)shapeDrawable;
        }
        return drawable;
    }
    
    private void a(final int n, final int n2, final boolean b) {
    Label_0059_Outer:
        while (true) {
            while (true) {
                float n3 = 0.0f;
                Drawable drawableByLayerId = null;
                Label_0103: {
                    synchronized (this) {
                        if (this.g > 0) {
                            n3 = n2 / this.g;
                        }
                        else {
                            n3 = 0.0f;
                        }
                        final Drawable i = this.i;
                        while (true) {
                            if (i == null) {
                                this.invalidate();
                                if (n == 16908301) {
                                    this.a(n3, b);
                                }
                                return;
                            }
                            final boolean b2 = i instanceof LayerDrawable;
                            drawableByLayerId = null;
                            if (b2) {
                                drawableByLayerId = ((LayerDrawable)i).findDrawableByLayerId(n);
                            }
                            break Label_0103;
                            final int level;
                            i.setLevel(level);
                            continue Label_0059_Outer;
                        }
                    }
                }
                final int level = (int)(10000.0f * n3);
                if (drawableByLayerId != null) {
                    final Drawable i = drawableByLayerId;
                    continue;
                }
                continue;
            }
        }
    }
    
    private void b(final int n, final int n2, final boolean b) {
        while (true) {
            while (true) {
                Label_0069: {
                    synchronized (this) {
                        if (this.m == Thread.currentThread().getId()) {
                            this.a(n, n2, b);
                        }
                        else {
                            if (this.l == null) {
                                break Label_0069;
                            }
                            final a l = this.l;
                            this.l = null;
                            l.a(n, n2, b);
                            this.post((Runnable)l);
                        }
                        return;
                    }
                }
                final a l = new a(this, n, n2, b);
                continue;
            }
        }
    }
    
    void a(final float n, final boolean b) {
    }
    
    final void a(final int n, final boolean b) {
        // monitorenter(this)
        // monitorenter(this)
        while (true) {
            Label_0055: {
                if (n >= 0) {
                    break Label_0055;
                }
                int g = 0;
                try {
                    if (g > this.g) {
                        g = this.g;
                    }
                    if (g != this.e) {
                        this.b(16908301, this.e = g, b);
                    }
                    return;
                }
                finally {
                }
                // monitorexit(this)
            }
            int g = n;
            continue;
        }
    }
    
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        final int[] drawableState = this.getDrawableState();
        if (this.h != null && this.h.isStateful()) {
            this.h.setState(drawableState);
        }
    }
    
    Drawable getCurrentDrawable() {
        return this.i;
    }
    
    Shape getDrawableShape() {
        return (Shape)new RoundRectShape(new float[] { 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f, 5.0f }, (RectF)null, (float[])null);
    }
    
    @ViewDebug$ExportedProperty
    public int getMax() {
        synchronized (this) {
            return this.g;
        }
    }
    
    @ViewDebug$ExportedProperty
    public int getProgress() {
        synchronized (this) {
            return this.e;
        }
    }
    
    public Drawable getProgressDrawable() {
        return this.h;
    }
    
    @ViewDebug$ExportedProperty
    public int getSecondaryProgress() {
        synchronized (this) {
            return this.f;
        }
    }
    
    public void invalidateDrawable(final Drawable drawable) {
        if (this.verifyDrawable(drawable)) {
            final Rect bounds = drawable.getBounds();
            this.invalidate(0 + bounds.left, 0 + bounds.top, 0 + bounds.right, 0 + bounds.bottom);
            return;
        }
        super.invalidateDrawable(drawable);
    }
    
    protected void onDraw(final Canvas canvas) {
        synchronized (this) {
            super.onDraw(canvas);
            final Drawable i = this.i;
            if (i != null) {
                canvas.save();
                canvas.translate(0.0f, 0.0f);
                i.draw(canvas);
                canvas.restore();
            }
        }
    }
    
    protected void onMeasure(final int n, final int n2) {
        while (true) {
            while (true) {
                synchronized (this) {
                    final Drawable i = this.i;
                    if (i != null) {
                        final int max = Math.max(this.a, Math.min(this.b, i.getIntrinsicWidth()));
                        final int max2 = Math.max(this.c, Math.min(this.d, i.getIntrinsicHeight()));
                        this.setMeasuredDimension(resolveSize(max + 0, n), resolveSize(max2 + 0, n2));
                        return;
                    }
                }
                final int max2 = 0;
                final int max = 0;
                continue;
            }
        }
    }
    
    public void onRestoreInstanceState(final Parcelable parcelable) {
        final VerticalProgressBar$SavedState verticalProgressBar$SavedState = (VerticalProgressBar$SavedState)parcelable;
        super.onRestoreInstanceState(verticalProgressBar$SavedState.getSuperState());
        this.setProgress(verticalProgressBar$SavedState.a);
        this.setSecondaryProgress(verticalProgressBar$SavedState.b);
    }
    
    public Parcelable onSaveInstanceState() {
        final VerticalProgressBar$SavedState verticalProgressBar$SavedState = new VerticalProgressBar$SavedState(super.onSaveInstanceState());
        verticalProgressBar$SavedState.a = this.e;
        verticalProgressBar$SavedState.b = this.f;
        return (Parcelable)verticalProgressBar$SavedState;
    }
    
    protected void onSizeChanged(final int n, final int n2, final int n3, final int n4) {
        final int n5 = 0 + (n + 0);
        final int n6 = 0 + (n2 + 0);
        if (this.h != null) {
            this.h.setBounds(0, 0, n5, n6);
        }
    }
    
    public void postInvalidate() {
        if (!this.k) {
            super.postInvalidate();
        }
    }
    
    public void setMax(int n) {
        // monitorenter(this)
        // monitorenter(this)
        if (n < 0) {
            n = 0;
        }
        try {
            if (n != this.g) {
                this.g = n;
                this.postInvalidate();
                if (this.e > n) {
                    this.b(16908301, this.e = n, false);
                }
            }
        }
        finally {
        }
        // monitorexit(this)
    }
    
    public void setProgress(final int n) {
        synchronized (this) {
            this.a(n, false);
        }
    }
    
    public void setProgressDrawable(final Drawable drawable) {
        if (drawable != null) {
            drawable.setCallback((Drawable$Callback)this);
            final int minimumHeight = drawable.getMinimumHeight();
            if (this.d < minimumHeight) {
                this.d = minimumHeight;
                this.requestLayout();
            }
        }
        this.h = drawable;
        this.i = drawable;
        this.postInvalidate();
    }
    
    public void setSecondaryProgress(final int n) {
        // monitorenter(this)
        // monitorenter(this)
        int g = 0;
        while (true) {
            Label_0053: {
                if (n >= 0) {
                    break Label_0053;
                }
                try {
                    if (g > this.g) {
                        g = this.g;
                    }
                    if (g != this.f) {
                        this.b(16908303, this.f = g, false);
                    }
                    return;
                }
                finally {
                }
                // monitorexit(this)
            }
            g = n;
            continue;
        }
    }
    
    public void setVisibility(final int visibility) {
        if (this.getVisibility() != visibility) {
            super.setVisibility(visibility);
        }
    }
    
    protected boolean verifyDrawable(final Drawable drawable) {
        return drawable == this.h || super.verifyDrawable(drawable);
    }
}
