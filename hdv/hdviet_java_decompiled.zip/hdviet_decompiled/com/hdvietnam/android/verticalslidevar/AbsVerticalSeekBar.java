package com.hdvietnam.android.verticalslidevar;

import android.graphics.drawable.Drawable$Callback;
import android.view.KeyEvent;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.graphics.Rect;
import android.content.res.TypedArray;
import com.hdvietnam.app.android.R$styleable;
import android.util.AttributeSet;
import android.content.Context;
import android.graphics.drawable.Drawable;

public class AbsVerticalSeekBar extends VerticalProgressBar
{
    private static final int NO_ALPHA = 255;
    private Drawable e;
    private int f;
    private boolean g;
    private int h;
    private float i;
    
    public AbsVerticalSeekBar(final Context context) {
        super(context);
        this.g = true;
        this.h = 1;
    }
    
    public AbsVerticalSeekBar(final Context context, final AttributeSet set) {
        super(context, set);
        this.g = true;
        this.h = 1;
    }
    
    public AbsVerticalSeekBar(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.g = true;
        this.h = 1;
        final TypedArray obtainStyledAttributes = context.obtainStyledAttributes(set, R$styleable.SeekBar, n, 0);
        this.setThumb(obtainStyledAttributes.getDrawable(0));
        this.setThumbOffset(obtainStyledAttributes.getDimensionPixelOffset(1, this.getThumbOffset()));
        obtainStyledAttributes.recycle();
        final TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(set, R$styleable.Theme, 0, 0);
        this.i = obtainStyledAttributes2.getFloat(0, 0.5f);
        obtainStyledAttributes2.recycle();
    }
    
    private void a(final int n, final Drawable drawable, final float n2, final int n3) {
        final int n4 = 0 + (n + 0);
        final int intrinsicWidth = drawable.getIntrinsicWidth();
        final int intrinsicHeight = drawable.getIntrinsicHeight();
        final int n5 = -3 + (int)((1.0f - n2) * (n4 - intrinsicHeight + 2 * this.f));
        int left;
        int right;
        if (n3 == Integer.MIN_VALUE) {
            final Rect bounds = drawable.getBounds();
            left = bounds.left;
            right = bounds.right;
        }
        else {
            left = n3 + (intrinsicWidth - this.a) / 2;
            right = n3 + intrinsicWidth + (intrinsicWidth - this.a) / 2;
        }
        drawable.setBounds(left, n5, right, n5 + intrinsicHeight);
    }
    
    private void a(final MotionEvent motionEvent) {
        final int height = this.getHeight();
        final int n = 0 + (height + 0);
        final int n2 = height - (int)motionEvent.getY();
        float n3;
        if (n2 < 0) {
            n3 = 0.0f;
        }
        else if (n2 > height + 0) {
            n3 = 1.0f;
        }
        else {
            n3 = (n2 + 0) / n;
        }
        this.a((int)(0.0f + n3 * this.getMax()), true);
    }
    
    void a() {
    }
    
    @Override
    void a(final float n, final boolean b) {
        final Drawable e = this.e;
        if (e != null) {
            this.a(this.getHeight(), e, n, Integer.MIN_VALUE);
            this.invalidate();
        }
    }
    
    void b() {
    }
    
    @Override
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        final Drawable progressDrawable = this.getProgressDrawable();
        if (progressDrawable != null) {
            int alpha;
            if (this.isEnabled()) {
                alpha = 255;
            }
            else {
                alpha = (int)(255.0f * this.i);
            }
            progressDrawable.setAlpha(alpha);
        }
        if (this.e != null && this.e.isStateful()) {
            this.e.setState(this.getDrawableState());
        }
    }
    
    public int getKeyProgressIncrement() {
        return this.h;
    }
    
    public int getThumbOffset() {
        return this.f;
    }
    
    @Override
    protected void onDraw(final Canvas canvas) {
        synchronized (this) {
            super.onDraw(canvas);
            if (this.e != null) {
                canvas.save();
                canvas.translate(0.0f, (float)(0 - this.f));
                this.e.draw(canvas);
                canvas.restore();
            }
        }
    }
    
    public boolean onKeyDown(final int n, final KeyEvent keyEvent) {
        final int progress = this.getProgress();
        switch (n) {
            case 20: {
                if (progress > 0) {
                    this.a(progress - this.h, true);
                    return true;
                }
                break;
            }
            case 19: {
                if (progress < this.getMax()) {
                    this.a(progress + this.h, true);
                    return true;
                }
                break;
            }
        }
        return super.onKeyDown(n, keyEvent);
    }
    
    @Override
    protected void onMeasure(final int n, final int n2) {
        while (true) {
            while (true) {
                synchronized (this) {
                    final Drawable currentDrawable = this.getCurrentDrawable();
                    int intrinsicWidth;
                    if (this.e == null) {
                        intrinsicWidth = 0;
                    }
                    else {
                        intrinsicWidth = this.e.getIntrinsicWidth();
                    }
                    if (currentDrawable != null) {
                        Math.max(this.a, Math.min(this.b, currentDrawable.getIntrinsicWidth()));
                        final int max = Math.max(intrinsicWidth, 0);
                        final int max2 = Math.max(this.c, Math.min(this.d, currentDrawable.getIntrinsicHeight()));
                        this.setMeasuredDimension(resolveSize(max + 0, n), resolveSize(max2 + 0, n2));
                        return;
                    }
                }
                final int max2 = 0;
                final int max = 0;
                continue;
            }
        }
    }
    
    @Override
    protected void onSizeChanged(final int n, final int n2, final int n3, final int n4) {
        final Drawable currentDrawable = this.getCurrentDrawable();
        final Drawable e = this.e;
        int intrinsicWidth;
        if (e == null) {
            intrinsicWidth = 0;
        }
        else {
            intrinsicWidth = e.getIntrinsicWidth();
        }
        final int min = Math.min(this.b, 0 + (n + 0));
        final int max = this.getMax();
        float n5;
        if (max > 0) {
            n5 = this.getProgress() / max;
        }
        else {
            n5 = 0.0f;
        }
        if (intrinsicWidth > min) {
            final int n6 = (intrinsicWidth - min) / 2;
            if (e != null) {
                this.a(n2, e, n5, n6 * -1);
            }
            if (currentDrawable != null) {
                currentDrawable.setBounds(n6, 0, 0 + (n + 0) - n6, 0 + (n2 + 0));
            }
        }
        else {
            if (currentDrawable != null) {
                currentDrawable.setBounds(0, 0, 0 + (n + 0), 0 + (n2 + 0));
            }
            final int n7 = (min - intrinsicWidth) / 2;
            if (e != null) {
                this.a(n2, e, n5, n7);
            }
        }
    }
    
    public boolean onTouchEvent(final MotionEvent motionEvent) {
        if (!this.g || !this.isEnabled()) {
            return false;
        }
        switch (motionEvent.getAction()) {
            default: {
                return true;
            }
            case 0: {
                this.setPressed(true);
                this.a();
                this.a(motionEvent);
                return true;
            }
            case 2: {
                this.a(motionEvent);
                return true;
            }
            case 1: {
                this.a(motionEvent);
            }
            case 3: {
                this.b();
                this.setPressed(false);
                this.invalidate();
                return true;
            }
        }
    }
    
    public void setKeyProgressIncrement(int h) {
        if (h < 0) {
            h = -h;
        }
        this.h = h;
    }
    
    @Override
    public void setMax(final int max) {
        synchronized (this) {
            super.setMax(max);
            if (this.h == 0 || this.getMax() / this.h > 20) {
                this.setKeyProgressIncrement(Math.max(1, Math.round(this.getMax() / 20.0f)));
            }
        }
    }
    
    public void setThumb(final Drawable e) {
        if (e != null) {
            e.setCallback((Drawable$Callback)this);
            this.f = e.getIntrinsicHeight() / 2;
        }
        this.e = e;
        this.invalidate();
    }
    
    public void setThumbOffset(final int f) {
        this.f = f;
        this.invalidate();
    }
    
    @Override
    protected boolean verifyDrawable(final Drawable drawable) {
        return drawable == this.e || super.verifyDrawable(drawable);
    }
}
