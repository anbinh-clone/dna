package com.example.hdvdecoderandroid;

public class HDVDecoder
{
    public static String decode(final String s, final int n, int i) {
        if (i <= 0 || s.equals("")) {
            return "";
        }
        int n2 = 0;
        do {
            n2 += i % 10;
            i /= 10;
        } while (i > 0);
        return RC4.decrypt(s, String.valueOf(n % n2));
    }
}
