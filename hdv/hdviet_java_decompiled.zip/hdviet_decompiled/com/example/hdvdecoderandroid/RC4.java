package com.example.hdvdecoderandroid;

import java.net.URLEncoder;
import java.net.URLDecoder;
import org.apache.commons.codec.binary.Hex;

public class RC4
{
    public static final String DEFAULT_KEY_LOCATION = "/resources/key/rc4";
    public static final String KEY_DIRECTORY = "/key/";
    private static String defaultKey;
    private byte[] state;
    private int x;
    private int y;
    
    static {
        RC4.defaultKey = "youcannotguessme";
    }
    
    public RC4() {
        this(RC4.defaultKey);
    }
    
    public RC4(final String s) {
        this(s.getBytes());
    }
    
    public RC4(final byte[] array) {
        int i = 0;
        super();
        this.state = new byte[256];
        for (int j = 0; j < 256; ++j) {
            this.state[j] = (byte)j;
        }
        this.x = 0;
        this.y = 0;
        if (array == null || array.length == 0) {
            throw new NullPointerException();
        }
        int n = 0;
        int n2 = 0;
        while (i < 256) {
            n = (0xFF & n + ((0xFF & array[n2]) + (0xFF & this.state[i])));
            final byte b = this.state[i];
            this.state[i] = this.state[n];
            this.state[n] = b;
            n2 = (n2 + 1) % array.length;
            ++i;
        }
    }
    
    public static String decrypt(final String s) {
        if (s == null) {
            return null;
        }
        final RC4 rc4 = new RC4(RC4.defaultKey);
        try {
            return URLDecoder.decode(new String(rc4.rc4(Hex.decodeHex(s.toCharArray())), "UTF-8"), "UTF-8");
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return s;
        }
    }
    
    public static String decrypt(final String s, final String s2) {
        if (s2 == null || s == null) {
            return null;
        }
        final RC4 rc4 = new RC4(s2);
        String s3;
        try {
            final String s4;
            s3 = (s4 = new String(rc4.rc4(Hex.decodeHex(s.toCharArray())), "UTF-8"));
            final String s5 = "<";
            final String s6 = "&lt;";
            s4.replaceAll(s5, s6);
            final String s7 = s3;
            final String s8 = ">";
            final String s9 = "&gt;";
            s7.replaceAll(s8, s9);
            final String s10 = s3;
            final String s11 = "%";
            final String s12 = "%25";
            s10.replace(s11, s12);
            final String s13 = s3;
            final String s14 = "%(?![0-9a-fA-F]{2})";
            final String s15 = "%25";
            final String s16 = s13.replaceAll(s14, s15);
            final String s17;
            s3 = (s17 = s16);
            final String s18 = "UTF-8";
            final String s19 = URLDecoder.decode(s17, s18);
            final String s20 = "%25";
            final String s21 = "%";
            final String replaceAll = s19.replaceAll(s20, s21);
            return replaceAll;
        }
        catch (Exception ex) {
            s3 = "";
        }
        while (true) {
            try {
                final String s4 = s3;
                final String s5 = "<";
                final String s6 = "&lt;";
                s4.replaceAll(s5, s6);
                final String s7 = s3;
                final String s8 = ">";
                final String s9 = "&gt;";
                s7.replaceAll(s8, s9);
                final String s10 = s3;
                final String s11 = "%";
                final String s12 = "%25";
                s10.replace(s11, s12);
                final String s13 = s3;
                final String s14 = "%(?![0-9a-fA-F]{2})";
                final String s15 = "%25";
                final String s16 = s13.replaceAll(s14, s15);
                final String s17;
                s3 = (s17 = s16);
                final String s18 = "UTF-8";
                final String s19 = URLDecoder.decode(s17, s18);
                final String s20 = "%25";
                final String s21 = "%";
                final String replaceAll2;
                final String replaceAll = replaceAll2 = s19.replaceAll(s20, s21);
                return replaceAll2;
                System.out.println("Decode error: " + s3);
                final Exception ex;
                ex.printStackTrace();
                return s;
            }
            catch (Exception ex) {
                continue;
            }
            break;
        }
    }
    
    public static String encrypt(final String s) {
        if (s == null) {
            return null;
        }
        final RC4 rc4 = new RC4(RC4.defaultKey);
        try {
            return Hex.encodeHexString(rc4.rc4(URLEncoder.encode(s, "UTF-8").getBytes("UTF-8")));
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return s;
        }
    }
    
    public static String encrypt(final String s, final String s2) {
        if (s2 == null || s == null) {
            return null;
        }
        final RC4 rc4 = new RC4(s2);
        try {
            return Hex.encodeHexString(rc4.rc4(URLEncoder.encode(s, "UTF-8").getBytes("UTF-8")));
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return s;
        }
    }
    
    public byte[] rc4(final String s) {
        if (s == null) {
            return null;
        }
        final byte[] bytes = s.getBytes();
        this.rc4(bytes);
        return bytes;
    }
    
    public byte[] rc4(final byte[] array) {
        if (array == null) {
            return null;
        }
        final byte[] array2 = new byte[array.length];
        for (int i = 0; i < array.length; ++i) {
            this.x = (0xFF & 1 + this.x);
            this.y = (0xFF & (0xFF & this.state[this.x]) + this.y);
            final byte b = this.state[this.x];
            this.state[this.x] = this.state[this.y];
            this.state[this.y] = b;
            array2[i] = (byte)(array[i] ^ this.state[0xFF & (0xFF & this.state[this.x]) + (0xFF & this.state[this.y])]);
        }
        return array2;
    }
}
