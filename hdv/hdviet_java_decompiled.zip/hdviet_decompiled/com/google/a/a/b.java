package com.google.a.a;

interface b
{
    void a(byte[] p0, byte[] p1);
}
