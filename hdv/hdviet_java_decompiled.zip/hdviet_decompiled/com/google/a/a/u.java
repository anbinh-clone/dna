package com.google.a.a;

public final class u extends Exception
{
    public u() {
        super();
    }
    
    public u(final Throwable t) {
        super(t);
    }
}
