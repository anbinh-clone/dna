package com.google.a.a;

final class r extends Exception
{
    public r() {
        super();
    }
    
    public r(final Throwable t) {
        super(t);
    }
}
