package com.google.a.a;

public final class t extends Exception
{
    public t() {
        super();
    }
    
    public t(final String s) {
        super(s);
    }
}
