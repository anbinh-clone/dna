package com.google.a.a;

import java.security.InvalidAlgorithmParameterException;
import javax.crypto.BadPaddingException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import com.google.b.a.b;
import java.lang.reflect.InvocationTargetException;
import android.media.Metadata;
import android.media.MediaPlayer;

public class a
{
    int A;
    int B;
    int C;
    int D;
    int E;
    int F;
    int G;
    int H;
    int I;
    int J;
    int K;
    int L;
    int M;
    int N;
    int O;
    int P;
    int Q;
    int R;
    int S;
    int T;
    int U;
    int V;
    int W;
    int X;
    int Y;
    int Z;
    int a;
    int aA;
    int aB;
    int aC;
    int aD;
    int aE;
    int aF;
    int aG;
    int aH;
    int aI;
    int aJ;
    int aK;
    int aL;
    int aM;
    int aN;
    int aO;
    int aP;
    int aQ;
    int aR;
    int aS;
    int aT;
    int aU;
    int aV;
    int aW;
    int aX;
    int aY;
    int aZ;
    int aa;
    int ab;
    int ac;
    int ad;
    int ae;
    int af;
    int ag;
    int ah;
    int ai;
    int aj;
    int ak;
    int al;
    int am;
    int an;
    int ao;
    int ap;
    int aq;
    int ar;
    int as;
    int at;
    int au;
    int av;
    int aw;
    int ax;
    int ay;
    int az;
    int b;
    int bA;
    int bB;
    int bC;
    int bD;
    int bE;
    int bF;
    int bG;
    int bH;
    int bI;
    int bJ;
    int bK;
    int bL;
    int bM;
    int bN;
    int bO;
    int bP;
    int bQ;
    int bR;
    int bS;
    int bT;
    int bU;
    int bV;
    int bW;
    int bX;
    int bY;
    int bZ;
    int ba;
    int bb;
    int bc;
    int bd;
    int be;
    int bf;
    int bg;
    int bh;
    int bi;
    int bj;
    int bk;
    int bl;
    int bm;
    int bn;
    int bo;
    int bp;
    int bq;
    int br;
    int bs;
    int bt;
    int bu;
    int bv;
    int bw;
    int bx;
    int by;
    int bz;
    int c;
    int cA;
    int cB;
    int cC;
    int cD;
    int cE;
    int cF;
    int cG;
    int cH;
    int cI;
    int cJ;
    int cK;
    int cL;
    int cM;
    private b[] cN;
    int ca;
    int cb;
    int cc;
    int cd;
    int ce;
    int cf;
    int cg;
    int ch;
    int ci;
    int cj;
    int ck;
    int cl;
    int cm;
    int cn;
    int co;
    int cp;
    int cq;
    int cr;
    int cs;
    int ct;
    int cu;
    int cv;
    int cw;
    int cx;
    int cy;
    int cz;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;
    int r;
    int s;
    int t;
    int u;
    int v;
    int w;
    int x;
    int y;
    int z;
    
    public a() {
        super();
        this.cN = new b[] { new c(this, 0), new d(this, 0), new g(this, 0), new h(this, 0), new i(this, 0), new j(this, 0), new k(this, 0), new l(this, 0), new m(this, 0), new n(this, 0), new e(this, 0), new f(this, 0) };
    }
    
    public static long a(final String s) {
        try {
            return 1000 * (60 * (Integer.parseInt(s.substring(0, 2)) * 60)) + 1000 * (Integer.parseInt(s.substring(3, 5)) * 60) + (long)(Float.parseFloat(s.substring(6, 12).replace(",", ".")) * 1000.0f);
        }
        catch (Exception ex) {
            return -1L;
        }
    }
    
    public static Metadata a(final MediaPlayer mediaPlayer, final boolean b, final boolean b2) {
        try {
            return (Metadata)mediaPlayer.getClass().getMethod("getMetadata", (Class<?>[])new Class[0]).invoke(mediaPlayer, false, false);
        }
        catch (NoSuchMethodException ex) {
            return null;
        }
        catch (IllegalAccessException ex2) {
            return null;
        }
        catch (InvocationTargetException ex3) {
            return null;
        }
    }
    
    public static boolean a(final MediaPlayer mediaPlayer) {
        try {
            return (boolean)mediaPlayer.getClass().getMethod("suspend", (Class<?>[])new Class[0]).invoke(mediaPlayer, new Object[0]);
        }
        catch (NoSuchMethodException ex) {
            return false;
        }
        catch (IllegalAccessException ex2) {
            return false;
        }
        catch (InvocationTargetException ex3) {
            return false;
        }
    }
    
    public static byte[] a(final byte[] array, final String s) {
        if (array.length != 16) {
            throw new u();
        }
        try {
            if (b.a(s).length <= 16) {
                throw new u();
            }
            goto Label_0049;
        }
        catch (NoSuchAlgorithmException ex) {
            throw new u(ex);
        }
        catch (InvalidKeyException ex2) {
            throw new u(ex2);
        }
        catch (IllegalBlockSizeException ex3) {
            throw new u(ex3);
        }
        catch (NoSuchPaddingException ex4) {
            throw new u(ex4);
        }
        catch (BadPaddingException ex5) {
            throw new u(ex5);
        }
        catch (InvalidAlgorithmParameterException ex6) {
            throw new u(ex6);
        }
    }
    
    public static boolean b(final MediaPlayer mediaPlayer) {
        try {
            return (boolean)mediaPlayer.getClass().getMethod("resume", (Class<?>[])new Class[0]).invoke(mediaPlayer, new Object[0]);
        }
        catch (NoSuchMethodException ex) {
            return false;
        }
        catch (IllegalAccessException ex2) {
            return false;
        }
        catch (InvocationTargetException ex3) {
            return false;
        }
    }
    
    final void a(final byte[] array, final byte[] array2) {
        final b[] cn = this.cN;
        for (int length = cn.length, i = 0; i < length; ++i) {
            cn[i].a(array, array2);
        }
    }
}
