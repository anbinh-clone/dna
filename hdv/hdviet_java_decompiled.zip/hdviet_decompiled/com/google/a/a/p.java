package com.google.a.a;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import com.google.b.a.b;
import java.security.MessageDigest;
import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.io.OutputStream;
import android.content.Context;
import android.util.DisplayMetrics;
import java.io.ByteArrayOutputStream;
import com.google.c.a;

public abstract class p
{
    a a;
    ByteArrayOutputStream b;
    protected DisplayMetrics c;
    
    protected p(final Context context) {
        super();
        this.a = null;
        this.b = null;
        this.c = null;
        try {
            this.c = context.getResources().getDisplayMetrics();
        }
        catch (UnsupportedOperationException ex) {
            this.c = new DisplayMetrics();
            this.c.density = 1.0f;
        }
    }
    
    public String a(final Context context) {
        return this.c(context);
    }
    
    void a() {
        this.b = new ByteArrayOutputStream();
        this.a = new a(this.b, new byte[4096]);
    }
    
    protected void a(final int n, long n2) {
        final a a = this.a;
        a.a(n, 0);
        while ((0xFFFFFFFFFFFFFF80L & n2) != 0x0L) {
            a.a(0x80 | (0x7F & (int)n2));
            n2 >>>= 7;
        }
        a.a((int)n2);
    }
    
    protected void a(final int n, final String s) {
        final a a = this.a;
        a.a(n, 2);
        final byte[] bytes = s.getBytes("UTF-8");
        a.b(bytes.length);
        int length = bytes.length;
        if (a.b - a.c >= length) {
            System.arraycopy(bytes, 0, a.a, a.c, length);
            a.c += length;
        }
        else {
            final int n2 = a.b - a.c;
            System.arraycopy(bytes, 0, a.a, a.c, n2);
            final int n3 = n2 + 0;
            length -= n2;
            a.c = a.b;
            a.d += n2;
            a.a();
            if (length <= a.b) {
                System.arraycopy(bytes, n3, a.a, 0, length);
                a.c = length;
            }
            else {
                a.e.write(bytes, n3, length);
            }
        }
        a.d += length;
    }
    
    protected abstract void b(final Context p0);
    
    byte[] b() {
        final a a = this.a;
        if (a.e != null) {
            a.a();
        }
        return this.b.toByteArray();
    }
    
    String c(final Context context) {
        try {
            this.a();
            this.b(context);
            byte[] array = this.b();
            if (array.length == 0) {
                return Integer.toString(5);
            }
            if (array.length > 239) {
                this.a();
                this.a(20, 1L);
                array = this.b();
            }
            byte[] array3;
            if (array.length < 239) {
                final byte[] array2 = new byte[239 - array.length];
                new SecureRandom().nextBytes(array2);
                array3 = ByteBuffer.allocate(240).put((byte)array.length).put(array).put(array2).array();
            }
            else {
                array3 = ByteBuffer.allocate(240).put((byte)array.length).put(array).array();
            }
            final MessageDigest instance = MessageDigest.getInstance("MD5");
            instance.update(array3);
            final byte[] array4 = ByteBuffer.allocate(256).put(instance.digest()).put(array3).array();
            final byte[] array5 = new byte[256];
            new a().a(array4, array5);
            return b.a(array5);
        }
        catch (NoSuchAlgorithmException ex) {
            return Integer.toString(7);
        }
        catch (UnsupportedEncodingException ex2) {
            return Integer.toString(7);
        }
        catch (IOException ex3) {
            return Integer.toString(3);
        }
    }
}
