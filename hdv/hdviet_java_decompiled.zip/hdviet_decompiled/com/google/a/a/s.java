package com.google.a.a;

import android.net.Uri;
import android.content.Context;

public final class s
{
    private String[] a;
    private p b;
    
    public s(final String s, final Context context) {
        super();
        this.a = new String[] { ".doubleclick.net", ".googleadservices.com", ".googlesyndication.com" };
        new o();
        this.b = q.a(s, context);
    }
    
    public Uri a(final Uri uri, final Context context) {
        try {
            if (uri.getQueryParameter("ms") != null) {
                throw new t("Query parameter already exists: ms");
            }
        }
        catch (UnsupportedOperationException ex) {
            throw new t("Provided Uri is not in a valid state");
        }
        final String a = this.b.a(context);
        final String string = uri.toString();
        int n = string.indexOf("&adurl");
        if (n == -1) {
            n = string.indexOf("?adurl");
        }
        if (n != -1) {
            return Uri.parse(string.substring(0, n + 1) + "ms" + "=" + a + "&" + string.substring(n + 1));
        }
        return uri.buildUpon().appendQueryParameter("ms", a).build();
    }
    
    public final boolean a(final Uri uri) {
        if (uri == null) {
            throw new NullPointerException();
        }
        try {
            final String host = uri.getHost();
            final String[] a = this.a;
            final int length = a.length;
            int n = 0;
            boolean b;
            while (true) {
                b = false;
                if (n >= length) {
                    break;
                }
                if (host.endsWith(a[n])) {
                    b = true;
                    break;
                }
                ++n;
            }
            return b;
        }
        catch (NullPointerException ex) {
            return false;
        }
    }
}
