package com.google.analytics.tracking.android;

import java.util.Map;
import java.util.HashMap;
import android.content.Context;
import vn.adflex.sdk.a;

public class b
{
    static final String LOG_TAG = "GAV2";
    public static a a;
    
    public static a a(final Context context) {
        if (b.a != null) {
            return b.a;
        }
        return b.a = new a(context);
    }
    
    public static void b(final Context context) {
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("gift_icon", "true");
        a(context).a(hashMap);
    }
    
    public static void c(final Context context) {
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("gift_icon", "false");
        a(context).a(hashMap);
    }
}
