package com.google.analytics.tracking.android;

import java.util.Random;

public class a
{
    static {
        new a();
    }
    
    private a() {
        super();
        new Random();
    }
}
