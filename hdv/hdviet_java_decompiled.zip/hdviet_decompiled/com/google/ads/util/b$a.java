package com.google.ads.util;

public enum b$a
{
    a("VERBOSE", 0, 2), 
    b("DEBUG", 1, 3), 
    c("INFO", 2, 4), 
    d("WARN", 3, 5), 
    e("ERROR", 4, 6);
    
    public final int f;
    
    static {
        g = new b$a[] { b$a.a, b$a.b, b$a.c, b$a.d, b$a.e };
    }
    
    private b$a(final String s, final int n, final int f) {
        this.f = f;
    }
}
