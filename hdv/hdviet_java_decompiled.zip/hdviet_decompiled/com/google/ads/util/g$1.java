package com.google.ads.util;

import android.webkit.ConsoleMessage$MessageLevel;

class g$1
{
    static {
        a = new int[ConsoleMessage$MessageLevel.values().length];
        while (true) {
            try {
                g$1.a[ConsoleMessage$MessageLevel.ERROR.ordinal()] = 1;
                try {
                    g$1.a[ConsoleMessage$MessageLevel.WARNING.ordinal()] = 2;
                    try {
                        g$1.a[ConsoleMessage$MessageLevel.LOG.ordinal()] = 3;
                        try {
                            g$1.a[ConsoleMessage$MessageLevel.TIP.ordinal()] = 4;
                            try {
                                g$1.a[ConsoleMessage$MessageLevel.DEBUG.ordinal()] = 5;
                            }
                            catch (NoSuchFieldError noSuchFieldError) {}
                        }
                        catch (NoSuchFieldError noSuchFieldError2) {}
                    }
                    catch (NoSuchFieldError noSuchFieldError3) {}
                }
                catch (NoSuchFieldError noSuchFieldError4) {}
            }
            catch (NoSuchFieldError noSuchFieldError5) {
                continue;
            }
            break;
        }
    }
}
