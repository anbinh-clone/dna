package com.google.ads.util;

import android.content.DialogInterface;
import android.webkit.JsPromptResult;
import android.content.DialogInterface$OnClickListener;

final class g$a$5 implements DialogInterface$OnClickListener
{
    final /* synthetic */ JsPromptResult a;
    
    g$a$5(final JsPromptResult a) {
        this.a = a;
        super();
    }
    
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        this.a.cancel();
    }
}
