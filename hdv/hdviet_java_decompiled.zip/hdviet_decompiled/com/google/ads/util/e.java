package com.google.ads.util;

import android.content.Intent;
import android.util.DisplayMetrics;
import android.content.Context;
import android.annotation.TargetApi;

@TargetApi(4)
public final class e
{
    private static int a(final Context context, final float n, int n2) {
        if ((0x2000 & context.getApplicationInfo().flags) != 0x0) {
            n2 /= (int)n;
        }
        return n2;
    }
    
    public static int a(final Context context, final DisplayMetrics displayMetrics) {
        return a(context, displayMetrics.density, displayMetrics.heightPixels);
    }
    
    public static void a(final Intent intent, final String package1) {
        intent.setPackage(package1);
    }
    
    public static int b(final Context context, final DisplayMetrics displayMetrics) {
        return a(context, displayMetrics.density, displayMetrics.widthPixels);
    }
}
