package com.google.ads.util;

import android.content.DialogInterface;
import android.webkit.JsResult;
import android.content.DialogInterface$OnCancelListener;

final class g$a$1 implements DialogInterface$OnCancelListener
{
    final /* synthetic */ JsResult a;
    
    g$a$1(final JsResult a) {
        this.a = a;
        super();
    }
    
    public final void onCancel(final DialogInterface dialogInterface) {
        this.a.cancel();
    }
}
