package com.google.ads.util;

public interface b$b
{
    void a(b$a p0, String p1, Throwable p2);
}
