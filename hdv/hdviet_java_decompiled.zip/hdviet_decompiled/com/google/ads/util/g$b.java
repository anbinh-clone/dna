package com.google.ads.util;

import com.google.ads.internal.c;
import java.io.IOException;
import com.google.ads.m;
import com.google.ads.m$a;
import java.io.File;
import android.webkit.WebView;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.HttpURLConnection;
import android.webkit.WebResourceResponse;
import android.content.Context;
import java.util.Map;
import com.google.ads.internal.d;
import com.google.ads.internal.i;

public class g$b extends i
{
    public g$b(final d d, final Map map, final boolean b, final boolean b2) {
        super(d, map, b, b2);
    }
    
    private static WebResourceResponse a(final String s, final Context context) {
        final HttpURLConnection httpURLConnection = (HttpURLConnection)new URL(s).openConnection();
        try {
            AdUtil.a(httpURLConnection, context.getApplicationContext());
            httpURLConnection.connect();
            return new WebResourceResponse("application/javascript", "UTF-8", (InputStream)new ByteArrayInputStream(AdUtil.a(new InputStreamReader(httpURLConnection.getInputStream())).getBytes("UTF-8")));
        }
        finally {
            httpURLConnection.disconnect();
        }
    }
    
    public WebResourceResponse shouldInterceptRequest(final WebView webView, final String s) {
        try {
            if (!"mraid.js".equalsIgnoreCase(new File(s).getName())) {
                goto Label_0154;
            }
            final c k = this.a.k();
            if (k != null) {
                k.c(true);
            }
            else {
                this.a.a(true);
            }
            final m$a m$a = (m$a)((m)this.a.i().d.a()).b.a();
            if (!this.a.i().b() && this.b) {
                final String s2 = (String)m$a.f.a();
                b.a("shouldInterceptRequest(" + s2 + ")");
                return a(s2, webView.getContext());
            }
            goto Label_0209;
        }
        catch (IOException ex) {
            b.d("IOException fetching MRAID JS.", ex);
        }
        catch (Throwable t) {
            b.d("An unknown error occurred fetching MRAID JS.", t);
            goto Label_0154;
        }
    }
}
