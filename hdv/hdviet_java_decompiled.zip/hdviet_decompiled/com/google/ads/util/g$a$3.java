package com.google.ads.util;

import android.content.DialogInterface;
import android.webkit.JsResult;
import android.content.DialogInterface$OnClickListener;

final class g$a$3 implements DialogInterface$OnClickListener
{
    final /* synthetic */ JsResult a;
    
    g$a$3(final JsResult a) {
        this.a = a;
        super();
    }
    
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        this.a.confirm();
    }
}
