package com.google.ads.util;

public class a$a extends Error
{
    public a$a(final String s) {
        super(s);
    }
}
