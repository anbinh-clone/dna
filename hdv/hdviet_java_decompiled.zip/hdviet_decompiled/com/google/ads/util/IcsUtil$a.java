package com.google.ads.util;

import android.webkit.WebChromeClient$CustomViewCallback;
import android.view.View;
import com.google.ads.n;

public class IcsUtil$a extends g$a
{
    public IcsUtil$a(final n n) {
        super(n);
    }
    
    public void onShowCustomView(final View view, final int n, final WebChromeClient$CustomViewCallback webChromeClient$CustomViewCallback) {
        webChromeClient$CustomViewCallback.onCustomViewHidden();
    }
}
