package com.google.ads.util;

import android.text.TextUtils;
import android.util.Log;

public class a
{
    private static boolean a;
    
    static {
        a.a = Log.isLoggable("GoogleAdsAssertion", 3);
    }
    
    public static void a(final Object o) {
        c(o == null, "Assertion that an object is null failed.");
    }
    
    public static void a(final Object o, final Object o2) {
        c(o == o2, "Assertion that 'a' and 'b' refer to the same object failed.a: " + o + ", b: " + o2);
    }
    
    public static void a(final String s) {
        c(!TextUtils.isEmpty((CharSequence)s), "Expected a non empty string, got: " + s);
    }
    
    public static void a(final boolean b) {
        c(b, "Assertion failed.");
    }
    
    public static void a(final boolean b, final String s) {
        c(b, s);
    }
    
    public static void b(final Object o) {
        c(o != null, "Assertion that an object is not null failed.");
    }
    
    public static void b(final boolean b) {
        c(!b, "Assertion failed.");
    }
    
    public static void b(final boolean b, final String s) {
        c(!b, s);
    }
    
    private static void c(final boolean b, final String s) {
        if ((Log.isLoggable("GoogleAdsAssertion", 3) || a.a) && !b) {
            final a$a a$a = new a$a(s);
            Log.d("GoogleAdsAssertion", s, (Throwable)a$a);
            throw a$a;
        }
    }
}
