package com.google.ads.util;

import com.google.ads.internal.ActivationOverlay;
import com.google.ads.AdSize;
import com.google.ads.n;
import com.google.ads.internal.AdWebView;

public class IcsUtil$IcsAdWebView extends AdWebView
{
    public IcsUtil$IcsAdWebView(final n n, final AdSize adSize) {
        super(n, adSize);
    }
    
    public boolean canScrollHorizontally(final int n) {
        if (this.a.e.a() != null) {
            return !((ActivationOverlay)this.a.e.a()).b();
        }
        return super.canScrollHorizontally(n);
    }
    
    public boolean canScrollVertically(final int n) {
        if (this.a.e.a() != null) {
            return !((ActivationOverlay)this.a.e.a()).b();
        }
        return super.canScrollVertically(n);
    }
}
