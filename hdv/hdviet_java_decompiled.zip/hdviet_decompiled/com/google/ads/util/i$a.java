package com.google.ads.util;

import java.util.ArrayList;
import java.util.HashMap;

public abstract class i$a
{
    protected Object a;
    protected final String b;
    final /* synthetic */ i c;
    
    private i$a(final i i, final String s) {
        this(i, s, (Object)null);
    }
    
    private i$a(final i c, final String b, final Object a) {
        this.c = c;
        super();
        this.b = b;
        c.a(this);
        this.a = a;
    }
    
    @Override
    public String toString() {
        return this.c.toString() + "." + this.b + " = " + this.a;
    }
}
