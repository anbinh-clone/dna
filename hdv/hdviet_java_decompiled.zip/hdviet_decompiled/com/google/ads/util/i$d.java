package com.google.ads.util;

import java.lang.ref.WeakReference;

public final class i$d extends i$a
{
    final /* synthetic */ i d;
    
    public i$d(final i d, final String s, final Object o) {
        this.d = d;
        super(d, s, new WeakReference(o), null);
    }
    
    public final Object a() {
        return ((WeakReference)this.a).get();
    }
    
    @Override
    public final String toString() {
        return this.d.toString() + "." + this.b + " = " + this.a() + " (?)";
    }
}
