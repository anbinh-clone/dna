package com.google.ads.util;

import android.util.Log;

public final class b
{
    public static b$b a;
    private static int b;
    
    static {
        b.a = null;
        b.b = 5;
    }
    
    private static void a(final b$a b$a, final String s) {
        a(b$a, s, null);
    }
    
    private static void a(final b$a b$a, final String s, final Throwable t) {
        if (b.a != null) {
            b.a.a(b$a, s, t);
        }
    }
    
    public static void a(final String s) {
        if (a("Ads", 3)) {
            Log.d("Ads", s);
        }
        a(b$a.b, s, null);
    }
    
    public static void a(final String s, final Throwable t) {
        if (a("Ads", 3)) {
            Log.d("Ads", s, t);
        }
        a(b$a.b, s, t);
    }
    
    private static boolean a(final int n) {
        return n >= b.b;
    }
    
    public static boolean a(final String s, final int n) {
        return a(n) || Log.isLoggable(s, n);
    }
    
    public static void b(final String s) {
        if (a("Ads", 6)) {
            Log.e("Ads", s);
        }
        a(b$a.e, s, null);
    }
    
    public static void b(final String s, final Throwable t) {
        if (a("Ads", 6)) {
            Log.e("Ads", s);
            Log.i("Ads", "The following was caught and handled:", t);
        }
        a(b$a.e, s, t);
    }
    
    public static void c(final String s) {
        if (a("Ads", 4)) {
            Log.i("Ads", s);
        }
        a(b$a.c, s, null);
    }
    
    public static void c(final String s, final Throwable t) {
        if (a("Ads", 4)) {
            Log.i("Ads", s, t);
        }
        a(b$a.c, s, t);
    }
    
    public static void d(final String s) {
        if (a("Ads", 2)) {
            Log.v("Ads", s);
        }
        a(b$a.a, s, null);
    }
    
    public static void d(final String s, final Throwable t) {
        if (a("Ads", 5)) {
            Log.w("Ads", s);
            Log.i("Ads", "The following was caught and handled:", t);
        }
        a(b$a.d, s, t);
    }
    
    public static void e(final String s) {
        if (a("Ads", 5)) {
            Log.w("Ads", s);
        }
        a(b$a.d, s, null);
    }
}
