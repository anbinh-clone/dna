package com.google.ads.util;

import android.content.DialogInterface;
import android.widget.EditText;
import android.webkit.JsPromptResult;
import android.content.DialogInterface$OnClickListener;

final class g$a$6 implements DialogInterface$OnClickListener
{
    final /* synthetic */ JsPromptResult a;
    final /* synthetic */ EditText b;
    
    g$a$6(final JsPromptResult a, final EditText b) {
        this.a = a;
        this.b = b;
        super();
    }
    
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        this.a.confirm(this.b.getText().toString());
    }
}
