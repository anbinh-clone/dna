package com.google.ads.util;

public final class i$c extends i$a
{
    final /* synthetic */ i d;
    private boolean e;
    
    public i$c(final i d, final String s) {
        this.d = d;
        super(d, s, null);
        this.e = false;
        this.e = false;
    }
    
    public i$c(final i d, final String s, final Object o) {
        this.d = d;
        super(d, s, o, null);
        this.e = false;
        this.e = false;
    }
    
    public final Object a() {
        synchronized (this) {
            return this.a;
        }
    }
    
    public final void a(final Object a) {
        synchronized (this) {
            b.d("State changed - " + this.d.toString() + "." + this.b + ": '" + a + "' <-- '" + this.a + "'.");
            this.a = a;
            this.e = true;
        }
    }
    
    @Override
    public final String toString() {
        final StringBuilder append = new StringBuilder().append(super.toString());
        String s;
        if (this.e) {
            s = " (*)";
        }
        else {
            s = "";
        }
        return append.append(s).toString();
    }
}
