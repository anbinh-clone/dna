package com.google.ads.util;

import android.annotation.TargetApi;

@TargetApi(14)
public class IcsUtil
{
}
