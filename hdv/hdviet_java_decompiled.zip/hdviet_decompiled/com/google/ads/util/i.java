package com.google.ads.util;

import java.util.ArrayList;
import java.util.HashMap;

public abstract class i
{
    private static final Object a;
    private static int b;
    private static HashMap c;
    private final ArrayList d;
    public final int u;
    
    static {
        a = new Object();
        i.b = 0;
        i.c = new HashMap();
    }
    
    public i() {
        super();
        this.d = new ArrayList();
        synchronized (i.a) {
            final int b = i.b;
            i.b = b + 1;
            this.u = b;
            final Integer n = i.c.get(this.getClass());
            if (n == null) {
                i.c.put(this.getClass(), 1);
            }
            else {
                i.c.put(this.getClass(), 1 + n);
            }
            // monitorexit(i.a)
            b.d("State created: " + this.toString());
        }
    }
    
    private void a(final i$a i$a) {
        this.d.add(i$a);
    }
    
    @Override
    protected void finalize() {
        synchronized (i.a) {
            i.c.put(this.getClass(), -1 + i.c.get(this.getClass()));
            // monitorexit(i.a)
            super.finalize();
        }
    }
    
    @Override
    public String toString() {
        return this.getClass().getSimpleName() + "[" + this.u + "]";
    }
}
