package com.google.ads.util;

import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public class AdUtil$UserActivityReceiver extends BroadcastReceiver
{
    public void onReceive(final Context context, final Intent intent) {
        if (intent.getAction().equals("android.intent.action.USER_PRESENT")) {
            AdUtil.a(true);
        }
        else if (intent.getAction().equals("android.intent.action.SCREEN_OFF")) {
            AdUtil.a(false);
        }
    }
}
