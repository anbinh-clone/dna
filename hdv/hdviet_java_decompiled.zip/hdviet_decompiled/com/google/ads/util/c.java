package com.google.ads.util;

public class c
{
    static {
        a = !c.class.desiredAssertionStatus();
    }
    
    public static byte[] a(final String s) {
        return a(s.getBytes(), 0);
    }
    
    public static byte[] a(final byte[] array, final int n) {
        return a(array, 0, array.length, n);
    }
    
    public static byte[] a(final byte[] array, final int n, final int n2, final int n3) {
        final c$b c$b = new c$b(n3, new byte[n2 * 3 / 4]);
        if (!c$b.a(array, n, n2, true)) {
            throw new IllegalArgumentException("bad base-64");
        }
        if (c$b.b == c$b.a.length) {
            return c$b.a;
        }
        final byte[] array2 = new byte[c$b.b];
        System.arraycopy(c$b.a, 0, array2, 0, c$b.b);
        return array2;
    }
}
