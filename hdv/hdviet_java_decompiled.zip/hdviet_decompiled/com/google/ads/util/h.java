package com.google.ads.util;

import com.google.ads.n;
import android.webkit.WebSettings;
import android.annotation.TargetApi;

@TargetApi(17)
public final class h
{
    public static void a(final WebSettings webSettings, final n n) {
        g.a(webSettings, n);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
    }
}
