package com.google.ads.util;

public final class i$b extends i$a
{
    final /* synthetic */ i d;
    
    public i$b(final i d, final String s, final Object o) {
        this.d = d;
        super(d, s, o, null);
    }
    
    public final Object a() {
        return this.a;
    }
    
    @Override
    public final String toString() {
        return super.toString() + " (!)";
    }
}
