package com.google.ads.util;

import android.webkit.WebChromeClient$CustomViewCallback;
import com.google.ads.m;
import com.google.ads.m$a;
import android.webkit.WebStorage$QuotaUpdater;
import android.webkit.ConsoleMessage;
import com.google.ads.AdActivity;
import com.google.ads.internal.AdWebView;
import android.webkit.WebView;
import android.webkit.JsResult;
import android.content.DialogInterface$OnCancelListener;
import android.content.DialogInterface$OnClickListener;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.webkit.JsPromptResult;
import android.content.Context;
import android.app.AlertDialog$Builder;
import com.google.ads.n;
import android.webkit.WebChromeClient;

public class g$a extends WebChromeClient
{
    private final n a;
    
    public g$a(final n a) {
        super();
        this.a = a;
    }
    
    private static void a(final AlertDialog$Builder alertDialog$Builder, final Context context, final String text, final String text2, final JsPromptResult jsPromptResult) {
        final LinearLayout view = new LinearLayout(context);
        view.setOrientation(1);
        final TextView textView = new TextView(context);
        textView.setText((CharSequence)text);
        final EditText editText = new EditText(context);
        editText.setText((CharSequence)text2);
        view.addView((View)textView);
        view.addView((View)editText);
        alertDialog$Builder.setView((View)view).setPositiveButton(17039370, (DialogInterface$OnClickListener)new g$a$6(jsPromptResult, editText)).setNegativeButton(17039360, (DialogInterface$OnClickListener)new g$a$5(jsPromptResult)).setOnCancelListener((DialogInterface$OnCancelListener)new g$a$4(jsPromptResult)).create().show();
    }
    
    private static void a(final AlertDialog$Builder alertDialog$Builder, final String message, final JsResult jsResult) {
        alertDialog$Builder.setMessage((CharSequence)message).setPositiveButton(17039370, (DialogInterface$OnClickListener)new g$a$3(jsResult)).setNegativeButton(17039360, (DialogInterface$OnClickListener)new g$a$2(jsResult)).setOnCancelListener((DialogInterface$OnCancelListener)new g$a$1(jsResult)).create().show();
    }
    
    private static boolean a(final WebView webView, final String title, final String s, final String s2, final JsResult jsResult, final JsPromptResult jsPromptResult, final boolean b) {
        if (webView instanceof AdWebView) {
            final AdActivity i = ((AdWebView)webView).i();
            if (i != null) {
                final AlertDialog$Builder alertDialog$Builder = new AlertDialog$Builder((Context)i);
                alertDialog$Builder.setTitle((CharSequence)title);
                if (b) {
                    a(alertDialog$Builder, (Context)i, s, s2, jsPromptResult);
                }
                else {
                    a(alertDialog$Builder, s, jsResult);
                }
                return true;
            }
        }
        return false;
    }
    
    public void onCloseWindow(final WebView webView) {
        if (webView instanceof AdWebView) {
            ((AdWebView)webView).f();
        }
    }
    
    public boolean onConsoleMessage(final ConsoleMessage consoleMessage) {
        final String string = "JS: " + consoleMessage.message() + " (" + consoleMessage.sourceId() + ":" + consoleMessage.lineNumber() + ")";
        switch (g$1.a[consoleMessage.messageLevel().ordinal()]) {
            case 1: {
                b.b(string);
                break;
            }
            case 2: {
                b.e(string);
                break;
            }
            case 3:
            case 4: {
                b.c(string);
                break;
            }
            case 5: {
                b.a(string);
                break;
            }
        }
        return super.onConsoleMessage(consoleMessage);
    }
    
    public void onExceededDatabaseQuota(final String s, final String s2, long min, long n, final long n2, final WebStorage$QuotaUpdater webStorage$QuotaUpdater) {
        final m$a m$a = (m$a)((m)this.a.d.a()).b.a();
        final long n3 = (long)m$a.l.a() - n2;
        if (n3 <= 0L) {
            webStorage$QuotaUpdater.updateQuota(min);
            return;
        }
        if (min == 0L) {
            if (n > n3 || n > (long)m$a.m.a()) {
                n = 0L;
            }
        }
        else {
            if (n == 0L) {
                min = Math.min(min + Math.min((long)m$a.n.a(), n3), (long)m$a.m.a());
            }
            else if (n <= Math.min((long)m$a.m.a() - min, n3)) {
                min += n;
            }
            n = min;
        }
        webStorage$QuotaUpdater.updateQuota(n);
    }
    
    public boolean onJsAlert(final WebView webView, final String s, final String s2, final JsResult jsResult) {
        return a(webView, s, s2, null, jsResult, null, false);
    }
    
    public boolean onJsBeforeUnload(final WebView webView, final String s, final String s2, final JsResult jsResult) {
        return a(webView, s, s2, null, jsResult, null, false);
    }
    
    public boolean onJsConfirm(final WebView webView, final String s, final String s2, final JsResult jsResult) {
        return a(webView, s, s2, null, jsResult, null, false);
    }
    
    public boolean onJsPrompt(final WebView webView, final String s, final String s2, final String s3, final JsPromptResult jsPromptResult) {
        return a(webView, s, s2, s3, null, jsPromptResult, true);
    }
    
    public void onReachedMaxAppCacheSize(final long n, final long n2, final WebStorage$QuotaUpdater webStorage$QuotaUpdater) {
        final m$a m$a = (m$a)((m)this.a.d.a()).b.a();
        final long n3 = (long)m$a.k.a() - n2;
        final long n4 = n + (long)m$a.j.a();
        if (n3 < n4) {
            webStorage$QuotaUpdater.updateQuota(0L);
            return;
        }
        webStorage$QuotaUpdater.updateQuota(n4);
    }
    
    public void onShowCustomView(final View view, final WebChromeClient$CustomViewCallback webChromeClient$CustomViewCallback) {
        webChromeClient$CustomViewCallback.onCustomViewHidden();
    }
}
