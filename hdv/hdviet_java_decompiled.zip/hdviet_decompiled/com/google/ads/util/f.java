package com.google.ads.util;

public interface f
{
    Object b();
}
