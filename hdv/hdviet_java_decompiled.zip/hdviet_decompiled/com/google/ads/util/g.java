package com.google.ads.util;

import java.io.File;
import com.google.ads.m;
import com.google.ads.m$a;
import android.content.Context;
import com.google.ads.n;
import android.webkit.WebSettings;
import android.view.Window;
import android.graphics.Paint;
import android.view.View;
import android.annotation.TargetApi;

@TargetApi(11)
public class g
{
    public static void a(final View view) {
        view.setLayerType(1, (Paint)null);
    }
    
    public static void a(final Window window) {
        window.setFlags(16777216, 16777216);
    }
    
    public static void a(final WebSettings webSettings, final n n) {
        final Context context = (Context)n.f.a();
        final m$a m$a = (m$a)((m)n.d.a()).b.a();
        webSettings.setAppCacheEnabled(true);
        webSettings.setAppCacheMaxSize((long)m$a.i.a());
        webSettings.setAppCachePath(new File(context.getCacheDir(), "admob").getAbsolutePath());
        webSettings.setDatabaseEnabled(true);
        webSettings.setDatabasePath(context.getDatabasePath("admob").getAbsolutePath());
        webSettings.setDomStorageEnabled(true);
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
    }
    
    public static void b(final View view) {
        view.setLayerType(0, (Paint)null);
    }
}
