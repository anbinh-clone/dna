package com.google.ads.util;

public abstract class c$a
{
    public byte[] a;
    public int b;
}
