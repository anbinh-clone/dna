package com.google.ads.util;

import android.content.DialogInterface;
import android.webkit.JsPromptResult;
import android.content.DialogInterface$OnCancelListener;

final class g$a$4 implements DialogInterface$OnCancelListener
{
    final /* synthetic */ JsPromptResult a;
    
    g$a$4(final JsPromptResult a) {
        this.a = a;
        super();
    }
    
    public final void onCancel(final DialogInterface dialogInterface) {
        this.a.cancel();
    }
}
