package com.google.ads.util;

public enum AdUtil$a
{
    a("INVALID", 0), 
    b("SPEAKER", 1), 
    c("HEADPHONES", 2), 
    d("VIBRATE", 3), 
    e("EMULATOR", 4), 
    f("OTHER", 5);
    
    static {
        g = new AdUtil$a[] { AdUtil$a.a, AdUtil$a.b, AdUtil$a.c, AdUtil$a.d, AdUtil$a.e, AdUtil$a.f };
    }
}
