package com.google.ads;

import java.util.Calendar;
import java.text.ParseException;
import android.text.TextUtils;
import com.google.ads.doubleclick.DfpExtras;
import com.google.ads.util.AdUtil;
import android.content.Context;
import java.util.Collections;
import java.util.Collection;
import java.util.HashSet;
import com.google.ads.mediation.NetworkExtras;
import com.google.ads.mediation.admob.AdMobAdapterExtras;
import java.util.HashMap;
import com.google.ads.util.b;
import android.location.Location;
import java.util.Map;
import java.util.Set;
import java.util.Date;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;

public class AdRequest
{
    public static final String LOGTAG = "Ads";
    public static final String TEST_EMULATOR;
    public static final String VERSION = "6.4.1";
    private static final SimpleDateFormat a;
    private static Method b;
    private static Method c;
    private AdRequest$Gender d;
    private Date e;
    private Set f;
    private Map g;
    private final Map h;
    private Location i;
    private boolean j;
    private boolean k;
    private Set l;
    
    static {
        while (true) {
            a = new SimpleDateFormat("yyyyMMdd");
            AdRequest.b = null;
            AdRequest.c = null;
            while (true) {
                int n = 0;
                try {
                    final Method[] methods = Class.forName("com.google.analytics.tracking.android.a").getMethods();
                    final int length = methods.length;
                    n = 0;
                    if (n >= length) {
                        goto Label_0122;
                    }
                    final Method method = methods[n];
                    if (method.getName().equals("getInstance") && method.getParameterTypes().length == 0) {
                        AdRequest.b = method;
                    }
                    else if (method.getName().equals("getJoinIds") && method.getParameterTypes().length == 0) {
                        AdRequest.c = method;
                    }
                }
                catch (ClassNotFoundException ex) {
                    b.a("No Google Analytics: Library Not Found.");
                }
                catch (Throwable t) {
                    b.a("No Google Analytics: Error Loading Library");
                    goto Label_0113;
                }
                ++n;
                continue;
            }
        }
    }
    
    public AdRequest() {
        super();
        this.d = null;
        this.e = null;
        this.f = null;
        this.g = null;
        this.h = new HashMap();
        this.i = null;
        this.j = false;
        this.k = false;
        this.l = null;
    }
    
    private AdMobAdapterExtras a() {
        synchronized (this) {
            if (this.getNetworkExtras(AdMobAdapterExtras.class) == null) {
                this.setNetworkExtras(new AdMobAdapterExtras());
            }
            return (AdMobAdapterExtras)this.getNetworkExtras(AdMobAdapterExtras.class);
        }
    }
    
    @Deprecated
    public AdRequest addExtra(final String s, final Object o) {
        final AdMobAdapterExtras a = this.a();
        if (a.getExtras() == null) {
            a.setExtras(new HashMap());
        }
        a.getExtras().put(s, o);
        return this;
    }
    
    public AdRequest addKeyword(final String s) {
        if (this.f == null) {
            this.f = new HashSet();
        }
        this.f.add(s);
        return this;
    }
    
    public AdRequest addKeywords(final Set set) {
        if (this.f == null) {
            this.f = new HashSet();
        }
        this.f.addAll(set);
        return this;
    }
    
    public AdRequest addMediationExtra(final String s, final Object o) {
        if (this.g == null) {
            this.g = new HashMap();
        }
        this.g.put(s, o);
        return this;
    }
    
    public AdRequest addTestDevice(final String s) {
        if (this.l == null) {
            this.l = new HashSet();
        }
        this.l.add(s);
        return this;
    }
    
    public AdRequest clearBirthday() {
        this.e = null;
        return this;
    }
    
    public Date getBirthday() {
        return this.e;
    }
    
    public AdRequest$Gender getGender() {
        return this.d;
    }
    
    public Set getKeywords() {
        if (this.f == null) {
            return null;
        }
        return Collections.unmodifiableSet((Set<?>)this.f);
    }
    
    public Location getLocation() {
        return this.i;
    }
    
    public Object getNetworkExtras(final Class clazz) {
        return this.h.get(clazz);
    }
    
    @Deprecated
    public boolean getPlusOneOptOut() {
        return this.a().getPlusOneOptOut();
    }
    
    public Map getRequestMap(final Context context) {
        final HashMap<String, Set> hashMap = new HashMap<String, Set>();
        if (this.f != null) {
            hashMap.put("kw", this.f);
        }
        if (this.d != null) {
            hashMap.put("cust_gender", (Set)this.d.ordinal());
        }
        if (this.e != null) {
            hashMap.put("cust_age", (Set)AdRequest.a.format(this.e));
        }
        if (this.i != null) {
            hashMap.put("uule", (Set)AdUtil.a(this.i));
        }
        if (this.j) {
            hashMap.put("testing", (Set)1);
        }
        Label_0322: {
            if (!this.isTestDevice(context)) {
                break Label_0322;
            }
            hashMap.put("adtest", (Set)"on");
        Label_0204_Outer:
            while (true) {
                final AdMobAdapterExtras adMobAdapterExtras = (AdMobAdapterExtras)this.getNetworkExtras(AdMobAdapterExtras.class);
                final DfpExtras dfpExtras = (DfpExtras)this.getNetworkExtras(DfpExtras.class);
                Label_0403: {
                    if (dfpExtras == null || dfpExtras.getExtras() == null || dfpExtras.getExtras().isEmpty()) {
                        break Label_0403;
                    }
                    hashMap.put("extras", (Set)dfpExtras.getExtras());
                Block_17_Outer:
                    while (true) {
                        if (dfpExtras != null) {
                            final String publisherProvidedId = dfpExtras.getPublisherProvidedId();
                            if (!TextUtils.isEmpty((CharSequence)publisherProvidedId)) {
                                hashMap.put("ppid", (Set)publisherProvidedId);
                            }
                        }
                        if (this.g != null) {
                            hashMap.put("mediation_extras", (Set)this.g);
                        }
                        try {
                            if (AdRequest.b != null) {
                                final Map map = (Map)AdRequest.c.invoke(AdRequest.b.invoke(null, new Object[0]), new Object[0]);
                                if (map != null && map.size() > 0) {
                                    hashMap.put("analytics_join_id", (Set)map);
                                }
                            }
                            return hashMap;
                            // iftrue(Label_0373:, !AdUtil.c())
                            // iftrue(Label_0142:, this.k)
                            // iftrue(Label_0204:, adMobAdapterExtras == null || adMobAdapterExtras.getExtras() == null || adMobAdapterExtras.getExtras().isEmpty())
                            String string = null;
                            Label_0339: {
                                Block_21: {
                                    Block_18: {
                                        while (true) {
                                            break Block_18;
                                            continue;
                                        }
                                        break Block_21;
                                        Label_0373: {
                                            string = "\"" + AdUtil.a(context) + "\"";
                                        }
                                        break Label_0339;
                                    }
                                    string = "AdRequest.TEST_EMULATOR";
                                    break Label_0339;
                                }
                                hashMap.put("extras", (Set)adMobAdapterExtras.getExtras());
                                continue Block_17_Outer;
                            }
                            b.c("To get test ads on this device, call adRequest.addTestDevice(" + string + ");");
                            this.k = true;
                            continue Label_0204_Outer;
                        }
                        catch (Throwable t) {
                            b.c("Internal Analytics Error:", t);
                            return hashMap;
                        }
                        break;
                    }
                }
                break;
            }
        }
    }
    
    public boolean isTestDevice(final Context context) {
        if (this.l != null) {
            final String a = AdUtil.a(context);
            if (a != null && this.l.contains(a)) {
                return true;
            }
        }
        return false;
    }
    
    public AdRequest removeNetworkExtras(final Class clazz) {
        this.h.remove(clazz);
        return this;
    }
    
    @Deprecated
    public AdRequest setBirthday(final String s) {
        if (s == "" || s == null) {
            this.e = null;
            return this;
        }
        try {
            this.e = AdRequest.a.parse(s);
            return this;
        }
        catch (ParseException ex) {
            b.e("Birthday format invalid.  Expected 'YYYYMMDD' where 'YYYY' is a 4 digit year, 'MM' is a two digit month, and 'DD' is a two digit day.  Birthday value ignored");
            this.e = null;
            return this;
        }
    }
    
    public AdRequest setBirthday(final Calendar calendar) {
        if (calendar == null) {
            this.e = null;
            return this;
        }
        this.setBirthday(calendar.getTime());
        return this;
    }
    
    public AdRequest setBirthday(final Date date) {
        if (date == null) {
            this.e = null;
            return this;
        }
        this.e = new Date(date.getTime());
        return this;
    }
    
    @Deprecated
    public AdRequest setExtras(final Map extras) {
        this.a().setExtras(extras);
        return this;
    }
    
    public AdRequest setGender(final AdRequest$Gender d) {
        this.d = d;
        return this;
    }
    
    public AdRequest setKeywords(final Set f) {
        this.f = f;
        return this;
    }
    
    public AdRequest setLocation(final Location i) {
        this.i = i;
        return this;
    }
    
    public AdRequest setMediationExtras(final Map g) {
        this.g = g;
        return this;
    }
    
    public AdRequest setNetworkExtras(final NetworkExtras networkExtras) {
        if (networkExtras != null) {
            this.h.put(networkExtras.getClass(), networkExtras);
        }
        return this;
    }
    
    @Deprecated
    public AdRequest setPlusOneOptOut(final boolean plusOneOptOut) {
        this.a().setPlusOneOptOut(plusOneOptOut);
        return this;
    }
    
    public AdRequest setTestDevices(final Set l) {
        this.l = l;
        return this;
    }
    
    @Deprecated
    public AdRequest setTesting(final boolean j) {
        this.j = j;
        return this;
    }
}
