package com.google.ads;

import android.content.Context;

public interface ai
{
    String a(Context p0);
    
    String a(Context p0, String p1);
}
