package com.google.ads;

import com.google.ads.util.b;
import com.google.ads.internal.AdWebView;
import android.webkit.WebView;
import java.util.HashMap;
import com.google.ads.internal.d;

public class s implements o
{
    @Override
    public void a(final d d, final HashMap hashMap, final WebView webView) {
        if (webView instanceof AdWebView) {
            ((AdWebView)webView).f();
            return;
        }
        b.b("Trying to close WebView that isn't an AdWebView");
    }
}
