package com.google.ads;

public enum AdRequest$Gender
{
    FEMALE("FEMALE", 2), 
    MALE("MALE", 1), 
    UNKNOWN("UNKNOWN", 0);
    
    static {
        a = new AdRequest$Gender[] { AdRequest$Gender.UNKNOWN, AdRequest$Gender.MALE, AdRequest$Gender.FEMALE };
    }
}
