package com.google.ads;

import java.util.Iterator;
import java.util.List;
import android.view.View;
import android.os.Handler;
import android.os.SystemClock;
import java.util.HashMap;
import android.app.Activity;
import com.google.ads.internal.h;
import com.google.ads.util.b;
import com.google.ads.util.a;
import com.google.ads.internal.d;

class e$2 implements Runnable
{
    final /* synthetic */ f a;
    final /* synthetic */ boolean b;
    final /* synthetic */ e c;
    
    e$2(final e c, final f a, final boolean b) {
        this.c = c;
        this.a = a;
        this.b = b;
        super();
    }
    
    @Override
    public void run() {
        this.c.a.a(this.a, this.b);
    }
}
