package com.google.ads;

import com.google.ads.util.b;
import com.google.ads.mediation.MediationInterstitialAdapter;

class h$2 implements Runnable
{
    final /* synthetic */ MediationInterstitialAdapter a;
    final /* synthetic */ h b;
    
    h$2(final h b, final MediationInterstitialAdapter a) {
        this.b = b;
        this.a = a;
        super();
    }
    
    @Override
    public void run() {
        try {
            this.a.showInterstitial();
        }
        catch (Throwable t) {
            b.b("Error while telling adapter (" + this.b.h() + ") ad to show interstitial: ", t);
        }
    }
}
