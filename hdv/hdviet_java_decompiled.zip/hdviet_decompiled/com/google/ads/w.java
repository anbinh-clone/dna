package com.google.ads;

import com.google.ads.internal.c;
import java.util.Locale;
import com.google.ads.util.AdUtil;
import android.content.Context;
import java.math.BigInteger;
import android.text.TextUtils;
import com.google.ads.util.b;
import com.google.ads.internal.c$d;
import android.webkit.WebView;
import java.util.HashMap;
import com.google.ads.internal.d;

public class w implements o
{
    @Override
    public void a(final d d, final HashMap hashMap, final WebView webView) {
        String replaceAll = hashMap.get("url");
        final String s = hashMap.get("type");
        final String s2 = hashMap.get("afma_notify_dt");
        final String s3 = hashMap.get("activation_overlay_url");
        final String s4 = hashMap.get("check_packages");
        final boolean equals = "1".equals(hashMap.get("drt_include"));
        final String s5 = hashMap.get("request_scenario");
        final boolean equals2 = "1".equals(hashMap.get("use_webview_loadurl"));
        c$d c$d;
        if (c$d.d.e.equals(s5)) {
            c$d = c$d.d;
        }
        else if (c$d.c.e.equals(s5)) {
            c$d = c$d.c;
        }
        else if (c$d.a.e.equals(s5)) {
            c$d = c$d.a;
        }
        else {
            c$d = c$d.b;
        }
        b.c("Received ad url: <url: \"" + replaceAll + "\" type: \"" + s + "\" afmaNotifyDt: \"" + s2 + "\" activationOverlayUrl: \"" + s3 + "\" useWebViewLoadUrl: \"" + equals2 + "\">");
        if (!TextUtils.isEmpty((CharSequence)s4) && !TextUtils.isEmpty((CharSequence)replaceAll)) {
            final BigInteger bigInteger = new BigInteger(new byte[1]);
            final String[] split = s4.split(",");
            int i = 0;
            BigInteger setBit = bigInteger;
            while (i < split.length) {
                if (AdUtil.a((Context)d.i().c.a(), split[i])) {
                    setBit = setBit.setBit(i);
                }
                ++i;
            }
            final String format = String.format(Locale.US, "%X", setBit);
            replaceAll = replaceAll.replaceAll("%40installed_markets%40", format);
            m.a().a.a(format);
            b.c("Ad url modified to " + replaceAll);
        }
        final c k = d.k();
        if (k != null) {
            k.d(equals);
            k.a(c$d);
            k.e(equals2);
            k.e(s3);
            k.d(replaceAll);
        }
    }
}
