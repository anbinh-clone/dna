package com.google.ads;

import android.os.Handler;
import android.os.Looper;
import com.google.ads.util.i$b;
import com.google.ads.util.i$c;
import com.google.ads.util.i;

public class m extends i
{
    private static final m d;
    public final i$c a;
    public final i$b b;
    public final i$b c;
    
    static {
        d = new m();
    }
    
    private m() {
        super();
        this.a = new i$c(this, "marketPackages", (Object)null);
        this.b = new i$b(this, "constants", new m$a());
        this.c = new i$b(this, "uiHandler", new Handler(Looper.getMainLooper()));
    }
    
    public static m a() {
        return m.d;
    }
}
