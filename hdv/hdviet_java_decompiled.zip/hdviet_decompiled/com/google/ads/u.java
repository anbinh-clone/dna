package com.google.ads;

import android.content.Context;
import com.google.ads.util.b;
import android.text.TextUtils;
import android.webkit.WebView;
import java.util.HashMap;
import com.google.ads.internal.d;

public class u implements o
{
    @Override
    public void a(final d d, final HashMap hashMap, final WebView webView) {
        final String s = hashMap.get("u");
        if (TextUtils.isEmpty((CharSequence)s)) {
            b.e("Could not get URL from track gmsg.");
            return;
        }
        new Thread(new ae(s, (Context)d.i().f.a())).start();
    }
}
