package com.google.ads;

import android.database.Cursor;
import java.util.Date;
import android.text.TextUtils;
import com.google.ads.util.b;
import android.preference.PreferenceManager;
import android.content.Context;
import android.app.Activity;
import android.content.SharedPreferences$Editor;
import java.lang.ref.WeakReference;

class at$a implements Runnable
{
    private final WeakReference a;
    private final SharedPreferences$Editor b;
    
    public at$a(final Activity activity) {
        this(activity, null);
    }
    
    at$a(final Activity activity, final SharedPreferences$Editor b) {
        super();
        this.a = new WeakReference(activity);
        this.b = b;
    }
    
    private SharedPreferences$Editor a(final Context context) {
        if (this.b == null) {
            return PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext()).edit();
        }
        return this.b;
    }
    
    @Override
    public void run() {
    Label_0129_Outer:
        while (true) {
            while (true) {
                SharedPreferences$Editor a = null;
            Label_0157:
                while (true) {
                    try {
                        final Activity activity = (Activity)this.a.get();
                        if (activity == null) {
                            b.a("Activity was null while making a doritos cookie request.");
                            return;
                        }
                        final Cursor query = activity.getContentResolver().query(as.a, as.b, (String)null, (String[])null, (String)null);
                        if (query != null && query.moveToFirst() && query.getColumnNames().length > 0) {
                            final String string = query.getString(query.getColumnIndex(query.getColumnName(0)));
                            a = this.a((Context)activity);
                            if (!TextUtils.isEmpty((CharSequence)string)) {
                                a.putString("drt", string);
                                a.putLong("drt_ts", new Date().getTime());
                                a.commit();
                                return;
                            }
                            break Label_0157;
                        }
                    }
                    catch (Throwable t) {
                        b.d("An unknown error occurred while sending a doritos request.", t);
                        return;
                    }
                    b.a("Google+ app not installed, not storing doritos cookie");
                    final String string = null;
                    continue Label_0129_Outer;
                }
                a.putString("drt", "");
                a.putLong("drt_ts", 0L);
                continue;
            }
        }
    }
}
