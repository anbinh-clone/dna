package com.google.ads;

import java.io.IOException;

public class au$a extends IOException
{
    au$a() {
        super("CodedOutputStream was writing to a flat byte array and ran out of space.");
    }
}
