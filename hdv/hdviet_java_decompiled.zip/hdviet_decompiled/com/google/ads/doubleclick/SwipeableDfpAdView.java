package com.google.ads.doubleclick;

import com.google.ads.SwipeableAdListener;
import com.google.ads.internal.ActivationOverlay;
import android.util.AttributeSet;
import android.content.Context;
import com.google.ads.AdSize;
import android.app.Activity;

public class SwipeableDfpAdView extends DfpAdView
{
    public SwipeableDfpAdView(final Activity activity, final AdSize adSize, final String s) {
        super(activity, adSize, s);
    }
    
    public SwipeableDfpAdView(final Context context, final AttributeSet set) {
        super(context, set);
    }
    
    public SwipeableDfpAdView(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
    }
    
    @Override
    public void resize(final AdSize adSize) {
        super.resize(adSize);
        if (((ActivationOverlay)this.a.i().e.a()).b()) {
            this.a.a(-1, -1, adSize.getWidth(), adSize.getHeight());
        }
    }
    
    @Override
    public void setSwipeableEventListener(final SwipeableAdListener swipeableEventListener) {
        super.setSwipeableEventListener(swipeableEventListener);
    }
}
