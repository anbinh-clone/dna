package com.google.ads.doubleclick;

import com.google.ads.AppEventListener;
import com.google.ads.internal.h;
import android.util.AttributeSet;
import android.content.Context;
import com.google.ads.AdSize;
import android.app.Activity;
import com.google.ads.AdView;

public class DfpAdView extends AdView
{
    public DfpAdView(final Activity activity, final AdSize adSize, final String s) {
        super(activity, adSize, s);
    }
    
    public DfpAdView(final Activity activity, final AdSize[] array, final String s) {
        super(activity, array, s);
    }
    
    public DfpAdView(final Context context, final AttributeSet set) {
        super(context, set);
    }
    
    public DfpAdView(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
    }
    
    public void enableManualImpressions(final boolean b) {
        this.a.i().t.a(b);
    }
    
    public void recordImpression() {
        this.a.z();
    }
    
    public void resize(final AdSize adSize) {
        this.a.l().setAdSize(adSize);
        ((h)this.a.i().g.a()).b(adSize);
    }
    
    @Override
    public void setAppEventListener(final AppEventListener appEventListener) {
        super.setAppEventListener(appEventListener);
    }
    
    @Override
    public void setSupportedAdSizes(final AdSize... supportedAdSizes) {
        super.setSupportedAdSizes(supportedAdSizes);
    }
}
