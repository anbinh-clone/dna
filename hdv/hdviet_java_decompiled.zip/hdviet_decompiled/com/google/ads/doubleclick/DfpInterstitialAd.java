package com.google.ads.doubleclick;

import com.google.ads.AppEventListener;
import android.app.Activity;
import com.google.ads.InterstitialAd;

public class DfpInterstitialAd extends InterstitialAd
{
    public DfpInterstitialAd(final Activity activity, final String s) {
        super(activity, s);
    }
    
    public DfpInterstitialAd(final Activity activity, final String s, final boolean b) {
        super(activity, s, b);
    }
    
    @Override
    public void setAppEventListener(final AppEventListener appEventListener) {
        super.setAppEventListener(appEventListener);
    }
}
