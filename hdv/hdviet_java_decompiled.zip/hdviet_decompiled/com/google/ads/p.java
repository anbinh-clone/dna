package com.google.ads;

import com.google.ads.util.b;
import android.webkit.WebView;
import java.util.HashMap;
import com.google.ads.internal.d;

public class p implements o
{
    @Override
    public void a(final d d, final HashMap hashMap, final WebView webView) {
        final String s = hashMap.get("name");
        if (s == null) {
            b.b("Error: App event with no name parameter.");
            return;
        }
        d.a(s, hashMap.get("info"));
    }
}
