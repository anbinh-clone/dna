package com.google.ads;

import android.widget.FrameLayout$LayoutParams;
import android.content.Context;
import android.widget.ImageButton;
import android.webkit.WebViewClient;
import com.google.ads.internal.i;
import android.os.Bundle;
import java.util.HashMap;
import android.os.SystemClock;
import android.view.ViewParent;
import android.view.Window;
import android.view.ViewGroup$LayoutParams;
import com.google.ads.util.g;
import com.google.ads.util.AdUtil;
import android.util.TypedValue;
import android.view.View;
import android.webkit.WebView;
import android.widget.RelativeLayout$LayoutParams;
import com.google.ads.internal.AdVideoView;
import android.widget.RelativeLayout;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.google.ads.internal.AdWebView;
import com.google.ads.internal.a;
import android.view.View$OnClickListener;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.app.Activity;
import com.google.ads.util.b;
import com.google.ads.internal.e;
import com.google.ads.internal.d;

public class AdActivity$StaticMethodWrapper
{
    public boolean isShowing() {
        synchronized (AdActivity.b) {
            return AdActivity.e != null;
        }
    }
    
    public void launchAdActivity(final d d, final e e) {
        final Activity activity;
        synchronized (AdActivity.b) {
            if (AdActivity.d == null) {
                AdActivity.d = d;
            }
            else if (AdActivity.d != d) {
                b.b("Tried to launch a new AdActivity with a different AdManager.");
                return;
            }
            // monitorexit(AdActivity.a())
            activity = (Activity)d.i().c.a();
            if (activity == null) {
                b.e("activity was null while launching an AdActivity.");
                return;
            }
        }
        final Intent intent = new Intent(activity.getApplicationContext(), (Class)AdActivity.class);
        intent.putExtra("com.google.ads.AdOpener", e.a());
        try {
            b.a("Launching AdActivity.");
            activity.startActivity(intent);
        }
        catch (ActivityNotFoundException ex) {
            b.b("Activity not found.", (Throwable)ex);
        }
    }
    
    public boolean leftApplication() {
        synchronized (AdActivity.b) {
            return AdActivity.c != null;
        }
    }
}
