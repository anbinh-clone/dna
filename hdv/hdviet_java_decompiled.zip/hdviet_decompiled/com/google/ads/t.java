package com.google.ads;

import com.google.ads.util.b;
import com.google.ads.internal.AdWebView;
import android.webkit.WebView;
import java.util.HashMap;
import com.google.ads.internal.d;

public class t implements o
{
    @Override
    public void a(final d d, final HashMap hashMap, final WebView webView) {
        if (webView instanceof AdWebView) {
            ((AdWebView)webView).setCustomClose("1".equals(hashMap.get("custom_close")));
            return;
        }
        b.b("Trying to set a custom close icon on a WebView that isn't an AdWebView");
    }
}
