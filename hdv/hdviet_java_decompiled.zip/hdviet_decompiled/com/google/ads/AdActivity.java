package com.google.ads;

import android.widget.FrameLayout$LayoutParams;
import android.content.Context;
import android.widget.ImageButton;
import android.webkit.WebViewClient;
import com.google.ads.internal.i;
import android.os.Bundle;
import java.util.HashMap;
import android.os.SystemClock;
import android.view.ViewParent;
import android.view.Window;
import android.view.ViewGroup$LayoutParams;
import com.google.ads.util.g;
import com.google.ads.util.AdUtil;
import android.util.TypedValue;
import com.google.ads.internal.e;
import android.view.View;
import android.webkit.WebView;
import com.google.ads.util.b;
import android.widget.RelativeLayout$LayoutParams;
import com.google.ads.internal.AdVideoView;
import android.widget.RelativeLayout;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.google.ads.internal.AdWebView;
import com.google.ads.internal.d;
import com.google.ads.internal.a;
import android.view.View$OnClickListener;
import android.app.Activity;

public class AdActivity extends Activity implements View$OnClickListener
{
    public static final String BASE_URL_PARAM = "baseurl";
    public static final String COMPONENT_NAME_PARAM = "c";
    public static final String CUSTOM_CLOSE_PARAM = "custom_close";
    public static final String HTML_PARAM = "html";
    public static final String INTENT_ACTION_PARAM = "i";
    public static final String INTENT_EXTRAS_PARAM = "e";
    public static final String INTENT_FLAGS_PARAM = "f";
    public static final String ORIENTATION_PARAM = "o";
    public static final String PACKAGE_NAME_PARAM = "p";
    public static final String TYPE_PARAM = "m";
    public static final String URL_PARAM = "u";
    private static final a a;
    private static final Object b;
    private static AdActivity c;
    private static d d;
    private static AdActivity e;
    private static AdActivity f;
    private static final AdActivity$StaticMethodWrapper g;
    private AdWebView h;
    private FrameLayout i;
    private int j;
    private ViewGroup k;
    private boolean l;
    private long m;
    private RelativeLayout n;
    private AdActivity o;
    private boolean p;
    private boolean q;
    private boolean r;
    private boolean s;
    private AdVideoView t;
    
    static {
        a = (a)a.a.b();
        b = new Object();
        AdActivity.c = null;
        AdActivity.d = null;
        AdActivity.e = null;
        AdActivity.f = null;
        g = new AdActivity$StaticMethodWrapper();
    }
    
    public AdActivity() {
        super();
        this.k = null;
        this.o = null;
    }
    
    private RelativeLayout$LayoutParams a(final int n, final int n2, final int n3, final int n4) {
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams = new RelativeLayout$LayoutParams(n3, n4);
        relativeLayout$LayoutParams.setMargins(n, n2, 0, 0);
        relativeLayout$LayoutParams.addRule(10);
        relativeLayout$LayoutParams.addRule(9);
        return relativeLayout$LayoutParams;
    }
    
    private void a(final String s) {
        b.b(s);
        this.finish();
    }
    
    private void a(final String s, final Throwable t) {
        b.b(s, t);
        this.finish();
    }
    
    private void e() {
        if (this.l) {
            return;
        }
        Label_0238: {
            while (true) {
                Label_0109: {
                    if (this.h == null) {
                        break Label_0109;
                    }
                    AdActivity.a.b(this.h);
                    this.h.setAdActivity(null);
                    this.h.setIsExpandedMraid(false);
                    if (this.q || this.n == null || this.k == null) {
                        break Label_0109;
                    }
                    if (!this.r || this.s) {
                        break Label_0238;
                    }
                    b.a("Disabling hardware acceleration on collapsing MRAID WebView.");
                    this.h.g();
                    this.n.removeView((View)this.h);
                    this.k.addView((View)this.h);
                }
                if (this.t != null) {
                    this.t.e();
                    this.t = null;
                }
                if (this == AdActivity.c) {
                    AdActivity.c = null;
                }
                AdActivity.f = this.o;
                synchronized (AdActivity.b) {
                    if (AdActivity.d != null && this.q && this.h != null) {
                        if (this.h == AdActivity.d.l()) {
                            AdActivity.d.a();
                        }
                        this.h.stopLoading();
                    }
                    if (this == AdActivity.e) {
                        AdActivity.e = null;
                        if (AdActivity.d != null) {
                            AdActivity.d.u();
                            AdActivity.d = null;
                        }
                        else {
                            b.e("currentAdManager is null while trying to destroy AdActivity.");
                        }
                    }
                    // monitorexit(AdActivity.b)
                    this.l = true;
                    b.a("AdActivity is closing.");
                    return;
                    // iftrue(Label_0087:, this.r || !this.s)
                    b.a("Re-enabling hardware acceleration on collapsing MRAID WebView.");
                    this.h.h();
                    continue;
                }
                break;
            }
        }
    }
    
    public static boolean isShowing() {
        return AdActivity.g.isShowing();
    }
    
    public static void launchAdActivity(final d d, final e e) {
        AdActivity.g.launchAdActivity(d, e);
    }
    
    public static boolean leftApplication() {
        return AdActivity.g.leftApplication();
    }
    
    protected View a(final int n, final boolean customClose) {
        this.j = (int)TypedValue.applyDimension(1, (float)n, this.getResources().getDisplayMetrics());
        (this.i = new FrameLayout(this.getApplicationContext())).setMinimumWidth(this.j);
        this.i.setMinimumHeight(this.j);
        this.i.setOnClickListener((View$OnClickListener)this);
        this.setCustomClose(customClose);
        return (View)this.i;
    }
    
    protected AdVideoView a(final Activity activity) {
        return new AdVideoView(activity, this.h);
    }
    
    protected void a(final AdWebView adWebView, final boolean b, final int requestedOrientation, final boolean b2, final boolean b3) {
        this.requestWindowFeature(1);
        final Window window = this.getWindow();
        window.setFlags(1024, 1024);
        if (AdUtil.a >= 11) {
            if (this.r) {
                b.a("Enabling hardware acceleration on the AdActivity window.");
                g.a(window);
            }
            else {
                b.a("Disabling hardware acceleration on the AdActivity WebView.");
                adWebView.g();
            }
        }
        final ViewParent parent = adWebView.getParent();
        if (parent != null) {
            if (!b2) {
                this.a("Interstitial created with an AdWebView that has a parent.");
                return;
            }
            if (!(parent instanceof ViewGroup)) {
                this.a("MRAID banner was not a child of a ViewGroup.");
                return;
            }
            (this.k = (ViewGroup)parent).removeView((View)adWebView);
        }
        if (adWebView.i() != null) {
            this.a("Interstitial created with an AdWebView that is already in use by another AdActivity.");
        }
        else {
            this.setRequestedOrientation(requestedOrientation);
            adWebView.setAdActivity(this);
            int n;
            if (b2) {
                n = 50;
            }
            else {
                n = 32;
            }
            final View a = this.a(n, b3);
            this.n.addView((View)adWebView, -1, -1);
            final RelativeLayout$LayoutParams relativeLayout$LayoutParams = new RelativeLayout$LayoutParams(-2, -2);
            if (b2) {
                relativeLayout$LayoutParams.addRule(10);
                relativeLayout$LayoutParams.addRule(11);
            }
            else {
                relativeLayout$LayoutParams.addRule(10);
                relativeLayout$LayoutParams.addRule(9);
            }
            this.n.addView(a, (ViewGroup$LayoutParams)relativeLayout$LayoutParams);
            this.n.setKeepScreenOn(true);
            this.setContentView((View)this.n);
            this.n.getRootView().setBackgroundColor(-16777216);
            if (b) {
                AdActivity.a.a(adWebView);
            }
        }
    }
    
    protected void a(final d d) {
        this.h = null;
        this.m = SystemClock.elapsedRealtime();
        this.p = true;
        synchronized (AdActivity.b) {
            if (AdActivity.c == null) {
                AdActivity.c = this;
                d.w();
            }
        }
    }
    
    protected void a(final HashMap p0, final d p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: iconst_0       
        //     1: istore_3       
        //     2: aload_1        
        //     3: ifnonnull       14
        //     6: aload_0        
        //     7: ldc_w           "Could not get the paramMap in launchIntent()"
        //    10: invokespecial   com/google/ads/AdActivity.a:(Ljava/lang/String;)V
        //    13: return         
        //    14: new             Landroid/content/Intent;
        //    17: dup            
        //    18: invokespecial   android/content/Intent.<init>:()V
        //    21: astore          4
        //    23: aload_1        
        //    24: ldc             "u"
        //    26: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    29: checkcast       Ljava/lang/String;
        //    32: astore          5
        //    34: aload_1        
        //    35: ldc             "m"
        //    37: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    40: checkcast       Ljava/lang/String;
        //    43: astore          6
        //    45: aload_1        
        //    46: ldc             "i"
        //    48: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    51: checkcast       Ljava/lang/String;
        //    54: astore          7
        //    56: aload_1        
        //    57: ldc             "p"
        //    59: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    62: checkcast       Ljava/lang/String;
        //    65: astore          8
        //    67: aload_1        
        //    68: ldc             "c"
        //    70: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    73: checkcast       Ljava/lang/String;
        //    76: astore          9
        //    78: aload_1        
        //    79: ldc             "f"
        //    81: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    84: checkcast       Ljava/lang/String;
        //    87: astore          10
        //    89: aload_1        
        //    90: ldc             "e"
        //    92: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    95: checkcast       Ljava/lang/String;
        //    98: astore          11
        //   100: aload           5
        //   102: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   105: ifne            416
        //   108: iconst_1       
        //   109: istore          12
        //   111: aload           6
        //   113: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   116: ifne            422
        //   119: iconst_1       
        //   120: istore          13
        //   122: iload           12
        //   124: ifeq            428
        //   127: iload           13
        //   129: ifeq            428
        //   132: aload           4
        //   134: aload           5
        //   136: invokestatic    android/net/Uri.parse:(Ljava/lang/String;)Landroid/net/Uri;
        //   139: aload           6
        //   141: invokevirtual   android/content/Intent.setDataAndType:(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;
        //   144: pop            
        //   145: aload           7
        //   147: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   150: ifne            463
        //   153: aload           4
        //   155: aload           7
        //   157: invokevirtual   android/content/Intent.setAction:(Ljava/lang/String;)Landroid/content/Intent;
        //   160: pop            
        //   161: aload           8
        //   163: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   166: ifne            183
        //   169: getstatic       com/google/ads/util/AdUtil.a:I
        //   172: iconst_4       
        //   173: if_icmplt       183
        //   176: aload           4
        //   178: aload           8
        //   180: invokestatic    com/google/ads/util/e.a:(Landroid/content/Intent;Ljava/lang/String;)V
        //   183: aload           9
        //   185: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   188: ifne            243
        //   191: aload           9
        //   193: ldc_w           "/"
        //   196: invokevirtual   java/lang/String.split:(Ljava/lang/String;)[Ljava/lang/String;
        //   199: astore          32
        //   201: aload           32
        //   203: arraylength    
        //   204: iconst_2       
        //   205: if_icmpge       229
        //   208: new             Ljava/lang/StringBuilder;
        //   211: dup            
        //   212: ldc_w           "Warning: Could not parse component name from open GMSG: "
        //   215: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   218: aload           9
        //   220: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   223: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   226: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //   229: aload           4
        //   231: aload           32
        //   233: iconst_0       
        //   234: aaload         
        //   235: aload           32
        //   237: iconst_1       
        //   238: aaload         
        //   239: invokevirtual   android/content/Intent.setClassName:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //   242: pop            
        //   243: aload           10
        //   245: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   248: ifne            270
        //   251: aload           10
        //   253: invokestatic    java/lang/Integer.parseInt:(Ljava/lang/String;)I
        //   256: istore          31
        //   258: iload           31
        //   260: istore          29
        //   262: aload           4
        //   264: iload           29
        //   266: invokevirtual   android/content/Intent.addFlags:(I)Landroid/content/Intent;
        //   269: pop            
        //   270: aload           11
        //   272: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   275: ifne            551
        //   278: new             La/a/c;
        //   281: dup            
        //   282: aload           11
        //   284: invokespecial   a/a/c.<init>:(Ljava/lang/String;)V
        //   287: astore          17
        //   289: aload           17
        //   291: invokevirtual   a/a/c.c:()La/a/a;
        //   294: astore          19
        //   296: iload_3        
        //   297: aload           19
        //   299: getfield        a/a/a.a:Ljava/util/ArrayList;
        //   302: invokevirtual   java/util/ArrayList.size:()I
        //   305: if_icmpge       551
        //   308: aload           19
        //   310: iload_3        
        //   311: invokevirtual   a/a/a.c:(I)Ljava/lang/String;
        //   314: astore          20
        //   316: aload           17
        //   318: aload           20
        //   320: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   323: astore          21
        //   325: aload           21
        //   327: ldc_w           "t"
        //   330: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   333: istore          22
        //   335: iload           22
        //   337: tableswitch {
        //                2: 509
        //                3: 574
        //                4: 593
        //                5: 612
        //                6: 631
        //          default: 372
        //        }
        //   372: new             Ljava/lang/StringBuilder;
        //   375: dup            
        //   376: ldc_w           "Warning: Unknown type in extras from open GMSG: "
        //   379: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   382: aload           20
        //   384: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   387: ldc_w           " (type: "
        //   390: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   393: iload           22
        //   395: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   398: ldc_w           ")"
        //   401: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   404: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   407: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //   410: iinc            3, 1
        //   413: goto            296
        //   416: iconst_0       
        //   417: istore          12
        //   419: goto            111
        //   422: iconst_0       
        //   423: istore          13
        //   425: goto            122
        //   428: iload           12
        //   430: ifeq            447
        //   433: aload           4
        //   435: aload           5
        //   437: invokestatic    android/net/Uri.parse:(Ljava/lang/String;)Landroid/net/Uri;
        //   440: invokevirtual   android/content/Intent.setData:(Landroid/net/Uri;)Landroid/content/Intent;
        //   443: pop            
        //   444: goto            145
        //   447: iload           13
        //   449: ifeq            145
        //   452: aload           4
        //   454: aload           6
        //   456: invokevirtual   android/content/Intent.setType:(Ljava/lang/String;)Landroid/content/Intent;
        //   459: pop            
        //   460: goto            145
        //   463: iload           12
        //   465: ifeq            161
        //   468: aload           4
        //   470: ldc_w           "android.intent.action.VIEW"
        //   473: invokevirtual   android/content/Intent.setAction:(Ljava/lang/String;)Landroid/content/Intent;
        //   476: pop            
        //   477: goto            161
        //   480: astore          28
        //   482: new             Ljava/lang/StringBuilder;
        //   485: dup            
        //   486: ldc_w           "Warning: Could not parse flags from open GMSG: "
        //   489: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   492: aload           10
        //   494: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   497: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   500: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //   503: iconst_0       
        //   504: istore          29
        //   506: goto            262
        //   509: aload           4
        //   511: aload           20
        //   513: aload           21
        //   515: ldc_w           "v"
        //   518: invokevirtual   a/a/c.a:(Ljava/lang/String;)Z
        //   521: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Z)Landroid/content/Intent;
        //   524: pop            
        //   525: goto            410
        //   528: astore          18
        //   530: new             Ljava/lang/StringBuilder;
        //   533: dup            
        //   534: ldc_w           "Warning: Could not parse extras from open GMSG: "
        //   537: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   540: aload           11
        //   542: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   545: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   548: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //   551: aload           4
        //   553: new             Landroid/content/Intent;
        //   556: dup            
        //   557: invokespecial   android/content/Intent.<init>:()V
        //   560: invokevirtual   android/content/Intent.filterEquals:(Landroid/content/Intent;)Z
        //   563: ifeq            650
        //   566: aload_0        
        //   567: ldc_w           "Tried to launch empty intent."
        //   570: invokespecial   com/google/ads/AdActivity.a:(Ljava/lang/String;)V
        //   573: return         
        //   574: aload           4
        //   576: aload           20
        //   578: aload           21
        //   580: ldc_w           "v"
        //   583: invokevirtual   a/a/c.b:(Ljava/lang/String;)D
        //   586: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;D)Landroid/content/Intent;
        //   589: pop            
        //   590: goto            410
        //   593: aload           4
        //   595: aload           20
        //   597: aload           21
        //   599: ldc_w           "v"
        //   602: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   605: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;I)Landroid/content/Intent;
        //   608: pop            
        //   609: goto            410
        //   612: aload           4
        //   614: aload           20
        //   616: aload           21
        //   618: ldc_w           "v"
        //   621: invokevirtual   a/a/c.f:(Ljava/lang/String;)J
        //   624: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;J)Landroid/content/Intent;
        //   627: pop            
        //   628: goto            410
        //   631: aload           4
        //   633: aload           20
        //   635: aload           21
        //   637: ldc_w           "v"
        //   640: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   643: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //   646: pop            
        //   647: goto            410
        //   650: new             Ljava/lang/StringBuilder;
        //   653: dup            
        //   654: ldc_w           "Launching an intent from AdActivity: "
        //   657: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   660: aload           4
        //   662: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   665: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   668: invokestatic    com/google/ads/util/b.a:(Ljava/lang/String;)V
        //   671: aload_0        
        //   672: aload           4
        //   674: invokevirtual   com/google/ads/AdActivity.startActivity:(Landroid/content/Intent;)V
        //   677: aload_0        
        //   678: aload_2        
        //   679: invokevirtual   com/google/ads/AdActivity.a:(Lcom/google/ads/internal/d;)V
        //   682: return         
        //   683: astore          16
        //   685: aload_0        
        //   686: aload           16
        //   688: invokevirtual   android/content/ActivityNotFoundException.getMessage:()Ljava/lang/String;
        //   691: aload           16
        //   693: invokespecial   com/google/ads/AdActivity.a:(Ljava/lang/String;Ljava/lang/Throwable;)V
        //   696: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  251    258    480    509    Ljava/lang/NumberFormatException;
        //  278    296    528    551    La/a/b;
        //  296    335    528    551    La/a/b;
        //  372    410    528    551    La/a/b;
        //  509    525    528    551    La/a/b;
        //  574    590    528    551    La/a/b;
        //  593    609    528    551    La/a/b;
        //  612    628    528    551    La/a/b;
        //  631    647    528    551    La/a/b;
        //  650    682    683    697    Landroid/content/ActivityNotFoundException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0296:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: iconst_0       
        //     1: istore_3       
        //     2: aload_1        
        //     3: ifnonnull       14
        //     6: aload_0        
        //     7: ldc_w           "Could not get the paramMap in launchIntent()"
        //    10: invokespecial   com/google/ads/AdActivity.a:(Ljava/lang/String;)V
        //    13: return         
        //    14: new             Landroid/content/Intent;
        //    17: dup            
        //    18: invokespecial   android/content/Intent.<init>:()V
        //    21: astore          4
        //    23: aload_1        
        //    24: ldc             "u"
        //    26: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    29: checkcast       Ljava/lang/String;
        //    32: astore          5
        //    34: aload_1        
        //    35: ldc             "m"
        //    37: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    40: checkcast       Ljava/lang/String;
        //    43: astore          6
        //    45: aload_1        
        //    46: ldc             "i"
        //    48: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    51: checkcast       Ljava/lang/String;
        //    54: astore          7
        //    56: aload_1        
        //    57: ldc             "p"
        //    59: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    62: checkcast       Ljava/lang/String;
        //    65: astore          8
        //    67: aload_1        
        //    68: ldc             "c"
        //    70: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    73: checkcast       Ljava/lang/String;
        //    76: astore          9
        //    78: aload_1        
        //    79: ldc             "f"
        //    81: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    84: checkcast       Ljava/lang/String;
        //    87: astore          10
        //    89: aload_1        
        //    90: ldc             "e"
        //    92: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //    95: checkcast       Ljava/lang/String;
        //    98: astore          11
        //   100: aload           5
        //   102: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   105: ifne            416
        //   108: iconst_1       
        //   109: istore          12
        //   111: aload           6
        //   113: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   116: ifne            422
        //   119: iconst_1       
        //   120: istore          13
        //   122: iload           12
        //   124: ifeq            428
        //   127: iload           13
        //   129: ifeq            428
        //   132: aload           4
        //   134: aload           5
        //   136: invokestatic    android/net/Uri.parse:(Ljava/lang/String;)Landroid/net/Uri;
        //   139: aload           6
        //   141: invokevirtual   android/content/Intent.setDataAndType:(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;
        //   144: pop            
        //   145: aload           7
        //   147: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   150: ifne            463
        //   153: aload           4
        //   155: aload           7
        //   157: invokevirtual   android/content/Intent.setAction:(Ljava/lang/String;)Landroid/content/Intent;
        //   160: pop            
        //   161: aload           8
        //   163: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   166: ifne            183
        //   169: getstatic       com/google/ads/util/AdUtil.a:I
        //   172: iconst_4       
        //   173: if_icmplt       183
        //   176: aload           4
        //   178: aload           8
        //   180: invokestatic    com/google/ads/util/e.a:(Landroid/content/Intent;Ljava/lang/String;)V
        //   183: aload           9
        //   185: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   188: ifne            243
        //   191: aload           9
        //   193: ldc_w           "/"
        //   196: invokevirtual   java/lang/String.split:(Ljava/lang/String;)[Ljava/lang/String;
        //   199: astore          32
        //   201: aload           32
        //   203: arraylength    
        //   204: iconst_2       
        //   205: if_icmpge       229
        //   208: new             Ljava/lang/StringBuilder;
        //   211: dup            
        //   212: ldc_w           "Warning: Could not parse component name from open GMSG: "
        //   215: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   218: aload           9
        //   220: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   223: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   226: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //   229: aload           4
        //   231: aload           32
        //   233: iconst_0       
        //   234: aaload         
        //   235: aload           32
        //   237: iconst_1       
        //   238: aaload         
        //   239: invokevirtual   android/content/Intent.setClassName:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //   242: pop            
        //   243: aload           10
        //   245: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   248: ifne            270
        //   251: aload           10
        //   253: invokestatic    java/lang/Integer.parseInt:(Ljava/lang/String;)I
        //   256: istore          31
        //   258: iload           31
        //   260: istore          29
        //   262: aload           4
        //   264: iload           29
        //   266: invokevirtual   android/content/Intent.addFlags:(I)Landroid/content/Intent;
        //   269: pop            
        //   270: aload           11
        //   272: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   275: ifne            551
        //   278: new             La/a/c;
        //   281: dup            
        //   282: aload           11
        //   284: invokespecial   a/a/c.<init>:(Ljava/lang/String;)V
        //   287: astore          17
        //   289: aload           17
        //   291: invokevirtual   a/a/c.c:()La/a/a;
        //   294: astore          19
        //   296: iload_3        
        //   297: aload           19
        //   299: getfield        a/a/a.a:Ljava/util/ArrayList;
        //   302: invokevirtual   java/util/ArrayList.size:()I
        //   305: if_icmpge       551
        //   308: aload           19
        //   310: iload_3        
        //   311: invokevirtual   a/a/a.c:(I)Ljava/lang/String;
        //   314: astore          20
        //   316: aload           17
        //   318: aload           20
        //   320: invokevirtual   a/a/c.e:(Ljava/lang/String;)La/a/c;
        //   323: astore          21
        //   325: aload           21
        //   327: ldc_w           "t"
        //   330: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   333: istore          22
        //   335: iload           22
        //   337: tableswitch {
        //                2: 509
        //                3: 574
        //                4: 593
        //                5: 612
        //                6: 631
        //          default: 372
        //        }
        //   372: new             Ljava/lang/StringBuilder;
        //   375: dup            
        //   376: ldc_w           "Warning: Unknown type in extras from open GMSG: "
        //   379: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   382: aload           20
        //   384: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   387: ldc_w           " (type: "
        //   390: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   393: iload           22
        //   395: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   398: ldc_w           ")"
        //   401: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   404: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   407: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //   410: iinc            3, 1
        //   413: goto            296
        //   416: iconst_0       
        //   417: istore          12
        //   419: goto            111
        //   422: iconst_0       
        //   423: istore          13
        //   425: goto            122
        //   428: iload           12
        //   430: ifeq            447
        //   433: aload           4
        //   435: aload           5
        //   437: invokestatic    android/net/Uri.parse:(Ljava/lang/String;)Landroid/net/Uri;
        //   440: invokevirtual   android/content/Intent.setData:(Landroid/net/Uri;)Landroid/content/Intent;
        //   443: pop            
        //   444: goto            145
        //   447: iload           13
        //   449: ifeq            145
        //   452: aload           4
        //   454: aload           6
        //   456: invokevirtual   android/content/Intent.setType:(Ljava/lang/String;)Landroid/content/Intent;
        //   459: pop            
        //   460: goto            145
        //   463: iload           12
        //   465: ifeq            161
        //   468: aload           4
        //   470: ldc_w           "android.intent.action.VIEW"
        //   473: invokevirtual   android/content/Intent.setAction:(Ljava/lang/String;)Landroid/content/Intent;
        //   476: pop            
        //   477: goto            161
        //   480: astore          28
        //   482: new             Ljava/lang/StringBuilder;
        //   485: dup            
        //   486: ldc_w           "Warning: Could not parse flags from open GMSG: "
        //   489: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   492: aload           10
        //   494: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   497: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   500: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //   503: iconst_0       
        //   504: istore          29
        //   506: goto            262
        //   509: aload           4
        //   511: aload           20
        //   513: aload           21
        //   515: ldc_w           "v"
        //   518: invokevirtual   a/a/c.a:(Ljava/lang/String;)Z
        //   521: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Z)Landroid/content/Intent;
        //   524: pop            
        //   525: goto            410
        //   528: astore          18
        //   530: new             Ljava/lang/StringBuilder;
        //   533: dup            
        //   534: ldc_w           "Warning: Could not parse extras from open GMSG: "
        //   537: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   540: aload           11
        //   542: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   545: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   548: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //   551: aload           4
        //   553: new             Landroid/content/Intent;
        //   556: dup            
        //   557: invokespecial   android/content/Intent.<init>:()V
        //   560: invokevirtual   android/content/Intent.filterEquals:(Landroid/content/Intent;)Z
        //   563: ifeq            650
        //   566: aload_0        
        //   567: ldc_w           "Tried to launch empty intent."
        //   570: invokespecial   com/google/ads/AdActivity.a:(Ljava/lang/String;)V
        //   573: return         
        //   574: aload           4
        //   576: aload           20
        //   578: aload           21
        //   580: ldc_w           "v"
        //   583: invokevirtual   a/a/c.b:(Ljava/lang/String;)D
        //   586: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;D)Landroid/content/Intent;
        //   589: pop            
        //   590: goto            410
        //   593: aload           4
        //   595: aload           20
        //   597: aload           21
        //   599: ldc_w           "v"
        //   602: invokevirtual   a/a/c.c:(Ljava/lang/String;)I
        //   605: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;I)Landroid/content/Intent;
        //   608: pop            
        //   609: goto            410
        //   612: aload           4
        //   614: aload           20
        //   616: aload           21
        //   618: ldc_w           "v"
        //   621: invokevirtual   a/a/c.f:(Ljava/lang/String;)J
        //   624: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;J)Landroid/content/Intent;
        //   627: pop            
        //   628: goto            410
        //   631: aload           4
        //   633: aload           20
        //   635: aload           21
        //   637: ldc_w           "v"
        //   640: invokevirtual   a/a/c.g:(Ljava/lang/String;)Ljava/lang/String;
        //   643: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //   646: pop            
        //   647: goto            410
        //   650: new             Ljava/lang/StringBuilder;
        //   653: dup            
        //   654: ldc_w           "Launching an intent from AdActivity: "
        //   657: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   660: aload           4
        //   662: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   665: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   668: invokestatic    com/google/ads/util/b.a:(Ljava/lang/String;)V
        //   671: aload_0        
        //   672: aload           4
        //   674: invokevirtual   com/google/ads/AdActivity.startActivity:(Landroid/content/Intent;)V
        //   677: aload_0        
        //   678: aload_2        
        //   679: invokevirtual   com/google/ads/AdActivity.a:(Lcom/google/ads/internal/d;)V
        //   682: return         
        //   683: astore          16
        //   685: aload_0        
        //   686: aload           16
        //   688: invokevirtual   android/content/ActivityNotFoundException.getMessage:()Ljava/lang/String;
        //   691: aload           16
        //   693: invokespecial   com/google/ads/AdActivity.a:(Ljava/lang/String;Ljava/lang/Throwable;)V
        //   696: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  251    258    480    509    Ljava/lang/NumberFormatException;
        //  278    296    528    551    La/a/b;
        //  296    335    528    551    La/a/b;
        //  372    410    528    551    La/a/b;
        //  509    525    528    551    La/a/b;
        //  574    590    528    551    La/a/b;
        //  593    609    528    551    La/a/b;
        //  612    628    528    551    La/a/b;
        //  631    647    528    551    La/a/b;
        //  650    682    683    697    Landroid/content/ActivityNotFoundException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0296:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public AdVideoView getAdVideoView() {
        return this.t;
    }
    
    public AdWebView getOpeningAdWebView() {
        if (this.o != null) {
            return this.o.h;
        }
        synchronized (AdActivity.b) {
            if (AdActivity.d == null) {
                b.e("currentAdManager was null while trying to get the opening AdWebView.");
                return null;
            }
        }
        final AdWebView l = AdActivity.d.l();
        if (l != this.h) {
            // monitorexit(o)
            return l;
        }
        // monitorexit(o)
        // monitorexit(o)
        return null;
    }
    
    public void moveAdVideoView(final int n, final int n2, final int n3, final int n4) {
        if (this.t != null) {
            this.t.setLayoutParams((ViewGroup$LayoutParams)this.a(n, n2, n3, n4));
            this.t.requestLayout();
        }
    }
    
    public void newAdVideoView(final int n, final int n2, final int n3, final int n4) {
        if (this.t == null) {
            this.t = this.a(this);
            this.n.addView((View)this.t, 0, (ViewGroup$LayoutParams)this.a(n, n2, n3, n4));
            synchronized (AdActivity.b) {
                if (AdActivity.d == null) {
                    b.e("currentAdManager was null while trying to get the opening AdWebView.");
                    return;
                }
                AdActivity.d.m().b(false);
            }
        }
    }
    
    public void onClick(final View view) {
        this.finish();
    }
    
    public void onCreate(final Bundle bundle) {
        d d = null;
        boolean r = false;
        Bundle bundleExtra = null;
    Label_0194_Outer:
        while (true) {
            super.onCreate(bundle);
            this.l = false;
            while (true) {
            Label_0268:
                while (true) {
                    synchronized (AdActivity.b) {
                        if (AdActivity.d == null) {
                            this.a("Could not get currentAdManager.");
                            return;
                        }
                        d = AdActivity.d;
                        if (AdActivity.e == null) {
                            AdActivity.e = this;
                            d.v();
                        }
                        if (this.o == null && AdActivity.f != null) {
                            this.o = AdActivity.f;
                        }
                        AdActivity.f = this;
                        if ((d.i().a() && AdActivity.e == this) || (d.i().b() && this.o == AdActivity.e)) {
                            d.x();
                        }
                        r = d.r();
                        final m$a m$a = (m$a)((m)d.i().d.a()).b.a();
                        if (AdUtil.a >= (int)m$a.b.a()) {
                            final boolean s = true;
                            this.s = s;
                            if (AdUtil.a < (int)m$a.d.a()) {
                                break Label_0268;
                            }
                            final boolean r2 = true;
                            this.r = r2;
                            // monitorexit(AdActivity.b)
                            this.n = null;
                            this.p = false;
                            this.q = true;
                            this.t = null;
                            bundleExtra = this.getIntent().getBundleExtra("com.google.ads.AdOpener");
                            if (bundleExtra == null) {
                                this.a("Could not get the Bundle used to create AdActivity.");
                                return;
                            }
                            break;
                        }
                    }
                    final boolean s = false;
                    continue Label_0194_Outer;
                }
                final boolean r2 = false;
                continue;
            }
        }
        final e e = new e(bundleExtra);
        final String b = e.b();
        final HashMap c = e.c();
        if (b.equals("intent")) {
            this.a(c, d);
            return;
        }
        this.n = new RelativeLayout(this.getApplicationContext());
        if (b.equals("webapp")) {
            this.h = new AdWebView(d.i(), null);
            final i a = i.a(d, a.d, true, !r);
            a.d(true);
            if (r) {
                a.a(true);
            }
            this.h.setWebViewClient((WebViewClient)a);
            final String s2 = c.get("u");
            final String s3 = c.get("baseurl");
            final String s4 = c.get("html");
            if (s2 != null) {
                this.h.loadUrl(s2);
            }
            else {
                if (s4 == null) {
                    this.a("Could not get the URL or HTML parameter to show a web app.");
                    return;
                }
                this.h.loadDataWithBaseURL(s3, s4, "text/html", "utf-8", null);
            }
            final String s5 = c.get("o");
            int n;
            if ("p".equals(s5)) {
                n = AdUtil.b();
            }
            else if ("l".equals(s5)) {
                n = AdUtil.a();
            }
            else if (this == AdActivity.e) {
                n = d.o();
            }
            else {
                n = -1;
            }
            this.a(this.h, false, n, r, c != null && "1".equals(c.get("custom_close")));
            return;
        }
        if (b.equals("interstitial") || b.equals("expand")) {
            this.h = d.l();
            final int o = d.o();
            boolean j;
            if (b.equals("expand")) {
                this.h.setIsExpandedMraid(true);
                this.q = false;
                boolean b2 = false;
                if (c != null) {
                    final boolean equals = "1".equals(c.get("custom_close"));
                    b2 = false;
                    if (equals) {
                        b2 = true;
                    }
                }
                if (this.r && !this.s) {
                    b.a("Re-enabling hardware acceleration on expanding MRAID WebView.");
                    this.h.h();
                    j = b2;
                }
                else {
                    j = b2;
                }
            }
            else {
                j = this.h.j();
            }
            this.a(this.h, true, o, r, j);
            return;
        }
        this.a("Unknown AdOpener, <action: " + b + ">");
    }
    
    public void onDestroy() {
        if (this.n != null) {
            this.n.removeAllViews();
        }
        if (this.isFinishing()) {
            this.e();
            if (this.q && this.h != null) {
                this.h.stopLoading();
                this.h.destroy();
                this.h = null;
            }
        }
        super.onDestroy();
    }
    
    public void onPause() {
        if (this.isFinishing()) {
            this.e();
        }
        super.onPause();
    }
    
    public void onWindowFocusChanged(final boolean b) {
        if (this.p && b && SystemClock.elapsedRealtime() - this.m > 250L) {
            b.d("Launcher AdActivity got focus and is closing.");
            this.finish();
        }
        super.onWindowFocusChanged(b);
    }
    
    public void setCustomClose(final boolean b) {
        if (this.i != null) {
            this.i.removeAllViews();
            if (!b) {
                final ImageButton imageButton = new ImageButton((Context)this);
                imageButton.setImageResource(17301527);
                imageButton.setBackgroundColor(0);
                imageButton.setOnClickListener((View$OnClickListener)this);
                imageButton.setPadding(0, 0, 0, 0);
                this.i.addView((View)imageButton, (ViewGroup$LayoutParams)new FrameLayout$LayoutParams(this.j, this.j, 17));
            }
        }
    }
}
