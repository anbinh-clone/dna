package com.google.ads;

public class ap extends IllegalArgumentException
{
    public ap() {
        super();
    }
    
    public ap(final String s) {
        super(s);
    }
}
