package com.google.ads;

import com.google.ads.internal.h;
import java.util.Iterator;
import java.util.HashMap;
import java.util.ArrayList;
import a.a.c;
import com.google.ads.util.a;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class c
{
    private static final Map a;
    private final String b;
    private final String c;
    private final List d;
    private final Integer e;
    private final Integer f;
    private final List g;
    private final List h;
    private final List i;
    
    static {
        a = Collections.unmodifiableMap((Map<?, ?>)new c$1());
    }
    
    private c(final String b, final String c, final List d, final Integer e, final Integer f, final List g, final List h, final List i) {
        super();
        a.a(b);
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
    }
    
    private static a a(final c c) {
        final String g = c.g("id");
        final String a = c.a("allocation_id", (String)null);
        final a.a.a d = c.d("adapters");
        final ArrayList list = new ArrayList<String>(d.a.size());
        for (int i = 0; i < d.a.size(); ++i) {
            list.add(d.c(i));
        }
        final List a2 = a(c, "imp_urls");
        final c j = c.j("data");
        final HashMap<String, String> hashMap = new HashMap<String, String>(0);
        HashMap<String, String> hashMap2;
        if (j != null) {
            hashMap2 = new HashMap<String, String>(j.b());
            final Iterator a3 = j.a();
            while (a3.hasNext()) {
                final String s = a3.next();
                hashMap2.put(s, j.g(s));
            }
        }
        else {
            hashMap2 = hashMap;
        }
        return new a(a, g, list, a2, hashMap2);
    }
    
    public static c a(final String s) {
        final c c = new c(s);
        final String g = c.g("qdata");
        String g2;
        if (c.h("ad_type")) {
            g2 = c.g("ad_type");
        }
        else {
            g2 = null;
        }
        final a.a.a d = c.d("ad_networks");
        final ArrayList list = new ArrayList<a>(d.a.size());
        for (int i = 0; i < d.a.size(); ++i) {
            list.add(a(d.b(i)));
        }
        final c j = c.j("settings");
        Integer value;
        List a;
        List a2;
        List a3;
        Integer n;
        if (j != null) {
            if (j.h("refresh")) {
                value = j.c("refresh");
            }
            else {
                value = null;
            }
            final boolean h = j.h("ad_network_timeout_millis");
            Integer value2 = null;
            if (h) {
                value2 = j.c("ad_network_timeout_millis");
            }
            a = a(j, "imp_urls");
            a2 = a(j, "click_urls");
            a3 = a(j, "nofill_urls");
            n = value2;
        }
        else {
            value = null;
            n = null;
            a = null;
            a2 = null;
            a3 = null;
        }
        return new c(g, g2, list, value, n, a, a2, a3);
    }
    
    private static List a(final c c, final String s) {
        final a.a.a i = c.i(s);
        if (i != null) {
            final ArrayList list = new ArrayList<String>(i.a.size());
            for (int j = 0; j < i.a.size(); ++j) {
                list.add(i.c(j));
            }
            return list;
        }
        return null;
    }
    
    public boolean a() {
        return this.f != null;
    }
    
    public int b() {
        return this.f;
    }
    
    public String c() {
        return this.b;
    }
    
    public boolean d() {
        return this.e != null;
    }
    
    public int e() {
        return this.e;
    }
    
    public List f() {
        return this.d;
    }
    
    public List g() {
        return this.g;
    }
    
    public List h() {
        return this.h;
    }
    
    public List i() {
        return this.i;
    }
    
    public h j() {
        if (this.c == null) {
            return null;
        }
        if ("interstitial".equals(this.c)) {
            return h.a;
        }
        final AdSize adSize = c.a.get(this.c);
        if (adSize != null) {
            return h.a(adSize);
        }
        return null;
    }
}
