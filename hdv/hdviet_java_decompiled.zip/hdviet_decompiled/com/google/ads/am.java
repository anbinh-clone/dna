package com.google.ads;

public class am extends Exception
{
    public am() {
        super();
    }
    
    public am(final String s) {
        super(s);
    }
}
