package com.google.ads;

class ak$a extends Exception
{
    public ak$a() {
        super();
    }
    
    public ak$a(final Throwable t) {
        super(t);
    }
}
