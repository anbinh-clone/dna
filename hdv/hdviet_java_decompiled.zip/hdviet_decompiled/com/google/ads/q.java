package com.google.ads;

import android.content.pm.PackageManager;
import java.util.Map;
import android.content.Intent;
import android.net.Uri;
import com.google.ads.util.b;
import android.webkit.WebView;
import java.util.HashMap;
import com.google.ads.internal.d;
import com.google.ads.internal.a;

public class q implements o
{
    private static final a a;
    
    static {
        a = (a)a.a.b();
    }
    
    @Override
    public void a(final d d, final HashMap hashMap, final WebView webView) {
        final String s = hashMap.get("urls");
        if (s == null) {
            b.e("Could not get the urls param from canOpenURLs gmsg.");
            return;
        }
        final String[] split = s.split(",");
        final HashMap<String, Boolean> hashMap2 = new HashMap<String, Boolean>();
        final PackageManager packageManager = webView.getContext().getPackageManager();
        for (final String s2 : split) {
            final String[] split2 = s2.split(";", 2);
            final String s3 = split2[0];
            String s4;
            if (split2.length >= 2) {
                s4 = split2[1];
            }
            else {
                s4 = "android.intent.action.VIEW";
            }
            hashMap2.put(s2, packageManager.resolveActivity(new Intent(s4, Uri.parse(s3)), 65536) != null);
        }
        q.a.a(webView, hashMap2);
    }
}
