package com.google.ads;

interface ag$a
{
    void a(byte[] p0, byte[] p1);
}
