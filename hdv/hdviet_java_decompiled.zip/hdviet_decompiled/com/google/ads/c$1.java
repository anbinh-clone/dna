package com.google.ads;

import java.util.HashMap;

final class c$1 extends HashMap
{
    c$1() {
        super();
        this.put("banner", AdSize.BANNER);
        this.put("mrec", AdSize.IAB_MRECT);
        this.put("fullbanner", AdSize.IAB_BANNER);
        this.put("leaderboard", AdSize.IAB_LEADERBOARD);
        this.put("skyscraper", AdSize.IAB_WIDE_SKYSCRAPER);
    }
}
