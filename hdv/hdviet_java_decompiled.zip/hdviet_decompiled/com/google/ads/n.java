package com.google.ads;

import com.google.ads.internal.ActivationOverlay;
import com.google.ads.internal.d;
import com.google.ads.internal.h;
import android.view.ViewGroup;
import android.content.Context;
import android.app.Activity;
import com.google.ads.util.i$c;
import com.google.ads.util.i$d;
import com.google.ads.util.i$b;
import com.google.ads.util.i;

public class n extends i
{
    public final i$b a;
    public final i$b b;
    public final i$d c;
    public final i$b d;
    public final i$b e;
    public final i$b f;
    public final i$b g;
    public final i$b h;
    public final i$b i;
    public final i$b j;
    public final i$b k;
    public final i$c l;
    public final i$c m;
    public final i$c n;
    public final i$c o;
    public final i$c p;
    public final i$c q;
    public final i$c r;
    public final i$c s;
    public final i$c t;
    
    public n(final m m, final Ad ad, final AdView adView, final InterstitialAd interstitialAd, final String s, final Activity activity, final Context context, final ViewGroup viewGroup, final h h, final d d) {
        super();
        this.l = new i$c(this, "currentAd", (Object)null);
        this.m = new i$c(this, "nextAd", (Object)null);
        this.o = new i$c(this, "adListener");
        this.p = new i$c(this, "appEventListener");
        this.q = new i$c(this, "swipeableEventListener");
        this.r = new i$c(this, "spamSignals", (Object)null);
        this.s = new i$c(this, "spamSignalsUtil", (Object)null);
        this.t = new i$c(this, "usesManualImpressions", false);
        this.d = new i$b(this, "appState", m);
        this.a = new i$b(this, "ad", ad);
        this.j = new i$b(this, "adView", adView);
        this.g = new i$b(this, "adType", h);
        this.h = new i$b(this, "adUnitId", s);
        this.c = new i$d(this, "activity", activity);
        this.k = new i$b(this, "interstitialAd", interstitialAd);
        this.i = new i$b(this, "bannerContainer", viewGroup);
        this.f = new i$b(this, "applicationContext", context);
        this.n = new i$c(this, "adSizes", (Object)null);
        this.b = new i$b(this, "adManager", d);
        Object o = null;
        if (h != null) {
            final boolean b = h.b();
            o = null;
            if (b) {
                o = new ActivationOverlay(this);
            }
        }
        this.e = new i$b(this, "activationOverlay", o);
    }
    
    public boolean a() {
        return !this.b();
    }
    
    public boolean b() {
        return ((h)this.g.a()).a();
    }
}
