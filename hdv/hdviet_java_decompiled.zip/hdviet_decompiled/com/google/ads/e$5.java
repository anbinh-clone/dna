package com.google.ads;

import java.util.Iterator;
import java.util.List;
import android.view.View;
import android.os.Handler;
import android.os.SystemClock;
import java.util.HashMap;
import android.app.Activity;
import com.google.ads.internal.h;
import com.google.ads.util.b;
import com.google.ads.util.a;
import com.google.ads.internal.d;

class e$5 implements Runnable
{
    final /* synthetic */ e a;
    
    e$5(final e a) {
        this.a = a;
        super();
    }
    
    @Override
    public void run() {
        this.a.a.u();
    }
}
