package com.google.ads;

import android.content.SharedPreferences$Editor;
import android.preference.PreferenceManager;
import android.content.Context;

final class at$1 implements Runnable
{
    final /* synthetic */ Context a;
    
    at$1(final Context a) {
        this.a = a;
        super();
    }
    
    @Override
    public final void run() {
        final SharedPreferences$Editor edit = PreferenceManager.getDefaultSharedPreferences(this.a.getApplicationContext()).edit();
        edit.putString("drt", "");
        edit.putLong("drt_ts", 0L);
        edit.commit();
    }
}
