package com.google.ads;

import android.net.Uri;

public class as
{
    public static final Uri a;
    public static final String[] b;
    
    static {
        a = Uri.parse("content://com.google.plus.platform/token");
        b = new String[] { "drt" };
    }
}
