package com.google.ads;

import com.google.ads.internal.AdVideoView;
import android.view.MotionEvent;
import android.os.SystemClock;
import android.app.Activity;
import com.google.ads.util.AdUtil;
import com.google.ads.internal.AdWebView;
import android.webkit.WebView;
import com.google.ads.internal.d;
import com.google.ads.util.b;
import android.util.TypedValue;
import android.util.DisplayMetrics;
import java.util.HashMap;
import com.google.ads.internal.a;

public class ac implements o
{
    private static final a a;
    
    static {
        a = (a)a.a.b();
    }
    
    protected int a(final HashMap hashMap, final String s, int n, final DisplayMetrics displayMetrics) {
        final String s2 = hashMap.get(s);
        if (s2 == null) {
            return n;
        }
        try {
            n = (int)TypedValue.applyDimension(1, (float)Integer.parseInt(s2), displayMetrics);
            return n;
        }
        catch (NumberFormatException ex) {
            b.a("Could not parse \"" + s + "\" in a video gmsg: " + s2);
            return n;
        }
    }
    
    @Override
    public void a(final d d, final HashMap hashMap, final WebView webView) {
        final String s = hashMap.get("action");
        if (s == null) {
            b.a("No \"action\" parameter in a video gmsg.");
            return;
        }
        if (!(webView instanceof AdWebView)) {
            b.a("Could not get adWebView for a video gmsg.");
            return;
        }
        final AdWebView adWebView = (AdWebView)webView;
        final AdActivity i = adWebView.i();
        if (i == null) {
            b.a("Could not get adActivity for a video gmsg.");
            return;
        }
        final boolean equals = s.equals("new");
        final boolean equals2 = s.equals("position");
        if (equals || equals2) {
            final DisplayMetrics a = AdUtil.a(i);
            final int a2 = this.a(hashMap, "x", 0, a);
            final int a3 = this.a(hashMap, "y", 0, a);
            final int a4 = this.a(hashMap, "w", -1, a);
            final int a5 = this.a(hashMap, "h", -1, a);
            if (equals && i.getAdVideoView() == null) {
                i.newAdVideoView(a2, a3, a4, a5);
                return;
            }
            i.moveAdVideoView(a2, a3, a4, a5);
        }
        else {
            final AdVideoView adVideoView = i.getAdVideoView();
            if (adVideoView == null) {
                ac.a.a(adWebView, "onVideoEvent", "{'event': 'error', 'what': 'no_video_view'}");
                return;
            }
            if (s.equals("click")) {
                final DisplayMetrics a6 = AdUtil.a(i);
                final int a7 = this.a(hashMap, "x", 0, a6);
                final int a8 = this.a(hashMap, "y", 0, a6);
                final long uptimeMillis = SystemClock.uptimeMillis();
                adVideoView.a(MotionEvent.obtain(uptimeMillis, uptimeMillis, 0, (float)a7, (float)a8, 0));
                return;
            }
            if (s.equals("controls")) {
                final String s2 = hashMap.get("enabled");
                if (s2 == null) {
                    b.a("No \"enabled\" parameter in a controls video gmsg.");
                    return;
                }
                if (s2.equals("true")) {
                    adVideoView.setMediaControllerEnabled(true);
                    return;
                }
                adVideoView.setMediaControllerEnabled(false);
            }
            else {
                if (s.equals("currentTime")) {
                    final String s3 = hashMap.get("time");
                    if (s3 == null) {
                        b.a("No \"time\" parameter in a currentTime video gmsg.");
                        return;
                    }
                    try {
                        adVideoView.a((int)(1000.0f * Float.parseFloat(s3)));
                        return;
                    }
                    catch (NumberFormatException ex) {
                        b.a("Could not parse \"time\" parameter: " + s3);
                        return;
                    }
                }
                if (s.equals("hide")) {
                    adVideoView.setVisibility(4);
                    return;
                }
                if (s.equals("load")) {
                    adVideoView.b();
                    return;
                }
                if (s.equals("pause")) {
                    adVideoView.c();
                    return;
                }
                if (s.equals("play")) {
                    adVideoView.d();
                    return;
                }
                if (s.equals("show")) {
                    adVideoView.setVisibility(0);
                    return;
                }
                if (s.equals("src")) {
                    adVideoView.setSrc(hashMap.get("src"));
                    return;
                }
                b.a("Unknown video action: " + s);
            }
        }
    }
}
