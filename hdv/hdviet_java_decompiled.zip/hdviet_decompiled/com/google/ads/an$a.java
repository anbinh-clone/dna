package com.google.ads;

public class an$a extends Exception
{
    public an$a() {
        super();
    }
    
    public an$a(final Throwable t) {
        super(t);
    }
}
