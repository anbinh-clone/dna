package com.google.ads;

import com.google.ads.internal.c;
import com.google.ads.util.i$c;
import com.google.ads.util.i$b;
import com.google.ads.util.i;

public final class l extends i
{
    public final i$b a;
    public final i$c b;
    public final i$c c;
    
    public l(final n n) {
        super();
        this.c = new i$c(this, "disableNativeScroll", false);
        this.a = new i$b(this, "slotState", n);
        this.b = new i$c(this, "adLoader", new c(this));
    }
}
