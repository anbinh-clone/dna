package com.google.ads;

import com.google.ads.internal.AdWebView;
import com.google.ads.internal.ActivationOverlay;
import com.google.ads.internal.h;
import com.google.ads.util.g;
import com.google.ads.util.AdUtil;
import android.webkit.WebView;
import com.google.ads.internal.d;
import com.google.ads.util.b;
import android.text.TextUtils;
import com.google.ads.util.i$c;
import java.util.HashMap;

public class x implements o
{
    private void a(final HashMap hashMap, final String s, final i$c i$c) {
        try {
            final String s2 = hashMap.get(s);
            if (!TextUtils.isEmpty((CharSequence)s2)) {
                i$c.a(Integer.valueOf(s2));
            }
        }
        catch (NumberFormatException ex) {
            b.a("Could not parse \"" + s + "\" constant.");
        }
    }
    
    private void b(final HashMap hashMap, final String s, final i$c i$c) {
        try {
            final String s2 = hashMap.get(s);
            if (!TextUtils.isEmpty((CharSequence)s2)) {
                i$c.a(Long.valueOf(s2));
            }
        }
        catch (NumberFormatException ex) {
            b.a("Could not parse \"" + s + "\" constant.");
        }
    }
    
    private void c(final HashMap hashMap, final String s, final i$c i$c) {
        final String s2 = hashMap.get(s);
        if (!TextUtils.isEmpty((CharSequence)s2)) {
            i$c.a(s2);
        }
    }
    
    @Override
    public void a(final d d, final HashMap hashMap, final WebView webView) {
        final n i = d.i();
        final m$a m$a = (m$a)((m)i.d.a()).b.a();
        this.c(hashMap, "as_domains", m$a.a);
        this.c(hashMap, "bad_ad_report_path", m$a.h);
        this.a(hashMap, "min_hwa_banner", m$a.b);
        this.a(hashMap, "min_hwa_activation_overlay", m$a.c);
        this.a(hashMap, "min_hwa_overlay", m$a.d);
        this.c(hashMap, "mraid_banner_path", m$a.e);
        this.c(hashMap, "mraid_expanded_banner_path", m$a.f);
        this.c(hashMap, "mraid_interstitial_path", m$a.g);
        this.b(hashMap, "ac_max_size", m$a.i);
        this.b(hashMap, "ac_padding", m$a.j);
        this.b(hashMap, "ac_total_quota", m$a.k);
        this.b(hashMap, "db_total_quota", m$a.l);
        this.b(hashMap, "db_quota_per_origin", m$a.m);
        this.b(hashMap, "db_quota_step_size", m$a.n);
        final AdWebView l = d.l();
        if (AdUtil.a >= 11) {
            g.a(l.getSettings(), i);
            g.a(webView.getSettings(), i);
        }
        if (!((h)i.g.a()).a()) {
            final boolean k = l.k();
            boolean b;
            if (AdUtil.a < (int)m$a.b.a()) {
                b = true;
            }
            else {
                b = false;
            }
            if (!b && k) {
                b.a("Re-enabling hardware acceleration for a banner after reading constants.");
                l.h();
            }
            else if (b && !k) {
                b.a("Disabling hardware acceleration for a banner after reading constants.");
                l.g();
            }
        }
        final ActivationOverlay activationOverlay = (ActivationOverlay)i.e.a();
        if (!((h)i.g.a()).b() && activationOverlay != null) {
            final boolean j = activationOverlay.k();
            boolean b2;
            if (AdUtil.a < (int)m$a.c.a()) {
                b2 = true;
            }
            else {
                b2 = false;
            }
            if (!b2 && j) {
                b.a("Re-enabling hardware acceleration for an activation overlay after reading constants.");
                activationOverlay.h();
            }
            else if (b2 && !j) {
                b.a("Disabling hardware acceleration for an activation overlay after reading constants.");
                activationOverlay.g();
            }
        }
        final String s = (String)m$a.a.a();
        final al al = (al)i.s.a();
        if (al != null && !TextUtils.isEmpty((CharSequence)s)) {
            al.a(s);
        }
        m$a.o.a(true);
    }
}
