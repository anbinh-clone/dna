package com.google.ads;

import com.google.ads.util.b;
import android.webkit.WebView;
import java.util.HashMap;
import com.google.ads.internal.d;

public class y implements o
{
    @Override
    public void a(final d d, final HashMap hashMap, final WebView webView) {
        b.c("Received log message: <\"string\": \"" + hashMap.get("string") + "\", \"afmaNotifyDt\": \"" + hashMap.get("afma_notify_dt") + "\">");
    }
}
