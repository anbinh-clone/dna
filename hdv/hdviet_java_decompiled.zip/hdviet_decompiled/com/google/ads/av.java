package com.google.ads;

public final class av
{
    static final int a;
    static final int b;
    static final int c;
    static final int d;
    
    static {
        a = a(1, 3);
        b = a(1, 4);
        c = a(2, 0);
        d = a(3, 2);
    }
    
    static int a(final int n, final int n2) {
        return n2 | n << 3;
    }
}
