package com.google.ads;

import java.io.OutputStream;

public final class au
{
    private final byte[] a;
    private final int b;
    private int c;
    private int d;
    private final OutputStream e;
    
    private au(final OutputStream e, final byte[] a) {
        super();
        this.d = 0;
        this.e = e;
        this.a = a;
        this.c = 0;
        this.b = a.length;
    }
    
    public static au a(final OutputStream outputStream) {
        return a(outputStream, 4096);
    }
    
    public static au a(final OutputStream outputStream, final int n) {
        return new au(outputStream, new byte[n]);
    }
    
    private void b() {
        if (this.e == null) {
            throw new au$a();
        }
        this.e.write(this.a, 0, this.c);
        this.c = 0;
    }
    
    public final void a() {
        if (this.e != null) {
            this.b();
        }
    }
    
    public final void a(final byte b) {
        if (this.c == this.b) {
            this.b();
        }
        this.a[this.c++] = b;
        this.d += 1;
    }
    
    public final void a(final int n) {
        this.a((byte)n);
    }
    
    public final void a(final int n, final int n2) {
        this.b(av.a(n, n2));
    }
    
    public final void a(final int n, final long n2) {
        this.a(n, 0);
        this.b(n2);
    }
    
    public final void a(final int n, final String s) {
        this.a(n, 2);
        this.a(s);
    }
    
    public final void a(final long n) {
        this.b(n);
    }
    
    public final void a(final String s) {
        final byte[] bytes = s.getBytes("UTF-8");
        this.b(bytes.length);
        this.a(bytes);
    }
    
    public final void a(final byte[] array) {
        this.a(array, 0, array.length);
    }
    
    public final void a(final byte[] array, final int n, int c) {
        if (this.b - this.c >= c) {
            System.arraycopy(array, n, this.a, this.c, c);
            this.c += c;
        }
        else {
            final int n2 = this.b - this.c;
            System.arraycopy(array, n, this.a, this.c, n2);
            final int n3 = n + n2;
            c -= n2;
            this.c = this.b;
            this.d += n2;
            this.b();
            if (c <= this.b) {
                System.arraycopy(array, n3, this.a, 0, c);
                this.c = c;
            }
            else {
                this.e.write(array, n3, c);
            }
        }
        this.d += c;
    }
    
    public final void b(int n) {
        while ((n & 0xFFFFFF80) != 0x0) {
            this.a((byte)(0x80 | (n & 0x7F)));
            n >>>= 7;
        }
        this.a((byte)n);
    }
    
    public final void b(long n) {
        while ((0xFFFFFFFFFFFFFF80L & n) != 0x0L) {
            this.a((byte)(0x80 | (0x7F & (int)n)));
            n >>>= 7;
        }
        this.a((byte)n);
    }
}
