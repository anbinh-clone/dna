package com.google.ads;

import java.security.InvalidAlgorithmParameterException;
import javax.crypto.BadPaddingException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.nio.ByteBuffer;

public class an
{
    static void a(final byte[] array) {
        for (int i = 0; i < array.length; ++i) {
            array[i] ^= 0x44;
        }
    }
    
    public static byte[] a(final String s) {
        final byte[] a = aq.a(s);
        if (a.length != 32) {
            throw new an$a();
        }
        final ByteBuffer wrap = ByteBuffer.wrap(a, 4, 16);
        final byte[] array = new byte[16];
        wrap.get(array);
        a(array);
        return array;
    }
    
    public static byte[] a(final byte[] array, final String s) {
        if (array.length != 16) {
            throw new an$a();
        }
        try {
            if (aq.a(s).length <= 16) {
                throw new an$a();
            }
            goto Label_0049;
        }
        catch (NoSuchAlgorithmException ex) {
            throw new an$a(ex);
        }
        catch (InvalidKeyException ex2) {
            throw new an$a(ex2);
        }
        catch (IllegalBlockSizeException ex3) {
            throw new an$a(ex3);
        }
        catch (NoSuchPaddingException ex4) {
            throw new an$a(ex4);
        }
        catch (BadPaddingException ex5) {
            throw new an$a(ex5);
        }
        catch (InvalidAlgorithmParameterException ex6) {
            throw new an$a(ex6);
        }
    }
}
