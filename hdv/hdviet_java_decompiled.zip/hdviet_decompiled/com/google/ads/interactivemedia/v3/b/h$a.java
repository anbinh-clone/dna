package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.b.b.d;
import com.google.ads.interactivemedia.v3.api.player.VideoProgressUpdate;
import android.view.View;
import android.util.Log;
import com.google.ads.interactivemedia.v3.api.Ad;
import com.google.ads.interactivemedia.v3.b.a.a;
import android.content.Context;
import com.google.ads.interactivemedia.v3.b.b.e;
import com.google.ads.interactivemedia.v3.api.AdDisplayContainer;
import com.google.ads.interactivemedia.v3.b.b.e$a;

final class h$a implements e$a
{
    final /* synthetic */ h a;
    
    private h$a(final h a) {
        this.a = a;
        super();
    }
    
    @Override
    public final void a() {
        this.a.b.b(new r(r$b.adsManager, r$c.skip, this.a.a));
    }
    
    @Override
    public final void b() {
        this.a.b.b(new r(r$b.videoDisplay, r$c.click, this.a.a));
        this.a.b.b(this.a.g.getClickThruUrl());
    }
}
