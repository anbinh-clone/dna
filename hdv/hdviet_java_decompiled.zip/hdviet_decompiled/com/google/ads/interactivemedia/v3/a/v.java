package com.google.ads.interactivemedia.v3.a;

import com.google.ads.interactivemedia.v3.a.d.c;
import java.lang.reflect.Type;
import com.google.ads.interactivemedia.v3.a.b.j;
import com.google.ads.interactivemedia.v3.a.c.a;

final class v extends w
{
    private final s a;
    private final k b;
    private final f c;
    private final a d;
    private final x e;
    private w f;
    
    private v(final s a, final k b, final f c, final a d, final x e) {
        super();
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    private w a() {
        final w f = this.f;
        if (f != null) {
            return f;
        }
        return this.f = this.c.a(this.e, this.d);
    }
    
    public static x a(final a a, final Object o) {
        return new v$a(o, a, false, 0);
    }
    
    @Override
    public final Object a(final com.google.ads.interactivemedia.v3.a.d.a a) {
        if (this.b == null) {
            return this.a().a(a);
        }
        final l a2 = j.a(a);
        if (a2.j()) {
            return null;
        }
        try {
            final k b = this.b;
            final Type b2 = this.d.b();
            final j a3 = this.c.a;
            return b.a(a2, b2);
        }
        catch (p p) {
            throw p;
        }
        catch (Exception ex) {
            throw new p(ex);
        }
    }
    
    @Override
    public final void a(final c c, final Object o) {
        if (this.a == null) {
            this.a().a(c, o);
            return;
        }
        if (o == null) {
            c.f();
            return;
        }
        final s a = this.a;
        this.d.b();
        final r b = this.c.b;
        j.a(a.a(o), c);
    }
}
