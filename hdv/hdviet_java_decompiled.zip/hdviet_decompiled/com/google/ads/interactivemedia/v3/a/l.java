package com.google.ads.interactivemedia.v3.a;

import java.io.IOException;
import com.google.ads.interactivemedia.v3.a.b.j;
import java.io.Writer;
import com.google.ads.interactivemedia.v3.a.d.c;
import java.io.StringWriter;

public abstract class l
{
    public Number a() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }
    
    public String b() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }
    
    public double c() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }
    
    public long d() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }
    
    public int e() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }
    
    public boolean f() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }
    
    public final boolean g() {
        return this instanceof i;
    }
    
    public final boolean h() {
        return this instanceof o;
    }
    
    public final boolean i() {
        return this instanceof q;
    }
    
    public final boolean j() {
        return this instanceof n;
    }
    
    public final o k() {
        if (this instanceof o) {
            return (o)this;
        }
        throw new IllegalStateException("Not a JSON Object: " + this);
    }
    
    public final i l() {
        if (this instanceof i) {
            return (i)this;
        }
        throw new IllegalStateException("This is not a JSON Array.");
    }
    
    public final q m() {
        if (this instanceof q) {
            return (q)this;
        }
        throw new IllegalStateException("This is not a JSON Primitive.");
    }
    
    @Override
    public String toString() {
        try {
            final StringWriter stringWriter = new StringWriter();
            final c c = new c(stringWriter);
            c.b(true);
            j.a(this, c);
            return stringWriter.toString();
        }
        catch (IOException ex) {
            throw new AssertionError((Object)ex);
        }
    }
}
