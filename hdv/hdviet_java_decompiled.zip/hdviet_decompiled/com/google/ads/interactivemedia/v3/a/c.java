package com.google.ads.interactivemedia.v3.a;

import com.google.ads.interactivemedia.v3.a.b.a;
import java.lang.reflect.Field;

public final class c
{
    private final Field a;
    
    public c(final Field a) {
        super();
        a.a(a);
        this.a = a;
    }
}
