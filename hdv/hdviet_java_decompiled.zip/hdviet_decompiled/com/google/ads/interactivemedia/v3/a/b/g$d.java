package com.google.ads.interactivemedia.v3.a.b;

import java.util.Map;

final class g$d implements Map.Entry
{
    g$d a;
    g$d b;
    g$d c;
    g$d d;
    g$d e;
    final Object f;
    Object g;
    int h;
    
    g$d() {
        super();
        this.f = null;
        this.e = this;
        this.d = this;
    }
    
    g$d(final g$d a, final Object f, final g$d d, final g$d e) {
        super();
        this.a = a;
        this.f = f;
        this.h = 1;
        this.d = d;
        this.e = e;
        e.d = this;
        d.e = this;
    }
    
    public final g$d a() {
        g$d b2;
        for (g$d b = this.b; b != null; b = b2) {
            b2 = b.b;
            this = b;
        }
        return this;
    }
    
    public final g$d b() {
        g$d c2;
        for (g$d c = this.c; c != null; c = c2) {
            c2 = c.c;
            this = c;
        }
        return this;
    }
    
    @Override
    public final boolean equals(final Object o) {
        final boolean b = o instanceof Map.Entry;
        boolean b2 = false;
        if (b) {
            final Map.Entry entry = (Map.Entry)o;
            if (this.f == null) {
                final K key = (K)entry.getKey();
                b2 = false;
                if (key != null) {
                    return b2;
                }
            }
            else {
                final boolean equals = this.f.equals(entry.getKey());
                b2 = false;
                if (!equals) {
                    return b2;
                }
            }
            if (this.g == null) {
                final Object value = entry.getValue();
                b2 = false;
                if (value != null) {
                    return b2;
                }
            }
            else {
                final boolean equals2 = this.g.equals(entry.getValue());
                b2 = false;
                if (!equals2) {
                    return b2;
                }
            }
            b2 = true;
        }
        return b2;
    }
    
    @Override
    public final Object getKey() {
        return this.f;
    }
    
    @Override
    public final Object getValue() {
        return this.g;
    }
    
    @Override
    public final int hashCode() {
        int hashCode;
        if (this.f == null) {
            hashCode = 0;
        }
        else {
            hashCode = this.f.hashCode();
        }
        final Object g = this.g;
        int hashCode2 = 0;
        if (g != null) {
            hashCode2 = this.g.hashCode();
        }
        return hashCode ^ hashCode2;
    }
    
    @Override
    public final Object setValue(final Object g) {
        final Object g2 = this.g;
        this.g = g;
        return g2;
    }
    
    @Override
    public final String toString() {
        return this.f + "=" + this.g;
    }
}
