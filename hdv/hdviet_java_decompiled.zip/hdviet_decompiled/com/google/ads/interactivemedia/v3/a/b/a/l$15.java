package com.google.ads.interactivemedia.v3.a.b.a;

import java.util.Date;
import java.sql.Timestamp;
import com.google.ads.interactivemedia.v3.a.w;
import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.x;

final class l$15 implements x
{
    @Override
    public final w a(final f f, final a a) {
        if (a.a() != Timestamp.class) {
            return null;
        }
        return new l$15$1(this, f.a(Date.class));
    }
}
