package com.google.ads.interactivemedia.v3.b.b;

import android.view.View;
import android.view.View$OnClickListener;

final class a$2 implements View$OnClickListener
{
    final /* synthetic */ a a;
    
    a$2(final a a) {
        this.a = a;
        super();
    }
    
    public final void onClick(final View view) {
        this.a.a();
    }
}
