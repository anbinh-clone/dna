package com.google.ads.interactivemedia.v3.a;

import com.google.ads.interactivemedia.v3.a.b.a.l;
import java.lang.reflect.Type;
import java.sql.Timestamp;
import com.google.ads.interactivemedia.v3.a.c.a;
import java.util.Date;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.google.ads.interactivemedia.v3.a.b.d;

public final class g
{
    private d a;
    private u b;
    private e c;
    private final Map d;
    private final List e;
    private final List f;
    private boolean g;
    private String h;
    private int i;
    private int j;
    private boolean k;
    private boolean l;
    private boolean m;
    private boolean n;
    private boolean o;
    
    public g() {
        super();
        this.a = d.a;
        this.b = u.a;
        this.c = d.a;
        this.d = new HashMap();
        this.e = new ArrayList();
        this.f = new ArrayList();
        this.i = 2;
        this.j = 2;
        this.m = true;
    }
    
    public final f a() {
        final ArrayList<Object> list = new ArrayList<Object>();
        list.addAll(this.e);
        Collections.reverse(list);
        list.addAll(this.f);
        final String h = this.h;
        final int i = this.i;
        final int j = this.j;
        a a;
        if (h != null && !"".equals(h.trim())) {
            a = new a(h);
        }
        else {
            if (i == 2 || j == 2) {
                return new f(this.a, this.c, this.d, this.g, this.k, this.o, this.m, this.n, this.l, this.b, list);
            }
            a = new a(i, j);
        }
        list.add(v.a(a.a(Date.class), a));
        list.add(v.a(a.a(Timestamp.class), a));
        list.add(v.a(a.a(java.sql.Date.class), a));
        return new f(this.a, this.c, this.d, this.g, this.k, this.o, this.m, this.n, this.l, this.b, list);
    }
    
    public final g a(final Type type, final Object o) {
        boolean b = true;
        com.google.ads.interactivemedia.v3.a.b.a.a((o instanceof s || o instanceof k || o instanceof h || o instanceof w) && b);
        if (o instanceof h) {
            this.d.put(type, o);
        }
        if (o instanceof s || o instanceof k) {
            final a a = a.a(type);
            final List e = this.e;
            if (a.b() != a.a()) {
                b = false;
            }
            e.add(new v$a(o, a, b, 0));
        }
        if (o instanceof w) {
            this.e.add(l.a(a.a(type), (w)o));
        }
        return this;
    }
}
