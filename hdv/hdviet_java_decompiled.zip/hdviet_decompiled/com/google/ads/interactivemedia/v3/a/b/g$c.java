package com.google.ads.interactivemedia.v3.a.b;

import java.util.ConcurrentModificationException;
import java.util.NoSuchElementException;
import java.util.Iterator;

abstract class g$c implements Iterator
{
    g$d b;
    g$d c;
    int d;
    final /* synthetic */ g e;
    
    private g$c(final g e) {
        this.e = e;
        super();
        this.b = this.e.e.d;
        this.c = null;
        this.d = this.e.d;
    }
    
    final g$d a() {
        final g$d b = this.b;
        if (b == this.e.e) {
            throw new NoSuchElementException();
        }
        if (this.e.d != this.d) {
            throw new ConcurrentModificationException();
        }
        this.b = b.d;
        return this.c = b;
    }
    
    @Override
    public final boolean hasNext() {
        return this.b != this.e.e;
    }
    
    @Override
    public final void remove() {
        if (this.c == null) {
            throw new IllegalStateException();
        }
        this.e.a(this.c, true);
        this.c = null;
        this.d = this.e.d;
    }
}
