package com.google.ads.interactivemedia.v3.api;

import java.util.List;

public interface AdsManager
{
    void addAdErrorListener(AdErrorEvent$AdErrorListener p0);
    
    void addAdEventListener(AdEvent$AdEventListener p0);
    
    void destroy();
    
    List getAdCuePoints();
    
    Ad getCurrentAd();
    
    void init();
    
    void init(AdsRenderingSettings p0);
    
    void removeAdErrorListener(AdErrorEvent$AdErrorListener p0);
    
    void removeAdEventListener(AdEvent$AdEventListener p0);
    
    void skip();
    
    void start();
}
