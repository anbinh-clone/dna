package com.google.ads.interactivemedia.v3.b;

import java.util.Iterator;
import com.google.ads.interactivemedia.v3.api.CompanionAdSlot;
import java.util.HashMap;
import java.util.Collections;
import java.util.Map;
import java.util.Collection;
import android.view.ViewGroup;
import com.google.ads.interactivemedia.v3.api.player.VideoAdPlayer;
import com.google.ads.interactivemedia.v3.api.AdDisplayContainer;

public final class a implements AdDisplayContainer
{
    private static int e;
    private VideoAdPlayer a;
    private ViewGroup b;
    private Collection c;
    private Map d;
    
    static {
        a.e = 0;
    }
    
    public a() {
        super();
        this.c = Collections.emptyList();
        this.d = null;
    }
    
    public final Map a() {
        if (this.d == null) {
            this.d = new HashMap();
            for (final CompanionAdSlot companionAdSlot : this.c) {
                final Map d = this.d;
                final StringBuilder sb = new StringBuilder("compSlot_");
                final int e = a.e;
                a.e = e + 1;
                d.put(sb.append(e).toString(), companionAdSlot);
            }
        }
        return this.d;
    }
    
    @Override
    public final ViewGroup getAdContainer() {
        return this.b;
    }
    
    @Override
    public final Collection getCompanionSlots() {
        return this.c;
    }
    
    @Override
    public final VideoAdPlayer getPlayer() {
        return this.a;
    }
    
    @Override
    public final void setAdContainer(final ViewGroup b) {
        this.b = b;
    }
    
    @Override
    public final void setCompanionSlots(final Collection c) {
        this.c = c;
    }
    
    @Override
    public final void setPlayer(final VideoAdPlayer a) {
        this.a = a;
    }
}
