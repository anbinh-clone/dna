package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.api.AdsManager;
import com.google.ads.interactivemedia.v3.api.AdsManagerLoadedEvent;

public final class g implements AdsManagerLoadedEvent
{
    private final AdsManager a;
    private final Object b;
    
    g(final AdsManager a, final Object b) {
        super();
        this.a = a;
        this.b = b;
    }
    
    @Override
    public final AdsManager getAdsManager() {
        return this.a;
    }
    
    @Override
    public final Object getUserRequestContext() {
        return this.b;
    }
}
