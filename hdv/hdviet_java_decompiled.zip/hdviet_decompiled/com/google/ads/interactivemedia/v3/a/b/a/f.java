package com.google.ads.interactivemedia.v3.a.b.a;

import java.lang.reflect.Type;
import com.google.ads.interactivemedia.v3.a.b.b;
import java.util.Map;
import com.google.ads.interactivemedia.v3.a.w;
import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.b.c;
import com.google.ads.interactivemedia.v3.a.x;

public final class f implements x
{
    private final c a;
    private final boolean b;
    
    public f(final c a, final boolean b) {
        super();
        this.a = a;
        this.b = b;
    }
    
    @Override
    public final w a(final f f, final a a) {
        final Type b = a.b();
        if (!Map.class.isAssignableFrom(a.a())) {
            return null;
        }
        final Type[] b2 = b.b(b, b.b(b));
        final Type type = b2[0];
        w w;
        if (type == Boolean.TYPE || type == Boolean.class) {
            w = l.f;
        }
        else {
            w = f.a(a.a(type));
        }
        return new f$a(this, f, b2[0], w, b2[1], f.a(a.a(b2[1])), this.a.a(a));
    }
}
