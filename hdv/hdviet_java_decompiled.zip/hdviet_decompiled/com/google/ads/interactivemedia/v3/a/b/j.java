package com.google.ads.interactivemedia.v3.a.b;

import com.google.ads.interactivemedia.v3.a.d.c;
import java.io.Writer;
import java.io.IOException;
import com.google.ads.interactivemedia.v3.a.m;
import com.google.ads.interactivemedia.v3.a.d.d;
import java.io.EOFException;
import com.google.ads.interactivemedia.v3.a.t;
import com.google.ads.interactivemedia.v3.a.n;
import com.google.ads.interactivemedia.v3.a.l;
import com.google.ads.interactivemedia.v3.a.d.a;

public final class j
{
    public static l a(final a a) {
        boolean b = true;
        try {
            a.f();
            b = false;
            return (l)com.google.ads.interactivemedia.v3.a.b.a.l.P.a(a);
        }
        catch (EOFException ex) {
            if (b) {
                return n.a;
            }
            throw new t(ex);
        }
        catch (d d) {
            throw new t(d);
        }
        catch (IOException ex2) {
            throw new m(ex2);
        }
        catch (NumberFormatException ex3) {
            throw new t(ex3);
        }
    }
    
    public static Writer a(final Appendable appendable) {
        if (appendable instanceof Writer) {
            return (Writer)appendable;
        }
        return new j$a(appendable, 0);
    }
    
    public static void a(final l l, final c c) {
        com.google.ads.interactivemedia.v3.a.b.a.l.P.a(c, l);
    }
}
