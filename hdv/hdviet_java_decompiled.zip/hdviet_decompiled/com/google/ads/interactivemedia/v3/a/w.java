package com.google.ads.interactivemedia.v3.a;

import com.google.ads.interactivemedia.v3.a.d.a;
import java.io.IOException;
import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.b.a.e;

public abstract class w
{
    public final l a(final Object o) {
        try {
            final e e = new e();
            this.a(e, o);
            return e.a();
        }
        catch (IOException ex) {
            throw new m(ex);
        }
    }
    
    public abstract Object a(final a p0);
    
    public abstract void a(final c p0, final Object p1);
}
