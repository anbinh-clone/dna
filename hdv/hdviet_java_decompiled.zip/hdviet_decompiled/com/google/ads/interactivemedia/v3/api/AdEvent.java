package com.google.ads.interactivemedia.v3.api;

public interface AdEvent
{
    Ad getAd();
    
    AdEvent$AdEventType getType();
}
