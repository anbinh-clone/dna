package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.w;
import com.google.ads.interactivemedia.v3.a.x;

final class l$25 implements x
{
    final /* synthetic */ Class a;
    final /* synthetic */ w b;
    
    l$25(final Class a, final w b) {
        this.a = a;
        this.b = b;
        super();
    }
    
    @Override
    public final w a(final f f, final a a) {
        if (this.a.isAssignableFrom(a.a())) {
            return this.b;
        }
        return null;
    }
    
    @Override
    public final String toString() {
        return "Factory[typeHierarchy=" + this.a.getName() + ",adapter=" + this.b + "]";
    }
}
