package com.google.ads.interactivemedia.v3.b.b;

import android.graphics.Canvas;
import android.graphics.Paint$Style;
import android.graphics.drawable.shapes.Shape;
import android.graphics.Paint;
import android.graphics.drawable.ShapeDrawable;

final class b$a extends ShapeDrawable
{
    private Paint a;
    private Paint b;
    
    public b$a() {
        super((Shape)new b$a$1());
        (this.a = new Paint()).setAntiAlias(true);
        this.a.setStyle(Paint$Style.STROKE);
        this.a.setStrokeWidth(1.0f);
        this.a.setARGB(150, 255, 255, 255);
        (this.b = new Paint()).setStyle(Paint$Style.FILL);
        this.b.setColor(-16777216);
        this.b.setAlpha(140);
    }
    
    protected final void onDraw(final Shape shape, final Canvas canvas, final Paint paint) {
        shape.draw(canvas, this.b);
        shape.draw(canvas, this.a);
    }
}
