package com.google.ads.interactivemedia.v3.a.b;

import java.lang.reflect.Type;
import java.lang.reflect.GenericArrayType;
import java.io.Serializable;

final class b$a implements Serializable, GenericArrayType
{
    private final Type a;
    
    public b$a(final Type type) {
        super();
        this.a = b.a(type);
    }
    
    @Override
    public final boolean equals(final Object o) {
        return o instanceof GenericArrayType && b.a(this, (Type)o);
    }
    
    @Override
    public final Type getGenericComponentType() {
        return this.a;
    }
    
    @Override
    public final int hashCode() {
        return this.a.hashCode();
    }
    
    @Override
    public final String toString() {
        return b.c(this.a) + "[]";
    }
}
