package com.google.ads.interactivemedia.v3.a;

final class f$2 implements r
{
    final /* synthetic */ f a;
    
    f$2(final f a) {
        this.a = a;
        super();
    }
}
