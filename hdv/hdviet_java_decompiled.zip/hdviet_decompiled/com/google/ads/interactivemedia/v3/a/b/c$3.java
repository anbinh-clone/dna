package com.google.ads.interactivemedia.v3.a.b;

final class c$3 implements h
{
    final /* synthetic */ c a;
    
    c$3(final c a) {
        this.a = a;
        super();
    }
    
    @Override
    public final Object a() {
        return new g();
    }
}
