package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.api.AdError;
import com.google.ads.interactivemedia.v3.api.AdErrorEvent;

public final class b implements AdErrorEvent
{
    private final AdError a;
    private final Object b;
    
    b(final AdError a) {
        super();
        this.a = a;
        this.b = null;
    }
    
    b(final AdError a, final Object b) {
        super();
        this.a = a;
        this.b = b;
    }
    
    @Override
    public final AdError getError() {
        return this.a;
    }
    
    @Override
    public final Object getUserRequestContext() {
        return this.b;
    }
}
