package com.google.ads.interactivemedia.v3.a.b.a;

import java.io.Reader;

final class d$1 extends Reader
{
    @Override
    public final void close() {
        throw new AssertionError();
    }
    
    @Override
    public final int read(final char[] array, final int n, final int n2) {
        throw new AssertionError();
    }
}
