package com.google.ads.interactivemedia.v3.a;

import com.google.ads.interactivemedia.v3.a.c.a;

public interface x
{
    w a(f p0, a p1);
}
