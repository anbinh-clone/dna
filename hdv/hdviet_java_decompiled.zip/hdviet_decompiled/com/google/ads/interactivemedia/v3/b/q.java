package com.google.ads.interactivemedia.v3.b;

import android.view.View;
import java.util.HashMap;
import android.content.Context;
import com.google.ads.interactivemedia.v3.b.a.c;
import android.view.View$OnClickListener;
import android.widget.ImageView;

public final class q extends ImageView implements View$OnClickListener
{
    private final c a;
    private final s b;
    private final String c;
    
    public q(final Context context, final s b, final c a, final String c) {
        super(context);
        this.b = b;
        this.a = a;
        this.c = c;
        this.setOnClickListener((View$OnClickListener)this);
        new q$1(this).execute((Object[])new Void[0]);
    }
    
    public final void onClick(final View view) {
        this.b.b(this.a.clickThroughUrl);
    }
}
