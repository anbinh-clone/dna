package com.google.ads.interactivemedia.v3.a;

public final class n extends l
{
    public static final n a;
    
    static {
        a = new n();
    }
    
    @Override
    public final boolean equals(final Object o) {
        return this == o || o instanceof n;
    }
    
    @Override
    public final int hashCode() {
        return n.class.hashCode();
    }
}
