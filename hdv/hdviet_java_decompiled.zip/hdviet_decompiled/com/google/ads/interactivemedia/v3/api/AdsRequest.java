package com.google.ads.interactivemedia.v3.api;

import java.util.Map;

public interface AdsRequest
{
    AdDisplayContainer getAdDisplayContainer();
    
    String getAdTagUrl();
    
    String getAdsResponse();
    
    String getExtraParameter(String p0);
    
    Map getExtraParameters();
    
    Object getUserRequestContext();
    
    void setAdDisplayContainer(AdDisplayContainer p0);
    
    void setAdTagUrl(String p0);
    
    void setAdsResponse(String p0);
    
    void setExtraParameter(String p0, String p1);
    
    void setUserRequestContext(Object p0);
}
