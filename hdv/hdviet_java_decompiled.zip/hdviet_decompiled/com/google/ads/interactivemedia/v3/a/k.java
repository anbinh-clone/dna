package com.google.ads.interactivemedia.v3.a;

import java.lang.reflect.Type;

public interface k
{
    Object a(l p0, Type p1);
}
