package com.google.ads.interactivemedia.v3.b;

public enum r$c
{
    adMetadata("adMetadata", 0), 
    adRemainingTime("adRemainingTime", 38), 
    adsLoaded("adsLoaded", 1), 
    allAdsCompleted("allAdsCompleted", 2), 
    click("click", 3), 
    companionView("companionView", 5), 
    complete("complete", 4), 
    contentComplete("contentComplete", 6), 
    contentPauseRequested("contentPauseRequested", 7), 
    contentResumeRequested("contentResumeRequested", 8), 
    contentTimeUpdate("contentTimeUpdate", 9), 
    csi("csi", 10), 
    destroy("destroy", 12), 
    displayCompanions("displayCompanions", 11), 
    end("end", 13), 
    error("error", 14), 
    firstquartile("firstquartile", 15), 
    fullscreen("fullscreen", 16), 
    hide("hide", 17), 
    init("init", 18), 
    initialized("initialized", 19), 
    learnMore("learnMore", 39), 
    load("load", 20), 
    loaded("loaded", 21), 
    log("log", 22), 
    midpoint("midpoint", 23), 
    mute("mute", 24), 
    pause("pause", 25), 
    play("play", 26), 
    preSkipButton("preSkipButton", 40), 
    requestAds("requestAds", 28), 
    resume("resume", 27), 
    showVideo("showVideo", 29), 
    skip("skip", 30), 
    skipButton("skipButton", 41), 
    start("start", 31), 
    startTracking("startTracking", 32), 
    stop("stop", 33), 
    stopTracking("stopTracking", 34), 
    thirdquartile("thirdquartile", 35), 
    timeupdate("timeupdate", 36), 
    unmute("unmute", 37);
    
    static {
        a = new r$c[] { r$c.adMetadata, r$c.adsLoaded, r$c.allAdsCompleted, r$c.click, r$c.complete, r$c.companionView, r$c.contentComplete, r$c.contentPauseRequested, r$c.contentResumeRequested, r$c.contentTimeUpdate, r$c.csi, r$c.displayCompanions, r$c.destroy, r$c.end, r$c.error, r$c.firstquartile, r$c.fullscreen, r$c.hide, r$c.init, r$c.initialized, r$c.load, r$c.loaded, r$c.log, r$c.midpoint, r$c.mute, r$c.pause, r$c.play, r$c.resume, r$c.requestAds, r$c.showVideo, r$c.skip, r$c.start, r$c.startTracking, r$c.stop, r$c.stopTracking, r$c.thirdquartile, r$c.timeupdate, r$c.unmute, r$c.adRemainingTime, r$c.learnMore, r$c.preSkipButton, r$c.skipButton };
    }
}
