package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.o;
import com.google.ads.interactivemedia.v3.a.i;
import com.google.ads.interactivemedia.v3.a.n;
import com.google.ads.interactivemedia.v3.a.b.f;
import com.google.ads.interactivemedia.v3.a.d.a;
import java.util.Iterator;
import com.google.ads.interactivemedia.v3.a.q;
import java.util.Map;
import com.google.ads.interactivemedia.v3.a.l;
import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.w;

final class l$18 extends w
{
    private void a(final c c, final l l) {
        if (l == null || l.j()) {
            c.f();
            return;
        }
        if (l.i()) {
            final q m = l.m();
            if (m.o()) {
                c.a(m.a());
                return;
            }
            if (m.n()) {
                c.a(m.f());
                return;
            }
            c.b(m.b());
        }
        else {
            if (l.g()) {
                c.b();
                final Iterator iterator = l.l().iterator();
                while (iterator.hasNext()) {
                    this.a(c, iterator.next());
                }
                c.c();
                return;
            }
            if (l.h()) {
                c.d();
                for (final Map.Entry<String, V> entry : l.k().n()) {
                    c.a(entry.getKey());
                    this.a(c, (l)entry.getValue());
                }
                c.e();
                return;
            }
            throw new IllegalArgumentException("Couldn't write " + l.getClass());
        }
    }
    
    private l b(final a a) {
        switch (l$26.a[a.f().ordinal()]) {
            default: {
                throw new IllegalArgumentException();
            }
            case 3: {
                return new q(a.h());
            }
            case 1: {
                return new q(new f(a.h()));
            }
            case 2: {
                return new q(Boolean.valueOf(a.i()));
            }
            case 4: {
                a.j();
                return n.a;
            }
            case 5: {
                final i i = new i();
                a.a();
                while (a.e()) {
                    i.a(this.b(a));
                }
                a.b();
                return i;
            }
            case 6: {
                final o o = new o();
                a.c();
                while (a.e()) {
                    o.a(a.g(), this.b(a));
                }
                a.d();
                return o;
            }
        }
    }
}
