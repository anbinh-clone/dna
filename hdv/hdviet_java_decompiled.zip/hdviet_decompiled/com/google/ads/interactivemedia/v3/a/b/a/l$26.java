package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.d.b;

final class l$26
{
    static {
        a = new int[b.values().length];
        while (true) {
            try {
                l$26.a[b.g.ordinal()] = 1;
                try {
                    l$26.a[b.h.ordinal()] = 2;
                    try {
                        l$26.a[b.f.ordinal()] = 3;
                        try {
                            l$26.a[b.i.ordinal()] = 4;
                            try {
                                l$26.a[b.a.ordinal()] = 5;
                                try {
                                    l$26.a[b.c.ordinal()] = 6;
                                    try {
                                        l$26.a[b.j.ordinal()] = 7;
                                        try {
                                            l$26.a[b.e.ordinal()] = 8;
                                            try {
                                                l$26.a[b.d.ordinal()] = 9;
                                                try {
                                                    l$26.a[b.b.ordinal()] = 10;
                                                }
                                                catch (NoSuchFieldError noSuchFieldError) {}
                                            }
                                            catch (NoSuchFieldError noSuchFieldError2) {}
                                        }
                                        catch (NoSuchFieldError noSuchFieldError3) {}
                                    }
                                    catch (NoSuchFieldError noSuchFieldError4) {}
                                }
                                catch (NoSuchFieldError noSuchFieldError5) {}
                            }
                            catch (NoSuchFieldError noSuchFieldError6) {}
                        }
                        catch (NoSuchFieldError noSuchFieldError7) {}
                    }
                    catch (NoSuchFieldError noSuchFieldError8) {}
                }
                catch (NoSuchFieldError noSuchFieldError9) {}
            }
            catch (NoSuchFieldError noSuchFieldError10) {
                continue;
            }
            break;
        }
    }
}
