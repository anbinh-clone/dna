package com.google.ads.interactivemedia.v3.b;

import android.webkit.WebViewClient;
import android.webkit.WebView$WebViewTransport;
import android.os.Message;
import android.webkit.WebView;
import android.content.Context;
import android.webkit.WebChromeClient;

final class l$1 extends WebChromeClient
{
    final /* synthetic */ Context a;
    final /* synthetic */ s b;
    final /* synthetic */ l c;
    
    l$1(final l c, final Context a, final s b) {
        this.c = c;
        this.a = a;
        this.b = b;
        super();
    }
    
    public final boolean onCreateWindow(final WebView webView, final boolean b, final boolean b2, final Message message) {
        final WebView$WebViewTransport webView$WebViewTransport = (WebView$WebViewTransport)message.obj;
        webView$WebViewTransport.setWebView(new WebView(this.a));
        webView$WebViewTransport.getWebView().setWebViewClient((WebViewClient)new l$1$1(this));
        message.sendToTarget();
        return true;
    }
}
