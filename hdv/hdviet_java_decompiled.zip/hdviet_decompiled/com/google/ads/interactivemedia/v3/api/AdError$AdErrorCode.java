package com.google.ads.interactivemedia.v3.api;

public enum AdError$AdErrorCode
{
    API_ERROR("API_ERROR", 18, 1102), 
    COMPANION_AD_LOADING_FAILED("COMPANION_AD_LOADING_FAILED", 11, 603), 
    FAILED_TO_REQUEST_ADS("FAILED_TO_REQUEST_ADS", 14, 1005), 
    INTERNAL_ERROR("INTERNAL_ERROR", 0, -1), 
    INVALID_ARGUMENTS("INVALID_ARGUMENTS", 17, 1101), 
    OVERLAY_AD_LOADING_FAILED("OVERLAY_AD_LOADING_FAILED", 9, 502), 
    OVERLAY_AD_PLAYING_FAILED("OVERLAY_AD_PLAYING_FAILED", 8, 500), 
    PLAYLIST_MALFORMED_RESPONSE("PLAYLIST_MALFORMED_RESPONSE", 13, 1004), 
    REQUIRED_LISTENERS_NOT_ADDED("REQUIRED_LISTENERS_NOT_ADDED", 15, 1006), 
    UNKNOWN_AD_RESPONSE("UNKNOWN_AD_RESPONSE", 2, 200), 
    UNKNOWN_ERROR("UNKNOWN_ERROR", 12, 900), 
    VAST_ASSET_NOT_FOUND("VAST_ASSET_NOT_FOUND", 16, 1007), 
    VAST_INVALID_URL("VAST_INVALID_URL", 5, 303), 
    VAST_LINEAR_ASSET_MISMATCH("VAST_LINEAR_ASSET_MISMATCH", 7, 403), 
    VAST_LOAD_TIMEOUT("VAST_LOAD_TIMEOUT", 3, 301), 
    VAST_MALFORMED_RESPONSE("VAST_MALFORMED_RESPONSE", 1, 100), 
    VAST_NONLINEAR_ASSET_MISMATCH("VAST_NONLINEAR_ASSET_MISMATCH", 10, 503), 
    VAST_TOO_MANY_REDIRECTS("VAST_TOO_MANY_REDIRECTS", 4, 302), 
    VIDEO_PLAY_ERROR("VIDEO_PLAY_ERROR", 6, 400);
    
    private final int a;
    
    static {
        b = new AdError$AdErrorCode[] { AdError$AdErrorCode.INTERNAL_ERROR, AdError$AdErrorCode.VAST_MALFORMED_RESPONSE, AdError$AdErrorCode.UNKNOWN_AD_RESPONSE, AdError$AdErrorCode.VAST_LOAD_TIMEOUT, AdError$AdErrorCode.VAST_TOO_MANY_REDIRECTS, AdError$AdErrorCode.VAST_INVALID_URL, AdError$AdErrorCode.VIDEO_PLAY_ERROR, AdError$AdErrorCode.VAST_LINEAR_ASSET_MISMATCH, AdError$AdErrorCode.OVERLAY_AD_PLAYING_FAILED, AdError$AdErrorCode.OVERLAY_AD_LOADING_FAILED, AdError$AdErrorCode.VAST_NONLINEAR_ASSET_MISMATCH, AdError$AdErrorCode.COMPANION_AD_LOADING_FAILED, AdError$AdErrorCode.UNKNOWN_ERROR, AdError$AdErrorCode.PLAYLIST_MALFORMED_RESPONSE, AdError$AdErrorCode.FAILED_TO_REQUEST_ADS, AdError$AdErrorCode.REQUIRED_LISTENERS_NOT_ADDED, AdError$AdErrorCode.VAST_ASSET_NOT_FOUND, AdError$AdErrorCode.INVALID_ARGUMENTS, AdError$AdErrorCode.API_ERROR };
    }
    
    private AdError$AdErrorCode(final String s, final int n, final int a) {
        this.a = a;
    }
    
    static AdError$AdErrorCode a(final int n) {
        for (final AdError$AdErrorCode adError$AdErrorCode : values()) {
            if (adError$AdErrorCode.a == n) {
                return adError$AdErrorCode;
            }
        }
        if (1204 == n) {
            return AdError$AdErrorCode.INTERNAL_ERROR;
        }
        return AdError$AdErrorCode.UNKNOWN_ERROR;
    }
    
    public final boolean equals(final int n) {
        return this.a == n;
    }
}
