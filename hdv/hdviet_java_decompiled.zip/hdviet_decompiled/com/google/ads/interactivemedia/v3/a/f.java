package com.google.ads.interactivemedia.v3.a;

import java.io.Writer;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.io.IOException;
import java.io.EOFException;
import java.lang.reflect.Type;
import com.google.ads.interactivemedia.v3.a.b.a.h;
import com.google.ads.interactivemedia.v3.a.b.a.f;
import com.google.ads.interactivemedia.v3.a.b.a.b;
import com.google.ads.interactivemedia.v3.a.b.a.a;
import com.google.ads.interactivemedia.v3.a.b.a.i;
import com.google.ads.interactivemedia.v3.a.b.a.j;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.Collection;
import com.google.ads.interactivemedia.v3.a.b.a.g;
import com.google.ads.interactivemedia.v3.a.b.a.l;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;
import com.google.ads.interactivemedia.v3.a.b.d;
import com.google.ads.interactivemedia.v3.a.b.c;
import java.util.List;
import java.util.Map;

public final class f
{
    final j a;
    final r b;
    private final ThreadLocal c;
    private final Map d;
    private final List e;
    private final c f;
    private final boolean g;
    private final boolean h;
    private final boolean i;
    private final boolean j;
    
    public f() {
        this(d.a, d.a, Collections.emptyMap(), false, false, false, true, false, false, u.a, Collections.emptyList());
    }
    
    f(final d d, final e e, final Map map, final boolean g, final boolean b, final boolean i, final boolean h, final boolean j, final boolean b2, final u u, final List list) {
        super();
        this.c = new ThreadLocal();
        this.d = Collections.synchronizedMap(new HashMap<Object, Object>());
        this.a = new f$1(this);
        this.b = new f$2(this);
        this.f = new c(map);
        this.g = g;
        this.i = i;
        this.h = h;
        this.j = j;
        final ArrayList<Object> list2 = new ArrayList<Object>();
        list2.add(l.Q);
        list2.add(g.a);
        list2.add(d);
        list2.addAll(list);
        list2.add(l.x);
        list2.add(l.m);
        list2.add(l.g);
        list2.add(l.i);
        list2.add(l.k);
        final Class<Long> type = Long.TYPE;
        w n;
        if (u == u.a) {
            n = l.n;
        }
        else {
            n = new f$5(this);
        }
        list2.add(l.a(type, Long.class, n));
        final Class<Double> type2 = Double.TYPE;
        w p11;
        if (b2) {
            p11 = l.p;
        }
        else {
            p11 = new f$3(this);
        }
        list2.add(l.a(type2, Double.class, p11));
        final Class<Float> type3 = Float.TYPE;
        w o;
        if (b2) {
            o = l.o;
        }
        else {
            o = new f$4(this);
        }
        list2.add(l.a(type3, Float.class, o));
        list2.add(l.r);
        list2.add(l.t);
        list2.add(l.z);
        list2.add(l.B);
        list2.add(l.a(BigDecimal.class, l.v));
        list2.add(l.a(BigInteger.class, l.w));
        list2.add(l.D);
        list2.add(l.F);
        list2.add(l.J);
        list2.add(l.O);
        list2.add(l.H);
        list2.add(l.d);
        list2.add(com.google.ads.interactivemedia.v3.a.b.a.c.a);
        list2.add(l.M);
        list2.add(j.a);
        list2.add(i.a);
        list2.add(l.K);
        list2.add(a.a);
        list2.add(l.R);
        list2.add(l.b);
        list2.add(new b(this.f));
        list2.add(new f(this.f, b));
        list2.add(new h(this.f, e, d));
        this.e = Collections.unmodifiableList((List<?>)list2);
    }
    
    private Object a(final com.google.ads.interactivemedia.v3.a.d.a a, final Type type) {
        boolean b = true;
        a.p();
        a.a(b);
        try {
            a.f();
            b = false;
            return this.a(com.google.ads.interactivemedia.v3.a.c.a.a(type)).a(a);
        }
        catch (EOFException ex) {
            if (b) {
                return null;
            }
            throw new t(ex);
        }
        catch (IllegalStateException ex3) {}
        catch (IOException ex4) {
            final IOException ex2;
            throw new t(ex2);
        }
    }
    
    public final w a(final com.google.ads.interactivemedia.v3.a.c.a a) {
        w a2 = this.d.get(a);
        if (a2 == null) {
            final Map<com.google.ads.interactivemedia.v3.a.c.a, f$a> map = this.c.get();
            while (true) {
                Label_0231: {
                    if (map != null) {
                        break Label_0231;
                    }
                    final HashMap<Object, f$a> hashMap = new HashMap<Object, f$a>();
                    this.c.set(hashMap);
                    final Object o = hashMap;
                    final int n = 1;
                    a2 = ((Map<Object, f$a>)o).get(a);
                    if (a2 != null) {
                        return a2;
                    }
                    try {
                        final f$a f$a = new f$a();
                        ((Map<com.google.ads.interactivemedia.v3.a.c.a, f$a>)o).put(a, f$a);
                        final Iterator<x> iterator = (Iterator<x>)this.e.iterator();
                        while (iterator.hasNext()) {
                            a2 = iterator.next().a(this, a);
                            if (a2 != null) {
                                f$a.a(a2);
                                this.d.put(a, a2);
                                return a2;
                            }
                        }
                        throw new IllegalArgumentException("GSON cannot handle " + a);
                    }
                    finally {
                        ((Map<Object, f$a>)o).remove(a);
                        if (n != 0) {
                            this.c.remove();
                        }
                    }
                }
                final Object o = map;
                final int n = 0;
                continue;
            }
        }
        return a2;
    }
    
    public final w a(final x x, final com.google.ads.interactivemedia.v3.a.c.a a) {
        final Iterator<x> iterator = (Iterator<x>)this.e.iterator();
        int n = 0;
        while (iterator.hasNext()) {
            final x x2 = iterator.next();
            if (n == 0) {
                if (x2 != x) {
                    continue;
                }
                n = 1;
            }
            else {
                final w a2 = x2.a(this, a);
                if (a2 != null) {
                    return a2;
                }
                continue;
            }
        }
        throw new IllegalArgumentException("GSON cannot serialize " + a);
    }
    
    public final w a(final Class clazz) {
        return this.a(com.google.ads.interactivemedia.v3.a.c.a.a(clazz));
    }
    
    public final Object a(final String s, final Class clazz) {
        Object a;
        if (s == null) {
            a = null;
        }
        else {
            final com.google.ads.interactivemedia.v3.a.d.a a2 = new com.google.ads.interactivemedia.v3.a.d.a(new StringReader(s));
            a = this.a(a2, clazz);
            if (a != null) {
                try {
                    if (a2.f() != com.google.ads.interactivemedia.v3.a.d.b.j) {
                        throw new m("JSON document was not fully consumed.");
                    }
                }
                catch (com.google.ads.interactivemedia.v3.a.d.d d) {
                    throw new t(d);
                }
                catch (IOException ex) {
                    throw new m(ex);
                }
            }
        }
        return com.google.ads.interactivemedia.v3.a.b.i.a(clazz).cast(a);
    }
    
    public final void a(final Object o, final Type type, final Appendable appendable) {
        try {
            final Writer a = com.google.ads.interactivemedia.v3.a.b.j.a(appendable);
            if (this.i) {
                a.write(")]}'\n");
            }
            final com.google.ads.interactivemedia.v3.a.d.c c = new com.google.ads.interactivemedia.v3.a.d.c(a);
            if (this.j) {
                c.c("  ");
            }
            c.d(this.g);
            final w a2 = this.a(com.google.ads.interactivemedia.v3.a.c.a.a(type));
            final boolean g = c.g();
            c.b(true);
            final boolean h = c.h();
            c.c(this.h);
            final boolean i = c.i();
            c.d(this.g);
            try {
                a2.a(c, o);
            }
            catch (IOException ex) {
                throw new m(ex);
            }
            finally {
                c.b(g);
                c.c(h);
                c.d(i);
            }
        }
        catch (IOException ex2) {
            throw new m(ex2);
        }
    }
    
    @Override
    public final String toString() {
        return "{serializeNulls:" + this.g + "factories:" + this.e + ",instanceCreators:" + this.f + "}";
    }
}
