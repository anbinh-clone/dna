package com.google.ads.interactivemedia.v3.a.b;

final class j$a$a implements CharSequence
{
    char[] a;
    
    @Override
    public final char charAt(final int n) {
        return this.a[n];
    }
    
    @Override
    public final int length() {
        return this.a.length;
    }
    
    @Override
    public final CharSequence subSequence(final int n, final int n2) {
        return new String(this.a, n, n2 - n);
    }
}
