package com.google.ads.interactivemedia.v3.api;

public enum AdEvent$AdEventType
{
    ALL_ADS_COMPLETED("ALL_ADS_COMPLETED", 0), 
    CLICKED("CLICKED", 1), 
    COMPLETED("COMPLETED", 2), 
    CONTENT_PAUSE_REQUESTED("CONTENT_PAUSE_REQUESTED", 3), 
    CONTENT_RESUME_REQUESTED("CONTENT_RESUME_REQUESTED", 4), 
    FIRST_QUARTILE("FIRST_QUARTILE", 5), 
    LOADED("LOADED", 12), 
    MIDPOINT("MIDPOINT", 6), 
    PAUSED("PAUSED", 7), 
    RESUMED("RESUMED", 8), 
    SKIPPED("SKIPPED", 9), 
    STARTED("STARTED", 10), 
    THIRD_QUARTILE("THIRD_QUARTILE", 11);
    
    static {
        a = new AdEvent$AdEventType[] { AdEvent$AdEventType.ALL_ADS_COMPLETED, AdEvent$AdEventType.CLICKED, AdEvent$AdEventType.COMPLETED, AdEvent$AdEventType.CONTENT_PAUSE_REQUESTED, AdEvent$AdEventType.CONTENT_RESUME_REQUESTED, AdEvent$AdEventType.FIRST_QUARTILE, AdEvent$AdEventType.MIDPOINT, AdEvent$AdEventType.PAUSED, AdEvent$AdEventType.RESUMED, AdEvent$AdEventType.SKIPPED, AdEvent$AdEventType.STARTED, AdEvent$AdEventType.THIRD_QUARTILE, AdEvent$AdEventType.LOADED };
    }
}
