package com.google.ads.interactivemedia.v3.b;

import java.util.SortedSet;
import java.util.List;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorCode;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorType;

public interface s$a
{
    void a(String p0, AdError$AdErrorType p1, int p2, String p3);
    
    void a(String p0, AdError$AdErrorType p1, AdError$AdErrorCode p2, String p3);
    
    void a(String p0, u p1, List p2, SortedSet p3);
}
