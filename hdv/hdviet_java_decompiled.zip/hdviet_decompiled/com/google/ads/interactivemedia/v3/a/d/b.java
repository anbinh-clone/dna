package com.google.ads.interactivemedia.v3.a.d;

public enum b
{
    a("BEGIN_ARRAY", 0), 
    b("END_ARRAY", 1), 
    c("BEGIN_OBJECT", 2), 
    d("END_OBJECT", 3), 
    e("NAME", 4), 
    f("STRING", 5), 
    g("NUMBER", 6), 
    h("BOOLEAN", 7), 
    i("NULL", 8), 
    j("END_DOCUMENT", 9);
    
    static {
        k = new b[] { b.a, b.b, b.c, b.d, b.e, b.f, b.g, b.h, b.i, b.j };
    }
}
