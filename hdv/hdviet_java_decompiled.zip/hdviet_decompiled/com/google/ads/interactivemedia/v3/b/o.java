package com.google.ads.interactivemedia.v3.b;

import java.util.Iterator;
import com.google.ads.interactivemedia.v3.api.AdErrorEvent;
import com.google.ads.interactivemedia.v3.api.AdErrorEvent$AdErrorListener;
import java.util.ArrayList;
import java.util.List;

public final class o
{
    private final List a;
    
    public o() {
        super();
        this.a = new ArrayList(1);
    }
    
    public final void a(final AdErrorEvent$AdErrorListener adErrorEvent$AdErrorListener) {
        this.a.add(adErrorEvent$AdErrorListener);
    }
    
    public final void a(final AdErrorEvent adErrorEvent) {
        final Iterator<AdErrorEvent$AdErrorListener> iterator = this.a.iterator();
        while (iterator.hasNext()) {
            iterator.next().onAdError(adErrorEvent);
        }
    }
    
    public final void b(final AdErrorEvent$AdErrorListener adErrorEvent$AdErrorListener) {
        this.a.remove(adErrorEvent$AdErrorListener);
    }
}
