package com.google.ads.interactivemedia.v3.b;

import android.graphics.Bitmap;
import android.webkit.WebView;
import android.webkit.WebViewClient;

final class t$1 extends WebViewClient
{
    final /* synthetic */ t a;
    
    t$1(final t a) {
        this.a = a;
        super();
    }
    
    public final void onPageFinished(final WebView webView, final String s) {
    }
    
    public final void onPageStarted(final WebView webView, final String s, final Bitmap bitmap) {
    }
    
    public final void onReceivedError(final WebView webView, final int n, final String s, final String s2) {
        new StringBuilder("Error: ").append(n).append(" ").append(s).append(" ").append(s2);
    }
    
    public final boolean shouldOverrideUrlLoading(final WebView webView, final String s) {
        if (!s.startsWith("gmsg://")) {
            return false;
        }
        this.a.b(s);
        return true;
    }
}
