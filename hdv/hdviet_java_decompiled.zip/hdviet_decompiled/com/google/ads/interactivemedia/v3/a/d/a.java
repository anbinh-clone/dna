package com.google.ads.interactivemedia.v3.a.d;

import java.io.EOFException;
import java.io.IOException;
import com.google.ads.interactivemedia.v3.a.b.e;
import java.io.Reader;
import java.io.Closeable;

public class a implements Closeable
{
    private static final char[] a;
    private final Reader b;
    private boolean c;
    private final char[] d;
    private int e;
    private int f;
    private int g;
    private int h;
    private int i;
    private long j;
    private int k;
    private String l;
    private int[] m;
    private int n;
    
    static {
        a = ")]}'\n".toCharArray();
        e.a = new a$1();
    }
    
    public a(final Reader b) {
        super();
        this.c = false;
        this.d = new char[1024];
        this.e = 0;
        this.f = 0;
        this.g = 0;
        this.h = 0;
        this.i = 0;
        this.m = new int[32];
        this.n = 0;
        this.m[this.n++] = 6;
        if (b == null) {
            throw new NullPointerException("in == null");
        }
        this.b = b;
    }
    
    private IOException a(final String s) {
        throw new d(s + " at line " + (1 + this.g) + " column " + this.t());
    }
    
    private void a(final int n) {
        if (this.n == this.m.length) {
            final int[] m = new int[2 * this.n];
            System.arraycopy(this.m, 0, m, 0, this.n);
            this.m = m;
        }
        this.m[this.n++] = n;
    }
    
    private boolean a(final char c) {
        switch (c) {
            default: {
                return true;
            }
            case '#':
            case '/':
            case ';':
            case '=':
            case '\\': {
                this.u();
            }
            case '\t':
            case '\n':
            case '\f':
            case '\r':
            case ' ':
            case ',':
            case ':':
            case '[':
            case ']':
            case '{':
            case '}': {
                return false;
            }
        }
    }
    
    private int b(final boolean b) {
        final char[] d = this.d;
        int e = this.e;
        int n = this.f;
    Label_0016:
        while (true) {
            while (true) {
                if (e == n) {
                    this.e = e;
                    if (this.b(1)) {
                        e = this.e;
                        n = this.f;
                    }
                    else {
                        if (b) {
                            throw new EOFException("End of input at line " + (1 + this.g) + " column " + this.t());
                        }
                        return -1;
                    }
                }
                final int n2 = e + 1;
                final char c = d[e];
                if (c == '\n') {
                    this.g += 1;
                    this.h = n2;
                    e = n2;
                }
                else if (c != ' ' && c != '\r' && c != '\t') {
                    if (c == '/') {
                        if ((this.e = n2) == n) {
                            this.e -= 1;
                            final boolean b2 = this.b(2);
                            this.e += 1;
                            if (!b2) {
                                return c;
                            }
                        }
                        this.u();
                        switch (d[this.e]) {
                            default: {
                                return c;
                            }
                            case '*': {
                                this.e += 1;
                                while (true) {
                                    while (this.e + "*/".length() <= this.f || this.b("*/".length())) {
                                        Label_0272: {
                                            if (this.d[this.e] == '\n') {
                                                this.g += 1;
                                                this.h = 1 + this.e;
                                            }
                                            else {
                                                for (int i = 0; i < "*/".length(); ++i) {
                                                    if (this.d[i + this.e] != "*/".charAt(i)) {
                                                        break Label_0272;
                                                    }
                                                }
                                                final int n3 = 1;
                                                if (n3 == 0) {
                                                    throw this.a("Unterminated comment");
                                                }
                                                e = 2 + this.e;
                                                n = this.f;
                                                continue Label_0016;
                                            }
                                        }
                                        this.e += 1;
                                    }
                                    final int n3 = 0;
                                    continue;
                                }
                            }
                            case '/': {
                                this.e += 1;
                                this.v();
                                e = this.e;
                                n = this.f;
                                continue;
                            }
                        }
                    }
                    else {
                        if (c != '#') {
                            this.e = n2;
                            return c;
                        }
                        this.e = n2;
                        this.u();
                        this.v();
                        e = this.e;
                        n = this.f;
                    }
                }
                else {
                    e = n2;
                }
            }
            break;
        }
    }
    
    private String b(final char c) {
        final char[] d = this.d;
        final StringBuilder sb = new StringBuilder();
    Label_0013:
        while (true) {
            final int e = this.e;
            int f;
            int i;
            int h;
            for (f = this.f, i = e; i < f; i = h) {
                h = i + 1;
                final char c2 = d[i];
                if (c2 == c) {
                    sb.append(d, e, -1 + ((this.e = h) - e));
                    return sb.toString();
                }
                if (c2 == '\\') {
                    sb.append(d, e, -1 + ((this.e = h) - e));
                    sb.append(this.w());
                    continue Label_0013;
                }
                if (c2 == '\n') {
                    this.g += 1;
                    this.h = h;
                }
            }
            sb.append(d, e, i - e);
            this.e = i;
            if (!this.b(1)) {
                throw this.a("Unterminated string");
            }
        }
    }
    
    private boolean b(int n) {
        final char[] d = this.d;
        this.h -= this.e;
        if (this.f != this.e) {
            this.f -= this.e;
            System.arraycopy(d, this.e, d, 0, this.f);
        }
        else {
            this.f = 0;
        }
        this.e = 0;
        do {
            final int read = this.b.read(d, this.f, d.length - this.f);
            final boolean b = false;
            if (read == -1) {
                return b;
            }
            this.f += read;
            if (this.g != 0 || this.h != 0 || this.f <= 0 || d[0] != '\ufeff') {
                continue;
            }
            this.e += 1;
            this.h += 1;
            ++n;
        } while (this.f < n);
        return true;
    }
    
    private void c(final char c) {
        final char[] d = this.d;
    Label_0005:
        while (true) {
            int i;
            int h;
            for (i = this.e; i < this.f; i = h) {
                h = i + 1;
                final char c2 = d[i];
                if (c2 == c) {
                    this.e = h;
                    return;
                }
                if (c2 == '\\') {
                    this.e = h;
                    this.w();
                    continue Label_0005;
                }
                if (c2 == '\n') {
                    this.g += 1;
                    this.h = h;
                }
            }
            this.e = i;
            if (!this.b(1)) {
                throw this.a("Unterminated string");
            }
        }
    }
    
    private int o() {
        final int n = this.m[-1 + this.n];
        if (n == 1) {
            this.m[-1 + this.n] = 2;
        }
        else if (n == 2) {
            switch (this.b(true)) {
                case 59: {
                    this.u();
                }
                case 44: {
                    break;
                }
                default: {
                    throw this.a("Unterminated array");
                }
                case 93: {
                    return this.i = 4;
                }
            }
        }
        else if (n == 3 || n == 5) {
            this.m[-1 + this.n] = 4;
            if (n == 5) {
                switch (this.b(true)) {
                    default: {
                        throw this.a("Unterminated object");
                    }
                    case 125: {
                        return this.i = 2;
                    }
                    case 59: {
                        this.u();
                    }
                    case 44: {
                        break;
                    }
                }
            }
            final int b = this.b(true);
            switch (b) {
                default: {
                    this.u();
                    this.e -= 1;
                    if (this.a((char)b)) {
                        return this.i = 14;
                    }
                    throw this.a("Expected name");
                }
                case 34: {
                    return this.i = 13;
                }
                case 39: {
                    this.u();
                    return this.i = 12;
                }
                case 125: {
                    if (n != 5) {
                        return this.i = 2;
                    }
                    throw this.a("Expected name");
                }
            }
        }
        else if (n == 4) {
            this.m[-1 + this.n] = 5;
            switch (this.b(true)) {
                case 58: {
                    break;
                }
                default: {
                    throw this.a("Expected ':'");
                }
                case 61: {
                    this.u();
                    if ((this.e < this.f || this.b(1)) && this.d[this.e] == '>') {
                        this.e += 1;
                        break;
                    }
                    break;
                }
            }
        }
        else if (n == 6) {
            Label_0621: {
                if (this.c) {
                    this.b(true);
                    this.e -= 1;
                    if (this.e + a.a.length <= this.f || this.b(a.a.length)) {
                        for (int i = 0; i < a.a.length; ++i) {
                            if (this.d[i + this.e] != a.a[i]) {
                                break Label_0621;
                            }
                        }
                        this.e += a.a.length;
                    }
                }
            }
            this.m[-1 + this.n] = 7;
        }
        else if (n == 7) {
            if (this.b(false) == -1) {
                return this.i = 17;
            }
            this.u();
            this.e -= 1;
        }
        else if (n == 8) {
            throw new IllegalStateException("JsonReader is closed");
        }
        switch (this.b(true)) {
            default: {
                this.e -= 1;
                if (this.n == 1) {
                    this.u();
                }
                int n2 = this.q();
                if (n2 == 0) {
                    n2 = this.r();
                    if (n2 == 0) {
                        if (!this.a(this.d[this.e])) {
                            throw this.a("Expected value");
                        }
                        this.u();
                        return this.i = 10;
                    }
                }
                return n2;
            }
            case 93: {
                if (n == 1) {
                    return this.i = 4;
                }
            }
            case 44:
            case 59: {
                if (n == 1 || n == 2) {
                    this.u();
                    this.e -= 1;
                    return this.i = 7;
                }
                throw this.a("Unexpected value");
            }
            case 39: {
                this.u();
                return this.i = 8;
            }
            case 34: {
                if (this.n == 1) {
                    this.u();
                }
                return this.i = 9;
            }
            case 91: {
                return this.i = 3;
            }
            case 123: {
                return this.i = 1;
            }
        }
    }
    
    private int q() {
        final char c = this.d[this.e];
        String s;
        String s2;
        int i;
        if (c == 't' || c == 'T') {
            s = "true";
            s2 = "TRUE";
            i = 5;
        }
        else if (c == 'f' || c == 'F') {
            s = "false";
            s2 = "FALSE";
            i = 6;
        }
        else {
            if (c != 'n' && c != 'N') {
                return 0;
            }
            s = "null";
            s2 = "NULL";
            i = 7;
        }
        final int length = s.length();
        for (int j = 1; j < length; ++j) {
            if (j + this.e >= this.f && !this.b(j + 1)) {
                return 0;
            }
            final char c2 = this.d[j + this.e];
            if (c2 != s.charAt(j) && c2 != s2.charAt(j)) {
                return 0;
            }
        }
        if ((length + this.e < this.f || this.b(length + 1)) && this.a(this.d[length + this.e])) {
            return 0;
        }
        this.e += length;
        return this.i = i;
    }
    
    private int r() {
        final char[] d = this.d;
        final int e = this.e;
        final int f = this.f;
        long j = 0L;
        int n = 0;
        boolean b = true;
        int n2 = 0;
        int k = 0;
        int f2 = f;
        int e2 = e;
    Label_0519:
        while (true) {
            if (e2 + k == f2) {
                if (k == d.length) {
                    return 0;
                }
                if (!this.b(k + 1)) {
                    break;
                }
                e2 = this.e;
                f2 = this.f;
            }
            final char c = d[e2 + k];
            int n4 = 0;
            boolean b2 = false;
            int n5 = 0;
            long n6 = 0L;
            switch (c) {
                default: {
                    if (c < '0' || c > '9') {
                        if (this.a(c)) {
                            return 0;
                        }
                        break Label_0519;
                    }
                    else {
                        if (n2 == 1 || n2 == 0) {
                            final long n3 = -(c - '0');
                            n4 = 2;
                            b2 = b;
                            n5 = n;
                            n6 = n3;
                            break;
                        }
                        if (n2 == 2) {
                            if (j == 0L) {
                                return 0;
                            }
                            final long n7 = 10L * j - (c - '0');
                            boolean b3;
                            if (j > -922337203685477580L || (j == -922337203685477580L && n7 < j)) {
                                b3 = true;
                            }
                            else {
                                b3 = false;
                            }
                            final boolean b4 = b3 & b;
                            n5 = n;
                            n6 = n7;
                            final int n8 = n2;
                            b2 = b4;
                            n4 = n8;
                            break;
                        }
                        else {
                            if (n2 == 3) {
                                n4 = 4;
                                b2 = b;
                                n5 = n;
                                n6 = j;
                                break;
                            }
                            if (n2 == 5 || n2 == 6) {
                                n4 = 7;
                                b2 = b;
                                n5 = n;
                                n6 = j;
                                break;
                            }
                            n4 = n2;
                            b2 = b;
                            n5 = n;
                            n6 = j;
                            break;
                        }
                    }
                    break;
                }
                case 45: {
                    if (n2 == 0) {
                        n4 = 1;
                        final boolean b5 = b;
                        n5 = 1;
                        b2 = b5;
                        n6 = j;
                        break;
                    }
                    if (n2 == 5) {
                        n4 = 6;
                        b2 = b;
                        n5 = n;
                        n6 = j;
                        break;
                    }
                    return 0;
                }
                case 43: {
                    if (n2 == 5) {
                        n4 = 6;
                        b2 = b;
                        n5 = n;
                        n6 = j;
                        break;
                    }
                    return 0;
                }
                case 69:
                case 101: {
                    if (n2 == 2 || n2 == 4) {
                        n4 = 5;
                        b2 = b;
                        n5 = n;
                        n6 = j;
                        break;
                    }
                    return 0;
                }
                case 46: {
                    if (n2 == 2) {
                        n4 = 3;
                        b2 = b;
                        n5 = n;
                        n6 = j;
                        break;
                    }
                    return 0;
                }
            }
            ++k;
            final boolean b6 = b2;
            n2 = n4;
            final int n9 = n5;
            b = b6;
            j = n6;
            n = n9;
        }
        if (n2 == 2 && b && (j != Long.MIN_VALUE || n != 0)) {
            if (n == 0) {
                j = -j;
            }
            this.j = j;
            this.e += k;
            return this.i = 15;
        }
        if (n2 == 2 || n2 == 4 || n2 == 7) {
            this.k = k;
            return this.i = 16;
        }
        return 0;
    }
    
    private String s() {
        StringBuilder sb = null;
        int n = 0;
    Label_0178:
        while (true) {
            Block_6: {
                while (true) {
                    if (n + this.e < this.f) {
                        switch (this.d[n + this.e]) {
                            default: {
                                ++n;
                                continue;
                            }
                            case '#':
                            case '/':
                            case ';':
                            case '=':
                            case '\\': {
                                this.u();
                            }
                            case '\t':
                            case '\n':
                            case '\f':
                            case '\r':
                            case ' ':
                            case ',':
                            case ':':
                            case '[':
                            case ']':
                            case '{':
                            case '}': {
                                break Label_0178;
                            }
                        }
                    }
                    else if (n < this.d.length) {
                        if (this.b(n + 1)) {
                            continue;
                        }
                        break;
                    }
                    else {
                        if (sb == null) {
                            sb = new StringBuilder();
                        }
                        sb.append(this.d, this.e, n);
                        this.e += n;
                        if (!this.b(1)) {
                            break Block_6;
                        }
                        n = 0;
                    }
                }
                String string;
                if (sb == null) {
                    string = new String(this.d, this.e, n);
                }
                else {
                    sb.append(this.d, this.e, n);
                    string = sb.toString();
                }
                this.e += n;
                return string;
            }
            n = 0;
            continue Label_0178;
        }
    }
    
    private int t() {
        return 1 + (this.e - this.h);
    }
    
    private void u() {
        if (!this.c) {
            throw this.a("Use JsonReader.setLenient(true) to accept malformed JSON");
        }
    }
    
    private void v() {
        while (this.e < this.f || this.b(1)) {
            final char c = this.d[this.e++];
            if (c == '\n') {
                this.g += 1;
                this.h = this.e;
                break;
            }
            if (c == '\r') {
                return;
            }
        }
    }
    
    private char w() {
        if (this.e == this.f && !this.b(1)) {
            throw this.a("Unterminated escape sequence");
        }
        final char c = this.d[this.e++];
        switch (c) {
            default: {
                return c;
            }
            case 117: {
                if (4 + this.e > this.f && !this.b(4)) {
                    throw this.a("Unterminated escape sequence");
                }
                final int e = this.e;
                final int n = e + 4;
                char c2 = '\0';
                for (int i = e; i < n; ++i) {
                    final char c3 = this.d[i];
                    final char c4 = (char)(c2 << 4);
                    if (c3 >= '0' && c3 <= '9') {
                        c2 = (char)(c4 + (c3 - '0'));
                    }
                    else if (c3 >= 'a' && c3 <= 'f') {
                        c2 = (char)(c4 + ('\n' + (c3 - 'a')));
                    }
                    else {
                        if (c3 < 'A' || c3 > 'F') {
                            throw new NumberFormatException("\\u" + new String(this.d, this.e, 4));
                        }
                        c2 = (char)(c4 + ('\n' + (c3 - 'A')));
                    }
                }
                this.e += 4;
                return c2;
            }
            case 116: {
                return '\t';
            }
            case 98: {
                return '\b';
            }
            case 110: {
                return '\n';
            }
            case 114: {
                return '\r';
            }
            case 102: {
                return '\f';
            }
            case 10: {
                this.g += 1;
                this.h = this.e;
                return c;
            }
        }
    }
    
    public void a() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        if (n == 3) {
            this.a(1);
            this.i = 0;
            return;
        }
        throw new IllegalStateException("Expected BEGIN_ARRAY but was " + this.f() + " at line " + (1 + this.g) + " column " + this.t());
    }
    
    public final void a(final boolean c) {
        this.c = c;
    }
    
    public void b() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        if (n == 4) {
            this.n -= 1;
            this.i = 0;
            return;
        }
        throw new IllegalStateException("Expected END_ARRAY but was " + this.f() + " at line " + (1 + this.g) + " column " + this.t());
    }
    
    public void c() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        if (n == 1) {
            this.a(3);
            this.i = 0;
            return;
        }
        throw new IllegalStateException("Expected BEGIN_OBJECT but was " + this.f() + " at line " + (1 + this.g) + " column " + this.t());
    }
    
    @Override
    public void close() {
        this.i = 0;
        this.m[0] = 8;
        this.n = 1;
        this.b.close();
    }
    
    public void d() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        if (n == 2) {
            this.n -= 1;
            this.i = 0;
            return;
        }
        throw new IllegalStateException("Expected END_OBJECT but was " + this.f() + " at line " + (1 + this.g) + " column " + this.t());
    }
    
    public boolean e() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        return n != 2 && n != 4;
    }
    
    public b f() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        switch (n) {
            default: {
                throw new AssertionError();
            }
            case 1: {
                return b.c;
            }
            case 2: {
                return b.d;
            }
            case 3: {
                return b.a;
            }
            case 4: {
                return b.b;
            }
            case 12:
            case 13:
            case 14: {
                return b.e;
            }
            case 5:
            case 6: {
                return b.h;
            }
            case 7: {
                return b.i;
            }
            case 8:
            case 9:
            case 10:
            case 11: {
                return b.f;
            }
            case 15:
            case 16: {
                return b.g;
            }
            case 17: {
                return b.j;
            }
        }
    }
    
    public String g() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        String s;
        if (n == 14) {
            s = this.s();
        }
        else if (n == 12) {
            s = this.b('\'');
        }
        else {
            if (n != 13) {
                throw new IllegalStateException("Expected a name but was " + this.f() + " at line " + (1 + this.g) + " column " + this.t());
            }
            s = this.b('\"');
        }
        this.i = 0;
        return s;
    }
    
    public String h() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        String s;
        if (n == 10) {
            s = this.s();
        }
        else if (n == 8) {
            s = this.b('\'');
        }
        else if (n == 9) {
            s = this.b('\"');
        }
        else if (n == 11) {
            s = this.l;
            this.l = null;
        }
        else if (n == 15) {
            s = Long.toString(this.j);
        }
        else {
            if (n != 16) {
                throw new IllegalStateException("Expected a string but was " + this.f() + " at line " + (1 + this.g) + " column " + this.t());
            }
            s = new String(this.d, this.e, this.k);
            this.e += this.k;
        }
        this.i = 0;
        return s;
    }
    
    public boolean i() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        if (n == 5) {
            this.i = 0;
            return true;
        }
        if (n == 6) {
            this.i = 0;
            return false;
        }
        throw new IllegalStateException("Expected a boolean but was " + this.f() + " at line " + (1 + this.g) + " column " + this.t());
    }
    
    public void j() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        if (n == 7) {
            this.i = 0;
            return;
        }
        throw new IllegalStateException("Expected null but was " + this.f() + " at line " + (1 + this.g) + " column " + this.t());
    }
    
    public double k() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        if (n == 15) {
            this.i = 0;
            return this.j;
        }
        if (n == 16) {
            this.l = new String(this.d, this.e, this.k);
            this.e += this.k;
        }
        else if (n == 8 || n == 9) {
            char c;
            if (n == 8) {
                c = '\'';
            }
            else {
                c = '\"';
            }
            this.l = this.b(c);
        }
        else if (n == 10) {
            this.l = this.s();
        }
        else if (n != 11) {
            throw new IllegalStateException("Expected a double but was " + this.f() + " at line " + (1 + this.g) + " column " + this.t());
        }
        this.i = 11;
        final double double1 = Double.parseDouble(this.l);
        if (!this.c && (Double.isNaN(double1) || Double.isInfinite(double1))) {
            throw new d("JSON forbids NaN and infinities: " + double1 + " at line " + (1 + this.g) + " column " + this.t());
        }
        this.l = null;
        this.i = 0;
        return double1;
    }
    
    public long l() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        if (n == 15) {
            this.i = 0;
            return this.j;
        }
        Label_0072: {
            if (n == 16) {
                this.l = new String(this.d, this.e, this.k);
                this.e += this.k;
            }
            else {
                if (n == 8 || n == 9) {
                    while (true) {
                        Label_0206: {
                            if (n != 8) {
                                break Label_0206;
                            }
                            final char c = '\'';
                            this.l = this.b(c);
                            try {
                                final long long1 = Long.parseLong(this.l);
                                this.i = 0;
                                return long1;
                            }
                            catch (NumberFormatException ex) {
                                break Label_0072;
                            }
                        }
                        final char c = '\"';
                        continue;
                    }
                }
                throw new IllegalStateException("Expected a long but was " + this.f() + " at line " + (1 + this.g) + " column " + this.t());
            }
        }
        this.i = 11;
        final double double1 = Double.parseDouble(this.l);
        final long n2 = (long)double1;
        if (n2 != double1) {
            throw new NumberFormatException("Expected a long but was " + this.l + " at line " + (1 + this.g) + " column " + this.t());
        }
        this.l = null;
        this.i = 0;
        return n2;
    }
    
    public int m() {
        int n = this.i;
        if (n == 0) {
            n = this.o();
        }
        if (n == 15) {
            final int n2 = (int)this.j;
            if (this.j != n2) {
                throw new NumberFormatException("Expected an int but was " + this.j + " at line " + (1 + this.g) + " column " + this.t());
            }
            this.i = 0;
            return n2;
        }
        else {
            Label_0142: {
                if (n == 16) {
                    this.l = new String(this.d, this.e, this.k);
                    this.e += this.k;
                }
                else {
                    if (n == 8 || n == 9) {
                        while (true) {
                            Label_0276: {
                                if (n != 8) {
                                    break Label_0276;
                                }
                                final char c = '\'';
                                this.l = this.b(c);
                                try {
                                    final int int1 = Integer.parseInt(this.l);
                                    this.i = 0;
                                    return int1;
                                }
                                catch (NumberFormatException ex) {
                                    break Label_0142;
                                }
                            }
                            final char c = '\"';
                            continue;
                        }
                    }
                    throw new IllegalStateException("Expected an int but was " + this.f() + " at line " + (1 + this.g) + " column " + this.t());
                }
            }
            this.i = 11;
            final double double1 = Double.parseDouble(this.l);
            final int n3 = (int)double1;
            if (n3 != double1) {
                throw new NumberFormatException("Expected an int but was " + this.l + " at line " + (1 + this.g) + " column " + this.t());
            }
            this.l = null;
            this.i = 0;
            return n3;
        }
    }
    
    public void n() {
        int n = 0;
        while (true) {
            int n2 = this.i;
            if (n2 == 0) {
                n2 = this.o();
            }
            Label_0029: {
                if (n2 == 3) {
                    this.a(1);
                    ++n;
                }
                else if (n2 == 1) {
                    this.a(3);
                    ++n;
                }
                else if (n2 == 4) {
                    this.n -= 1;
                    --n;
                }
                else if (n2 == 2) {
                    this.n -= 1;
                    --n;
                }
                else if (n2 == 14 || n2 == 10) {
                    do {
                        int n3 = 0;
                        while (n3 + this.e < this.f) {
                            switch (this.d[n3 + this.e]) {
                                default: {
                                    ++n3;
                                    continue;
                                }
                                case '#':
                                case '/':
                                case ';':
                                case '=':
                                case '\\': {
                                    this.u();
                                }
                                case '\t':
                                case '\n':
                                case '\f':
                                case '\r':
                                case ' ':
                                case ',':
                                case ':':
                                case '[':
                                case ']':
                                case '{':
                                case '}': {
                                    this.e += n3;
                                    break Label_0029;
                                }
                            }
                        }
                        this.e += n3;
                    } while (this.b(1));
                }
                else if (n2 == 8 || n2 == 12) {
                    this.c('\'');
                }
                else if (n2 == 9 || n2 == 13) {
                    this.c('\"');
                }
                else if (n2 == 16) {
                    this.e += this.k;
                }
            }
            this.i = 0;
            if (n == 0) {
                break;
            }
        }
    }
    
    public final boolean p() {
        return this.c;
    }
    
    @Override
    public String toString() {
        return this.getClass().getSimpleName() + " at line " + (1 + this.g) + " column " + this.t();
    }
}
