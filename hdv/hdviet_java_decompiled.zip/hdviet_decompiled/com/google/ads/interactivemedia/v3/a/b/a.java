package com.google.ads.interactivemedia.v3.a.b;

public final class a
{
    public static Object a(final Object o) {
        if (o == null) {
            throw new NullPointerException();
        }
        return o;
    }
    
    public static void a(final boolean b) {
        if (!b) {
            throw new IllegalArgumentException();
        }
    }
}
