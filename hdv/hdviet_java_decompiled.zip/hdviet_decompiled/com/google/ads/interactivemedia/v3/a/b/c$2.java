package com.google.ads.interactivemedia.v3.a.b;

import java.util.LinkedHashMap;

final class c$2 implements h
{
    final /* synthetic */ c a;
    
    c$2(final c a) {
        this.a = a;
        super();
    }
    
    @Override
    public final Object a() {
        return new LinkedHashMap();
    }
}
