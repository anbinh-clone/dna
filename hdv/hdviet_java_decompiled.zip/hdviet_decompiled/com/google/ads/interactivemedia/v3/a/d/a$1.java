package com.google.ads.interactivemedia.v3.a.d;

import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.io.Closeable;
import com.google.ads.interactivemedia.v3.a.b.a.d;
import com.google.ads.interactivemedia.v3.a.b.e;

final class a$1 extends e
{
    @Override
    public final void a(final a a) {
        if (a instanceof d) {
            ((d)a).o();
            return;
        }
        int n = a.i;
        if (n == 0) {
            n = a.o();
        }
        if (n == 13) {
            a.i = 9;
            return;
        }
        if (n == 12) {
            a.i = 8;
            return;
        }
        if (n == 14) {
            a.i = 10;
            return;
        }
        throw new IllegalStateException("Expected a name but was " + a.f() + "  at line " + (1 + a.g) + " column " + a.t());
    }
}
