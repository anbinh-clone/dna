package com.google.ads.interactivemedia.v3.api;

public class AdError extends Exception
{
    private final AdError$AdErrorCode a;
    private final AdError$AdErrorType b;
    
    public AdError(final AdError$AdErrorType adError$AdErrorType, final int n, final String s) {
        this(adError$AdErrorType, AdError$AdErrorCode.a(n), s);
    }
    
    public AdError(final AdError$AdErrorType b, final AdError$AdErrorCode a, final String s) {
        super(s);
        this.b = b;
        this.a = a;
    }
    
    public AdError$AdErrorCode getErrorCode() {
        return this.a;
    }
    
    public AdError$AdErrorType getErrorType() {
        return this.b;
    }
    
    @Override
    public String getMessage() {
        return super.getMessage();
    }
}
