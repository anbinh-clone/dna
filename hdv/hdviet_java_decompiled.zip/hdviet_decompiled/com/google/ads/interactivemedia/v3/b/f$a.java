package com.google.ads.interactivemedia.v3.b;

import java.util.HashMap;
import com.google.ads.interactivemedia.v3.api.AdsRenderingSettings;
import com.google.ads.interactivemedia.v3.api.AdErrorEvent$AdErrorListener;
import java.util.Iterator;
import com.google.ads.interactivemedia.v3.api.AdEvent;
import com.google.ads.interactivemedia.v3.api.AdEvent$AdEventListener;
import java.util.ArrayList;
import android.content.Context;
import java.util.SortedSet;
import com.google.ads.interactivemedia.v3.api.AdDisplayContainer;
import java.util.List;
import com.google.ads.interactivemedia.v3.api.player.VideoAdPlayer;
import com.google.ads.interactivemedia.v3.api.AdsManager;
import com.google.ads.interactivemedia.v3.api.player.VideoAdPlayer$VideoAdPlayerCallback;
import com.google.ads.interactivemedia.v3.b.a.a;
import com.google.ads.interactivemedia.v3.api.AdEvent$AdEventType;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorCode;
import com.google.ads.interactivemedia.v3.api.Ad;
import com.google.ads.interactivemedia.v3.api.AdErrorEvent;
import com.google.ads.interactivemedia.v3.api.AdError;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorType;

final class f$a implements s$b
{
    final /* synthetic */ f a;
    
    private f$a(final f a) {
        this.a = a;
        super();
    }
    
    @Override
    public final void a(final AdError$AdErrorType adError$AdErrorType, final int n, final String s) {
        this.a.l.a(new b(new AdError(adError$AdErrorType, n, s)));
        this.a.i.a((Ad)this.a.e);
    }
    
    @Override
    public final void a(final AdError$AdErrorType adError$AdErrorType, final AdError$AdErrorCode adError$AdErrorCode, final String s) {
        this.a.l.a(new b(new AdError(adError$AdErrorType, adError$AdErrorCode, s)));
        this.a.i.a((Ad)this.a.e);
    }
    
    @Override
    public final void a(final AdEvent$AdEventType adEvent$AdEventType, final a a) {
        if (a != null) {
            this.a.e = a;
        }
        switch (f$1.a[adEvent$AdEventType.ordinal()]) {
            case 1: {
                this.a.g = new d(this.a.b, this.a.c, this.a.a);
                this.a.d.addCallback(this.a.g);
                this.a.a.a(this.a.g);
                if (this.a.j != null) {
                    this.a.d.removeCallback(this.a.j);
                    break;
                }
                break;
            }
            case 2: {
                this.a.d.removeCallback(this.a.g);
                this.a.a.b(this.a.g);
                if (this.a.j != null) {
                    this.a.d.addCallback(this.a.j);
                    break;
                }
                break;
            }
            case 3: {
                this.a.i.a(this.a.e);
                break;
            }
            case 4: {
                this.a.i.a((Ad)this.a.e);
                break;
            }
            case 5: {
                this.a.destroy();
                break;
            }
        }
        this.a.a(adEvent$AdEventType);
        if (adEvent$AdEventType == AdEvent$AdEventType.COMPLETED) {
            this.a.e = null;
        }
    }
}
