package com.google.ads.interactivemedia.v3.a.b;

final class g$b$1 extends g$c
{
    final /* synthetic */ g$b a;
    
    g$b$1(final g$b a) {
        this.a = a;
        super(a.a, 0);
    }
    
    @Override
    public final Object next() {
        return this.a().f;
    }
}
