package com.google.ads.interactivemedia.v3.a;

public class p extends RuntimeException
{
    public p(final String s) {
        super(s);
    }
    
    public p(final String s, final Throwable t) {
        super(s, t);
    }
    
    public p(final Throwable t) {
        super(t);
    }
}
