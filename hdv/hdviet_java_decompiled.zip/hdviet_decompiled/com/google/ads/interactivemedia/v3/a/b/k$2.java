package com.google.ads.interactivemedia.v3.a.b;

import java.lang.reflect.Method;

final class k$2 extends k
{
    final /* synthetic */ Method a;
    
    k$2(final Method a) {
        this.a = a;
        super();
    }
    
    @Override
    public final Object a(final Class clazz) {
        return this.a.invoke(null, clazz, Object.class);
    }
}
