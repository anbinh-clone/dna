package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.api.AdDisplayContainer;
import android.net.NetworkInfo;
import com.google.a.a.t;
import com.google.ads.interactivemedia.v3.b.a.d;
import android.net.ConnectivityManager;
import android.util.Log;
import android.os.Build$VERSION;
import java.util.Random;
import com.google.ads.interactivemedia.v3.api.AdErrorEvent$AdErrorListener;
import java.util.Iterator;
import com.google.ads.interactivemedia.v3.api.AdsLoader$AdsLoadedListener;
import java.util.HashMap;
import java.util.ArrayList;
import android.net.Uri;
import com.google.ads.interactivemedia.v3.api.ImaSdkSettings;
import com.google.a.a.s;
import java.util.Map;
import android.content.Context;
import com.google.ads.interactivemedia.v3.api.AdsLoader;
import com.google.ads.interactivemedia.v3.api.AdsManagerLoadedEvent;
import com.google.ads.interactivemedia.v3.api.AdsManager;
import java.util.SortedSet;
import java.util.List;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorCode;
import com.google.ads.interactivemedia.v3.api.AdErrorEvent;
import com.google.ads.interactivemedia.v3.api.AdsRequest;
import com.google.ads.interactivemedia.v3.api.AdError;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorType;

final class e$1 implements s$a
{
    final /* synthetic */ e a;
    
    e$1(final e a) {
        this.a = a;
        super();
    }
    
    @Override
    public final void a(final String s, final AdError$AdErrorType adError$AdErrorType, final int n, final String s2) {
        this.a.c.a(new b(new AdError(adError$AdErrorType, n, s2), this.a.e.get(s).getUserRequestContext()));
    }
    
    @Override
    public final void a(final String s, final AdError$AdErrorType adError$AdErrorType, final AdError$AdErrorCode adError$AdErrorCode, final String s2) {
        this.a.c.a(new b(new AdError(adError$AdErrorType, adError$AdErrorCode, s2), this.a.e.get(s).getUserRequestContext()));
    }
    
    @Override
    public final void a(final String s, final u u, final List list, final SortedSet set) {
        final AdsRequest adsRequest = this.a.e.get(s);
        this.a.a(new g(new f(s, this.a.a, u, adsRequest.getAdDisplayContainer(), list, set, new v(adsRequest.getAdDisplayContainer().getPlayer(), u.a()), this.a.b), adsRequest.getUserRequestContext()));
    }
}
