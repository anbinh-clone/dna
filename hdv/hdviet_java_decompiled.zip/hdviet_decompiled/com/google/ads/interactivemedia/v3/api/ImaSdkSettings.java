package com.google.ads.interactivemedia.v3.api;

public class ImaSdkSettings
{
    private transient String language;
    private String ppid;
    
    public ImaSdkSettings() {
        super();
        this.language = "en";
    }
    
    public String getLanguage() {
        return this.language;
    }
    
    public String getPpid() {
        return this.ppid;
    }
    
    public void setLanguage(final String language) {
        this.language = language;
    }
    
    public void setPpid(final String ppid) {
        this.ppid = ppid;
    }
    
    @Override
    public String toString() {
        return "ImaSdkSettings [ppid=" + this.ppid + ", language=" + this.language + "]";
    }
}
