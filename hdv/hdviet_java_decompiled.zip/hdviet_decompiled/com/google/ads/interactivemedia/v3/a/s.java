package com.google.ads.interactivemedia.v3.a;

public interface s
{
    l a(Object p0);
}
