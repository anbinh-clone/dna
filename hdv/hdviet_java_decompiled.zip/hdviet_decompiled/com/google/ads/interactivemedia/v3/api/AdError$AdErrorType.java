package com.google.ads.interactivemedia.v3.api;

public enum AdError$AdErrorType
{
    LOAD("LOAD", 0), 
    PLAY("PLAY", 1);
    
    static {
        a = new AdError$AdErrorType[] { AdError$AdErrorType.LOAD, AdError$AdErrorType.PLAY };
    }
}
