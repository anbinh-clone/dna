package com.google.ads.interactivemedia.v3.a.b;

import java.io.Writer;

final class j$a extends Writer
{
    private final Appendable a;
    private final j$a$a b;
    
    private j$a(final Appendable a) {
        super();
        this.b = new j$a$a();
        this.a = a;
    }
    
    @Override
    public final void close() {
    }
    
    @Override
    public final void flush() {
    }
    
    @Override
    public final void write(final int n) {
        this.a.append((char)n);
    }
    
    @Override
    public final void write(final char[] a, final int n, final int n2) {
        this.b.a = a;
        this.a.append(this.b, n, n + n2);
    }
}
