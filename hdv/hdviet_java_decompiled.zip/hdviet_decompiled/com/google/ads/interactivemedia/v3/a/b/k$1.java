package com.google.ads.interactivemedia.v3.a.b;

import java.lang.reflect.Method;

final class k$1 extends k
{
    final /* synthetic */ Method a;
    final /* synthetic */ Object b;
    
    k$1(final Method a, final Object b) {
        this.a = a;
        this.b = b;
        super();
    }
    
    @Override
    public final Object a(final Class clazz) {
        return this.a.invoke(this.b, clazz);
    }
}
