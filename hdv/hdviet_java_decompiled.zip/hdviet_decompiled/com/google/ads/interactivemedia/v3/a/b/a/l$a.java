package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.d.a;
import com.google.ads.interactivemedia.v3.a.a.b;
import java.util.HashMap;
import java.util.Map;
import com.google.ads.interactivemedia.v3.a.w;

final class l$a extends w
{
    private final Map a;
    private final Map b;
    
    public l$a(final Class clazz) {
        while (true) {
            super();
            this.a = new HashMap();
            this.b = new HashMap();
            while (true) {
                String name = null;
                Label_0135: {
                    try {
                        for (final Enum enum1 : clazz.getEnumConstants()) {
                            name = enum1.name();
                            final b b = clazz.getField(name).getAnnotation(b.class);
                            if (b == null) {
                                break Label_0135;
                            }
                            final String a = b.a();
                            this.a.put(a, enum1);
                            this.b.put(enum1, a);
                        }
                    }
                    catch (NoSuchFieldException ex) {
                        throw new AssertionError();
                    }
                    break;
                }
                final String a = name;
                continue;
            }
        }
    }
}
