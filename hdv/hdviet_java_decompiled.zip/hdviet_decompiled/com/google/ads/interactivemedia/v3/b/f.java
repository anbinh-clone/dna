package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.api.AdErrorEvent;
import com.google.ads.interactivemedia.v3.api.AdError;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorCode;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorType;
import java.util.HashMap;
import com.google.ads.interactivemedia.v3.api.AdsRenderingSettings;
import com.google.ads.interactivemedia.v3.api.AdErrorEvent$AdErrorListener;
import java.util.Iterator;
import com.google.ads.interactivemedia.v3.api.AdEvent;
import com.google.ads.interactivemedia.v3.api.AdEvent$AdEventListener;
import com.google.ads.interactivemedia.v3.api.Ad;
import com.google.ads.interactivemedia.v3.api.AdEvent$AdEventType;
import java.util.ArrayList;
import android.content.Context;
import java.util.SortedSet;
import com.google.ads.interactivemedia.v3.api.AdDisplayContainer;
import com.google.ads.interactivemedia.v3.api.player.VideoAdPlayer$VideoAdPlayerCallback;
import java.util.List;
import com.google.ads.interactivemedia.v3.b.a.a;
import com.google.ads.interactivemedia.v3.api.player.VideoAdPlayer;
import com.google.ads.interactivemedia.v3.api.AdsManager;

public final class f implements AdsManager
{
    v a;
    private final s b;
    private final String c;
    private final VideoAdPlayer d;
    private a e;
    private n f;
    private d g;
    private List h;
    private h i;
    private VideoAdPlayer$VideoAdPlayerCallback j;
    private final List k;
    private final o l;
    
    f(final String c, final s b, final u u, final AdDisplayContainer adDisplayContainer, final List h, final SortedSet set, final v a, final Context context) {
        super();
        this.k = new ArrayList(1);
        this.l = new o();
        this.i = new h(c, u, b, adDisplayContainer, context);
        this.c = c;
        this.b = b;
        this.d = adDisplayContainer.getPlayer();
        this.h = h;
        (this.a = a).a(this.i);
        if (set != null && !set.isEmpty()) {
            a.c(this.f = new n(b, set, c));
            this.j = new m(a);
        }
    }
    
    private void a(final r$c r$c) {
        this.b.b(new r(r$b.adsManager, r$c, this.c));
    }
    
    final void a(final AdEvent$AdEventType adEvent$AdEventType) {
        final c c = new c(adEvent$AdEventType, this.e);
        final Iterator<AdEvent$AdEventListener> iterator = (Iterator<AdEvent$AdEventListener>)this.k.iterator();
        while (iterator.hasNext()) {
            iterator.next().onAdEvent(c);
        }
    }
    
    @Override
    public final void addAdErrorListener(final AdErrorEvent$AdErrorListener adErrorEvent$AdErrorListener) {
        this.l.a(adErrorEvent$AdErrorListener);
    }
    
    @Override
    public final void addAdEventListener(final AdEvent$AdEventListener adEvent$AdEventListener) {
        this.k.add(adEvent$AdEventListener);
    }
    
    @Override
    public final void destroy() {
        this.a.c();
        this.d.removeCallback(this.g);
        if (this.j != null) {
            this.d.removeCallback(this.j);
        }
        this.a(r$c.destroy);
    }
    
    @Override
    public final List getAdCuePoints() {
        return this.h;
    }
    
    @Override
    public final Ad getCurrentAd() {
        return this.e;
    }
    
    @Override
    public final void init() {
        this.init(null);
    }
    
    @Override
    public final void init(final AdsRenderingSettings adsRenderingSettings) {
        this.b.a(new f$a(this, 0), this.c);
        final HashMap<String, AdsRenderingSettings> hashMap = new HashMap<String, AdsRenderingSettings>();
        hashMap.put("adsRenderingSettings", adsRenderingSettings);
        this.b.b(new r(r$b.adsManager, r$c.init, this.c, hashMap));
    }
    
    @Override
    public final void removeAdErrorListener(final AdErrorEvent$AdErrorListener adErrorEvent$AdErrorListener) {
        this.l.b(adErrorEvent$AdErrorListener);
    }
    
    @Override
    public final void removeAdEventListener(final AdEvent$AdEventListener adEvent$AdEventListener) {
        this.k.remove(adEvent$AdEventListener);
    }
    
    @Override
    public final void skip() {
        this.b.b(new r(r$b.adsManager, r$c.skip, this.c));
    }
    
    @Override
    public final void start() {
        if (this.d == null) {
            this.l.a(new b(new AdError(AdError$AdErrorType.PLAY, AdError$AdErrorCode.INVALID_ARGUMENTS, "Ad Display Container must contain a non-null video player.")));
            return;
        }
        this.b.a(this.d, this.c);
        this.a(r$c.start);
    }
}
