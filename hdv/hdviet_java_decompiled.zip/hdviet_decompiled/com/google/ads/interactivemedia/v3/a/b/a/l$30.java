package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.t;
import com.google.ads.interactivemedia.v3.a.d.b;
import com.google.ads.interactivemedia.v3.a.d.a;
import com.google.ads.interactivemedia.v3.a.w;

final class l$30 extends w
{
    private static Number b(final a a) {
        if (a.f() == b.i) {
            a.j();
            return null;
        }
        try {
            return a.m();
        }
        catch (NumberFormatException ex) {
            throw new t(ex);
        }
    }
}
