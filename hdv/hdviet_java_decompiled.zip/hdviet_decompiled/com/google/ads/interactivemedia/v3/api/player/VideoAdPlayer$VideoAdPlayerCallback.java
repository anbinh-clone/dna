package com.google.ads.interactivemedia.v3.api.player;

public interface VideoAdPlayer$VideoAdPlayerCallback
{
    void onEnded();
    
    void onError();
    
    void onPause();
    
    void onPlay();
    
    void onResume();
    
    void onVolumeChanged(int p0);
}
