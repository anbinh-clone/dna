package com.google.ads.interactivemedia.v3.b;

import java.util.List;
import com.google.ads.interactivemedia.v3.api.AdsRenderingSettings;

public final class i implements AdsRenderingSettings
{
    private int a;
    private List b;
    
    public i() {
        super();
        this.a = -1;
        this.b = null;
    }
    
    @Override
    public final int getBitrateKbps() {
        return this.a;
    }
    
    @Override
    public final List getMimeTypes() {
        return this.b;
    }
    
    @Override
    public final void setBitrateKbps(final int a) {
        this.a = a;
    }
    
    @Override
    public final void setMimeTypes(final List b) {
        this.b = b;
    }
    
    @Override
    public final String toString() {
        return "AdsRenderingSettings [bitrate=" + this.a + ", mimeTypes=" + this.b + "]";
    }
}
