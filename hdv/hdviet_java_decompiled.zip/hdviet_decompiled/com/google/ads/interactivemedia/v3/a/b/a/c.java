package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.d.b;
import com.google.ads.interactivemedia.v3.a.d.a;
import com.google.ads.interactivemedia.v3.a.d.c;
import java.text.ParseException;
import com.google.ads.interactivemedia.v3.a.t;
import java.util.Date;
import java.util.TimeZone;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.text.DateFormat;
import com.google.ads.interactivemedia.v3.a.x;
import com.google.ads.interactivemedia.v3.a.w;

public final class c extends w
{
    public static final x a;
    private final DateFormat b;
    private final DateFormat c;
    private final DateFormat d;
    
    static {
        a = new c$1();
    }
    
    public c() {
        super();
        this.b = DateFormat.getDateTimeInstance(2, 2, Locale.US);
        this.c = DateFormat.getDateTimeInstance(2, 2);
        final SimpleDateFormat d = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        d.setTimeZone(TimeZone.getTimeZone("UTC"));
        this.d = d;
    }
    
    private Date a(final String s) {
        synchronized (this) {
            try {
                return this.c.parse(s);
            }
            catch (ParseException ex2) {
                try {
                    final Date date = this.b.parse(s);
                }
                catch (ParseException ex3) {
                    try {
                        final Date date = this.d.parse(s);
                    }
                    catch (ParseException ex) {
                        throw new t(s, ex);
                    }
                }
            }
        }
    }
    
    private void a(final c c, final Date date) {
        // monitorenter(this)
        // monitorenter(this)
        Label_0014: {
            if (date != null) {
                break Label_0014;
            }
            try {
                c.f();
                return;
                c.b(this.b.format(date));
            }
            finally {
            }
            // monitorexit(this)
        }
    }
}
