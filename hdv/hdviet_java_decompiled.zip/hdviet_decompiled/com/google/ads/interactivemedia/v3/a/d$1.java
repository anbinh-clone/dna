package com.google.ads.interactivemedia.v3.a;

import java.lang.reflect.Field;

enum d$1
{
    @Override
    public final String a(final Field field) {
        return field.getName();
    }
}
