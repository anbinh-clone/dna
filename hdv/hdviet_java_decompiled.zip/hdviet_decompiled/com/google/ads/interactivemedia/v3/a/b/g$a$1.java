package com.google.ads.interactivemedia.v3.a.b;

final class g$a$1 extends g$c
{
    final /* synthetic */ g$a a;
    
    g$a$1(final g$a a) {
        this.a = a;
        super(a.a, 0);
    }
}
