package com.google.ads.interactivemedia.v3.a.d;

import java.io.IOException;

public final class d extends IOException
{
    public d(final String s) {
        super(s);
    }
}
