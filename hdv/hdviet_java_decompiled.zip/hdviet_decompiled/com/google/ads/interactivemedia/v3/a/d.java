package com.google.ads.interactivemedia.v3.a;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public enum d implements e
{
    a("IDENTITY"), 
    b("UPPER_CAMEL_CASE"), 
    c("UPPER_CAMEL_CASE_WITH_SPACES"), 
    d("LOWER_CASE_WITH_UNDERSCORES"), 
    e("LOWER_CASE_WITH_DASHES");
    
    static {
        f = new d[] { d.a, d.b, d.c, d.d, d.e };
    }
}
