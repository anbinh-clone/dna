package com.google.ads.interactivemedia.v3.b.b;

enum e$b
{
    a("NOT_SKIPPABLE", 0), 
    b("WAITING_TO_SKIP", 1), 
    c("SKIPPABLE", 2);
    
    static {
        d = new e$b[] { e$b.a, e$b.b, e$b.c };
    }
}
