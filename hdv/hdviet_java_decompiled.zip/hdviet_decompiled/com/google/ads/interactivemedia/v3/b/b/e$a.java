package com.google.ads.interactivemedia.v3.b.b;

public interface e$a extends a$a
{
    void a();
}
