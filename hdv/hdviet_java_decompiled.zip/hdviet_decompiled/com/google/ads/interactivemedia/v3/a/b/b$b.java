package com.google.ads.interactivemedia.v3.a.b;

import java.util.Map;
import java.util.Properties;
import java.lang.reflect.Array;
import java.lang.reflect.GenericDeclaration;
import java.util.NoSuchElementException;
import java.lang.reflect.TypeVariable;
import java.util.Collection;
import java.lang.reflect.WildcardType;
import java.lang.reflect.GenericArrayType;
import java.util.Arrays;
import java.lang.reflect.Type;
import java.lang.reflect.ParameterizedType;
import java.io.Serializable;

final class b$b implements Serializable, ParameterizedType
{
    private final Type a;
    private final Type b;
    private final Type[] c;
    
    public b$b(final Type type, final Type type2, final Type... array) {
        boolean b = true;
        int i = 0;
        super();
        if (type2 instanceof Class) {
            final Class clazz = (Class)type2;
            a.a((type != null || clazz.getEnclosingClass() == null) && b);
            if (type != null && clazz.getEnclosingClass() == null) {
                b = false;
            }
            a.a(b);
        }
        Type a;
        if (type == null) {
            a = null;
        }
        else {
            a = b.a(type);
        }
        this.a = a;
        this.b = b.a(type2);
        this.c = array.clone();
        while (i < this.c.length) {
            a.a(this.c[i]);
            b.e(this.c[i]);
            this.c[i] = b.a(this.c[i]);
            ++i;
        }
    }
    
    @Override
    public final boolean equals(final Object o) {
        return o instanceof ParameterizedType && b.a(this, (Type)o);
    }
    
    @Override
    public final Type[] getActualTypeArguments() {
        return this.c.clone();
    }
    
    @Override
    public final Type getOwnerType() {
        return this.a;
    }
    
    @Override
    public final Type getRawType() {
        return this.b;
    }
    
    @Override
    public final int hashCode() {
        return Arrays.hashCode(this.c) ^ this.b.hashCode() ^ b.a((Object)this.a);
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder(30 * (1 + this.c.length));
        sb.append(b.c(this.b));
        if (this.c.length == 0) {
            return sb.toString();
        }
        sb.append("<").append(b.c(this.c[0]));
        for (int i = 1; i < this.c.length; ++i) {
            sb.append(", ").append(b.c(this.c[i]));
        }
        return sb.append(">").toString();
    }
}
