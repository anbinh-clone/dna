package com.google.ads.interactivemedia.v3.a.b.a;

import java.sql.Date;
import com.google.ads.interactivemedia.v3.a.w;
import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.x;

final class i$1 implements x
{
    @Override
    public final w a(final f f, final a a) {
        if (a.a() == Date.class) {
            return new i();
        }
        return null;
    }
}
