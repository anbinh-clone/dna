package com.google.ads.interactivemedia.v3.a.b;

import java.lang.reflect.Type;

final class c$4 implements h
{
    final /* synthetic */ Class a;
    final /* synthetic */ Type b;
    final /* synthetic */ c c;
    private final k d;
    
    c$4(final c c, final Class a, final Type b) {
        this.c = c;
        this.a = a;
        this.b = b;
        super();
        this.d = k.a();
    }
    
    @Override
    public final Object a() {
        try {
            return this.d.a(this.a);
        }
        catch (Exception ex) {
            throw new RuntimeException("Unable to invoke no-args constructor for " + this.b + ". Register an InstanceCreator with Gson for this type may fix this problem.", ex);
        }
    }
}
