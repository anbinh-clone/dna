package com.google.ads.interactivemedia.v3.a;

public interface b
{
    boolean a();
    
    boolean b();
}
