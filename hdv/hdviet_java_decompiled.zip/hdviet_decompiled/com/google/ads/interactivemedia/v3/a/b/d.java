package com.google.ads.interactivemedia.v3.a.b;

import java.lang.reflect.Field;
import java.util.Iterator;
import com.google.ads.interactivemedia.v3.a.b;
import com.google.ads.interactivemedia.v3.a.w;
import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.a.d;
import com.google.ads.interactivemedia.v3.a.a.c;
import java.util.Collections;
import java.util.List;
import com.google.ads.interactivemedia.v3.a.x;

public final class d implements x, Cloneable
{
    public static final d a;
    private double b;
    private int c;
    private boolean d;
    private boolean e;
    private List f;
    private List g;
    
    static {
        a = new d();
    }
    
    public d() {
        super();
        this.b = -1.0;
        this.c = 136;
        this.d = true;
        this.f = Collections.emptyList();
        this.g = Collections.emptyList();
    }
    
    private d a() {
        try {
            return (d)super.clone();
        }
        catch (CloneNotSupportedException ex) {
            throw new AssertionError();
        }
    }
    
    private boolean a(final c c, final d d) {
        int n;
        if (c != null && c.a() > this.b) {
            n = 0;
        }
        else {
            n = 1;
        }
        if (n != 0) {
            int n2;
            if (d != null && d.a() <= this.b) {
                n2 = 0;
            }
            else {
                n2 = 1;
            }
            if (n2 != 0) {
                return true;
            }
        }
        return false;
    }
    
    private static boolean a(final Class clazz) {
        return !Enum.class.isAssignableFrom(clazz) && (clazz.isAnonymousClass() || clazz.isLocalClass());
    }
    
    private static boolean b(final Class clazz) {
        if (clazz.isMemberClass()) {
            int n;
            if ((0x8 & clazz.getModifiers()) != 0x0) {
                n = 1;
            }
            else {
                n = 0;
            }
            if (n == 0) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public final w a(final f f, final a a) {
        final Class a2 = a.a();
        final boolean a3 = this.a(a2, true);
        final boolean a4 = this.a(a2, false);
        if (!a3 && !a4) {
            return null;
        }
        return new d$1(this, a4, a3, f, a);
    }
    
    public final boolean a(final Class clazz, final boolean b) {
        if (this.b != -1.0 && !this.a(clazz.getAnnotation(c.class), clazz.getAnnotation(d.class))) {
            return true;
        }
        if (!this.d && b(clazz)) {
            return true;
        }
        if (a(clazz)) {
            return true;
        }
        List list;
        if (b) {
            list = this.f;
        }
        else {
            list = this.g;
        }
        final Iterator<b> iterator = list.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().b()) {
                return true;
            }
        }
        return false;
    }
    
    public final boolean a(final Field field, final boolean b) {
        if ((this.c & field.getModifiers()) != 0x0) {
            return true;
        }
        if (this.b != -1.0 && !this.a(field.getAnnotation(c.class), field.getAnnotation(d.class))) {
            return true;
        }
        if (field.isSynthetic()) {
            return true;
        }
        Label_0110: {
            if (this.e) {
                final com.google.ads.interactivemedia.v3.a.a.a a = field.getAnnotation(com.google.ads.interactivemedia.v3.a.a.a.class);
                if (a != null) {
                    if (b) {
                        if (a.a()) {
                            break Label_0110;
                        }
                    }
                    else if (a.b()) {
                        break Label_0110;
                    }
                }
                return true;
            }
        }
        if (!this.d && b(field.getType())) {
            return true;
        }
        if (a(field.getType())) {
            return true;
        }
        List list;
        if (b) {
            list = this.f;
        }
        else {
            list = this.g;
        }
        if (!list.isEmpty()) {
            new com.google.ads.interactivemedia.v3.a.c(field);
            final Iterator<b> iterator = list.iterator();
            while (iterator.hasNext()) {
                if (iterator.next().a()) {
                    return true;
                }
            }
        }
        return false;
    }
}
