package com.google.ads.interactivemedia.v3.b.b;

public interface a$a
{
    void b();
}
