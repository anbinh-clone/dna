package com.google.ads.interactivemedia.v3.b;

import android.view.ViewGroup;
import com.google.ads.interactivemedia.v3.api.CompanionAdSlot;

public final class k implements CompanionAdSlot
{
    private int a;
    private int b;
    private ViewGroup c;
    
    @Override
    public final ViewGroup getContainer() {
        return this.c;
    }
    
    @Override
    public final int getHeight() {
        return this.b;
    }
    
    @Override
    public final int getWidth() {
        return this.a;
    }
    
    @Override
    public final void setContainer(final ViewGroup c) {
        this.c = c;
    }
    
    @Override
    public final void setSize(final int a, final int b) {
        this.a = a;
        this.b = b;
    }
}
