package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.w;
import com.google.ads.interactivemedia.v3.a.x;

final class l$21 implements x
{
    final /* synthetic */ Class a;
    final /* synthetic */ w b;
    
    l$21(final Class a, final w b) {
        this.a = a;
        this.b = b;
        super();
    }
    
    @Override
    public final w a(final f f, final a a) {
        if (a.a() == this.a) {
            return this.b;
        }
        return null;
    }
    
    @Override
    public final String toString() {
        return "Factory[type=" + this.a.getName() + ",adapter=" + this.b + "]";
    }
}
