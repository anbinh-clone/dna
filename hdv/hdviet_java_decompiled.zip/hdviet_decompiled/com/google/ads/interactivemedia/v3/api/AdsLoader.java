package com.google.ads.interactivemedia.v3.api;

public interface AdsLoader
{
    void addAdErrorListener(AdErrorEvent$AdErrorListener p0);
    
    void addAdsLoadedListener(AdsLoader$AdsLoadedListener p0);
    
    void contentComplete();
    
    ImaSdkSettings getSettings();
    
    void removeAdErrorListener(AdErrorEvent$AdErrorListener p0);
    
    void removeAdsLoadedListener(AdsLoader$AdsLoadedListener p0);
    
    void requestAds(AdsRequest p0);
}
