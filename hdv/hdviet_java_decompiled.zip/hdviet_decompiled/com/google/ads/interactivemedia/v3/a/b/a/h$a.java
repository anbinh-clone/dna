package com.google.ads.interactivemedia.v3.a.b.a;

import java.util.Iterator;
import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.t;
import com.google.ads.interactivemedia.v3.a.d.b;
import com.google.ads.interactivemedia.v3.a.d.a;
import java.util.Map;
import com.google.ads.interactivemedia.v3.a.b.h;
import com.google.ads.interactivemedia.v3.a.w;

public final class h$a extends w
{
    private final h a;
    private final Map b;
    
    private h$a(final h a, final Map b) {
        super();
        this.a = a;
        this.b = b;
    }
    
    @Override
    public final Object a(final a a) {
        if (a.f() == b.i) {
            a.j();
            return null;
        }
        final Object a2 = this.a.a();
        try {
            a.c();
            while (a.e()) {
                final h$b h$b = this.b.get(a.g());
                if (h$b != null && h$b.i) {
                    goto Label_0091;
                }
                a.n();
            }
        }
        catch (IllegalStateException ex) {
            throw new t(ex);
        }
        catch (IllegalAccessException ex2) {
            throw new AssertionError((Object)ex2);
        }
        a.d();
        return a2;
    }
    
    @Override
    public final void a(final c c, final Object o) {
        if (o == null) {
            c.f();
            return;
        }
        c.d();
        try {
            for (final h$b h$b : this.b.values()) {
                if (h$b.h) {
                    c.a(h$b.g);
                    h$b.a(c, o);
                }
            }
        }
        catch (IllegalAccessException ex) {
            throw new AssertionError();
        }
        c.e();
    }
}
