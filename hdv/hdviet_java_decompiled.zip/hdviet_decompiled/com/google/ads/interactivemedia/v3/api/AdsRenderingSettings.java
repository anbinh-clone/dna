package com.google.ads.interactivemedia.v3.api;

import java.util.List;

public interface AdsRenderingSettings
{
    int getBitrateKbps();
    
    List getMimeTypes();
    
    void setBitrateKbps(int p0);
    
    void setMimeTypes(List p0);
}
