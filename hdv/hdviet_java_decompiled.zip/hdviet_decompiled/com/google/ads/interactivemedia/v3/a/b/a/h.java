package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.w;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import com.google.ads.interactivemedia.v3.a.b.i;
import com.google.ads.interactivemedia.v3.a.b.b;
import java.util.LinkedHashMap;
import java.util.Map;
import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.b.d;
import com.google.ads.interactivemedia.v3.a.e;
import com.google.ads.interactivemedia.v3.a.b.c;
import com.google.ads.interactivemedia.v3.a.x;

public final class h implements x
{
    private final c a;
    private final e b;
    private final d c;
    
    public h(final c a, final e b, final d c) {
        super();
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    private Map a(final f f, a a, Class a2) {
        final LinkedHashMap<String, h$1> linkedHashMap = new LinkedHashMap<String, h$1>();
        if (a2.isInterface()) {
            return linkedHashMap;
        }
        final Type b = a.b();
        while (a2 != Object.class) {
            for (final Field field : a2.getDeclaredFields()) {
                final boolean a3 = this.a(field, true);
                final boolean a4 = this.a(field, false);
                if (a3 || a4) {
                    field.setAccessible(true);
                    final Type a5 = b.a(a.b(), a2, field.getGenericType());
                    final com.google.ads.interactivemedia.v3.a.a.b b2 = field.getAnnotation(com.google.ads.interactivemedia.v3.a.a.b.class);
                    String s;
                    if (b2 == null) {
                        s = this.b.a(field);
                    }
                    else {
                        s = b2.a();
                    }
                    final a a6 = a.a(a5);
                    final h$1 h$1 = new h$1(this, s, a3, a4, f, a6, field, i.a((Type)a6.a()));
                    final h$1 h$2 = linkedHashMap.put(h$1.g, h$1);
                    if (h$2 != null) {
                        throw new IllegalArgumentException(b + " declares multiple JSON fields named " + h$2.g);
                    }
                }
            }
            a = a.a(b.a(a.b(), a2, a2.getGenericSuperclass()));
            a2 = a.a();
        }
        return linkedHashMap;
    }
    
    private boolean a(final Field field, final boolean b) {
        return !this.c.a(field.getType(), b) && !this.c.a(field, b);
    }
    
    @Override
    public final w a(final f f, final a a) {
        final Class a2 = a.a();
        if (!Object.class.isAssignableFrom(a2)) {
            return null;
        }
        return new h$a(this.a.a(a), this.a(f, a, a2), 0);
    }
}
