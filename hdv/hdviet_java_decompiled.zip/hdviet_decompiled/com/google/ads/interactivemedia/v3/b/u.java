package com.google.ads.interactivemedia.v3.b;

public final class u
{
    private final long a;
    private final r$a b;
    
    u(final long a, final r$a b) {
        super();
        this.a = a;
        this.b = b;
    }
    
    public final long a() {
        return this.a;
    }
    
    public final r$a b() {
        return this.b;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this != o) {
            if (o == null) {
                return false;
            }
            if (this.getClass() != o.getClass()) {
                return false;
            }
            final u u = (u)o;
            if (this.a != u.a) {
                return false;
            }
            if (this.b != u.b) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public final int hashCode() {
        return 31 * (int)this.a + this.b.hashCode();
    }
    
    @Override
    public final String toString() {
        return "NativeBridgeConfig [adTimeUpdateMs=" + this.a + ", adUiStyle=" + this.b + "]";
    }
}
