package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.b.b.e$a;
import com.google.ads.interactivemedia.v3.b.b.d;
import com.google.ads.interactivemedia.v3.api.player.VideoProgressUpdate;
import android.view.View;
import android.util.Log;
import com.google.ads.interactivemedia.v3.api.Ad;
import com.google.ads.interactivemedia.v3.b.a.a;
import android.content.Context;
import com.google.ads.interactivemedia.v3.b.b.e;
import com.google.ads.interactivemedia.v3.api.AdDisplayContainer;

public final class h implements v$a
{
    private final String a;
    private s b;
    private u c;
    private AdDisplayContainer d;
    private e e;
    private Context f;
    private a g;
    
    public h(final String a, final u c, final s b, final AdDisplayContainer d, final Context f) {
        super();
        this.b = b;
        this.c = c;
        this.f = f;
        this.a = a;
        this.d = d;
    }
    
    public final void a(final Ad ad) {
        if (this.g != null && !this.g.equals(ad)) {
            Log.e("IMASDK", "Cannot stop non current ad UI");
            return;
        }
        switch (h$1.b[this.c.b().ordinal()]) {
            case 1: {
                if (this.e != null) {
                    this.e.b();
                    this.d.getAdContainer().removeView(this.e.a());
                    this.e = null;
                    this.b.a(this.a);
                    break;
                }
                break;
            }
            case 2: {
                this.d.getAdContainer().removeView((View)this.b.a());
                break;
            }
        }
        this.g = null;
    }
    
    @Override
    public final void a(final VideoProgressUpdate videoProgressUpdate) {
        if (this.e != null) {
            this.e.a(videoProgressUpdate);
        }
    }
    
    public final void a(final a g) {
        if (this.g != null) {
            this.a((Ad)this.g);
        }
        if (g.isLinear()) {
            this.g = g;
            switch (h$1.b[this.c.b().ordinal()]) {
                case 1: {
                    final d d = new d();
                    d.a = g.isSkippable();
                    final Context f = this.f;
                    this.d.getPlayer();
                    this.e = new e(f, d, this.b, this.a);
                    this.b.a(this.e, this.a);
                    this.e.a(new h$a(this, 0));
                    this.d.getAdContainer().addView(this.e.a());
                    this.e.a(g);
                }
                case 2: {
                    this.d.getAdContainer().addView((View)this.b.a());
                }
            }
        }
    }
}
