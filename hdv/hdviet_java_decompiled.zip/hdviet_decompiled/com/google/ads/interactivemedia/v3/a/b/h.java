package com.google.ads.interactivemedia.v3.a.b;

public interface h
{
    Object a();
}
