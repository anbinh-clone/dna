package com.google.ads.interactivemedia.v3.a.b;

import java.util.Set;
import java.util.Map;
import java.util.Comparator;
import java.io.Serializable;
import java.util.AbstractMap;

public final class g extends AbstractMap implements Serializable
{
    static final /* synthetic */ boolean f;
    private static final Comparator g;
    Comparator a;
    g$d b;
    int c;
    int d;
    final g$d e;
    private g$a h;
    private g$b i;
    
    static {
        f = !g.class.desiredAssertionStatus();
        g = new g$1();
    }
    
    public g() {
        this(g.g);
    }
    
    private g(Comparator g) {
        super();
        this.c = 0;
        this.d = 0;
        this.e = new g$d();
        if (g == null) {
            g = g.g;
        }
        this.a = g;
    }
    
    private g$d a(final Object o, final boolean b) {
        final Comparator a = this.a;
        g$d b2 = this.b;
        g$d g$d = null;
        int n = 0;
        Label_0129: {
            if (b2 == null) {
                g$d = b2;
                n = 0;
                break Label_0129;
            }
            Comparable<Object> comparable;
            if (a == g.g) {
                comparable = (Comparable<Object>)o;
            }
            else {
                comparable = null;
            }
            g$d g$d2;
            while (true) {
                int n2;
                if (comparable != null) {
                    n2 = comparable.compareTo(b2.f);
                }
                else {
                    n2 = a.compare(o, b2.f);
                }
                if (n2 == 0) {
                    g$d2 = b2;
                    break;
                }
                g$d g$d3;
                if (n2 < 0) {
                    g$d3 = b2.b;
                }
                else {
                    g$d3 = b2.c;
                }
                if (g$d3 == null) {
                    final int n3 = n2;
                    g$d = b2;
                    n = n3;
                    break Label_0129;
                }
                b2 = g$d3;
            }
            return g$d2;
        }
        g$d g$d2 = null;
        if (b) {
            final g$d e = this.e;
            g$d c;
            if (g$d == null) {
                if (a == g.g && !(o instanceof Comparable)) {
                    throw new ClassCastException(o.getClass().getName() + " is not Comparable");
                }
                c = new g$d(g$d, o, e, e.e);
                this.b = c;
            }
            else {
                c = new g$d(g$d, o, e, e.e);
                if (n < 0) {
                    g$d.b = c;
                }
                else {
                    g$d.c = c;
                }
                this.b(g$d, true);
            }
            this.c += 1;
            this.d += 1;
            return c;
        }
        return g$d2;
    }
    
    private void a(final g$d g$d) {
        final g$d b = g$d.b;
        final g$d c = g$d.c;
        final g$d b2 = c.b;
        final g$d c2 = c.c;
        g$d.c = b2;
        if (b2 != null) {
            b2.a = g$d;
        }
        this.a(g$d, c);
        c.b = g$d;
        g$d.a = c;
        int h;
        if (b != null) {
            h = b.h;
        }
        else {
            h = 0;
        }
        int h2;
        if (b2 != null) {
            h2 = b2.h;
        }
        else {
            h2 = 0;
        }
        g$d.h = 1 + Math.max(h, h2);
        final int h3 = g$d.h;
        int h4 = 0;
        if (c2 != null) {
            h4 = c2.h;
        }
        c.h = 1 + Math.max(h3, h4);
    }
    
    private void a(final g$d g$d, final g$d c) {
        final g$d a = g$d.a;
        g$d.a = null;
        if (c != null) {
            c.a = a;
        }
        if (a == null) {
            this.b = c;
            return;
        }
        if (a.b == g$d) {
            a.b = c;
            return;
        }
        if (!g.f && a.c != g$d) {
            throw new AssertionError();
        }
        a.c = c;
    }
    
    private g$d b(final Object o) {
        g$d a = null;
        if (o == null) {
            return a;
        }
        try {
            a = this.a(o, false);
            return a;
        }
        catch (ClassCastException ex) {
            return null;
        }
    }
    
    private void b(final g$d g$d) {
        final g$d b = g$d.b;
        final g$d c = g$d.c;
        final g$d b2 = b.b;
        final g$d c2 = b.c;
        g$d.b = c2;
        if (c2 != null) {
            c2.a = g$d;
        }
        this.a(g$d, b);
        b.c = g$d;
        g$d.a = b;
        int h;
        if (c != null) {
            h = c.h;
        }
        else {
            h = 0;
        }
        int h2;
        if (c2 != null) {
            h2 = c2.h;
        }
        else {
            h2 = 0;
        }
        g$d.h = 1 + Math.max(h, h2);
        final int h3 = g$d.h;
        int h4 = 0;
        if (b2 != null) {
            h4 = b2.h;
        }
        b.h = 1 + Math.max(h3, h4);
    }
    
    private void b(g$d a, final boolean b) {
        while (a != null) {
            final g$d b2 = a.b;
            final g$d c = a.c;
            int h;
            if (b2 != null) {
                h = b2.h;
            }
            else {
                h = 0;
            }
            int h2;
            if (c != null) {
                h2 = c.h;
            }
            else {
                h2 = 0;
            }
            final int n = h - h2;
            if (n == -2) {
                final g$d b3 = c.b;
                final g$d c2 = c.c;
                int h3;
                if (c2 != null) {
                    h3 = c2.h;
                }
                else {
                    h3 = 0;
                }
                int h4;
                if (b3 != null) {
                    h4 = b3.h;
                }
                else {
                    h4 = 0;
                }
                final int n2 = h4 - h3;
                if (n2 == -1 || (n2 == 0 && !b)) {
                    this.a(a);
                }
                else {
                    if (!g.f && n2 != 1) {
                        throw new AssertionError();
                    }
                    this.b(c);
                    this.a(a);
                }
                if (b) {
                    break;
                }
            }
            else if (n == 2) {
                final g$d b4 = b2.b;
                final g$d c3 = b2.c;
                int h5;
                if (c3 != null) {
                    h5 = c3.h;
                }
                else {
                    h5 = 0;
                }
                int h6;
                if (b4 != null) {
                    h6 = b4.h;
                }
                else {
                    h6 = 0;
                }
                final int n3 = h6 - h5;
                if (n3 == 1 || (n3 == 0 && !b)) {
                    this.b(a);
                }
                else {
                    if (!g.f && n3 != -1) {
                        throw new AssertionError();
                    }
                    this.a(b2);
                    this.b(a);
                }
                if (b) {
                    break;
                }
            }
            else if (n == 0) {
                a.h = h + 1;
                if (b) {
                    return;
                }
            }
            else {
                if (!g.f && n != -1 && n != 1) {
                    throw new AssertionError();
                }
                a.h = 1 + Math.max(h, h2);
                if (!b) {
                    break;
                }
            }
            a = a.a;
        }
    }
    
    final g$d a(final Object o) {
        final g$d b = this.b(o);
        if (b != null) {
            this.a(b, true);
        }
        return b;
    }
    
    final g$d a(final Map.Entry entry) {
        int n = 1;
        final g$d b = this.b(entry.getKey());
        while (true) {
            Label_0073: {
                if (b == null) {
                    break Label_0073;
                }
                final Object g = b.g;
                final V value = entry.getValue();
                int n2;
                if (g == value || (g != null && g.equals(value))) {
                    n2 = n;
                }
                else {
                    n2 = 0;
                }
                if (n2 == 0) {
                    break Label_0073;
                }
                if (n != 0) {
                    return b;
                }
                return null;
            }
            n = 0;
            continue;
        }
    }
    
    final void a(final g$d g$d, final boolean b) {
        if (b) {
            g$d.e.d = g$d.d;
            g$d.d.e = g$d.e;
        }
        final g$d b2 = g$d.b;
        final g$d c = g$d.c;
        final g$d a = g$d.a;
        if (b2 != null && c != null) {
            g$d g$d2;
            if (b2.h > c.h) {
                g$d2 = b2.b();
            }
            else {
                g$d2 = c.a();
            }
            this.a(g$d2, false);
            final g$d b3 = g$d.b;
            int h;
            if (b3 != null) {
                h = b3.h;
                g$d2.b = b3;
                b3.a = g$d2;
                g$d.b = null;
            }
            else {
                h = 0;
            }
            final g$d c2 = g$d.c;
            int h2 = 0;
            if (c2 != null) {
                h2 = c2.h;
                g$d2.c = c2;
                c2.a = g$d2;
                g$d.c = null;
            }
            g$d2.h = 1 + Math.max(h, h2);
            this.a(g$d, g$d2);
            return;
        }
        if (b2 != null) {
            this.a(g$d, b2);
            g$d.b = null;
        }
        else if (c != null) {
            this.a(g$d, c);
            g$d.c = null;
        }
        else {
            this.a(g$d, null);
        }
        this.b(a, false);
        this.c -= 1;
        this.d += 1;
    }
    
    @Override
    public final void clear() {
        this.b = null;
        this.c = 0;
        this.d += 1;
        final g$d e = this.e;
        e.e = e;
        e.d = e;
    }
    
    @Override
    public final boolean containsKey(final Object o) {
        return this.b(o) != null;
    }
    
    @Override
    public final Set entrySet() {
        final g$a h = this.h;
        if (h != null) {
            return h;
        }
        return this.h = new g$a(this);
    }
    
    @Override
    public final Object get(final Object o) {
        final g$d b = this.b(o);
        if (b != null) {
            return b.g;
        }
        return null;
    }
    
    @Override
    public final Set keySet() {
        final g$b i = this.i;
        if (i != null) {
            return i;
        }
        return this.i = new g$b(this);
    }
    
    @Override
    public final Object put(final Object o, final Object g) {
        if (o == null) {
            throw new NullPointerException("key == null");
        }
        final g$d a = this.a(o, true);
        final Object g2 = a.g;
        a.g = g;
        return g2;
    }
    
    @Override
    public final Object remove(final Object o) {
        final g$d a = this.a(o);
        if (a != null) {
            return a.g;
        }
        return null;
    }
    
    @Override
    public final int size() {
        return this.c;
    }
}
