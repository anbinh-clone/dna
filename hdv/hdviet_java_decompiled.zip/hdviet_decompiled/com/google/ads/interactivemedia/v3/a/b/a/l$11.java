package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.d.c;
import java.net.URISyntaxException;
import com.google.ads.interactivemedia.v3.a.m;
import com.google.ads.interactivemedia.v3.a.d.b;
import java.net.URI;
import com.google.ads.interactivemedia.v3.a.d.a;
import com.google.ads.interactivemedia.v3.a.w;

final class l$11 extends w
{
    private static URI b(final a a) {
        if (a.f() == b.i) {
            a.j();
        }
        else {
            try {
                final String h = a.h();
                if (!"null".equals(h)) {
                    return new URI(h);
                }
            }
            catch (URISyntaxException ex) {
                throw new m(ex);
            }
        }
        return null;
    }
}
