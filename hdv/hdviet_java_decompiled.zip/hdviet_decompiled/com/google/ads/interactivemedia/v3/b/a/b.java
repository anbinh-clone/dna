package com.google.ads.interactivemedia.v3.b.a;

import com.google.ads.interactivemedia.v3.api.AdPodInfo;

public final class b implements AdPodInfo
{
    public int adPosition;
    public boolean isBumper;
    public int totalAds;
    
    public b() {
        super();
        this.totalAds = 1;
        this.adPosition = 1;
        this.isBumper = false;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this != o) {
            if (o == null) {
                return false;
            }
            if (this.getClass() != o.getClass()) {
                return false;
            }
            final b b = (b)o;
            if (this.adPosition != b.adPosition) {
                return false;
            }
            if (this.isBumper != b.isBumper) {
                return false;
            }
            if (this.totalAds != b.totalAds) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public final int getAdPosition() {
        return this.adPosition;
    }
    
    @Override
    public final int getTotalAds() {
        return this.totalAds;
    }
    
    @Override
    public final int hashCode() {
        final int n = 31 * (31 + this.adPosition);
        int n2;
        if (this.isBumper) {
            n2 = 1231;
        }
        else {
            n2 = 1237;
        }
        return 31 * (n2 + n) + this.totalAds;
    }
    
    @Override
    public final boolean isBumper() {
        return this.isBumper;
    }
    
    @Override
    public final String toString() {
        return "AdPodInfo [totalAds=" + this.totalAds + ", adPosition=" + this.adPosition + ", isBumper=" + this.isBumper + "]";
    }
}
