package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.b.a.a;
import com.google.ads.interactivemedia.v3.api.AdEvent$AdEventType;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorCode;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorType;

public interface s$b
{
    void a(AdError$AdErrorType p0, int p1, String p2);
    
    void a(AdError$AdErrorType p0, AdError$AdErrorCode p1, String p2);
    
    void a(AdEvent$AdEventType p0, a p1);
}
