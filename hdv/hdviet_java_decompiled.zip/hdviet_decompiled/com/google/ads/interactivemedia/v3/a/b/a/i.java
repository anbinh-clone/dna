package com.google.ads.interactivemedia.v3.a.b.a;

import java.text.ParseException;
import com.google.ads.interactivemedia.v3.a.t;
import com.google.ads.interactivemedia.v3.a.d.b;
import com.google.ads.interactivemedia.v3.a.d.a;
import java.sql.Date;
import com.google.ads.interactivemedia.v3.a.d.c;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import com.google.ads.interactivemedia.v3.a.x;
import com.google.ads.interactivemedia.v3.a.w;

public final class i extends w
{
    public static final x a;
    private final DateFormat b;
    
    static {
        a = new i$1();
    }
    
    public i() {
        super();
        this.b = new SimpleDateFormat("MMM d, yyyy");
    }
    
    private void a(final c c, final Date date) {
        // monitorenter(this)
        // monitorenter(this)
        Label_0019: {
            if (date != null) {
                break Label_0019;
            }
            String format = null;
            try {
                while (true) {
                    c.b(format);
                    return;
                    format = this.b.format(date);
                    continue;
                }
            }
            finally {
            }
            // monitorexit(this)
        }
    }
    
    private Date b(final a a) {
        synchronized (this) {
            Date date;
            if (a.f() == b.i) {
                a.j();
                date = null;
            }
            else {
                try {
                    date = new Date(this.b.parse(a.h()).getTime());
                }
                catch (ParseException ex) {
                    throw new t(ex);
                }
            }
            return date;
        }
    }
}
