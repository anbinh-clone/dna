package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.a.q;
import com.google.ads.interactivemedia.v3.api.CompanionAdSlot;
import com.google.ads.interactivemedia.v3.a.l;
import com.google.ads.interactivemedia.v3.a.s;

final class r$1 implements s
{
}
