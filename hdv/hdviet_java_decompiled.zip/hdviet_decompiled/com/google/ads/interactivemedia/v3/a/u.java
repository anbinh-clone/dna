package com.google.ads.interactivemedia.v3.a;

public enum u
{
    a("DEFAULT"), 
    b("STRING");
    
    static {
        c = new u[] { u.a, u.b };
    }
}
