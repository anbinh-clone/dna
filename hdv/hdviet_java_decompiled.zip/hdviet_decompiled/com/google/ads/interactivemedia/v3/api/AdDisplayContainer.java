package com.google.ads.interactivemedia.v3.api;

import com.google.ads.interactivemedia.v3.api.player.VideoAdPlayer;
import java.util.Collection;
import android.view.ViewGroup;

public interface AdDisplayContainer
{
    ViewGroup getAdContainer();
    
    Collection getCompanionSlots();
    
    VideoAdPlayer getPlayer();
    
    void setAdContainer(ViewGroup p0);
    
    void setCompanionSlots(Collection p0);
    
    void setPlayer(VideoAdPlayer p0);
}
