package com.google.ads.interactivemedia.v3.b;

import android.view.View;
import java.util.HashMap;
import android.content.Context;
import com.google.ads.interactivemedia.v3.b.a.c;
import android.view.View$OnClickListener;
import android.widget.ImageView;
import android.util.Log;
import android.graphics.BitmapFactory;
import java.net.URL;
import android.graphics.Bitmap;
import android.os.AsyncTask;

final class q$1 extends AsyncTask
{
    Exception a;
    final /* synthetic */ q b;
    
    q$1(final q b) {
        this.b = b;
        super();
        this.a = null;
    }
    
    private Bitmap a() {
        try {
            return BitmapFactory.decodeStream(new URL(this.b.a.src).openConnection().getInputStream());
        }
        catch (Exception a) {
            this.a = a;
            return null;
        }
    }
}
