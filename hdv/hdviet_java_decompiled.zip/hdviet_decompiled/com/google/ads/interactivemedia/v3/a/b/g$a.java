package com.google.ads.interactivemedia.v3.a.b;

import java.util.Iterator;
import java.util.Map;
import java.util.AbstractSet;

final class g$a extends AbstractSet
{
    final /* synthetic */ g a;
    
    g$a(final g a) {
        this.a = a;
        super();
    }
    
    @Override
    public final void clear() {
        this.a.clear();
    }
    
    @Override
    public final boolean contains(final Object o) {
        return o instanceof Map.Entry && this.a.a((Map.Entry)o) != null;
    }
    
    @Override
    public final Iterator iterator() {
        return new g$a$1(this);
    }
    
    @Override
    public final boolean remove(final Object o) {
        if (o instanceof Map.Entry) {
            final g$d a = this.a.a((Map.Entry)o);
            if (a != null) {
                this.a.a(a, true);
                return true;
            }
        }
        return false;
    }
    
    @Override
    public final int size() {
        return this.a.c;
    }
}
