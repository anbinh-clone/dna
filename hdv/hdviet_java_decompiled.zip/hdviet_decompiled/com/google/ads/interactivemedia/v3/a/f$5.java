package com.google.ads.interactivemedia.v3.a;

import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.d.b;
import com.google.ads.interactivemedia.v3.a.d.a;

final class f$5 extends w
{
    final /* synthetic */ f a;
    
    f$5(final f a) {
        this.a = a;
        super();
    }
}
