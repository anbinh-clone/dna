package com.google.ads.interactivemedia.v3.api;

import com.google.ads.interactivemedia.v3.b.k;
import com.google.ads.interactivemedia.v3.b.j;
import com.google.ads.interactivemedia.v3.b.i;
import com.google.ads.interactivemedia.v3.b.p;
import com.google.ads.interactivemedia.v3.b.a;
import com.google.ads.interactivemedia.v3.b.e;
import android.net.Uri;
import android.content.Context;

public class ImaSdkFactory
{
    private static ImaSdkFactory instance;
    
    private AdsLoader createAdsLoader(final Context context, final Uri uri, final ImaSdkSettings imaSdkSettings) {
        return new e(context, uri, imaSdkSettings);
    }
    
    public static ImaSdkFactory getInstance() {
        if (ImaSdkFactory.instance == null) {
            ImaSdkFactory.instance = new ImaSdkFactory();
        }
        return ImaSdkFactory.instance;
    }
    
    public AdDisplayContainer createAdDisplayContainer() {
        return new a();
    }
    
    public AdsLoader createAdsLoader(final Context context) {
        return this.createAdsLoader(context, this.createImaSdkSettings());
    }
    
    public AdsLoader createAdsLoader(final Context context, final ImaSdkSettings imaSdkSettings) {
        return new e(context, p.a, imaSdkSettings);
    }
    
    public AdsRenderingSettings createAdsRenderingSettings() {
        return new i();
    }
    
    public AdsRequest createAdsRequest() {
        return new j();
    }
    
    public CompanionAdSlot createCompanionAdSlot() {
        return new k();
    }
    
    public ImaSdkSettings createImaSdkSettings() {
        return new ImaSdkSettings();
    }
}
