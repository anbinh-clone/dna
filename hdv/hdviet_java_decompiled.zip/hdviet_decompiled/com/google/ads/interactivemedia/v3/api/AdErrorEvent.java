package com.google.ads.interactivemedia.v3.api;

public interface AdErrorEvent
{
    AdError getError();
    
    Object getUserRequestContext();
}
