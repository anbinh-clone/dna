package com.google.ads.interactivemedia.v3.b;

import java.io.StringWriter;
import java.util.HashMap;
import com.google.ads.interactivemedia.v3.b.a.e;
import java.net.MalformedURLException;
import android.net.Uri;
import java.lang.reflect.Type;
import com.google.ads.interactivemedia.v3.api.CompanionAdSlot;
import com.google.ads.interactivemedia.v3.a.g;
import com.google.ads.interactivemedia.v3.a.f;

public final class r
{
    private static final f a;
    private final r$b b;
    private final Object c;
    private final String d;
    private final r$c e;
    
    static {
        a = new g().a(CompanionAdSlot.class, new r$1()).a();
    }
    
    public r(final r$b r$b, final r$c r$c, final String s) {
        this(r$b, r$c, s, null);
    }
    
    public r(final r$b b, final r$c e, final String d, final Object c) {
        super();
        this.b = b;
        this.e = e;
        this.d = d;
        this.c = c;
    }
    
    public static r a(final String s) {
        final Uri parse = Uri.parse(s);
        final String substring = parse.getPath().substring(1);
        if (parse.getQueryParameter("sid") == null) {
            throw new MalformedURLException("Session id must be provided in message.");
        }
        return new r(r$b.valueOf(substring), r$c.valueOf(parse.getQueryParameter("type")), parse.getQueryParameter("sid"), r.a.a(parse.getQueryParameter("data"), e.class));
    }
    
    public final r$b a() {
        return this.b;
    }
    
    public final r$c b() {
        return this.e;
    }
    
    public final Object c() {
        return this.c;
    }
    
    public final String d() {
        return this.d;
    }
    
    public final String e() {
        final HashMap<String, r$c> hashMap = new HashMap<String, r$c>(3);
        hashMap.put("type", this.e);
        hashMap.put("sid", (r$c)this.d);
        hashMap.put("data", (r$c)this.c);
        final Object[] array = { "javascript:adsense.mobileads.afmanotify.receiveMessage", this.b, null };
        final f a = r.a;
        final Class<? extends HashMap> class1 = hashMap.getClass();
        final StringWriter stringWriter = new StringWriter();
        a.a(hashMap, class1, stringWriter);
        array[2] = stringWriter.toString();
        return String.format("%s('%s', %s);", array);
    }
    
    @Override
    public final String toString() {
        return String.format("JavaScriptMessage [command=%s, type=%s, sid=%s, data=%s]", this.b, this.e, this.d, this.c);
    }
}
