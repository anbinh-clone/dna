package com.google.ads.interactivemedia.v3.a.b.a;

import java.io.IOException;
import com.google.ads.interactivemedia.v3.a.i;
import com.google.ads.interactivemedia.v3.a.o;
import com.google.ads.interactivemedia.v3.a.n;
import java.util.ArrayList;
import com.google.ads.interactivemedia.v3.a.l;
import java.util.List;
import com.google.ads.interactivemedia.v3.a.q;
import java.io.Writer;
import com.google.ads.interactivemedia.v3.a.d.c;

public final class e extends c
{
    private static final Writer a;
    private static final q b;
    private final List c;
    private String d;
    private l e;
    
    static {
        a = new e$1();
        b = new q("closed");
    }
    
    public e() {
        super(e.a);
        this.c = new ArrayList();
        this.e = n.a;
    }
    
    private void a(final l e) {
        if (this.d != null) {
            if (!e.j() || this.i()) {
                ((o)this.j()).a(this.d, e);
            }
            this.d = null;
            return;
        }
        if (this.c.isEmpty()) {
            this.e = e;
            return;
        }
        final l j = this.j();
        if (j instanceof i) {
            ((i)j).a(e);
            return;
        }
        throw new IllegalStateException();
    }
    
    private l j() {
        return this.c.get(-1 + this.c.size());
    }
    
    @Override
    public final c a(final long n) {
        this.a(new q(n));
        return this;
    }
    
    @Override
    public final c a(final Number n) {
        if (n == null) {
            return this.f();
        }
        if (!this.g()) {
            final double doubleValue = n.doubleValue();
            if (Double.isNaN(doubleValue) || Double.isInfinite(doubleValue)) {
                throw new IllegalArgumentException("JSON forbids NaN and infinities: " + n);
            }
        }
        this.a(new q(n));
        return this;
    }
    
    @Override
    public final c a(final String d) {
        if (this.c.isEmpty() || this.d != null) {
            throw new IllegalStateException();
        }
        if (this.j() instanceof o) {
            this.d = d;
            return this;
        }
        throw new IllegalStateException();
    }
    
    @Override
    public final c a(final boolean b) {
        this.a(new q(Boolean.valueOf(b)));
        return this;
    }
    
    public final l a() {
        if (!this.c.isEmpty()) {
            throw new IllegalStateException("Expected one JSON element but was " + this.c);
        }
        return this.e;
    }
    
    @Override
    public final c b() {
        final i i = new i();
        this.a(i);
        this.c.add(i);
        return this;
    }
    
    @Override
    public final c b(final String s) {
        if (s == null) {
            return this.f();
        }
        this.a(new q(s));
        return this;
    }
    
    @Override
    public final c c() {
        if (this.c.isEmpty() || this.d != null) {
            throw new IllegalStateException();
        }
        if (this.j() instanceof i) {
            this.c.remove(-1 + this.c.size());
            return this;
        }
        throw new IllegalStateException();
    }
    
    @Override
    public final void close() {
        if (!this.c.isEmpty()) {
            throw new IOException("Incomplete document");
        }
        this.c.add(e.b);
    }
    
    @Override
    public final c d() {
        final o o = new o();
        this.a(o);
        this.c.add(o);
        return this;
    }
    
    @Override
    public final c e() {
        if (this.c.isEmpty() || this.d != null) {
            throw new IllegalStateException();
        }
        if (this.j() instanceof o) {
            this.c.remove(-1 + this.c.size());
            return this;
        }
        throw new IllegalStateException();
    }
    
    @Override
    public final c f() {
        this.a(n.a);
        return this;
    }
    
    @Override
    public final void flush() {
    }
}
