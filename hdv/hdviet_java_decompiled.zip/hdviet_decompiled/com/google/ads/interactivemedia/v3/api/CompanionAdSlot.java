package com.google.ads.interactivemedia.v3.api;

import android.view.ViewGroup;

public interface CompanionAdSlot
{
    ViewGroup getContainer();
    
    int getHeight();
    
    int getWidth();
    
    void setContainer(ViewGroup p0);
    
    void setSize(int p0, int p1);
}
