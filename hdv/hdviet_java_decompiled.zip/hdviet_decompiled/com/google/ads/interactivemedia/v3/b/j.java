package com.google.ads.interactivemedia.v3.b;

import java.util.HashMap;
import java.util.Map;
import com.google.ads.interactivemedia.v3.api.AdDisplayContainer;
import com.google.ads.interactivemedia.v3.api.AdsRequest;

public final class j implements AdsRequest
{
    private String a;
    private AdDisplayContainer b;
    private Map c;
    private String d;
    private transient Object e;
    
    @Override
    public final AdDisplayContainer getAdDisplayContainer() {
        return this.b;
    }
    
    @Override
    public final String getAdTagUrl() {
        return this.a;
    }
    
    @Override
    public final String getAdsResponse() {
        return this.d;
    }
    
    @Override
    public final String getExtraParameter(final String s) {
        if (this.c == null) {
            return null;
        }
        return this.c.get(s);
    }
    
    @Override
    public final Map getExtraParameters() {
        return this.c;
    }
    
    @Override
    public final Object getUserRequestContext() {
        return this.e;
    }
    
    @Override
    public final void setAdDisplayContainer(final AdDisplayContainer b) {
        this.b = b;
    }
    
    @Override
    public final void setAdTagUrl(final String a) {
        this.a = a;
    }
    
    @Override
    public final void setAdsResponse(final String d) {
        this.d = d;
    }
    
    @Override
    public final void setExtraParameter(final String s, final String s2) {
        if (this.c == null) {
            this.c = new HashMap();
        }
        this.c.put(s, s2);
    }
    
    @Override
    public final void setUserRequestContext(final Object e) {
        this.e = e;
    }
}
