package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.b.g;
import java.util.ArrayList;
import com.google.ads.interactivemedia.v3.a.d.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.x;
import com.google.ads.interactivemedia.v3.a.w;

public final class g extends w
{
    public static final x a;
    private final f b;
    
    static {
        a = new g$1();
    }
    
    private g(final f b) {
        super();
        this.b = b;
    }
    
    @Override
    public final Object a(final a a) {
        switch (g$2.a[a.f().ordinal()]) {
            default: {
                throw new IllegalStateException();
            }
            case 1: {
                final ArrayList<Object> list = new ArrayList<Object>();
                a.a();
                while (a.e()) {
                    list.add(this.a(a));
                }
                a.b();
                return list;
            }
            case 2: {
                final g g = new g();
                a.c();
                while (a.e()) {
                    g.put(a.g(), this.a(a));
                }
                a.d();
                return g;
            }
            case 3: {
                return a.h();
            }
            case 4: {
                return a.k();
            }
            case 5: {
                return a.i();
            }
            case 6: {
                a.j();
                return null;
            }
        }
    }
    
    @Override
    public final void a(final c c, final Object o) {
        if (o == null) {
            c.f();
            return;
        }
        final w a = this.b.a(o.getClass());
        if (a instanceof g) {
            c.d();
            c.e();
            return;
        }
        a.a(c, o);
    }
}
