package com.google.ads.interactivemedia.v3.a;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

public final class i extends l implements Iterable
{
    private final List a;
    
    public i() {
        super();
        this.a = new ArrayList();
    }
    
    @Override
    public final Number a() {
        if (this.a.size() == 1) {
            return this.a.get(0).a();
        }
        throw new IllegalStateException();
    }
    
    public final void a(l a) {
        if (a == null) {
            a = n.a;
        }
        this.a.add(a);
    }
    
    @Override
    public final String b() {
        if (this.a.size() == 1) {
            return this.a.get(0).b();
        }
        throw new IllegalStateException();
    }
    
    @Override
    public final double c() {
        if (this.a.size() == 1) {
            return this.a.get(0).c();
        }
        throw new IllegalStateException();
    }
    
    @Override
    public final long d() {
        if (this.a.size() == 1) {
            return this.a.get(0).d();
        }
        throw new IllegalStateException();
    }
    
    @Override
    public final int e() {
        if (this.a.size() == 1) {
            return this.a.get(0).e();
        }
        throw new IllegalStateException();
    }
    
    @Override
    public final boolean equals(final Object o) {
        return o == this || (o instanceof i && ((i)o).a.equals(this.a));
    }
    
    @Override
    public final boolean f() {
        if (this.a.size() == 1) {
            return this.a.get(0).f();
        }
        throw new IllegalStateException();
    }
    
    @Override
    public final int hashCode() {
        return this.a.hashCode();
    }
    
    @Override
    public final Iterator iterator() {
        return this.a.iterator();
    }
}
