package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.d.c;
import java.sql.Timestamp;
import java.util.Date;
import com.google.ads.interactivemedia.v3.a.d.a;
import com.google.ads.interactivemedia.v3.a.w;

final class l$15$1 extends w
{
    final /* synthetic */ w a;
    final /* synthetic */ l$15 b;
    
    l$15$1(final l$15 b, final w a) {
        this.b = b;
        this.a = a;
        super();
    }
}
