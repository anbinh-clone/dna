package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.api.player.VideoProgressUpdate;
import java.util.SortedSet;

public final class n implements v$a
{
    private final SortedSet a;
    private s b;
    private String c;
    private float d;
    
    public n(final s b, final SortedSet a, final String c) {
        super();
        this.d = 0.0f;
        this.b = b;
        this.c = c;
        this.a = a;
    }
    
    @Override
    public final void a(final VideoProgressUpdate videoProgressUpdate) {
        if (videoProgressUpdate != null && videoProgressUpdate.getDuration() >= 0.0f) {
            final float currentTime = videoProgressUpdate.getCurrentTime();
            SortedSet<Float> set;
            if (this.d < currentTime) {
                set = this.a.subSet(this.d, currentTime);
            }
            else {
                set = this.a.subSet(currentTime, this.d);
            }
            int n;
            if (!set.isEmpty()) {
                n = 1;
            }
            else {
                n = 0;
            }
            this.d = videoProgressUpdate.getCurrentTime();
            if (n != 0) {
                this.b.b(new r(r$b.contentTimeUpdate, r$c.contentTimeUpdate, this.c, videoProgressUpdate));
            }
        }
    }
}
