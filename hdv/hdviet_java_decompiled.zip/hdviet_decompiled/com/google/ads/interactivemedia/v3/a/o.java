package com.google.ads.interactivemedia.v3.a;

import java.util.Set;
import com.google.ads.interactivemedia.v3.a.b.g;

public final class o extends l
{
    private final g a;
    
    public o() {
        super();
        this.a = new g();
    }
    
    public final void a(final String s, l a) {
        if (a == null) {
            a = n.a;
        }
        this.a.put(s, a);
    }
    
    @Override
    public final boolean equals(final Object o) {
        return o == this || (o instanceof o && ((o)o).a.equals(this.a));
    }
    
    @Override
    public final int hashCode() {
        return this.a.hashCode();
    }
    
    public final Set n() {
        return this.a.entrySet();
    }
}
