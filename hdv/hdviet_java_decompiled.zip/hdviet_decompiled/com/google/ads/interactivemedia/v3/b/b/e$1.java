package com.google.ads.interactivemedia.v3.b.b;

import com.google.ads.interactivemedia.v3.api.player.VideoProgressUpdate;
import java.util.HashMap;
import com.google.ads.interactivemedia.v3.b.r;
import com.google.ads.interactivemedia.v3.b.r$c;
import com.google.ads.interactivemedia.v3.b.r$b;
import com.google.ads.interactivemedia.v3.api.Ad;
import android.text.TextUtils;
import android.view.ViewGroup$LayoutParams;
import android.view.View;
import android.widget.RelativeLayout$LayoutParams;
import java.util.ArrayList;
import android.content.Context;
import com.google.ads.interactivemedia.v3.b.s;
import java.util.List;
import android.widget.FrameLayout;
import com.google.ads.interactivemedia.v3.b.v$a;
import com.google.ads.interactivemedia.v3.b.s$c;
import android.view.View$OnClickListener;
import android.widget.RelativeLayout;
import java.util.Iterator;

final class e$1 implements a$a
{
    final /* synthetic */ e a;
    
    e$1(final e a) {
        this.a = a;
        super();
    }
    
    @Override
    public final void b() {
        final Iterator<e$a> iterator = this.a.b.iterator();
        while (iterator.hasNext()) {
            iterator.next().b();
        }
    }
}
