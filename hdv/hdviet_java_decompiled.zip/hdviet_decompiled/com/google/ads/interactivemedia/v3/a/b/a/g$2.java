package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.d.b;

final class g$2
{
    static {
        a = new int[b.values().length];
        while (true) {
            try {
                g$2.a[b.a.ordinal()] = 1;
                try {
                    g$2.a[b.c.ordinal()] = 2;
                    try {
                        g$2.a[b.f.ordinal()] = 3;
                        try {
                            g$2.a[b.g.ordinal()] = 4;
                            try {
                                g$2.a[b.h.ordinal()] = 5;
                                try {
                                    g$2.a[b.i.ordinal()] = 6;
                                }
                                catch (NoSuchFieldError noSuchFieldError) {}
                            }
                            catch (NoSuchFieldError noSuchFieldError2) {}
                        }
                        catch (NoSuchFieldError noSuchFieldError3) {}
                    }
                    catch (NoSuchFieldError noSuchFieldError4) {}
                }
                catch (NoSuchFieldError noSuchFieldError5) {}
            }
            catch (NoSuchFieldError noSuchFieldError6) {
                continue;
            }
            break;
        }
    }
}
