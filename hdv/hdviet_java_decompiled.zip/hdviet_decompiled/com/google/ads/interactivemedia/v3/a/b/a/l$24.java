package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.w;
import com.google.ads.interactivemedia.v3.a.x;

final class l$24 implements x
{
    final /* synthetic */ Class a;
    final /* synthetic */ Class b;
    final /* synthetic */ w c;
    
    l$24(final Class a, final Class b, final w c) {
        this.a = a;
        this.b = b;
        this.c = c;
        super();
    }
    
    @Override
    public final w a(final f f, final a a) {
        final Class a2 = a.a();
        if (a2 == this.a || a2 == this.b) {
            return this.c;
        }
        return null;
    }
    
    @Override
    public final String toString() {
        return "Factory[type=" + this.a.getName() + "+" + this.b.getName() + ",adapter=" + this.c + "]";
    }
}
