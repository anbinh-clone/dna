package com.google.ads.interactivemedia.v3.b.b;

import java.util.Iterator;
import com.google.ads.interactivemedia.v3.api.player.VideoProgressUpdate;
import java.util.HashMap;
import com.google.ads.interactivemedia.v3.b.r;
import com.google.ads.interactivemedia.v3.b.r$c;
import com.google.ads.interactivemedia.v3.b.r$b;
import com.google.ads.interactivemedia.v3.api.Ad;
import android.text.TextUtils;
import android.view.ViewGroup$LayoutParams;
import android.view.View;
import android.widget.RelativeLayout$LayoutParams;
import java.util.ArrayList;
import android.content.Context;
import com.google.ads.interactivemedia.v3.b.s;
import java.util.List;
import android.widget.FrameLayout;
import com.google.ads.interactivemedia.v3.b.v$a;
import com.google.ads.interactivemedia.v3.b.s$c;
import android.view.View$OnClickListener;
import android.widget.RelativeLayout;

public final class e extends RelativeLayout implements View$OnClickListener, s$c, v$a
{
    private FrameLayout a;
    private List b;
    private final float c;
    private final String d;
    private s e;
    private boolean f;
    private float g;
    private String h;
    private e$b i;
    private b j;
    private d k;
    private a l;
    
    public e(final Context context, final d k, final s e, final String d) {
        super(context);
        this.b = new ArrayList();
        this.f = false;
        this.e = e;
        this.d = d;
        this.k = k;
        this.c = this.getResources().getDisplayMetrics().density;
        this.l = new a(context, this.k);
        final RelativeLayout$LayoutParams relativeLayout$LayoutParams = new RelativeLayout$LayoutParams(-1, -2);
        relativeLayout$LayoutParams.addRule(10);
        this.addView((View)this.l, (ViewGroup$LayoutParams)relativeLayout$LayoutParams);
        this.l.a(new e$1(this));
        if (k.a) {
            this.a = new FrameLayout(context);
            this.j = new b(context);
            this.a.addView((View)this.j, (ViewGroup$LayoutParams)new RelativeLayout$LayoutParams(-2, -2));
            final int a = c.a(15, this.c);
            this.a.setPadding(a, a, 0, a);
            final RelativeLayout$LayoutParams layoutParams = new RelativeLayout$LayoutParams(-2, -2);
            layoutParams.addRule(12);
            layoutParams.addRule(11);
            this.a.setLayoutParams((ViewGroup$LayoutParams)layoutParams);
            this.a.setOnClickListener((View$OnClickListener)this);
            this.addView((View)this.a);
        }
        this.f = this.f;
        if (this.k.a) {
            ((RelativeLayout$LayoutParams)this.a.getLayoutParams()).setMargins(0, 0, 0, c.a(25, this.c));
        }
    }
    
    private void a(final String s) {
        if (this.f && !TextUtils.isEmpty((CharSequence)this.h)) {
            this.l.a(s + ": " + this.h + "?");
            return;
        }
        this.l.a(s);
    }
    
    private void b(final String s) {
        this.l.b(s);
    }
    
    public final View a() {
        return (View)this;
    }
    
    public final void a(final Ad ad) {
        this.a("");
        this.b(this.k.m);
        this.e.b(new r(r$b.i18n, r$c.learnMore, this.d));
        if (ad.isSkippable()) {
            this.i = e$b.b;
            this.a.setVisibility(0);
            final HashMap<String, Integer> hashMap = new HashMap<String, Integer>(1);
            hashMap.put("seconds", 5);
            this.e.b(new r(r$b.i18n, r$c.preSkipButton, this.d, hashMap));
        }
        else {
            this.i = e$b.a;
            if (this.a != null) {
                this.a.setVisibility(4);
            }
        }
        this.setVisibility(0);
    }
    
    public final void a(final VideoProgressUpdate videoProgressUpdate) {
        if (videoProgressUpdate != null && videoProgressUpdate.getDuration() >= 0.0f) {
            final float g = videoProgressUpdate.getDuration() - videoProgressUpdate.getCurrentTime();
            boolean b;
            if (Math.floor(g) != Math.floor(this.g)) {
                b = true;
            }
            else {
                b = false;
            }
            if (b) {
                final HashMap<String, Float> hashMap = new HashMap<String, Float>(2);
                hashMap.put("minutes", g / 60.0f);
                hashMap.put("seconds", g % 60.0f);
                this.e.b(new r(r$b.i18n, r$c.adRemainingTime, this.d, hashMap));
            }
            if (this.i == e$b.b) {
                final float n = 5.0f - videoProgressUpdate.getCurrentTime();
                if (n <= 0.0f) {
                    this.i = e$b.c;
                    this.e.b(new r(r$b.i18n, r$c.skipButton, this.d));
                    final Iterator iterator = this.b.iterator();
                    while (iterator.hasNext()) {
                        iterator.next();
                    }
                }
                else if (b) {
                    final HashMap<String, Float> hashMap2 = new HashMap<String, Float>(1);
                    hashMap2.put("seconds", n);
                    this.e.b(new r(r$b.i18n, r$c.preSkipButton, this.d, hashMap2));
                }
                this.g = g;
            }
        }
    }
    
    public final void a(final e$a e$a) {
        this.b.add(e$a);
    }
    
    public final void a(final r$c r$c, final String s) {
        switch (e$2.a[r$c.ordinal()]) {
            default: {}
            case 1: {
                this.a(s);
            }
            case 2: {
                this.b(s);
            }
            case 3:
            case 4: {
                this.j.a(s);
            }
        }
    }
    
    public final void b() {
        this.setVisibility(4);
    }
    
    public final void onClick(final View view) {
        if (view == this.a && this.i == e$b.c) {
            final Iterator<e$a> iterator = this.b.iterator();
            while (iterator.hasNext()) {
                iterator.next().a();
            }
        }
    }
}
