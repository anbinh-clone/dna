package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.l;
import java.util.Locale;
import java.util.GregorianCalendar;
import java.util.Calendar;
import java.util.UUID;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.util.BitSet;
import com.google.ads.interactivemedia.v3.a.x;
import com.google.ads.interactivemedia.v3.a.w;

public final class l
{
    public static final w A;
    public static final x B;
    public static final w C;
    public static final x D;
    public static final w E;
    public static final x F;
    public static final w G;
    public static final x H;
    public static final w I;
    public static final x J;
    public static final x K;
    public static final w L;
    public static final x M;
    public static final w N;
    public static final x O;
    public static final w P;
    public static final x Q;
    public static final x R;
    public static final w a;
    public static final x b;
    public static final w c;
    public static final x d;
    public static final w e;
    public static final w f;
    public static final x g;
    public static final w h;
    public static final x i;
    public static final w j;
    public static final x k;
    public static final w l;
    public static final x m;
    public static final w n;
    public static final w o;
    public static final w p;
    public static final w q;
    public static final x r;
    public static final w s;
    public static final x t;
    public static final w u;
    public static final w v;
    public static final w w;
    public static final x x;
    public static final w y;
    public static final x z;
    
    static {
        a = new l$1();
        b = a(Class.class, l.a);
        c = new l$12();
        d = a(BitSet.class, l.c);
        e = new l$23();
        f = new l$27();
        g = a(Boolean.TYPE, Boolean.class, l.e);
        h = new l$28();
        i = a(Byte.TYPE, Byte.class, l.h);
        j = new l$29();
        k = a(Short.TYPE, Short.class, l.j);
        l = new l$30();
        m = a(Integer.TYPE, Integer.class, l.l);
        n = new l$31();
        o = new l$32();
        p = new l$2();
        q = new l$3();
        r = a(Number.class, l.q);
        s = new l$4();
        t = a(Character.TYPE, Character.class, l.s);
        u = new l$5();
        v = new l$6();
        w = new l$7();
        x = a(String.class, l.u);
        y = new l$8();
        z = a(StringBuilder.class, l.y);
        A = new l$9();
        B = a(StringBuffer.class, l.A);
        C = new l$10();
        D = a(URL.class, l.C);
        E = new l$11();
        F = a(URI.class, l.E);
        G = new l$13();
        H = b(InetAddress.class, l.G);
        I = new l$14();
        J = a(UUID.class, l.I);
        K = new l$15();
        L = new l$16();
        M = new l$24(Calendar.class, GregorianCalendar.class, l.L);
        N = new l$17();
        O = a(Locale.class, l.N);
        P = new l$18();
        Q = b(l.class, l.P);
        R = new l$19();
    }
    
    public static x a(final a a, final w w) {
        return new l$20(a, w);
    }
    
    public static x a(final Class clazz, final w w) {
        return new l$21(clazz, w);
    }
    
    public static x a(final Class clazz, final Class clazz2, final w w) {
        return new l$22(clazz, clazz2, w);
    }
    
    private static x b(final Class clazz, final w w) {
        return new l$25(clazz, w);
    }
}
