package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.api.player.VideoAdPlayer$VideoAdPlayerCallback;

final class m implements VideoAdPlayer$VideoAdPlayerCallback
{
    private v a;
    
    public m(final v a) {
        super();
        this.a = a;
    }
    
    @Override
    public final void onEnded() {
        this.a.c();
    }
    
    @Override
    public final void onError() {
        this.a.c();
    }
    
    @Override
    public final void onPause() {
        this.a.c();
    }
    
    @Override
    public final void onPlay() {
        this.a.a();
    }
    
    @Override
    public final void onResume() {
        this.a.a();
    }
    
    @Override
    public final void onVolumeChanged(final int n) {
    }
}
