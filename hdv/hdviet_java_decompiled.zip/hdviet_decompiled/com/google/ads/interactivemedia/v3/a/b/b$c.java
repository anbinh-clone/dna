package com.google.ads.interactivemedia.v3.a.b;

import java.util.Map;
import java.util.Properties;
import java.lang.reflect.Array;
import java.lang.reflect.GenericDeclaration;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.lang.reflect.TypeVariable;
import java.util.Collection;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;
import java.io.Serializable;

final class b$c implements Serializable, WildcardType
{
    private final Type a;
    private final Type b;
    
    public b$c(final Type[] array, final Type[] array2) {
        int n = 1;
        super();
        boolean b;
        if (array2.length <= n) {
            b = (n != 0);
        }
        else {
            b = false;
        }
        a.a(b);
        boolean b2;
        if (array.length == n) {
            b2 = (n != 0);
        }
        else {
            b2 = false;
        }
        a.a(b2);
        if (array2.length == n) {
            a.a(array2[0]);
            b.e(array2[0]);
            if (array[0] != Object.class) {
                n = 0;
            }
            a.a(n != 0);
            this.b = b.a(array2[0]);
            this.a = Object.class;
            return;
        }
        a.a(array[0]);
        b.e(array[0]);
        this.b = null;
        this.a = b.a(array[0]);
    }
    
    @Override
    public final boolean equals(final Object o) {
        return o instanceof WildcardType && b.a(this, (Type)o);
    }
    
    @Override
    public final Type[] getLowerBounds() {
        if (this.b != null) {
            return new Type[] { this.b };
        }
        return b.a;
    }
    
    @Override
    public final Type[] getUpperBounds() {
        return new Type[] { this.a };
    }
    
    @Override
    public final int hashCode() {
        int n;
        if (this.b != null) {
            n = 31 + this.b.hashCode();
        }
        else {
            n = 1;
        }
        return n ^ 31 + this.a.hashCode();
    }
    
    @Override
    public final String toString() {
        if (this.b != null) {
            return "? super " + b.c(this.b);
        }
        if (this.a == Object.class) {
            return "?";
        }
        return "? extends " + b.c(this.a);
    }
}
