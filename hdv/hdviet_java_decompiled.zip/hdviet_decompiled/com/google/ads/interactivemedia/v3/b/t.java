package com.google.ads.interactivemedia.v3.b;

import android.util.Log;
import android.webkit.WebViewClient;
import android.content.Context;
import android.webkit.WebView;

public final class t
{
    private final t$a a;
    private final WebView b;
    
    public t(final Context context, final t$a t$a) {
        this(new WebView(context), t$a);
    }
    
    private t(final WebView b, final t$a a) {
        super();
        this.a = a;
        (this.b = b).setBackgroundColor(0);
        b.getSettings().setJavaScriptEnabled(true);
        b.setWebViewClient((WebViewClient)new t$1(this));
    }
    
    public final WebView a() {
        return this.b;
    }
    
    public final void a(final r r) {
        final String e = r.e();
        new StringBuilder("Sending javascript msg: ").append(r).append(" as URL ").append(e);
        this.b.loadUrl(e);
    }
    
    public final void a(final String s) {
        this.b.loadUrl(s);
    }
    
    protected final void b(final String s) {
        try {
            final r a = r.a(s);
            new StringBuilder("Received msg: ").append(a).append(" from URL ").append(s);
            this.a.a(a);
        }
        catch (IllegalArgumentException ex2) {
            Log.w("IMASDK", "Invalid internal message, ignoring. Please make sure the Google IMA SDK library is up to date. Message: " + s);
        }
        catch (Exception ex) {
            Log.e("IMASDK", "An internal error occured parsing message from javascript.  Message to be parsed: " + s, (Throwable)ex);
        }
    }
}
