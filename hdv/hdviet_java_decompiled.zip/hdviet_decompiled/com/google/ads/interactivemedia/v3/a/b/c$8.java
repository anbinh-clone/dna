package com.google.ads.interactivemedia.v3.a.b;

import java.util.EnumSet;
import com.google.ads.interactivemedia.v3.a.m;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

final class c$8 implements h
{
    final /* synthetic */ Type a;
    final /* synthetic */ c b;
    
    c$8(final c b, final Type a) {
        this.b = b;
        this.a = a;
        super();
    }
    
    @Override
    public final Object a() {
        if (!(this.a instanceof ParameterizedType)) {
            throw new m("Invalid EnumSet type: " + this.a.toString());
        }
        final Type type = ((ParameterizedType)this.a).getActualTypeArguments()[0];
        if (type instanceof Class) {
            return EnumSet.noneOf((Class<Enum>)type);
        }
        throw new m("Invalid EnumSet type: " + this.a.toString());
    }
}
