package com.google.ads.interactivemedia.v3.a;

import com.google.ads.interactivemedia.v3.a.c.a;

final class v$a implements x
{
    private final a a;
    private final boolean b;
    private final Class c;
    private final s d;
    private final k e;
    
    private v$a(final Object o, final a a, final boolean b) {
        super();
        s d;
        if (o instanceof s) {
            d = (s)o;
        }
        else {
            d = null;
        }
        this.d = d;
        k e;
        if (o instanceof k) {
            e = (k)o;
        }
        else {
            e = null;
        }
        this.e = e;
        com.google.ads.interactivemedia.v3.a.b.a.a(this.d != null || this.e != null);
        this.a = a;
        this.b = b;
        this.c = null;
    }
    
    @Override
    public final w a(final f f, final a a) {
        int assignable;
        if (this.a != null) {
            if (this.a.equals(a) || (this.b && this.a.b() == a.a())) {
                assignable = 1;
            }
            else {
                assignable = 0;
            }
        }
        else {
            assignable = (this.c.isAssignableFrom(a.a()) ? 1 : 0);
        }
        if (assignable != 0) {
            return new v(this.d, this.e, f, a, this, 0);
        }
        return null;
    }
}
