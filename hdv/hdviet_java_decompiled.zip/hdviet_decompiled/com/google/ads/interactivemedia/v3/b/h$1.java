package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.b.a.c$a;

final class h$1
{
    static {
        b = new int[r$a.values().length];
        while (true) {
            try {
                h$1.b[r$a.b.ordinal()] = 1;
                try {
                    h$1.b[r$a.a.ordinal()] = 2;
                    a = new int[c$a.values().length];
                    try {
                        h$1.a[c$a.Html.ordinal()] = 1;
                        try {
                            h$1.a[c$a.IFrame.ordinal()] = 2;
                            try {
                                h$1.a[c$a.Static.ordinal()] = 3;
                            }
                            catch (NoSuchFieldError noSuchFieldError) {}
                        }
                        catch (NoSuchFieldError noSuchFieldError2) {}
                    }
                    catch (NoSuchFieldError noSuchFieldError3) {}
                }
                catch (NoSuchFieldError noSuchFieldError4) {}
            }
            catch (NoSuchFieldError noSuchFieldError5) {
                continue;
            }
            break;
        }
    }
}
