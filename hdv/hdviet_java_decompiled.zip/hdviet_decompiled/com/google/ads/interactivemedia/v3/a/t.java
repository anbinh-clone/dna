package com.google.ads.interactivemedia.v3.a;

public final class t extends p
{
    public t(final String s) {
        super(s);
    }
    
    public t(final String s, final Throwable t) {
        super(s, t);
    }
    
    public t(final Throwable t) {
        super(t);
    }
}
