package com.google.ads.interactivemedia.v3.api;

public interface AdErrorEvent$AdErrorListener
{
    void onAdError(AdErrorEvent p0);
}
