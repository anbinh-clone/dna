package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.b.a.c$a;

final class s$1
{
    static {
        c = new int[c$a.values().length];
        while (true) {
            try {
                s$1.c[c$a.Html.ordinal()] = 1;
                try {
                    s$1.c[c$a.IFrame.ordinal()] = 2;
                    try {
                        s$1.c[c$a.Static.ordinal()] = 3;
                        b = new int[r$c.values().length];
                        try {
                            s$1.b[r$c.initialized.ordinal()] = 1;
                            try {
                                s$1.b[r$c.log.ordinal()] = 2;
                                try {
                                    s$1.b[r$c.displayCompanions.ordinal()] = 3;
                                    try {
                                        s$1.b[r$c.showVideo.ordinal()] = 4;
                                        try {
                                            s$1.b[r$c.hide.ordinal()] = 5;
                                            try {
                                                s$1.b[r$c.adsLoaded.ordinal()] = 6;
                                                try {
                                                    s$1.b[r$c.error.ordinal()] = 7;
                                                    try {
                                                        s$1.b[r$c.play.ordinal()] = 8;
                                                        try {
                                                            s$1.b[r$c.pause.ordinal()] = 9;
                                                            try {
                                                                s$1.b[r$c.load.ordinal()] = 10;
                                                                try {
                                                                    s$1.b[r$c.startTracking.ordinal()] = 11;
                                                                    try {
                                                                        s$1.b[r$c.stopTracking.ordinal()] = 12;
                                                                        try {
                                                                            s$1.b[r$c.adMetadata.ordinal()] = 13;
                                                                            try {
                                                                                s$1.b[r$c.loaded.ordinal()] = 14;
                                                                                try {
                                                                                    s$1.b[r$c.contentPauseRequested.ordinal()] = 15;
                                                                                    try {
                                                                                        s$1.b[r$c.contentResumeRequested.ordinal()] = 16;
                                                                                        try {
                                                                                            s$1.b[r$c.complete.ordinal()] = 17;
                                                                                            try {
                                                                                                s$1.b[r$c.allAdsCompleted.ordinal()] = 18;
                                                                                                try {
                                                                                                    s$1.b[r$c.skip.ordinal()] = 19;
                                                                                                    try {
                                                                                                        s$1.b[r$c.start.ordinal()] = 20;
                                                                                                        try {
                                                                                                            s$1.b[r$c.resume.ordinal()] = 21;
                                                                                                            try {
                                                                                                                s$1.b[r$c.firstquartile.ordinal()] = 22;
                                                                                                                try {
                                                                                                                    s$1.b[r$c.midpoint.ordinal()] = 23;
                                                                                                                    try {
                                                                                                                        s$1.b[r$c.thirdquartile.ordinal()] = 24;
                                                                                                                        try {
                                                                                                                            s$1.b[r$c.click.ordinal()] = 25;
                                                                                                                            a = new int[r$b.values().length];
                                                                                                                            try {
                                                                                                                                s$1.a[r$b.adsManager.ordinal()] = 1;
                                                                                                                                try {
                                                                                                                                    s$1.a[r$b.videoDisplay.ordinal()] = 2;
                                                                                                                                    try {
                                                                                                                                        s$1.a[r$b.adsLoader.ordinal()] = 3;
                                                                                                                                        try {
                                                                                                                                            s$1.a[r$b.displayContainer.ordinal()] = 4;
                                                                                                                                            try {
                                                                                                                                                s$1.a[r$b.i18n.ordinal()] = 5;
                                                                                                                                                try {
                                                                                                                                                    s$1.a[r$b.webViewLoaded.ordinal()] = 6;
                                                                                                                                                    try {
                                                                                                                                                        s$1.a[r$b.log.ordinal()] = 7;
                                                                                                                                                    }
                                                                                                                                                    catch (NoSuchFieldError noSuchFieldError) {}
                                                                                                                                                }
                                                                                                                                                catch (NoSuchFieldError noSuchFieldError2) {}
                                                                                                                                            }
                                                                                                                                            catch (NoSuchFieldError noSuchFieldError3) {}
                                                                                                                                        }
                                                                                                                                        catch (NoSuchFieldError noSuchFieldError4) {}
                                                                                                                                    }
                                                                                                                                    catch (NoSuchFieldError noSuchFieldError5) {}
                                                                                                                                }
                                                                                                                                catch (NoSuchFieldError noSuchFieldError6) {}
                                                                                                                            }
                                                                                                                            catch (NoSuchFieldError noSuchFieldError7) {}
                                                                                                                        }
                                                                                                                        catch (NoSuchFieldError noSuchFieldError8) {}
                                                                                                                    }
                                                                                                                    catch (NoSuchFieldError noSuchFieldError9) {}
                                                                                                                }
                                                                                                                catch (NoSuchFieldError noSuchFieldError10) {}
                                                                                                            }
                                                                                                            catch (NoSuchFieldError noSuchFieldError11) {}
                                                                                                        }
                                                                                                        catch (NoSuchFieldError noSuchFieldError12) {}
                                                                                                    }
                                                                                                    catch (NoSuchFieldError noSuchFieldError13) {}
                                                                                                }
                                                                                                catch (NoSuchFieldError noSuchFieldError14) {}
                                                                                            }
                                                                                            catch (NoSuchFieldError noSuchFieldError15) {}
                                                                                        }
                                                                                        catch (NoSuchFieldError noSuchFieldError16) {}
                                                                                    }
                                                                                    catch (NoSuchFieldError noSuchFieldError17) {}
                                                                                }
                                                                                catch (NoSuchFieldError noSuchFieldError18) {}
                                                                            }
                                                                            catch (NoSuchFieldError noSuchFieldError19) {}
                                                                        }
                                                                        catch (NoSuchFieldError noSuchFieldError20) {}
                                                                    }
                                                                    catch (NoSuchFieldError noSuchFieldError21) {}
                                                                }
                                                                catch (NoSuchFieldError noSuchFieldError22) {}
                                                            }
                                                            catch (NoSuchFieldError noSuchFieldError23) {}
                                                        }
                                                        catch (NoSuchFieldError noSuchFieldError24) {}
                                                    }
                                                    catch (NoSuchFieldError noSuchFieldError25) {}
                                                }
                                                catch (NoSuchFieldError noSuchFieldError26) {}
                                            }
                                            catch (NoSuchFieldError noSuchFieldError27) {}
                                        }
                                        catch (NoSuchFieldError noSuchFieldError28) {}
                                    }
                                    catch (NoSuchFieldError noSuchFieldError29) {}
                                }
                                catch (NoSuchFieldError noSuchFieldError30) {}
                            }
                            catch (NoSuchFieldError noSuchFieldError31) {}
                        }
                        catch (NoSuchFieldError noSuchFieldError32) {}
                    }
                    catch (NoSuchFieldError noSuchFieldError33) {}
                }
                catch (NoSuchFieldError noSuchFieldError34) {}
            }
            catch (NoSuchFieldError noSuchFieldError35) {
                continue;
            }
            break;
        }
    }
}
