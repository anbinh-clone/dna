package com.google.ads.interactivemedia.v3.b.b;

import android.graphics.RectF;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.drawable.shapes.Shape;

final class b$a$1 extends Shape
{
    private Path a;
    
    public final void draw(final Canvas canvas, final Paint paint) {
        canvas.drawPath(this.a, paint);
    }
    
    public final void onResize(final float n, final float n2) {
        (this.a = new Path()).moveTo(this.getWidth(), this.getHeight());
        this.a.lineTo(6.0f, this.getHeight());
        this.a.arcTo(new RectF(0.0f, this.getHeight() - 12.0f, 12.0f, this.getHeight()), 90.0f, 90.0f);
        this.a.lineTo(0.0f, 6.0f);
        this.a.arcTo(new RectF(0.0f, 0.0f, 12.0f, 12.0f), 180.0f, 90.0f);
        this.a.lineTo(this.getWidth(), 0.0f);
    }
}
