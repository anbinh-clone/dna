package com.google.ads.interactivemedia.v3.a.b;

import java.lang.reflect.Method;

final class k$3 extends k
{
    final /* synthetic */ Method a;
    final /* synthetic */ int b;
    
    k$3(final Method a, final int b) {
        this.a = a;
        this.b = b;
        super();
    }
    
    @Override
    public final Object a(final Class clazz) {
        return this.a.invoke(null, clazz, this.b);
    }
}
