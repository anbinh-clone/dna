package com.google.ads.interactivemedia.v3.api.player;

public interface VideoAdPlayer
{
    void addCallback(VideoAdPlayer$VideoAdPlayerCallback p0);
    
    VideoProgressUpdate getProgress();
    
    void loadAd(String p0);
    
    void pauseAd();
    
    void playAd();
    
    void removeCallback(VideoAdPlayer$VideoAdPlayerCallback p0);
    
    void resumeAd();
    
    void stopAd();
}
