package com.google.ads.interactivemedia.v3.a.b;

import java.lang.reflect.Type;
import java.lang.reflect.ParameterizedType;
import java.util.SortedMap;
import java.util.Queue;
import java.util.Set;
import java.util.EnumSet;
import java.util.SortedSet;
import java.util.Collection;
import com.google.ads.interactivemedia.v3.a.h;
import com.google.ads.interactivemedia.v3.a.c.a;
import java.lang.reflect.Constructor;
import java.util.Map;

public final class c
{
    private final Map a;
    
    public c(final Map a) {
        super();
        this.a = a;
    }
    
    private h a(final Class clazz) {
        try {
            final Constructor declaredConstructor = clazz.getDeclaredConstructor(new Class[0]);
            if (!declaredConstructor.isAccessible()) {
                declaredConstructor.setAccessible(true);
            }
            return new c$6(this, declaredConstructor);
        }
        catch (NoSuchMethodException ex) {
            return null;
        }
    }
    
    public final h a(final a a) {
        final Type b = a.b();
        final Class a2 = a.a();
        final h h = this.a.get(b);
        h a3;
        if (h != null) {
            a3 = new c$1(this, h, b);
        }
        else {
            final h h2 = this.a.get(a2);
            if (h2 != null) {
                return new c$5(this, h2, b);
            }
            a3 = this.a(a2);
            if (a3 == null) {
                if (Collection.class.isAssignableFrom(a2)) {
                    if (SortedSet.class.isAssignableFrom(a2)) {
                        a3 = new c$7(this);
                    }
                    else if (EnumSet.class.isAssignableFrom(a2)) {
                        a3 = new c$8(this, b);
                    }
                    else if (Set.class.isAssignableFrom(a2)) {
                        a3 = new c$9(this);
                    }
                    else if (Queue.class.isAssignableFrom(a2)) {
                        a3 = new c$10(this);
                    }
                    else {
                        a3 = new c$11(this);
                    }
                }
                else if (Map.class.isAssignableFrom(a2)) {
                    if (SortedMap.class.isAssignableFrom(a2)) {
                        a3 = new c$12(this);
                    }
                    else if (b instanceof ParameterizedType && !String.class.isAssignableFrom(a.a(((ParameterizedType)b).getActualTypeArguments()[0]).a())) {
                        a3 = new c$2(this);
                    }
                    else {
                        a3 = new c$3(this);
                    }
                }
                else {
                    a3 = null;
                }
                if (a3 == null) {
                    return new c$4(this, a2, b);
                }
            }
        }
        return a3;
    }
    
    @Override
    public final String toString() {
        return this.a.toString();
    }
}
