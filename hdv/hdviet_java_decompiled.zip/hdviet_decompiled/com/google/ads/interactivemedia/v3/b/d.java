package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.api.player.VideoProgressUpdate;
import com.google.ads.interactivemedia.v3.api.player.VideoAdPlayer$VideoAdPlayerCallback;

public final class d implements VideoAdPlayer$VideoAdPlayerCallback, v$a
{
    private s a;
    private String b;
    private boolean c;
    private boolean d;
    private v e;
    
    public d(final s a, final String b, final v e) {
        super();
        this.c = false;
        this.d = false;
        this.a = a;
        this.b = b;
        this.e = e;
    }
    
    private void a(final r$c r$c, final VideoProgressUpdate videoProgressUpdate) {
        this.a.b(new r(r$b.videoDisplay, r$c, this.b, videoProgressUpdate));
    }
    
    @Override
    public final void a(final VideoProgressUpdate videoProgressUpdate) {
        if (videoProgressUpdate != null && videoProgressUpdate.getDuration() > 0.0f) {
            if (!this.d && videoProgressUpdate.getCurrentTime() > 0.0f) {
                this.a(r$c.start, null);
                this.d = true;
            }
            this.a(r$c.timeupdate, videoProgressUpdate);
        }
    }
    
    @Override
    public final void onEnded() {
        this.e.c();
        this.a(r$c.end, null);
    }
    
    @Override
    public final void onError() {
        this.e.c();
        this.a(r$c.error, null);
    }
    
    @Override
    public final void onPause() {
        this.e.c();
        this.a(r$c.pause, null);
    }
    
    @Override
    public final void onPlay() {
        this.e.b();
        this.d = false;
    }
    
    @Override
    public final void onResume() {
        this.e.b();
        this.a(r$c.play, null);
    }
    
    @Override
    public final void onVolumeChanged(final int n) {
        if (n == 0 && !this.c) {
            this.a(r$c.mute, null);
            this.c = true;
        }
        if (n != 0 && this.c) {
            this.a(r$c.unmute, null);
            this.c = false;
        }
    }
}
