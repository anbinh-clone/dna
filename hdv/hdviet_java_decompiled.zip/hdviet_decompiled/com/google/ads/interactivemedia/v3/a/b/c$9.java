package com.google.ads.interactivemedia.v3.a.b;

import java.util.LinkedHashSet;

final class c$9 implements h
{
    final /* synthetic */ c a;
    
    c$9(final c a) {
        this.a = a;
        super();
    }
    
    @Override
    public final Object a() {
        return new LinkedHashSet();
    }
}
