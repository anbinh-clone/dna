package com.google.ads.interactivemedia.v3.api;

public interface AdsLoader$AdsLoadedListener
{
    void onAdsManagerLoaded(AdsManagerLoadedEvent p0);
}
