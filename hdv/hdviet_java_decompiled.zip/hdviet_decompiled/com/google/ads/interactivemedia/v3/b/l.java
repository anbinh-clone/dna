package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.b.a.c$a;
import android.webkit.WebChromeClient;
import com.google.ads.interactivemedia.v3.b.a.c;
import android.content.Context;
import android.webkit.WebView;

public final class l extends WebView
{
    public l(final Context context, final s s, final c c) {
        super(context);
        this.getSettings().setSupportMultipleWindows(true);
        this.setWebChromeClient((WebChromeClient)new l$1(this, context, s));
        if (c.type == c$a.Html) {
            this.loadData(c.src, "text/html", (String)null);
            return;
        }
        if (c.type == c$a.IFrame) {
            this.loadUrl(c.src);
            return;
        }
        throw new IllegalArgumentException("Companion type " + c.type + " is not valid for a CompanionWebView");
    }
}
