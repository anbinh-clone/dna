package com.google.ads.interactivemedia.v3.a;

import com.google.ads.interactivemedia.v3.a.b.f;
import java.math.BigInteger;
import com.google.ads.interactivemedia.v3.a.b.a;

public final class q extends l
{
    private static final Class[] a;
    private Object b;
    
    static {
        a = new Class[] { Integer.TYPE, Long.TYPE, Short.TYPE, Float.TYPE, Double.TYPE, Byte.TYPE, Boolean.TYPE, Character.TYPE, Integer.class, Long.class, Short.class, Float.class, Double.class, Byte.class, Boolean.class, Character.class };
    }
    
    public q(final Boolean b) {
        super();
        this.a(b);
    }
    
    public q(final Number n) {
        super();
        this.a(n);
    }
    
    public q(final String s) {
        super();
        this.a(s);
    }
    
    private void a(final Object b) {
        if (b instanceof Character) {
            this.b = String.valueOf((char)b);
            return;
        }
        boolean b2 = false;
        Label_0048: {
            if (!(b instanceof Number)) {
                int n = 0;
                Label_0039: {
                    if (b instanceof String) {
                        n = 1;
                    }
                    else {
                        final Class<?> class1 = b.getClass();
                        final Class[] a = q.a;
                        for (int length = a.length, i = 0; i < length; ++i) {
                            if (a[i].isAssignableFrom(class1)) {
                                n = 1;
                                break Label_0039;
                            }
                        }
                        n = 0;
                    }
                }
                b2 = false;
                if (n == 0) {
                    break Label_0048;
                }
            }
            b2 = true;
        }
        a.a(b2);
        this.b = b;
    }
    
    private static boolean a(final q q) {
        if (q.b instanceof Number) {
            final Number n = (Number)q.b;
            return n instanceof BigInteger || n instanceof Long || n instanceof Integer || n instanceof Short || n instanceof Byte;
        }
        return false;
    }
    
    @Override
    public final Number a() {
        if (this.b instanceof String) {
            return new f((String)this.b);
        }
        return (Number)this.b;
    }
    
    @Override
    public final String b() {
        if (this.b instanceof Number) {
            return this.a().toString();
        }
        if (this.b instanceof Boolean) {
            return ((Boolean)this.b).toString();
        }
        return (String)this.b;
    }
    
    @Override
    public final double c() {
        if (this.b instanceof Number) {
            return this.a().doubleValue();
        }
        return Double.parseDouble(this.b());
    }
    
    @Override
    public final long d() {
        if (this.b instanceof Number) {
            return this.a().longValue();
        }
        return Long.parseLong(this.b());
    }
    
    @Override
    public final int e() {
        if (this.b instanceof Number) {
            return this.a().intValue();
        }
        return Integer.parseInt(this.b());
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this != o) {
            if (o == null || this.getClass() != o.getClass()) {
                return false;
            }
            final q q = (q)o;
            if (this.b == null) {
                if (q.b != null) {
                    return false;
                }
            }
            else if (a(this) && a(q)) {
                if (this.a().longValue() != q.a().longValue()) {
                    return false;
                }
            }
            else {
                if (!(this.b instanceof Number) || !(q.b instanceof Number)) {
                    return this.b.equals(q.b);
                }
                final double doubleValue = this.a().doubleValue();
                final double doubleValue2 = q.a().doubleValue();
                if (doubleValue != doubleValue2 && (!Double.isNaN(doubleValue) || !Double.isNaN(doubleValue2))) {
                    return false;
                }
            }
        }
        return true;
    }
    
    @Override
    public final boolean f() {
        if (this.b instanceof Boolean) {
            return (boolean)this.b;
        }
        return Boolean.parseBoolean(this.b());
    }
    
    @Override
    public final int hashCode() {
        if (this.b == null) {
            return 31;
        }
        if (a(this)) {
            final long longValue = this.a().longValue();
            return (int)(longValue ^ longValue >>> 32);
        }
        if (this.b instanceof Number) {
            final long doubleToLongBits = Double.doubleToLongBits(this.a().doubleValue());
            return (int)(doubleToLongBits ^ doubleToLongBits >>> 32);
        }
        return this.b.hashCode();
    }
    
    public final boolean n() {
        return this.b instanceof Boolean;
    }
    
    public final boolean o() {
        return this.b instanceof Number;
    }
    
    public final boolean p() {
        return this.b instanceof String;
    }
}
