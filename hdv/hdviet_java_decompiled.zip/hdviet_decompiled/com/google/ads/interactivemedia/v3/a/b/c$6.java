package com.google.ads.interactivemedia.v3.a.b;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Constructor;

final class c$6 implements h
{
    final /* synthetic */ Constructor a;
    final /* synthetic */ c b;
    
    c$6(final c b, final Constructor a) {
        this.b = b;
        this.a = a;
        super();
    }
    
    @Override
    public final Object a() {
        try {
            return this.a.newInstance((Object[])null);
        }
        catch (InstantiationException ex) {
            throw new RuntimeException("Failed to invoke " + this.a + " with no args", ex);
        }
        catch (InvocationTargetException ex2) {
            throw new RuntimeException("Failed to invoke " + this.a + " with no args", ex2.getTargetException());
        }
        catch (IllegalAccessException ex3) {
            throw new AssertionError((Object)ex3);
        }
    }
}
