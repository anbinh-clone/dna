package com.google.ads.interactivemedia.v3.api;

public interface AdEvent$AdEventListener
{
    void onAdEvent(AdEvent p0);
}
