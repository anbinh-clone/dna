package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.d.a;

abstract class h$b
{
    final String g;
    final boolean h;
    final boolean i;
    
    protected h$b(final String g, final boolean h, final boolean i) {
        super();
        this.g = g;
        this.h = h;
        this.i = i;
    }
    
    abstract void a(final a p0, final Object p1);
    
    abstract void a(final c p0, final Object p1);
}
