package com.google.ads.interactivemedia.v3.a.b;

import java.util.TreeSet;

final class c$7 implements h
{
    final /* synthetic */ c a;
    
    c$7(final c a) {
        this.a = a;
        super();
    }
    
    @Override
    public final Object a() {
        return new TreeSet();
    }
}
