package com.google.ads.interactivemedia.v3.a;

public final class m extends p
{
    public m(final String s) {
        super(s);
    }
    
    public m(final Throwable t) {
        super(t);
    }
}
