package com.google.ads.interactivemedia.v3.a.b.a;

import java.io.Writer;

final class e$1 extends Writer
{
    @Override
    public final void close() {
        throw new AssertionError();
    }
    
    @Override
    public final void flush() {
        throw new AssertionError();
    }
    
    @Override
    public final void write(final char[] array, final int n, final int n2) {
        throw new AssertionError();
    }
}
