package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.d.c;
import java.lang.reflect.Array;
import java.util.ArrayList;
import com.google.ads.interactivemedia.v3.a.d.b;
import com.google.ads.interactivemedia.v3.a.d.a;
import java.lang.reflect.Type;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.x;
import com.google.ads.interactivemedia.v3.a.w;

public final class a extends w
{
    public static final x a;
    private final Class b;
    private final w c;
    
    static {
        a = new a$1();
    }
    
    public a(final f f, final w w, final Class b) {
        super();
        this.c = new k(f, w, b);
        this.b = b;
    }
    
    @Override
    public final Object a(final a a) {
        if (a.f() == b.i) {
            a.j();
            return null;
        }
        final ArrayList<Object> list = new ArrayList<Object>();
        a.a();
        while (a.e()) {
            list.add(this.c.a(a));
        }
        a.b();
        final Object instance = Array.newInstance(this.b, list.size());
        for (int i = 0; i < list.size(); ++i) {
            Array.set(instance, i, list.get(i));
        }
        return instance;
    }
    
    @Override
    public final void a(final c c, final Object o) {
        if (o == null) {
            c.f();
            return;
        }
        c.b();
        for (int i = 0; i < Array.getLength(o); ++i) {
            this.c.a(c, Array.get(o, i));
        }
        c.c();
    }
}
