package com.google.ads.interactivemedia.v3.b.b;

import com.google.ads.interactivemedia.v3.b.r$c;

final class e$2
{
    static {
        a = new int[r$c.values().length];
        while (true) {
            try {
                e$2.a[r$c.adRemainingTime.ordinal()] = 1;
                try {
                    e$2.a[r$c.learnMore.ordinal()] = 2;
                    try {
                        e$2.a[r$c.preSkipButton.ordinal()] = 3;
                        try {
                            e$2.a[r$c.skipButton.ordinal()] = 4;
                        }
                        catch (NoSuchFieldError noSuchFieldError) {}
                    }
                    catch (NoSuchFieldError noSuchFieldError2) {}
                }
                catch (NoSuchFieldError noSuchFieldError3) {}
            }
            catch (NoSuchFieldError noSuchFieldError4) {
                continue;
            }
            break;
        }
    }
}
