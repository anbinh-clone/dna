package com.google.ads.interactivemedia.v3.a;

import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.d.a;

final class f$a extends w
{
    private w a;
    
    @Override
    public final Object a(final a a) {
        if (this.a == null) {
            throw new IllegalStateException();
        }
        return this.a.a(a);
    }
    
    @Override
    public final void a(final c c, final Object o) {
        if (this.a == null) {
            throw new IllegalStateException();
        }
        this.a.a(c, o);
    }
    
    public final void a(final w a) {
        if (this.a != null) {
            throw new AssertionError();
        }
        this.a = a;
    }
}
