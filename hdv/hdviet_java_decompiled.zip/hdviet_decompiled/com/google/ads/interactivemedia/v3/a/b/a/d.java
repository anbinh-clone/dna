package com.google.ads.interactivemedia.v3.a.b.a;

import java.util.Map;
import com.google.ads.interactivemedia.v3.a.n;
import com.google.ads.interactivemedia.v3.a.q;
import java.util.Iterator;
import com.google.ads.interactivemedia.v3.a.o;
import com.google.ads.interactivemedia.v3.a.i;
import com.google.ads.interactivemedia.v3.a.d.b;
import java.util.List;
import java.io.Reader;
import com.google.ads.interactivemedia.v3.a.d.a;

public final class d extends a
{
    private static final Reader a;
    private static final Object b;
    private final List c;
    
    static {
        a = new d$1();
        b = new Object();
    }
    
    private void a(final b b) {
        if (this.f() != b) {
            throw new IllegalStateException("Expected " + b + " but was " + this.f());
        }
    }
    
    private Object q() {
        return this.c.get(-1 + this.c.size());
    }
    
    private Object r() {
        return this.c.remove(-1 + this.c.size());
    }
    
    @Override
    public final void a() {
        this.a(b.a);
        this.c.add(((i)this.q()).iterator());
    }
    
    @Override
    public final void b() {
        this.a(b.b);
        this.r();
        this.r();
    }
    
    @Override
    public final void c() {
        this.a(b.c);
        this.c.add(((o)this.q()).n().iterator());
    }
    
    @Override
    public final void close() {
        this.c.clear();
        this.c.add(d.b);
    }
    
    @Override
    public final void d() {
        this.a(b.d);
        this.r();
        this.r();
    }
    
    @Override
    public final boolean e() {
        final b f = this.f();
        return f != b.d && f != b.b;
    }
    
    @Override
    public final b f() {
        while (!this.c.isEmpty()) {
            final Object q = this.q();
            if (q instanceof Iterator) {
                final boolean b = this.c.get(-2 + this.c.size()) instanceof o;
                final Iterator<Object> iterator = (Iterator<Object>)q;
                if (iterator.hasNext()) {
                    if (b) {
                        return b.e;
                    }
                    this.c.add(iterator.next());
                }
                else {
                    if (b) {
                        return b.d;
                    }
                    return b.b;
                }
            }
            else {
                if (q instanceof o) {
                    return b.c;
                }
                if (q instanceof i) {
                    return b.a;
                }
                if (q instanceof q) {
                    final q q2 = (q)q;
                    if (q2.p()) {
                        return b.f;
                    }
                    if (q2.n()) {
                        return b.h;
                    }
                    if (q2.o()) {
                        return b.g;
                    }
                    throw new AssertionError();
                }
                else {
                    if (q instanceof n) {
                        return b.i;
                    }
                    if (q == d.b) {
                        throw new IllegalStateException("JsonReader is closed");
                    }
                    throw new AssertionError();
                }
            }
        }
        return b.j;
    }
    
    @Override
    public final String g() {
        this.a(b.e);
        final Map.Entry<K, Object> entry = ((Iterator)this.q()).next();
        this.c.add(entry.getValue());
        return (String)entry.getKey();
    }
    
    @Override
    public final String h() {
        final b f = this.f();
        if (f != b.f && f != b.g) {
            throw new IllegalStateException("Expected " + b.f + " but was " + f);
        }
        return ((q)this.r()).b();
    }
    
    @Override
    public final boolean i() {
        this.a(b.h);
        return ((q)this.r()).f();
    }
    
    @Override
    public final void j() {
        this.a(b.i);
        this.r();
    }
    
    @Override
    public final double k() {
        final b f = this.f();
        if (f != b.g && f != b.f) {
            throw new IllegalStateException("Expected " + b.g + " but was " + f);
        }
        final double c = ((q)this.q()).c();
        if (!this.p() && (Double.isNaN(c) || Double.isInfinite(c))) {
            throw new NumberFormatException("JSON forbids NaN and infinities: " + c);
        }
        this.r();
        return c;
    }
    
    @Override
    public final long l() {
        final b f = this.f();
        if (f != b.g && f != b.f) {
            throw new IllegalStateException("Expected " + b.g + " but was " + f);
        }
        final long d = ((q)this.q()).d();
        this.r();
        return d;
    }
    
    @Override
    public final int m() {
        final b f = this.f();
        if (f != b.g && f != b.f) {
            throw new IllegalStateException("Expected " + b.g + " but was " + f);
        }
        final int e = ((q)this.q()).e();
        this.r();
        return e;
    }
    
    @Override
    public final void n() {
        if (this.f() == b.e) {
            this.g();
            return;
        }
        this.r();
    }
    
    public final void o() {
        this.a(b.e);
        final Map.Entry<K, Object> entry = ((Iterator)this.q()).next();
        this.c.add(entry.getValue());
        this.c.add(new q((String)entry.getKey()));
    }
    
    @Override
    public final String toString() {
        return this.getClass().getSimpleName();
    }
}
