package com.google.ads.interactivemedia.v3.b;

public interface s$c
{
    void a(r$c p0, String p1);
}
