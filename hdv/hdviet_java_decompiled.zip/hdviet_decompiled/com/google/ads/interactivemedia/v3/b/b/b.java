package com.google.ads.interactivemedia.v3.b.b;

import android.view.View;
import android.graphics.drawable.Drawable;
import android.content.Context;
import android.widget.TextView;
import android.widget.FrameLayout;

public final class b extends FrameLayout
{
    private final float a;
    private final TextView b;
    
    public b(final Context context) {
        super(context);
        this.a = this.getResources().getDisplayMetrics().density;
        this.setBackgroundDrawable((Drawable)new b$a());
        final int n = (int)(0.5f + 8.0f * this.a);
        this.setPadding(n, n, n, n);
        (this.b = new TextView(context)).setTextColor(-3355444);
        this.b.setIncludeFontPadding(false);
        this.b.setGravity(17);
        this.addView((View)this.b);
    }
    
    public final void a(final String text) {
        this.b.setText((CharSequence)text);
    }
}
