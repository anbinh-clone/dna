package com.google.ads.interactivemedia.v3.a.b;

import java.util.TreeMap;

final class c$12 implements h
{
    final /* synthetic */ c a;
    
    c$12(final c a) {
        this.a = a;
        super();
    }
    
    @Override
    public final Object a() {
        return new TreeMap();
    }
}
