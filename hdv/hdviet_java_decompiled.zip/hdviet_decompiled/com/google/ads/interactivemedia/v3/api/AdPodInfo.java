package com.google.ads.interactivemedia.v3.api;

public interface AdPodInfo
{
    int getAdPosition();
    
    int getTotalAds();
    
    boolean isBumper();
}
