package com.google.ads.interactivemedia.v3.a.b;

final class k$4 extends k
{
    @Override
    public final Object a(final Class clazz) {
        throw new UnsupportedOperationException("Cannot allocate " + clazz);
    }
}
