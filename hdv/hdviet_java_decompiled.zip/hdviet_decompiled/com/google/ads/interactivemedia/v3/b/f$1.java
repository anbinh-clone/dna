package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.api.AdEvent$AdEventType;

final class f$1
{
    static {
        a = new int[AdEvent$AdEventType.values().length];
        while (true) {
            try {
                f$1.a[AdEvent$AdEventType.CONTENT_PAUSE_REQUESTED.ordinal()] = 1;
                try {
                    f$1.a[AdEvent$AdEventType.CONTENT_RESUME_REQUESTED.ordinal()] = 2;
                    try {
                        f$1.a[AdEvent$AdEventType.STARTED.ordinal()] = 3;
                        try {
                            f$1.a[AdEvent$AdEventType.COMPLETED.ordinal()] = 4;
                            try {
                                f$1.a[AdEvent$AdEventType.ALL_ADS_COMPLETED.ordinal()] = 5;
                            }
                            catch (NoSuchFieldError noSuchFieldError) {}
                        }
                        catch (NoSuchFieldError noSuchFieldError2) {}
                    }
                    catch (NoSuchFieldError noSuchFieldError3) {}
                }
                catch (NoSuchFieldError noSuchFieldError4) {}
            }
            catch (NoSuchFieldError noSuchFieldError5) {
                continue;
            }
            break;
        }
    }
}
