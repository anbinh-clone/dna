package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.d.c;
import java.lang.reflect.Field;
import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.w;

final class h$1 extends h$b
{
    final w a;
    final /* synthetic */ f b;
    final /* synthetic */ a c;
    final /* synthetic */ Field d;
    final /* synthetic */ boolean e;
    final /* synthetic */ h f;
    
    h$1(final h f, final String s, final boolean b, final boolean b2, final f b3, final a c, final Field d, final boolean e) {
        this.f = f;
        this.b = b3;
        this.c = c;
        this.d = d;
        this.e = e;
        super(s, b, b2);
        this.a = this.b.a(this.c);
    }
    
    @Override
    final void a(final com.google.ads.interactivemedia.v3.a.d.a a, final Object o) {
        final Object a2 = this.a.a(a);
        if (a2 != null || !this.e) {
            this.d.set(o, a2);
        }
    }
    
    @Override
    final void a(final c c, final Object o) {
        new k(this.b, this.a, this.c.b()).a(c, this.d.get(o));
    }
}
