package com.google.ads.interactivemedia.v3.a.b.a;

import java.text.ParseException;
import com.google.ads.interactivemedia.v3.a.t;
import com.google.ads.interactivemedia.v3.a.d.b;
import com.google.ads.interactivemedia.v3.a.d.a;
import java.util.Date;
import java.sql.Time;
import com.google.ads.interactivemedia.v3.a.d.c;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import com.google.ads.interactivemedia.v3.a.x;
import com.google.ads.interactivemedia.v3.a.w;

public final class j extends w
{
    public static final x a;
    private final DateFormat b;
    
    static {
        a = new j$1();
    }
    
    public j() {
        super();
        this.b = new SimpleDateFormat("hh:mm:ss a");
    }
    
    private void a(final c c, final Time time) {
        // monitorenter(this)
        // monitorenter(this)
        Label_0019: {
            if (time != null) {
                break Label_0019;
            }
            String format = null;
            try {
                while (true) {
                    c.b(format);
                    return;
                    format = this.b.format(time);
                    continue;
                }
            }
            finally {
            }
            // monitorexit(this)
        }
    }
    
    private Time b(final a a) {
        synchronized (this) {
            Time time;
            if (a.f() == b.i) {
                a.j();
                time = null;
            }
            else {
                try {
                    time = new Time(this.b.parse(a.h()).getTime());
                }
                catch (ParseException ex) {
                    throw new t(ex);
                }
            }
            return time;
        }
    }
}
