package com.google.ads.interactivemedia.v3.b.b;

import android.graphics.Paint;
import android.graphics.Canvas;
import android.graphics.drawable.shapes.Shape;

final class a$3 extends Shape
{
    final /* synthetic */ a a;
    
    a$3(final a a) {
        this.a = a;
        super();
    }
    
    public final void draw(final Canvas canvas, final Paint paint) {
        canvas.drawLine(0.0f, this.getHeight(), this.getWidth(), this.getHeight(), paint);
    }
}
