package com.google.ads.interactivemedia.v3.a.b;

import java.util.Iterator;
import java.util.AbstractSet;

final class g$b extends AbstractSet
{
    final /* synthetic */ g a;
    
    g$b(final g a) {
        this.a = a;
        super();
    }
    
    @Override
    public final void clear() {
        this.a.clear();
    }
    
    @Override
    public final boolean contains(final Object o) {
        return this.a.containsKey(o);
    }
    
    @Override
    public final Iterator iterator() {
        return new g$b$1(this);
    }
    
    @Override
    public final boolean remove(final Object o) {
        return this.a.a(o) != null;
    }
    
    @Override
    public final int size() {
        return this.a.c;
    }
}
