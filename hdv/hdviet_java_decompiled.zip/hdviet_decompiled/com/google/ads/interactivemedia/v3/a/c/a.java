package com.google.ads.interactivemedia.v3.a.c;

import com.google.ads.interactivemedia.v3.a.b.a;
import com.google.ads.interactivemedia.v3.a.b.b;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public final class a
{
    final Class a;
    final Type b;
    final int c;
    
    protected a() {
        super();
        final Type genericSuperclass = this.getClass().getGenericSuperclass();
        if (genericSuperclass instanceof Class) {
            throw new RuntimeException("Missing type parameter.");
        }
        this.b = b.a(((ParameterizedType)genericSuperclass).getActualTypeArguments()[0]);
        this.a = b.b(this.b);
        this.c = this.b.hashCode();
    }
    
    private a(final Type type) {
        super();
        this.b = b.a((Type)a.a(type));
        this.a = b.b(this.b);
        this.c = this.b.hashCode();
    }
    
    public static a a(final Class clazz) {
        return new a(clazz);
    }
    
    public static a a(final Type type) {
        return new a(type);
    }
    
    public final Class a() {
        return this.a;
    }
    
    public final Type b() {
        return this.b;
    }
    
    @Override
    public final boolean equals(final Object o) {
        return o instanceof a && b.a(this.b, ((a)o).b);
    }
    
    @Override
    public final int hashCode() {
        return this.c;
    }
    
    @Override
    public final String toString() {
        return b.c(this.b);
    }
}
