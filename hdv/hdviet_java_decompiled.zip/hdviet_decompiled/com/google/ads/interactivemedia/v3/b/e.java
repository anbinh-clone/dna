package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.api.AdDisplayContainer;
import android.net.NetworkInfo;
import com.google.a.a.t;
import com.google.ads.interactivemedia.v3.b.a.d;
import android.net.ConnectivityManager;
import android.util.Log;
import android.os.Build$VERSION;
import com.google.ads.interactivemedia.v3.api.AdErrorEvent;
import com.google.ads.interactivemedia.v3.api.AdError;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorCode;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorType;
import java.util.Random;
import com.google.ads.interactivemedia.v3.api.AdsRequest;
import com.google.ads.interactivemedia.v3.api.AdErrorEvent$AdErrorListener;
import java.util.Iterator;
import com.google.ads.interactivemedia.v3.api.AdsLoader$AdsLoadedListener;
import com.google.ads.interactivemedia.v3.api.AdsManagerLoadedEvent;
import java.util.HashMap;
import java.util.ArrayList;
import android.net.Uri;
import com.google.ads.interactivemedia.v3.api.ImaSdkSettings;
import com.google.a.a.s;
import java.util.Map;
import java.util.List;
import android.content.Context;
import com.google.ads.interactivemedia.v3.api.AdsLoader;

public final class e implements AdsLoader
{
    private final s a;
    private final Context b;
    private final o c;
    private final List d;
    private final Map e;
    private s f;
    private ImaSdkSettings g;
    
    public e(final Context context, final Uri uri, final ImaSdkSettings g) {
        this(s.a(context, uri, g), context);
        this.g = g;
    }
    
    private e(final s a, final Context b) {
        super();
        this.c = new o();
        this.d = new ArrayList(1);
        this.e = new HashMap();
        this.g = new ImaSdkSettings();
        this.a = a;
        this.b = b;
        this.f = new s("a.3.0b2", b);
    }
    
    final void a(final AdsManagerLoadedEvent adsManagerLoadedEvent) {
        final Iterator<AdsLoader$AdsLoadedListener> iterator = this.d.iterator();
        while (iterator.hasNext()) {
            iterator.next().onAdsManagerLoaded(adsManagerLoadedEvent);
        }
    }
    
    @Override
    public final void addAdErrorListener(final AdErrorEvent$AdErrorListener adErrorEvent$AdErrorListener) {
        this.c.a(adErrorEvent$AdErrorListener);
    }
    
    @Override
    public final void addAdsLoadedListener(final AdsLoader$AdsLoadedListener adsLoader$AdsLoadedListener) {
        this.d.add(adsLoader$AdsLoadedListener);
    }
    
    @Override
    public final void contentComplete() {
        this.a.b(new r(r$b.adsLoader, r$c.contentComplete, "*"));
    }
    
    @Override
    public final ImaSdkSettings getSettings() {
        return this.g;
    }
    
    @Override
    public final void removeAdErrorListener(final AdErrorEvent$AdErrorListener adErrorEvent$AdErrorListener) {
        this.c.b(adErrorEvent$AdErrorListener);
    }
    
    @Override
    public final void removeAdsLoadedListener(final AdsLoader$AdsLoadedListener adsLoader$AdsLoadedListener) {
        this.d.remove(adsLoader$AdsLoadedListener);
    }
    
    @Override
    public final void requestAds(final AdsRequest adsRequest) {
        final String string = "ima_sid_" + Integer.valueOf(new Random().nextInt(1000000000)).toString();
        Label_0291: {
            if (adsRequest != null) {
                break Label_0291;
            }
            this.c.a(new b(new AdError(AdError$AdErrorType.LOAD, AdError$AdErrorCode.INVALID_ARGUMENTS, "AdsRequest cannot be null.")));
            int n = 0;
        Label_0178_Outer:
            while (true) {
                if (n == 0) {
                    return;
                }
                this.e.put(string, adsRequest);
                this.a.a(new e$1(this), string);
                this.a.a(adsRequest.getAdDisplayContainer(), string);
                final String adTagUrl = adsRequest.getAdTagUrl();
            Block_10_Outer:
                while (true) {
                    try {
                        if (this.f != null && adTagUrl != null) {
                            final Uri parse = Uri.parse(adTagUrl);
                            if (this.f.a(parse)) {
                                adsRequest.setAdTagUrl(this.f.a(parse, this.b).toString());
                            }
                        }
                        final String format = String.format("android%s:%s:%s", Build$VERSION.RELEASE, "3.0b2", this.b.getPackageName());
                        String format2;
                        if (this.b.checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE") != 0) {
                            Log.w("IMASDK", "Host application doesn't have ACCESS_NETWORK_STATE permission");
                            format2 = "android:0";
                        }
                        else {
                            final NetworkInfo activeNetworkInfo = ((ConnectivityManager)this.b.getSystemService("connectivity")).getActiveNetworkInfo();
                            if (activeNetworkInfo == null) {
                                format2 = "android:0";
                            }
                            else {
                                format2 = String.format("android:%d:%d", activeNetworkInfo.getType(), activeNetworkInfo.getSubtype());
                            }
                        }
                        this.a.b(new r(r$b.adsLoader, r$c.requestAds, string, new d(adsRequest, format, format2, this.g)));
                        return;
                        // iftrue(Label_0338:, adDisplayContainer != null)
                        while (true) {
                            this.c.a(new b(new AdError(AdError$AdErrorType.LOAD, AdError$AdErrorCode.INVALID_ARGUMENTS, "Ad display container must be provided in the AdsRequest.")));
                            n = 0;
                            continue Label_0178_Outer;
                            final AdDisplayContainer adDisplayContainer = adsRequest.getAdDisplayContainer();
                            continue Block_10_Outer;
                        }
                    Label_0404_Outer:
                        while (true) {
                            this.c.a(new b(new AdError(AdError$AdErrorType.LOAD, AdError$AdErrorCode.INVALID_ARGUMENTS, "Ad display container must have a UI container.")));
                            n = 0;
                            continue Label_0178_Outer;
                            while (true) {
                                this.c.a(new b(new AdError(AdError$AdErrorType.LOAD, AdError$AdErrorCode.INVALID_ARGUMENTS, "Ad tag url must non-null and non empty.")));
                                n = 0;
                                continue Label_0178_Outer;
                                Label_0383: {
                                    continue;
                                }
                            }
                            Label_0440: {
                                n = 1;
                            }
                            continue Label_0178_Outer;
                            Label_0338:
                            continue Label_0404_Outer;
                        }
                    }
                    // iftrue(Label_0440:, adsRequest.getAdTagUrl() != null && adsRequest.getAdTagUrl().length() != 0)
                    // iftrue(Label_0383:, adDisplayContainer.getAdContainer() != null)
                    catch (t t) {
                        continue;
                    }
                    break;
                }
                break;
            }
        }
    }
}
