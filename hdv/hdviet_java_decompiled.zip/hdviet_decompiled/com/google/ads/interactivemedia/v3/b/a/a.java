package com.google.ads.interactivemedia.v3.b.a;

import java.util.Arrays;
import com.google.ads.interactivemedia.v3.api.AdPodInfo;
import com.google.ads.interactivemedia.v3.api.Ad;

public final class a implements Ad
{
    private String adId;
    private b adPodInfo;
    private String adSystem;
    private String[] adWrapperIds;
    private String[] adWrapperSystems;
    private String clickThroughUrl;
    private double duration;
    private int height;
    private boolean linear;
    private String selectedMediaUrl;
    private boolean skippable;
    private String traffickingParameters;
    private int width;
    
    public a() {
        super();
        this.adPodInfo = new b();
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this != o) {
            if (o == null) {
                return false;
            }
            if (this.getClass() != o.getClass()) {
                return false;
            }
            final a a = (a)o;
            if (this.adId == null) {
                if (a.adId != null) {
                    return false;
                }
            }
            else if (!this.adId.equals(a.adId)) {
                return false;
            }
            if (this.adSystem == null) {
                if (a.adSystem != null) {
                    return false;
                }
            }
            else if (!this.adSystem.equals(a.adSystem)) {
                return false;
            }
            if (this.adPodInfo == null) {
                if (a.adPodInfo != null) {
                    return false;
                }
            }
            else if (!this.adPodInfo.equals(a.adPodInfo)) {
                return false;
            }
            if (this.clickThroughUrl == null) {
                if (a.clickThroughUrl != null) {
                    return false;
                }
            }
            else if (!this.clickThroughUrl.equals(a.clickThroughUrl)) {
                return false;
            }
            if (Double.doubleToLongBits(this.duration) != Double.doubleToLongBits(a.duration)) {
                return false;
            }
            if (this.height != a.height) {
                return false;
            }
            if (this.linear != a.linear) {
                return false;
            }
            if (this.traffickingParameters == null) {
                if (a.traffickingParameters != null) {
                    return false;
                }
            }
            else if (!this.traffickingParameters.equals(a.traffickingParameters)) {
                return false;
            }
            if (this.width != a.width) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public final String getAdId() {
        return this.adId;
    }
    
    @Override
    public final AdPodInfo getAdPodInfo() {
        return this.adPodInfo;
    }
    
    @Override
    public final String getAdSystem() {
        return this.adSystem;
    }
    
    @Override
    public final String[] getAdWrapperIds() {
        return this.adWrapperIds;
    }
    
    @Override
    public final String[] getAdWrapperSystems() {
        return this.adWrapperSystems;
    }
    
    public final String getClickThruUrl() {
        return this.clickThroughUrl;
    }
    
    @Override
    public final double getDuration() {
        return this.duration;
    }
    
    @Override
    public final int getHeight() {
        return this.height;
    }
    
    @Override
    public final String getSelectedMediaUrl() {
        return this.selectedMediaUrl;
    }
    
    @Override
    public final String getTraffickingParameters() {
        return this.traffickingParameters;
    }
    
    @Override
    public final int getWidth() {
        return this.width;
    }
    
    @Override
    public final int hashCode() {
        int hashCode;
        if (this.adId == null) {
            hashCode = 0;
        }
        else {
            hashCode = this.adId.hashCode();
        }
        final int n = 31 * (hashCode + 31);
        int hashCode2;
        if (this.adPodInfo == null) {
            hashCode2 = 0;
        }
        else {
            hashCode2 = this.adPodInfo.hashCode();
        }
        final int n2 = 31 * (hashCode2 + n);
        int hashCode3;
        if (this.clickThroughUrl == null) {
            hashCode3 = 0;
        }
        else {
            hashCode3 = this.clickThroughUrl.hashCode();
        }
        final int n3 = hashCode3 + n2;
        final long doubleToLongBits = Double.doubleToLongBits(this.duration);
        final int n4 = 31 * (31 * (n3 * 31 + (int)(doubleToLongBits ^ doubleToLongBits >>> 32)) + this.height);
        int n5;
        if (this.linear) {
            n5 = 1231;
        }
        else {
            n5 = 1237;
        }
        final int n6 = 31 * (n5 + n4);
        final String traffickingParameters = this.traffickingParameters;
        int hashCode4 = 0;
        if (traffickingParameters != null) {
            hashCode4 = this.traffickingParameters.hashCode();
        }
        return 31 * (n6 + hashCode4) + this.width;
    }
    
    @Override
    public final boolean isLinear() {
        return this.linear;
    }
    
    @Override
    public final boolean isSkippable() {
        return this.skippable;
    }
    
    @Override
    public final String toString() {
        return "Ad [adId=" + this.adId + ", adWrapperIds=" + Arrays.toString(this.adWrapperIds) + ", adWrapperSystems=" + Arrays.toString(this.adWrapperSystems) + ", adSystem=" + this.adSystem + ", linear=" + this.linear + ", width=" + this.width + ", height=" + this.height + ", traffickingParameters=" + this.traffickingParameters + ", clickThroughUrl=" + this.clickThroughUrl + ", duration=" + this.duration + ", adPodInfo=" + this.adPodInfo + "]";
    }
}
