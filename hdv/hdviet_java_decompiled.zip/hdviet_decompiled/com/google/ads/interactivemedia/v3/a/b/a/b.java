package com.google.ads.interactivemedia.v3.a.b.a;

import java.lang.reflect.Type;
import com.google.ads.interactivemedia.v3.a.b.b;
import java.util.Collection;
import com.google.ads.interactivemedia.v3.a.w;
import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.b.c;
import com.google.ads.interactivemedia.v3.a.x;

public final class b implements x
{
    private final c a;
    
    public b(final c a) {
        super();
        this.a = a;
    }
    
    @Override
    public final w a(final f f, final a a) {
        final Type b = a.b();
        final Class a2 = a.a();
        if (!Collection.class.isAssignableFrom(a2)) {
            return null;
        }
        final Type a3 = b.a(b, a2);
        return new b$a(f, a3, f.a(a.a(a3)), this.a.a(a));
    }
}
