package com.google.ads.interactivemedia.v3.a.b;

import com.google.ads.interactivemedia.v3.a.d.a;

public abstract class e
{
    public static e a;
    
    public abstract void a(final a p0);
}
