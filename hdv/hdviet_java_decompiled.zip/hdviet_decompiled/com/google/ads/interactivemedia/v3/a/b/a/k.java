package com.google.ads.interactivemedia.v3.a.b.a;

import java.lang.reflect.TypeVariable;
import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.d.a;
import java.lang.reflect.Type;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.w;

final class k extends w
{
    private final f a;
    private final w b;
    private final Type c;
    
    k(final f a, final w b, final Type c) {
        super();
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    @Override
    public final Object a(final a a) {
        return this.b.a(a);
    }
    
    @Override
    public final void a(final c c, final Object o) {
        final w b = this.b;
        Type type = this.c;
        if (o != null && (type == Object.class || type instanceof TypeVariable || type instanceof Class)) {
            type = o.getClass();
        }
        w w;
        if (type != this.c) {
            w = this.a.a(com.google.ads.interactivemedia.v3.a.c.a.a(type));
            if (w instanceof h$a && !(this.b instanceof h$a)) {
                w = this.b;
            }
        }
        else {
            w = b;
        }
        w.a(c, o);
    }
}
