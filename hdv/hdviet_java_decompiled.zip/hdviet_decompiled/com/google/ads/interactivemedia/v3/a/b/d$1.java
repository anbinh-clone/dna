package com.google.ads.interactivemedia.v3.a.b;

import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.x;
import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.w;

final class d$1 extends w
{
    final /* synthetic */ boolean a;
    final /* synthetic */ boolean b;
    final /* synthetic */ f c;
    final /* synthetic */ a d;
    final /* synthetic */ d e;
    private w f;
    
    d$1(final d e, final boolean a, final boolean b, final f c, final a d) {
        this.e = e;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        super();
    }
    
    private w a() {
        final w f = this.f;
        if (f != null) {
            return f;
        }
        return this.f = this.c.a(this.e, this.d);
    }
    
    @Override
    public final Object a(final com.google.ads.interactivemedia.v3.a.d.a a) {
        if (this.a) {
            a.n();
            return null;
        }
        return this.a().a(a);
    }
    
    @Override
    public final void a(final c c, final Object o) {
        if (this.b) {
            c.f();
            return;
        }
        this.a().a(c, o);
    }
}
