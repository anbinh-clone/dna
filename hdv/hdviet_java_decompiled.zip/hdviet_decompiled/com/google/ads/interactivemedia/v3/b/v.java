package com.google.ads.interactivemedia.v3.b;

import java.util.Iterator;
import com.google.ads.interactivemedia.v3.api.player.VideoProgressUpdate;
import android.os.Message;
import java.util.ArrayList;
import java.util.List;
import android.os.Handler;
import com.google.ads.interactivemedia.v3.api.player.VideoAdPlayer;
import android.os.Handler$Callback;

public final class v implements Handler$Callback
{
    protected final VideoAdPlayer a;
    protected final long b;
    protected boolean c;
    private Handler d;
    private List e;
    private List f;
    private List g;
    
    public v(final VideoAdPlayer videoAdPlayer, final long n) {
        this(videoAdPlayer, n, 0);
    }
    
    private v(final VideoAdPlayer a, final long b, final byte b2) {
        super();
        this.c = false;
        this.e = new ArrayList(1);
        this.f = new ArrayList(1);
        this.a = a;
        this.b = b;
        this.d = null;
        this.d = new Handler((Handler$Callback)this);
        this.g = this.e;
    }
    
    private void d() {
        if (this.c) {
            return;
        }
        this.c = true;
        this.d.sendEmptyMessage(1);
    }
    
    public final void a() {
        this.g = this.f;
        this.d();
    }
    
    public final void a(final v$a v$a) {
        this.e.add(v$a);
    }
    
    public final void b() {
        this.g = this.e;
        this.d();
    }
    
    public final void b(final v$a v$a) {
        this.e.remove(v$a);
    }
    
    public final void c() {
        this.c = false;
        this.d.sendMessageAtFrontOfQueue(Message.obtain(this.d, 2));
    }
    
    public final void c(final v$a v$a) {
        this.f.add(v$a);
    }
    
    public final boolean handleMessage(final Message message) {
        switch (message.what) {
            default: {
                return true;
            }
            case 2: {
                this.d.removeMessages(1);
                return true;
            }
            case 1: {
                final VideoProgressUpdate progress = this.a.getProgress();
                final Iterator<v$a> iterator = (Iterator<v$a>)this.g.iterator();
                while (iterator.hasNext()) {
                    iterator.next().a(progress);
                }
                this.d.sendMessageDelayed(Message.obtain(this.d, 1), this.b);
                return true;
            }
        }
    }
}
