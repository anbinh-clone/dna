package com.google.ads.interactivemedia.v3.a.b;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class i
{
    private static final Map a;
    private static final Map b;
    
    static {
        final HashMap<Object, Object> hashMap = new HashMap<Object, Object>(16);
        final HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>(16);
        a(hashMap, hashMap2, Boolean.TYPE, Boolean.class);
        a(hashMap, hashMap2, Byte.TYPE, Byte.class);
        a(hashMap, hashMap2, Character.TYPE, Character.class);
        a(hashMap, hashMap2, Double.TYPE, Double.class);
        a(hashMap, hashMap2, Float.TYPE, Float.class);
        a(hashMap, hashMap2, Integer.TYPE, Integer.class);
        a(hashMap, hashMap2, Long.TYPE, Long.class);
        a(hashMap, hashMap2, Short.TYPE, Short.class);
        a(hashMap, hashMap2, Void.TYPE, Void.class);
        a = Collections.unmodifiableMap((Map<?, ?>)hashMap);
        b = Collections.unmodifiableMap((Map<?, ?>)hashMap2);
    }
    
    public static Class a(final Class clazz) {
        final Class clazz2 = i.a.get(a.a(clazz));
        if (clazz2 == null) {
            return clazz;
        }
        return clazz2;
    }
    
    private static void a(final Map map, final Map map2, final Class clazz, final Class clazz2) {
        map.put(clazz, clazz2);
        map2.put(clazz2, clazz);
    }
    
    public static boolean a(final Type type) {
        return i.a.containsKey(type);
    }
}
