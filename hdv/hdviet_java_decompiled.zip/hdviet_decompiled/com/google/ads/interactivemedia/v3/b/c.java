package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.api.Ad;
import com.google.ads.interactivemedia.v3.api.AdEvent$AdEventType;
import com.google.ads.interactivemedia.v3.api.AdEvent;

public final class c implements AdEvent
{
    private AdEvent$AdEventType a;
    private Ad b;
    
    c(final AdEvent$AdEventType a, final Ad b) {
        super();
        this.a = a;
        this.b = b;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this != o) {
            if (!(o instanceof c)) {
                return false;
            }
            final c c = (c)o;
            if (this.b == null) {
                if (c.b != null) {
                    return false;
                }
            }
            else if (!this.b.equals(c.b)) {
                return false;
            }
            if (this.a != c.a) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public final Ad getAd() {
        return this.b;
    }
    
    @Override
    public final AdEvent$AdEventType getType() {
        return this.a;
    }
    
    @Override
    public final String toString() {
        return String.format("AdEvent[type=%s, ad=%s]", this.a, this.b);
    }
}
