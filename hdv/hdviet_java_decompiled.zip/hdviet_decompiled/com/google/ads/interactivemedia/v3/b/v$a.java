package com.google.ads.interactivemedia.v3.b;

import com.google.ads.interactivemedia.v3.api.player.VideoProgressUpdate;

public interface v$a
{
    void a(VideoProgressUpdate p0);
}
