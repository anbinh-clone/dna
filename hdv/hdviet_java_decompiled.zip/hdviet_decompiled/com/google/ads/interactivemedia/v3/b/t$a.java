package com.google.ads.interactivemedia.v3.b;

public interface t$a
{
    void a(r p0);
}
