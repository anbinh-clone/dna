package com.google.ads.interactivemedia.v3.a.b;

import java.lang.reflect.Type;
import com.google.ads.interactivemedia.v3.a.h;

final class c$5 implements h
{
    final /* synthetic */ h a;
    final /* synthetic */ Type b;
    final /* synthetic */ c c;
    
    c$5(final c c, final h a, final Type b) {
        this.c = c;
        this.a = a;
        this.b = b;
        super();
    }
    
    @Override
    public final Object a() {
        final h a = this.a;
        final Type b = this.b;
        return a.a();
    }
}
