package com.google.ads.interactivemedia.v3.a.b;

import java.util.Map;
import java.util.Properties;
import java.lang.reflect.Array;
import java.lang.reflect.GenericDeclaration;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.lang.reflect.TypeVariable;
import java.util.Collection;
import java.lang.reflect.WildcardType;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public final class b
{
    static final Type[] a;
    
    static {
        a = new Type[0];
    }
    
    public static Type a(Type type) {
        if (type instanceof Class) {
            type = type;
            if (((Class)type).isArray()) {
                type = new b$a(a(((Class)type).getComponentType()));
            }
        }
        else {
            if (type instanceof ParameterizedType) {
                final ParameterizedType parameterizedType = (ParameterizedType)type;
                return new b$b(parameterizedType.getOwnerType(), parameterizedType.getRawType(), parameterizedType.getActualTypeArguments());
            }
            if (type instanceof GenericArrayType) {
                return new b$a(((GenericArrayType)type).getGenericComponentType());
            }
            if (type instanceof WildcardType) {
                final WildcardType wildcardType = (WildcardType)type;
                return new b$c(wildcardType.getUpperBounds(), wildcardType.getLowerBounds());
            }
        }
        return type;
    }
    
    public static Type a(final Type type, final Class clazz) {
        Type b = b(type, clazz, Collection.class);
        if (b instanceof WildcardType) {
            b = ((WildcardType)b).getUpperBounds()[0];
        }
        if (b instanceof ParameterizedType) {
            return ((ParameterizedType)b).getActualTypeArguments()[0];
        }
        return Object.class;
    }
    
    private static Type a(final Type type, final Class clazz, Class type2) {
        Class<?> clazz2 = (Class<?>)clazz;
        Type type3 = type;
    Label_0005:
        while (type2 != clazz2) {
            if (((Class)type2).isInterface()) {
                final Class<?>[] interfaces = clazz2.getInterfaces();
                for (int i = 0; i < interfaces.length; ++i) {
                    if (interfaces[i] == type2) {
                        return clazz2.getGenericInterfaces()[i];
                    }
                    if (((Class)type2).isAssignableFrom(interfaces[i])) {
                        final Type type4 = clazz2.getGenericInterfaces()[i];
                        clazz2 = interfaces[i];
                        type3 = type4;
                        continue Label_0005;
                    }
                }
            }
            if (!clazz2.isInterface()) {
                while (clazz2 != Object.class) {
                    final Class<? super Object> superclass = clazz2.getSuperclass();
                    if (superclass == type2) {
                        return clazz2.getGenericSuperclass();
                    }
                    if (((Class)type2).isAssignableFrom(superclass)) {
                        final Type genericSuperclass = clazz2.getGenericSuperclass();
                        clazz2 = superclass;
                        type3 = genericSuperclass;
                        continue Label_0005;
                    }
                    clazz2 = superclass;
                }
            }
            return type2;
        }
        type2 = type3;
        return type2;
    }
    
    public static Type a(final Type type, final Class clazz, final Type type2) {
        int i = 0;
        Type type3 = type2;
    Label_0112_Outer:
        while (type3 instanceof TypeVariable) {
            final TypeVariable<Class> typeVariable = (TypeVariable<Class>)type3;
            final Class genericDeclaration = typeVariable.getGenericDeclaration();
            Class clazz2;
            if (genericDeclaration instanceof Class) {
                clazz2 = genericDeclaration;
            }
            else {
                clazz2 = null;
            }
        Label_0112:
            while (true) {
                Label_0142: {
                    if (clazz2 == null) {
                        break Label_0142;
                    }
                    final Type a = a(type, clazz, clazz2);
                    if (a instanceof ParameterizedType) {
                        final TypeVariable[] typeParameters = clazz2.getTypeParameters();
                        for (int j = 0; j < typeParameters.length; ++j) {
                            if (typeVariable.equals(typeParameters[j])) {
                                type3 = ((ParameterizedType)a).getActualTypeArguments()[j];
                                break Label_0112;
                            }
                        }
                        throw new NoSuchElementException();
                    }
                    break Label_0142;
                    if (type3 == typeVariable) {
                        return type3;
                    }
                    continue Label_0112_Outer;
                }
                type3 = typeVariable;
                continue Label_0112;
            }
        }
        if (type3 instanceof Class && ((Class<Class>)type3).isArray()) {
            type3 = type3;
            final Class<?> componentType = ((Class)type3).getComponentType();
            final Type a2 = a(type, clazz, (Type)componentType);
            if (componentType != a2) {
                return f(a2);
            }
            return type3;
        }
        else if (type3 instanceof GenericArrayType) {
            type3 = type3;
            final Type genericComponentType = ((GenericArrayType)type3).getGenericComponentType();
            final Type a3 = a(type, clazz, genericComponentType);
            if (genericComponentType != a3) {
                return f(a3);
            }
            return type3;
        }
        else if (type3 instanceof ParameterizedType) {
            type3 = type3;
            final Type ownerType = ((ParameterizedType)type3).getOwnerType();
            final Type a4 = a(type, clazz, ownerType);
            int n;
            if (a4 != ownerType) {
                n = 1;
            }
            else {
                n = 0;
            }
            Type[] actualTypeArguments;
            for (actualTypeArguments = ((ParameterizedType)type3).getActualTypeArguments(); i < actualTypeArguments.length; ++i) {
                final Type a5 = a(type, clazz, actualTypeArguments[i]);
                if (a5 != actualTypeArguments[i]) {
                    if (n == 0) {
                        actualTypeArguments = actualTypeArguments.clone();
                        n = 1;
                    }
                    actualTypeArguments[i] = a5;
                }
            }
            if (n != 0) {
                return new b$b(a4, ((ParameterizedType)type3).getRawType(), actualTypeArguments);
            }
            return type3;
        }
        else {
            if (!(type3 instanceof WildcardType)) {
                return type3;
            }
            type3 = type3;
            final Type[] lowerBounds = ((WildcardType)type3).getLowerBounds();
            final Type[] upperBounds = ((WildcardType)type3).getUpperBounds();
            if (lowerBounds.length == 1) {
                final Type a6 = a(type, clazz, lowerBounds[0]);
                if (a6 != lowerBounds[0]) {
                    return new b$c(new Type[] { Object.class }, new Type[] { a6 });
                }
                return type3;
            }
            else {
                if (upperBounds.length != 1) {
                    return type3;
                }
                final Type a7 = a(type, clazz, upperBounds[0]);
                if (a7 != upperBounds[0]) {
                    return new b$c(new Type[] { a7 }, b.a);
                }
                return type3;
            }
        }
    }
    
    public static boolean a(final Type type, final Type type2) {
        Type genericComponentType = type2;
        Type genericComponentType2 = type;
        while (genericComponentType2 != genericComponentType) {
            if (genericComponentType2 instanceof Class) {
                return genericComponentType2.equals(genericComponentType);
            }
            if (genericComponentType2 instanceof ParameterizedType) {
                if (!(genericComponentType instanceof ParameterizedType)) {
                    return false;
                }
                final ParameterizedType parameterizedType = (ParameterizedType)genericComponentType2;
                final ParameterizedType parameterizedType2 = (ParameterizedType)genericComponentType;
                final Type ownerType = parameterizedType.getOwnerType();
                final Type ownerType2 = parameterizedType2.getOwnerType();
                boolean b;
                if (ownerType == ownerType2 || (ownerType != null && ownerType.equals(ownerType2))) {
                    b = true;
                }
                else {
                    b = false;
                }
                return b && parameterizedType.getRawType().equals(parameterizedType2.getRawType()) && Arrays.equals(parameterizedType.getActualTypeArguments(), parameterizedType2.getActualTypeArguments());
            }
            else if (genericComponentType2 instanceof GenericArrayType) {
                if (!(genericComponentType instanceof GenericArrayType)) {
                    return false;
                }
                final GenericArrayType genericArrayType = (GenericArrayType)genericComponentType2;
                final GenericArrayType genericArrayType2 = (GenericArrayType)genericComponentType;
                genericComponentType2 = genericArrayType.getGenericComponentType();
                genericComponentType = genericArrayType2.getGenericComponentType();
            }
            else if (genericComponentType2 instanceof WildcardType) {
                if (!(genericComponentType instanceof WildcardType)) {
                    return false;
                }
                final WildcardType wildcardType = (WildcardType)genericComponentType2;
                final WildcardType wildcardType2 = (WildcardType)genericComponentType;
                return Arrays.equals(wildcardType.getUpperBounds(), wildcardType2.getUpperBounds()) && Arrays.equals(wildcardType.getLowerBounds(), wildcardType2.getLowerBounds());
            }
            else {
                if (!(genericComponentType2 instanceof TypeVariable)) {
                    return false;
                }
                if (!(genericComponentType instanceof TypeVariable)) {
                    return false;
                }
                final TypeVariable<GenericDeclaration> typeVariable = (TypeVariable<GenericDeclaration>)genericComponentType2;
                final TypeVariable<GenericDeclaration> typeVariable2 = (TypeVariable<GenericDeclaration>)genericComponentType;
                return typeVariable.getGenericDeclaration() == typeVariable2.getGenericDeclaration() && typeVariable.getName().equals(typeVariable2.getName());
            }
        }
        return true;
    }
    
    public static Class b(final Type type) {
        Type type2;
        for (type2 = type; !(type2 instanceof Class); type2 = ((WildcardType)type2).getUpperBounds()[0]) {
            if (type2 instanceof ParameterizedType) {
                final Type rawType = ((ParameterizedType)type2).getRawType();
                a.a(rawType instanceof Class);
                return (Class)rawType;
            }
            if (type2 instanceof GenericArrayType) {
                return Array.newInstance(b(((GenericArrayType)type2).getGenericComponentType()), 0).getClass();
            }
            if (type2 instanceof TypeVariable) {
                return Object.class;
            }
            if (!(type2 instanceof WildcardType)) {
                String name;
                if (type2 == null) {
                    name = "null";
                }
                else {
                    name = ((WildcardType)type2).getClass().getName();
                }
                throw new IllegalArgumentException("Expected a Class, ParameterizedType, or GenericArrayType, but <" + type2 + "> is of type " + name);
            }
        }
        return (Class)type2;
    }
    
    private static Type b(final Type type, final Class clazz, final Class clazz2) {
        a.a(clazz2.isAssignableFrom(clazz));
        return a(type, clazz, a(type, clazz, clazz2));
    }
    
    public static Type[] b(final Type type, final Class clazz) {
        if (type == Properties.class) {
            return new Type[] { String.class, String.class };
        }
        final Type b = b(type, clazz, Map.class);
        if (b instanceof ParameterizedType) {
            return ((ParameterizedType)b).getActualTypeArguments();
        }
        return new Type[] { Object.class, Object.class };
    }
    
    public static String c(final Type type) {
        if (type instanceof Class) {
            return ((Class)type).getName();
        }
        return type.toString();
    }
    
    public static Type d(final Type type) {
        if (type instanceof GenericArrayType) {
            return ((GenericArrayType)type).getGenericComponentType();
        }
        return ((Class)type).getComponentType();
    }
    
    private static GenericArrayType f(final Type type) {
        return new b$a(type);
    }
}
