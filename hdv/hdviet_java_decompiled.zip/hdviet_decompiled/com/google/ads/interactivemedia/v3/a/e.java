package com.google.ads.interactivemedia.v3.a;

import java.lang.reflect.Field;

public interface e
{
    String a(Field p0);
}
