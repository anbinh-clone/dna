package com.google.ads.interactivemedia.v3.b;

import android.webkit.WebView;
import android.webkit.WebViewClient;

final class l$1$1 extends WebViewClient
{
    final /* synthetic */ l$1 a;
    
    l$1$1(final l$1 a) {
        this.a = a;
        super();
    }
    
    public final boolean shouldOverrideUrlLoading(final WebView webView, final String s) {
        this.a.b.b(s);
        return true;
    }
}
