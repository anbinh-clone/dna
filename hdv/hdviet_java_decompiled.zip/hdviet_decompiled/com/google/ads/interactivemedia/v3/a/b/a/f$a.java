package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.x;
import com.google.ads.interactivemedia.v3.a.q;
import java.util.Iterator;
import com.google.ads.interactivemedia.v3.a.b.j;
import com.google.ads.interactivemedia.v3.a.l;
import java.util.ArrayList;
import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.b.e;
import com.google.ads.interactivemedia.v3.a.t;
import java.util.Map;
import com.google.ads.interactivemedia.v3.a.d.b;
import com.google.ads.interactivemedia.v3.a.d.a;
import java.lang.reflect.Type;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.b.h;
import com.google.ads.interactivemedia.v3.a.w;

final class f$a extends w
{
    final /* synthetic */ f a;
    private final w b;
    private final w c;
    private final h d;
    
    public f$a(final f a, final f f, final Type type, final w w, final Type type2, final w w2, final h d) {
        this.a = a;
        super();
        this.b = new k(f, w, type);
        this.c = new k(f, w2, type2);
        this.d = d;
    }
}
