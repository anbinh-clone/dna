package com.google.ads.interactivemedia.v3.a.b.a;

import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.t;
import com.google.ads.interactivemedia.v3.a.d.b;
import java.util.BitSet;
import com.google.ads.interactivemedia.v3.a.d.a;
import com.google.ads.interactivemedia.v3.a.w;

final class l$12 extends w
{
    private static BitSet b(final a a) {
        if (a.f() == b.i) {
            a.j();
            return null;
        }
        final BitSet set = new BitSet();
        a.a();
        b b = a.f();
        int n = 0;
    Label_0203:
        while (b != b.b) {
            int i = 0;
            switch (l$26.a[b.ordinal()]) {
                default: {
                    throw new t("Invalid bitset value type: " + b);
                }
                case 1: {
                    if (a.m() != 0) {
                        i = 1;
                        break;
                    }
                    i = 0;
                    break;
                }
                case 2: {
                    i = (a.i() ? 1 : 0);
                    break;
                }
                case 3: {
                    final String h = a.h();
                    try {
                        if (Integer.parseInt(h) != 0) {
                            i = 1;
                            break;
                        }
                        i = 0;
                        break;
                    }
                    catch (NumberFormatException ex) {
                        throw new t("Error: Expecting: bitset number value (1, 0), Found: " + h);
                    }
                    break Label_0203;
                }
            }
            if (i != 0) {
                set.set(n);
            }
            ++n;
            b = a.f();
        }
        a.b();
        return set;
    }
}
