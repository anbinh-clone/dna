package com.google.ads.interactivemedia.v3.b;

import android.net.Uri;

public final class p
{
    public static final Uri a;
    
    static {
        a = Uri.parse("http://s0.2mdn.net/instream/html5/native/native_sdk_v3.html");
    }
}
