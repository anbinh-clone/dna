package com.google.ads.interactivemedia.v3.b;

import android.content.Intent;
import com.google.ads.interactivemedia.v3.b.a.a;
import com.google.ads.interactivemedia.v3.api.AdEvent$AdEventType;
import com.google.ads.interactivemedia.v3.api.player.VideoAdPlayer;
import com.google.ads.interactivemedia.v3.api.AdDisplayContainer;
import android.webkit.WebView;
import android.view.View;
import com.google.ads.interactivemedia.v3.b.a.c;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorCode;
import com.google.ads.interactivemedia.v3.api.AdError$AdErrorType;
import android.util.Log;
import com.google.ads.interactivemedia.v3.b.a.e;
import java.util.Iterator;
import com.google.ads.interactivemedia.v3.api.CompanionAdSlot;
import android.view.ViewGroup;
import java.util.Set;
import com.google.ads.interactivemedia.v3.api.ImaSdkSettings;
import android.net.Uri;
import android.os.SystemClock;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Queue;
import android.content.Context;
import java.util.Map;

public final class s implements t$a
{
    private static s a;
    private Map b;
    private Map c;
    private Map d;
    private Map e;
    private Map f;
    private final Context g;
    private final t h;
    private u i;
    private boolean j;
    private Queue k;
    private long l;
    
    private s(final Context g, final String s) {
        super();
        this.b = new HashMap();
        this.c = new HashMap();
        this.d = new HashMap();
        this.e = new HashMap();
        this.f = new HashMap();
        this.j = false;
        this.k = new LinkedList();
        this.l = SystemClock.elapsedRealtime();
        this.g = g;
        (this.h = new t(g, this)).a(s);
    }
    
    public static s a(final Context context, final Uri uri, final ImaSdkSettings imaSdkSettings) {
        if (s.a == null) {
            s.a = new s(context, uri.buildUpon().appendQueryParameter("sdk_version", "a.3.0b2").appendQueryParameter("hl", imaSdkSettings.getLanguage()).build().toString());
        }
        return s.a;
    }
    
    private static String a(final String s, final String s2) {
        if (s2 == null || s2.length() == 0) {
            return s;
        }
        return s + " Caused by: " + s2;
    }
    
    private static Map a(final a a, final Set set) {
        final HashMap<String, ViewGroup> hashMap = new HashMap<String, ViewGroup>(set.size());
        for (final String s : set) {
            final CompanionAdSlot companionAdSlot = a.a().get(s);
            if (companionAdSlot.getContainer() == null) {
                return null;
            }
            hashMap.put(s, companionAdSlot.getContainer());
        }
        return hashMap;
    }
    
    private void a(final r$c r$c, final String s, final e e) {
        final a a = this.f.get(s);
        final s$b s$b = this.b.get(s);
        if (a == null || s$b == null) {
            Log.e("IMASDK", "Received displayContainer message: " + r$c + " for invalid session id: " + s);
        }
        else {
            switch (s$1.b[r$c.ordinal()]) {
                case 4:
                case 5: {
                    break;
                }
                default: {
                    throw new IllegalArgumentException("Illegal message type " + r$c + " received for displayContainer channel");
                }
                case 3: {
                    if (e == null || e.companions == null) {
                        s$b.a(AdError$AdErrorType.LOAD, AdError$AdErrorCode.INTERNAL_ERROR, "Display companions message requires companions in data.");
                        return;
                    }
                    final Map a2 = a(a, e.companions.keySet());
                    if (a2 == null) {
                        s$b.a(AdError$AdErrorType.LOAD, AdError$AdErrorCode.INTERNAL_ERROR, "Display requested for invalid companion slot.");
                        return;
                    }
                    for (final String s2 : a2.keySet()) {
                        final ViewGroup viewGroup = (ViewGroup)a2.get(s2);
                        final c c = e.companions.get(s2);
                        viewGroup.removeAllViews();
                        Object o = null;
                        switch (s$1.c[c.type.ordinal()]) {
                            default: {
                                o = null;
                                break;
                            }
                            case 1:
                            case 2: {
                                o = new l(viewGroup.getContext(), this, c);
                                break;
                            }
                            case 3: {
                                o = new q(viewGroup.getContext(), this, c, s);
                                break;
                            }
                        }
                        viewGroup.addView((View)o);
                    }
                    break;
                }
            }
        }
    }
    
    private void b() {
        while (this.j && !this.k.isEmpty()) {
            this.h.a(this.k.remove());
        }
    }
    
    public final WebView a() {
        return this.h.a();
    }
    
    public final void a(final AdDisplayContainer adDisplayContainer, final String s) {
        this.f.put(s, adDisplayContainer);
    }
    
    public final void a(final VideoAdPlayer videoAdPlayer, final String s) {
        this.e.put(s, videoAdPlayer);
    }
    
    @Override
    public final void a(final r r) {
        final e e = (e)r.c();
        final String d = r.d();
        final r$c b = r.b();
    Label_1158_Outer:
        while (true) {
            Label_1389: {
                Label_0098: {
                    switch (s$1.a[r.a().ordinal()]) {
                        default: {
                            Log.e("IMASDK", "Unknown message channel: " + r.a());
                            break;
                        }
                        case 1: {
                            final s$b s$b = this.b.get(d);
                            if (s$b == null) {
                                Log.e("IMASDK", "Received manager message: " + b + " for invalid session id: " + d);
                                return;
                            }
                            if (e != null && e.adData != null) {
                                final a adData = e.adData;
                                break Label_0170;
                            }
                            break Label_1389;
                        }
                        case 2: {
                            final VideoAdPlayer videoAdPlayer = this.e.get(d);
                            if (videoAdPlayer == null) {
                                Log.e("IMASDK", "Received player message: " + b + " for invalid session id: " + d);
                                return;
                            }
                            switch (s$1.b[b.ordinal()]) {
                                case 11:
                                case 12: {
                                    break Label_0098;
                                }
                                default: {
                                    throw new IllegalArgumentException("Illegal message type " + b + " received for player channel");
                                }
                                case 8: {
                                    if (e != null && e.videoUrl != null) {
                                        videoAdPlayer.loadAd(e.videoUrl);
                                    }
                                    videoAdPlayer.playAd();
                                    return;
                                }
                                case 9: {
                                    videoAdPlayer.pauseAd();
                                    return;
                                }
                                case 10: {
                                    if (e != null && e.videoUrl != null) {
                                        videoAdPlayer.loadAd(e.videoUrl);
                                        return;
                                    }
                                    Log.e("IMASDK", "Load message must contain video url");
                                    final s$b s$b2 = this.b.get(d);
                                    if (s$b2 != null) {
                                        s$b2.a(AdError$AdErrorType.LOAD, AdError$AdErrorCode.INTERNAL_ERROR, "Loading message did not contain a video url.");
                                        return;
                                    }
                                    break Label_0098;
                                }
                            }
                            break;
                        }
                        case 3: {
                            final s$a s$a = this.c.get(d);
                            if (s$a == null) {
                                Log.e("IMASDK", "Received request message: " + b + " for invalid session id: " + d);
                                return;
                            }
                            switch (s$1.b[b.ordinal()]) {
                                default: {
                                    throw new IllegalArgumentException("Illegal message type " + b + " received for request channel");
                                }
                                case 6: {
                                    if (e == null) {
                                        s$a.a(d, AdError$AdErrorType.LOAD, AdError$AdErrorCode.INTERNAL_ERROR, "adsLoaded message did not contain cue points.");
                                        return;
                                    }
                                    s$a.a(d, this.i, e.adCuePoints, e.internalCuePoints);
                                    return;
                                }
                                case 7: {
                                    s$a.a(d, AdError$AdErrorType.LOAD, e.errorCode, a(e.errorMessage, e.innerError));
                                    return;
                                }
                            }
                            break;
                        }
                        case 4: {
                            this.a(b, d, e);
                            return;
                        }
                        case 5: {
                            final s$c s$c = this.d.get(d);
                            if (s$c != null) {
                                s$c.a(b, e.translation);
                                return;
                            }
                            break;
                        }
                        case 6:
                        case 7: {
                            while (true) {
                                switch (s$1.b[b.ordinal()]) {
                                    default: {
                                        throw new IllegalArgumentException("Illegal message type " + b + " received for other channel");
                                    }
                                    case 1: {
                                        r$a r$a = r$a.b;
                                        while (true) {
                                            try {
                                                if (e.adUiStyle != null) {
                                                    r$a = r$a.valueOf(e.adUiStyle);
                                                }
                                                this.i = new u(e.adTimeUpdateMs, r$a);
                                                this.j = true;
                                                final long n = SystemClock.elapsedRealtime() - this.l;
                                                final HashMap<String, Long> hashMap = new HashMap<String, Long>();
                                                hashMap.put("webViewLoadingTime", n);
                                                this.b(new r(r$b.webViewLoaded, r$c.csi, d, hashMap));
                                                this.b();
                                                return;
                                                Label_1351: {
                                                    final String string;
                                                    Log.i(string, e.m);
                                                }
                                                return;
                                                final String string;
                                                Label_1373:
                                                Log.w(string, e.m);
                                                return;
                                                // iftrue(Label_1203:, e.ln != null && e.n != null && e.m != null)
                                                while (true) {
                                                    Log.e("IMASDK", "Invalid logging message data: " + e);
                                                    return;
                                                    Label_1292:
                                                    Log.w("IMASDK", "Unrecognized log level: " + e.ln);
                                                    Log.w(string, e.m);
                                                    return;
                                                    Label_1340:
                                                    Log.e(string, e.m);
                                                    return;
                                                    Label_1329:
                                                    Log.d(string, e.m);
                                                    return;
                                                    continue Label_1158_Outer;
                                                }
                                                Label_1203:
                                                string = "SDK_LOG:" + e.n;
                                                // switch([Lcom.strobel.decompiler.ast.Label;@61b14694, e.ln.charAt(0))
                                                Label_1362:
                                                Log.v(string, e.m);
                                                return;
                                            }
                                            catch (IllegalArgumentException ex) {
                                                continue Label_1158_Outer;
                                            }
                                            break;
                                        }
                                        break Label_1389;
                                    }
                                    case 2: {
                                        continue;
                                    }
                                }
                                break;
                            }
                            break;
                        }
                    }
                }
                return;
                switch (s$1.b[b.ordinal()]) {
                    case 13: {
                        return;
                    }
                    default: {
                        throw new IllegalArgumentException("Illegal message type " + b + " received for manager channel");
                    }
                    case 14: {
                        final s$b s$b;
                        final a adData;
                        if (adData != null) {
                            s$b.a(AdEvent$AdEventType.LOADED, adData);
                            return;
                        }
                        Log.e("IMASDK", "Ad loaded message requires adData");
                        s$b.a(AdError$AdErrorType.LOAD, AdError$AdErrorCode.INTERNAL_ERROR, "Ad loaded message did not contain adData.");
                        return;
                    }
                    case 15: {
                        final s$b s$b;
                        s$b.a(AdEvent$AdEventType.CONTENT_PAUSE_REQUESTED, null);
                        return;
                    }
                    case 16: {
                        final s$b s$b;
                        s$b.a(AdEvent$AdEventType.CONTENT_RESUME_REQUESTED, null);
                        return;
                    }
                    case 17: {
                        final s$b s$b;
                        final a adData;
                        s$b.a(AdEvent$AdEventType.COMPLETED, adData);
                        return;
                    }
                    case 18: {
                        final s$b s$b;
                        s$b.a(AdEvent$AdEventType.ALL_ADS_COMPLETED, null);
                        return;
                    }
                    case 19: {
                        final s$b s$b;
                        final a adData;
                        s$b.a(AdEvent$AdEventType.SKIPPED, adData);
                        return;
                    }
                    case 20: {
                        final s$b s$b;
                        final a adData;
                        s$b.a(AdEvent$AdEventType.STARTED, adData);
                        return;
                    }
                    case 9: {
                        final s$b s$b;
                        final a adData;
                        s$b.a(AdEvent$AdEventType.PAUSED, adData);
                        return;
                    }
                    case 21: {
                        final s$b s$b;
                        final a adData;
                        s$b.a(AdEvent$AdEventType.RESUMED, adData);
                        return;
                    }
                    case 22: {
                        final s$b s$b;
                        final a adData;
                        s$b.a(AdEvent$AdEventType.FIRST_QUARTILE, adData);
                        return;
                    }
                    case 23: {
                        final s$b s$b;
                        final a adData;
                        s$b.a(AdEvent$AdEventType.MIDPOINT, adData);
                        return;
                    }
                    case 24: {
                        final s$b s$b;
                        final a adData;
                        s$b.a(AdEvent$AdEventType.THIRD_QUARTILE, adData);
                        return;
                    }
                    case 25: {
                        final s$b s$b;
                        final a adData;
                        s$b.a(AdEvent$AdEventType.CLICKED, adData);
                        return;
                    }
                    case 7: {
                        final s$b s$b;
                        s$b.a(AdError$AdErrorType.PLAY, e.errorCode, a(e.errorMessage, e.innerError));
                        return;
                    }
                }
            }
            final a adData = null;
            continue;
        }
    }
    
    public final void a(final s$a s$a, final String s) {
        this.c.put(s, s$a);
    }
    
    public final void a(final s$b s$b, final String s) {
        this.b.put(s, s$b);
    }
    
    public final void a(final s$c s$c, final String s) {
        this.d.put(s, s$c);
    }
    
    public final void a(final String s) {
        this.d.remove(s);
    }
    
    public final void b(final r r) {
        this.k.add(r);
        this.b();
    }
    
    public final void b(final String s) {
        this.g.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(s)));
    }
}
