package com.google.ads.interactivemedia.v3.a;

final class f$1 implements j
{
    final /* synthetic */ f a;
    
    f$1(final f a) {
        this.a = a;
        super();
    }
}
