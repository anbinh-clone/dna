package com.google.ads.interactivemedia.v3.b;

public enum r$b
{
    adsLoader("adsLoader", 1), 
    adsManager("adsManager", 0), 
    contentTimeUpdate("contentTimeUpdate", 2), 
    displayContainer("displayContainer", 3), 
    i18n("i18n", 4), 
    log("log", 5), 
    videoDisplay("videoDisplay", 6), 
    webViewLoaded("webViewLoaded", 7);
    
    static {
        a = new r$b[] { r$b.adsManager, r$b.adsLoader, r$b.contentTimeUpdate, r$b.displayContainer, r$b.i18n, r$b.log, r$b.videoDisplay, r$b.webViewLoaded };
    }
}
