package com.google.ads.interactivemedia.v3.b.b;

public final class c
{
    public static int a(final int n, final float n2) {
        return (int)(0.5f + n2 * n);
    }
}
