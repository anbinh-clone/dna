package com.google.ads.interactivemedia.v3.a;

import java.io.Writer;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.io.IOException;
import java.io.EOFException;
import java.lang.reflect.Type;
import com.google.ads.interactivemedia.v3.a.b.a.h;
import com.google.ads.interactivemedia.v3.a.b.a.f;
import com.google.ads.interactivemedia.v3.a.b.a.i;
import com.google.ads.interactivemedia.v3.a.b.a.j;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.Collection;
import com.google.ads.interactivemedia.v3.a.b.a.g;
import com.google.ads.interactivemedia.v3.a.b.a.l;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;
import com.google.ads.interactivemedia.v3.a.b.d;
import java.util.List;
import java.util.Map;
import com.google.ads.interactivemedia.v3.a.d.c;
import com.google.ads.interactivemedia.v3.a.d.b;
import com.google.ads.interactivemedia.v3.a.d.a;

final class f$3 extends w
{
    final /* synthetic */ f a;
    
    f$3(final f a) {
        this.a = a;
        super();
    }
}
