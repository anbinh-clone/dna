package com.google.ads.interactivemedia.v3.b.a;

import java.util.Iterator;
import com.google.ads.interactivemedia.v3.api.CompanionAdSlot;
import java.util.HashMap;
import com.google.ads.interactivemedia.v3.b.a;
import com.google.ads.interactivemedia.v3.api.AdsRequest;
import com.google.ads.interactivemedia.v3.api.ImaSdkSettings;
import java.util.Map;

public final class d
{
    private String adTagUrl;
    private String adsResponse;
    private Map companionSlots;
    private String env;
    private Map extraParameters;
    private String network;
    private ImaSdkSettings settings;
    
    public d(final AdsRequest adsRequest, final String env, final String network, final ImaSdkSettings settings) {
        super();
        this.adTagUrl = adsRequest.getAdTagUrl();
        this.adsResponse = adsRequest.getAdsResponse();
        this.env = env;
        this.network = network;
        this.extraParameters = adsRequest.getExtraParameters();
        this.settings = settings;
        final Map a = ((a)adsRequest.getAdDisplayContainer()).a();
        if (a != null && !a.isEmpty()) {
            this.companionSlots = new HashMap();
            for (final String s : a.keySet()) {
                final CompanionAdSlot companionAdSlot = (CompanionAdSlot)a.get(s);
                this.companionSlots.put(s, companionAdSlot.getWidth() + "x" + companionAdSlot.getHeight());
            }
        }
    }
    
    @Override
    public final String toString() {
        String s = "adTagUrl=" + this.adTagUrl + ", env=" + this.env + ", network=" + this.network + ", companionSlots=" + this.companionSlots + ", extraParameters=" + this.extraParameters + ", settings=" + this.settings;
        if (this.adsResponse != null) {
            s = s + ", adsResponse=" + this.adsResponse;
        }
        return "GsonAdsRequest [" + s + "]";
    }
}
