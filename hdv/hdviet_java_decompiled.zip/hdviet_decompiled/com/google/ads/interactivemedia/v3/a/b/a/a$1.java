package com.google.ads.interactivemedia.v3.a.b.a;

import java.lang.reflect.Type;
import com.google.ads.interactivemedia.v3.a.b.b;
import java.lang.reflect.GenericArrayType;
import com.google.ads.interactivemedia.v3.a.w;
import com.google.ads.interactivemedia.v3.a.c.a;
import com.google.ads.interactivemedia.v3.a.f;
import com.google.ads.interactivemedia.v3.a.x;

final class a$1 implements x
{
    @Override
    public final w a(final f f, final a a) {
        final Type b = a.b();
        if (!(b instanceof GenericArrayType) && (!(b instanceof Class) || !((Class)b).isArray())) {
            return null;
        }
        final Type d = b.d(b);
        return new a(f, f.a(a.a(d)), b.b(d));
    }
}
