package com.google.ads;

import java.util.Date;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.content.Context;
import android.app.Activity;
import com.google.ads.internal.a;

public final class at
{
    private static final a a;
    
    static {
        a = (a)a.a.b();
    }
    
    public static void a(final Activity activity) {
        new Thread(new at$a(activity)).start();
    }
    
    public static boolean a(final Context context, final long n) {
        if (!a(context, n, PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext()))) {
            return false;
        }
        new Thread(new at$1(context)).start();
        return true;
    }
    
    static boolean a(final Context context, final long n, final SharedPreferences sharedPreferences) {
        return !sharedPreferences.contains("drt") || !sharedPreferences.contains("drt_ts") || sharedPreferences.getLong("drt_ts", 0L) < new Date().getTime() - n;
    }
}
