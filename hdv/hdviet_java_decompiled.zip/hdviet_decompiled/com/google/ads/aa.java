package com.google.ads;

import android.text.TextUtils;
import com.google.ads.util.b;
import com.google.ads.internal.ActivationOverlay;
import android.webkit.WebView;
import java.util.HashMap;
import com.google.ads.internal.d;

public class aa implements o
{
    @Override
    public void a(final d d, final HashMap hashMap, final WebView webView) {
        int int1 = -1;
        if (!(webView instanceof ActivationOverlay)) {
            b.b("Trying to activate an overlay when this is not an overlay.");
            return;
        }
        int int2;
        int int3;
        int int4;
        while (true) {
            while (true) {
                Label_0255: {
                    while (true) {
                        Label_0248: {
                            while (true) {
                                Label_0241: {
                                    try {
                                        if (TextUtils.isEmpty((CharSequence)hashMap.get("w"))) {
                                            break Label_0255;
                                        }
                                        int2 = Integer.parseInt(hashMap.get("w"));
                                        if (TextUtils.isEmpty((CharSequence)hashMap.get("h"))) {
                                            break Label_0248;
                                        }
                                        int3 = Integer.parseInt(hashMap.get("h"));
                                        if (TextUtils.isEmpty((CharSequence)hashMap.get("x"))) {
                                            break Label_0241;
                                        }
                                        int4 = Integer.parseInt(hashMap.get("x"));
                                        if (!TextUtils.isEmpty((CharSequence)hashMap.get("y"))) {
                                            int1 = Integer.parseInt(hashMap.get("y"));
                                        }
                                        if (hashMap.get("a") != null && hashMap.get("a").equals("1")) {
                                            d.a(null, true, int4, int1, int2, int3);
                                            return;
                                        }
                                    }
                                    catch (NumberFormatException ex) {
                                        b.d("Invalid number format in activation overlay response.", ex);
                                        return;
                                    }
                                    break;
                                }
                                int4 = int1;
                                continue;
                            }
                        }
                        int3 = int1;
                        continue;
                    }
                }
                int2 = int1;
                continue;
            }
        }
        if (hashMap.get("a") != null && hashMap.get("a").equals("0")) {
            d.a(null, false, int4, int1, int2, int3);
            return;
        }
        d.a(int4, int1, int2, int3);
    }
}
