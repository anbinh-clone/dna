package com.google.ads;

import com.google.ads.internal.g;
import android.content.Context;
import java.util.Locale;
import android.net.Uri;
import com.google.ads.util.b;
import android.webkit.WebView;
import java.util.HashMap;
import com.google.ads.internal.d;

public class r implements o
{
    @Override
    public void a(final d d, final HashMap hashMap, final WebView webView) {
        final String s = hashMap.get("u");
        if (s == null) {
            b.e("Could not get URL from click gmsg.");
            return;
        }
        final g n = d.n();
        if (n != null) {
            final Uri parse = Uri.parse(s);
            final String host = parse.getHost();
            if (host != null && host.toLowerCase(Locale.US).endsWith(".admob.com")) {
                final String path = parse.getPath();
                String string = null;
                if (path != null) {
                    final String[] split = path.split("/");
                    final int length = split.length;
                    string = null;
                    if (length >= 4) {
                        string = split[2] + "/" + split[3];
                    }
                }
                n.a(string);
            }
        }
        while (true) {
            final n i = d.i();
            final Context context = (Context)i.f.a();
            final Uri parse2 = Uri.parse(s);
            while (true) {
                try {
                    final al al = (al)i.s.a();
                    if (al != null && al.a(parse2)) {
                        final Uri a = al.a(parse2, context);
                        new Thread(new ae(a.toString(), context)).start();
                        return;
                    }
                }
                catch (am am) {
                    b.e("Unable to append parameter to URL: " + s);
                }
                final Uri a = parse2;
                continue;
            }
        }
    }
}
