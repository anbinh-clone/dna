package com.google.ads;

import com.google.ads.util.b;
import com.google.ads.internal.d;
import java.lang.ref.WeakReference;

public class af implements Runnable
{
    private WeakReference a;
    
    public af(final d d) {
        super();
        this.a = new WeakReference(d);
    }
    
    @Override
    public void run() {
        final d d = (d)this.a.get();
        if (d == null) {
            b.a("The ad must be gone, so cancelling the refresh timer.");
            return;
        }
        d.A();
    }
}
