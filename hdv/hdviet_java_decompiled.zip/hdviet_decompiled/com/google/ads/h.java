package com.google.ads;

import com.google.ads.util.b;
import com.google.ads.mediation.MediationInterstitialAdapter;
import android.os.Handler;
import android.app.Activity;
import com.google.ads.util.a;
import android.text.TextUtils;
import java.util.HashMap;
import android.view.View;
import com.google.ads.mediation.MediationAdapter;
import com.google.ads.internal.h;

public class h
{
    final h a;
    private final f b;
    private boolean c;
    private boolean d;
    private g$a e;
    private final e f;
    private MediationAdapter g;
    private boolean h;
    private boolean i;
    private View j;
    private final String k;
    private final AdRequest l;
    private final HashMap m;
    
    public h(final e f, final h a, final f b, final String k, final AdRequest l, final HashMap m) {
        super();
        a.b(TextUtils.isEmpty((CharSequence)k));
        this.f = f;
        this.a = a;
        this.b = b;
        this.k = k;
        this.l = l;
        this.m = m;
        this.c = false;
        this.d = false;
        this.e = null;
        this.g = null;
        this.h = false;
        this.i = false;
        this.j = null;
    }
    
    public f a() {
        return this.b;
    }
    
    public void a(final Activity activity) {
        synchronized (this) {
            a.b(this.h, "startLoadAdTask has already been called.");
            this.h = true;
            ((Handler)m.a().c.a()).post((Runnable)new i(this, activity, this.k, this.l, this.m));
        }
    }
    
    void a(final View j) {
        synchronized (this) {
            this.j = j;
        }
    }
    
    void a(final MediationAdapter g) {
        synchronized (this) {
            this.g = g;
        }
    }
    
    void a(final boolean d, final g$a e) {
        synchronized (this) {
            this.d = d;
            this.c = true;
            this.e = e;
            this.notify();
        }
    }
    
    public void b() {
        synchronized (this) {
            a.a(this.h, "destroy() called but startLoadAdTask has not been called.");
            ((Handler)m.a().c.a()).post((Runnable)new h$1(this));
        }
    }
    
    public boolean c() {
        synchronized (this) {
            return this.c;
        }
    }
    
    public boolean d() {
        synchronized (this) {
            a.a(this.c, "isLoadAdTaskSuccessful() called when isLoadAdTaskDone() is false.");
            return this.d;
        }
    }
    
    public g$a e() {
        synchronized (this) {
            g$a g$a;
            if (this.e == null) {
                g$a = g$a.d;
            }
            else {
                g$a = this.e;
            }
            return g$a;
        }
    }
    
    public View f() {
        synchronized (this) {
            a.a(this.c, "getAdView() called when isLoadAdTaskDone() is false.");
            return this.j;
        }
    }
    
    public void g() {
        synchronized (this) {
            a.a(this.a.a());
            try {
                ((Handler)m.a().c.a()).post((Runnable)new h$2(this, (MediationInterstitialAdapter)this.g));
            }
            catch (ClassCastException ex) {
                b.b("In Ambassador.show(): ambassador.adapter does not implement the MediationInterstitialAdapter interface.", ex);
            }
        }
    }
    
    public String h() {
        synchronized (this) {
            String name;
            if (this.g != null) {
                name = this.g.getClass().getName();
            }
            else {
                name = "\"adapter was not created.\"";
            }
            return name;
        }
    }
    
    MediationAdapter i() {
        synchronized (this) {
            return this.g;
        }
    }
    
    e j() {
        return this.f;
    }
    
    void k() {
        synchronized (this) {
            this.i = true;
        }
    }
    
    boolean l() {
        synchronized (this) {
            return this.i;
        }
    }
}
