package com.google.ads.searchads;

public enum SearchAdRequest$BorderType
{
    DASHED("DASHED", 1, "dashed"), 
    DOTTED("DOTTED", 2, "dotted"), 
    NONE("NONE", 0, "none"), 
    SOLID("SOLID", 3, "solid");
    
    private String a;
    
    static {
        b = new SearchAdRequest$BorderType[] { SearchAdRequest$BorderType.NONE, SearchAdRequest$BorderType.DASHED, SearchAdRequest$BorderType.DOTTED, SearchAdRequest$BorderType.SOLID };
    }
    
    private SearchAdRequest$BorderType(final String s, final int n, final String a) {
        this.a = a;
    }
    
    @Override
    public final String toString() {
        return this.a;
    }
}
