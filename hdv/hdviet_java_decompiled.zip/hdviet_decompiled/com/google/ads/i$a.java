package com.google.ads;

class i$a extends Exception
{
    public i$a(final String s) {
        super(s);
    }
}
