package com.google.ads;

import com.google.ads.util.i$c;
import com.google.ads.util.i;

public final class m$a extends i
{
    public final i$c a;
    public final i$c b;
    public final i$c c;
    public final i$c d;
    public final i$c e;
    public final i$c f;
    public final i$c g;
    public final i$c h;
    public final i$c i;
    public final i$c j;
    public final i$c k;
    public final i$c l;
    public final i$c m;
    public final i$c n;
    public final i$c o;
    
    public m$a() {
        super();
        this.a = new i$c(this, "ASDomains", (Object)null);
        this.b = new i$c(this, "minHwAccelerationVersionBanner", 18);
        this.c = new i$c(this, "minHwAccelerationVersionOverlay", 18);
        this.d = new i$c(this, "minHwAccelerationVersionOverlay", 14);
        this.e = new i$c(this, "mraidBannerPath", "http://media.admob.com/mraid/v1/mraid_app_banner.js");
        this.f = new i$c(this, "mraidExpandedBannerPath", "http://media.admob.com/mraid/v1/mraid_app_expanded_banner.js");
        this.g = new i$c(this, "mraidInterstitialPath", "http://media.admob.com/mraid/v1/mraid_app_interstitial.js");
        this.h = new i$c(this, "badAdReportPath", "https://badad.googleplex.com/s/reportAd");
        this.i = new i$c(this, "appCacheMaxSize", 0L);
        this.j = new i$c(this, "appCacheMaxSizePaddingInBytes", 131072L);
        this.k = new i$c(this, "maxTotalAppCacheQuotaInBytes", 5242880L);
        this.l = new i$c(this, "maxTotalDatabaseQuotaInBytes", 5242880L);
        this.m = new i$c(this, "maxDatabaseQuotaPerOriginInBytes", 1048576L);
        this.n = new i$c(this, "databaseQuotaIncreaseStepInBytes", 131072L);
        this.o = new i$c(this, "isInitialized", false);
    }
}
