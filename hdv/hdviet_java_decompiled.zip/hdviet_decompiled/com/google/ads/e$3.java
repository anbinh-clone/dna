package com.google.ads;

import java.util.Iterator;
import java.util.List;
import android.os.Handler;
import android.os.SystemClock;
import java.util.HashMap;
import android.app.Activity;
import com.google.ads.internal.h;
import com.google.ads.util.b;
import com.google.ads.util.a;
import com.google.ads.internal.d;
import android.view.View;

class e$3 implements Runnable
{
    final /* synthetic */ View a;
    final /* synthetic */ f b;
    final /* synthetic */ e c;
    
    e$3(final e c, final View a, final f b) {
        this.c = c;
        this.a = a;
        this.b = b;
        super();
    }
    
    @Override
    public void run() {
        this.c.a.a(this.a, this.c.b, this.b, true);
    }
}
