package com.google.ads.internal;

import com.google.ads.o;
import com.google.ads.util.AdUtil;
import a.a.c;
import android.webkit.WebView;
import com.google.ads.util.b;
import java.util.HashMap;
import android.net.Uri;
import java.util.Collections;
import java.util.Map;
import com.google.ads.util.f;

public class a
{
    public static final f a;
    public static final Map b;
    public static final Map c;
    public static final Map d;
    private static final a e;
    
    static {
        e = new a();
        a = new a$2();
        b = Collections.unmodifiableMap((Map<?, ?>)new a$3());
        c = Collections.unmodifiableMap((Map<?, ?>)new a$4());
        d = Collections.unmodifiableMap((Map<?, ?>)new a$1());
    }
    
    public String a(final Uri uri, final HashMap hashMap) {
        if (this.c(uri)) {
            final String host = uri.getHost();
            if (host == null) {
                b.e("An error occurred while parsing the AMSG parameters.");
                return null;
            }
            if (host.equals("launch")) {
                hashMap.put("a", "intent");
                hashMap.put("u", hashMap.get("url"));
                hashMap.remove("url");
                return "/open";
            }
            if (host.equals("closecanvas")) {
                return "/close";
            }
            if (host.equals("log")) {
                return "/log";
            }
            b.e("An error occurred while parsing the AMSG: " + uri.toString());
            return null;
        }
        else {
            if (this.b(uri)) {
                return uri.getPath();
            }
            b.e("Message was neither a GMSG nor an AMSG.");
            return null;
        }
    }
    
    public void a(final WebView webView) {
        this.a(webView, "onshow", "{'version': 'afma-sdk-a-v6.4.1'}");
    }
    
    public void a(final WebView webView, final String s) {
        b.a("Sending JS to a WebView: " + s);
        webView.loadUrl("javascript:" + s);
    }
    
    public void a(final WebView webView, final String s, final String s2) {
        if (s2 != null) {
            this.a(webView, "AFMA_ReceiveMessage" + "('" + s + "', " + s2 + ");");
            return;
        }
        this.a(webView, "AFMA_ReceiveMessage" + "('" + s + "');");
    }
    
    public void a(final WebView webView, final Map map) {
        this.a(webView, "openableURLs", new c(map).toString());
    }
    
    public void a(final d d, final Map map, final Uri uri, final WebView webView) {
        final HashMap b = AdUtil.b(uri);
        if (b == null) {
            b.e("An error occurred while parsing the message parameters.");
            return;
        }
        final String a = this.a(uri, b);
        if (a == null) {
            b.e("An error occurred while parsing the message.");
            return;
        }
        final o o = map.get(a);
        if (o == null) {
            b.e("No AdResponse found, <message: " + a + ">");
            return;
        }
        o.a(d, b, webView);
    }
    
    public boolean a(final Uri uri) {
        return uri != null && uri.isHierarchical() && (this.b(uri) || this.c(uri));
    }
    
    public void b(final WebView webView) {
        this.a(webView, "onhide", null);
    }
    
    public boolean b(final Uri uri) {
        final String scheme = uri.getScheme();
        if (scheme != null && scheme.equals("gmsg")) {
            final String authority = uri.getAuthority();
            if (authority != null && authority.equals("mobileads.google.com")) {
                return true;
            }
        }
        return false;
    }
    
    public boolean c(final Uri uri) {
        final String scheme = uri.getScheme();
        return scheme != null && scheme.equals("admob");
    }
}
