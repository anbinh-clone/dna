package com.google.ads.internal;

import java.io.IOException;
import com.google.ads.util.b;
import com.google.ads.m;
import com.google.ads.m$a;
import com.google.ads.util.AdUtil;
import java.net.URL;
import java.io.BufferedOutputStream;
import java.net.HttpURLConnection;
import android.content.Context;

public class j implements Runnable
{
    private String a;
    private Context b;
    
    public j(final String a, final Context b) {
        super();
        this.a = a;
        this.b = b;
    }
    
    protected BufferedOutputStream a(final HttpURLConnection httpURLConnection) {
        return new BufferedOutputStream(httpURLConnection.getOutputStream());
    }
    
    protected HttpURLConnection a(final URL url) {
        final HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setInstanceFollowRedirects(true);
        AdUtil.a(httpURLConnection, this.b);
        httpURLConnection.setRequestProperty("Accept", "application/json");
        httpURLConnection.setRequestProperty("Content-Type", "application/json");
        return httpURLConnection;
    }
    
    @Override
    public void run() {
        final String s = (String)((m$a)m.a().b.a()).h.a();
        try {
            final HttpURLConnection a = this.a(new URL(s));
            final byte[] bytes = new j$a(this.a).a().toString().getBytes();
            a.setFixedLengthStreamingMode(bytes.length);
            try {
                final BufferedOutputStream a2 = this.a(a);
                a2.write(bytes);
                a2.close();
                if (a.getResponseCode() != 200) {
                    b.b("Got error response from BadAd backend: " + a.getResponseMessage());
                }
            }
            finally {
                a.disconnect();
            }
        }
        catch (IOException ex) {
            b.b("Error reporting bad ad.", ex);
        }
    }
}
