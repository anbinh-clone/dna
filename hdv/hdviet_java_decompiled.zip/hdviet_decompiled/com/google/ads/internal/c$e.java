package com.google.ads.internal;

import android.util.DisplayMetrics;
import com.google.ads.m$a;
import android.telephony.TelephonyManager;
import android.content.pm.PackageManager$NameNotFoundException;
import java.util.HashMap;
import com.google.ads.AdView;
import com.google.ads.ai;
import com.google.ads.al;
import android.content.Context;
import com.google.ads.ak;
import android.text.TextUtils;
import com.google.ads.util.AdUtil;
import java.util.Map;
import com.google.ads.searchads.SearchAdRequest;
import com.google.ads.m;
import android.os.Handler;
import java.util.regex.Matcher;
import java.util.Locale;
import java.util.regex.Pattern;
import com.google.ads.d;
import com.google.ads.c;
import com.google.ads.util.b;
import android.webkit.WebViewClient;
import android.app.Activity;
import com.google.ads.AdRequest$ErrorCode;
import com.google.ads.l;
import com.google.ads.AdRequest;
import com.google.ads.n;
import com.google.ads.AdSize;
import java.util.LinkedList;
import android.webkit.WebView;

class c$e implements Runnable
{
    final /* synthetic */ c a;
    private final d b;
    private final WebView c;
    private final LinkedList d;
    private final int e;
    private final boolean f;
    private final String g;
    private final AdSize h;
    
    public c$e(final c a, final d b, final WebView c, final LinkedList d, final int e, final boolean f, final String g, final AdSize h) {
        this.a = a;
        super();
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
    }
    
    @Override
    public void run() {
        if (this.c != null) {
            this.c.stopLoading();
            this.c.destroy();
        }
        this.b.a(this.d);
        this.b.a(this.e);
        this.b.a(this.f);
        this.b.a(this.g);
        if (this.h != null) {
            ((h)((n)this.a.j.a.a()).g.a()).b(this.h);
            this.b.l().setAdSize(this.h);
        }
        this.b.E();
    }
}
