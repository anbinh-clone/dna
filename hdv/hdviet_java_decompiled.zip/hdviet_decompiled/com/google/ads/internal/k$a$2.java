package com.google.ads.internal;

import java.util.Iterator;
import java.util.ArrayList;
import android.content.Context;
import android.app.AlertDialog$Builder;
import com.google.ads.util.b;
import android.gesture.Prediction;
import android.gesture.Gesture;
import android.gesture.GestureOverlayView;
import android.app.Activity;
import android.gesture.GestureStore;
import android.gesture.GestureOverlayView$OnGesturePerformedListener;
import android.content.DialogInterface;
import android.content.DialogInterface$OnClickListener;

class k$a$2 implements DialogInterface$OnClickListener
{
    final /* synthetic */ k$a a;
    
    k$a$2(final k$a a) {
        this.a = a;
        super();
    }
    
    public void onClick(final DialogInterface dialogInterface, final int n) {
        new Thread(new j(this.a.c.d(), this.a.b.getApplicationContext())).start();
    }
}
