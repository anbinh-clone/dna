package com.google.ads.internal;

import com.google.ads.util.b;

public final class b extends Exception
{
    public final boolean a;
    
    public b(final String s, final boolean a) {
        super(s);
        this.a = a;
    }
    
    public b(final String s, final boolean a, final Throwable t) {
        super(s, t);
        this.a = a;
    }
    
    public final void a(final String s) {
        b.b(this.c(s));
        b.a(null, this);
    }
    
    public final void b(final String s) {
        final String c = this.c(s);
        final Throwable t;
        if (!this.a) {
            t = null;
        }
        throw new RuntimeException(c, t);
    }
    
    public final String c(String string) {
        if (this.a) {
            string = string + ": " + this.getMessage();
        }
        return string;
    }
}
