package com.google.ads.internal;

import com.google.ads.AdActivity;
import android.content.ActivityNotFoundException;
import com.google.ads.util.b;
import android.content.Context;
import com.google.ads.util.AdUtil;
import android.net.Uri;
import android.content.Intent;
import android.webkit.DownloadListener;

class AdWebView$1 implements DownloadListener
{
    final /* synthetic */ AdWebView a;
    
    AdWebView$1(final AdWebView a) {
        this.a = a;
        super();
    }
    
    public void onDownloadStart(final String s, final String s2, final String s3, final String s4, final long n) {
        try {
            final Intent intent = new Intent("android.intent.action.VIEW");
            intent.setDataAndType(Uri.parse(s), s4);
            final AdActivity i = this.a.i();
            if (i != null && AdUtil.a(intent, (Context)i)) {
                i.startActivity(intent);
            }
        }
        catch (ActivityNotFoundException ex) {
            b.a("Couldn't find an Activity to view url/mimetype: " + s + " / " + s4);
        }
        catch (Throwable t) {
            b.b("Unknown error trying to start activity to view URL: " + s, t);
        }
    }
}
