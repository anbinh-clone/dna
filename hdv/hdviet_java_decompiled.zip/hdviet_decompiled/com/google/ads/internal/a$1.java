package com.google.ads.internal;

import com.google.ads.ac;
import com.google.ads.ab;
import com.google.ads.u;
import com.google.ads.r;
import com.google.ads.y;
import com.google.ads.p;
import com.google.ads.t;
import com.google.ads.s;
import com.google.ads.q;
import com.google.ads.z;
import java.util.HashMap;

final class a$1 extends HashMap
{
    a$1() {
        super();
        this.put("/open", new z());
        this.put("/canOpenURLs", new q());
        this.put("/close", new s());
        this.put("/customClose", new t());
        this.put("/appEvent", new p());
        this.put("/log", new y());
        this.put("/click", new r());
        this.put("/httpTrack", new u());
        this.put("/touch", new ab());
        this.put("/video", new ac());
    }
}
