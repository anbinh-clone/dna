package com.google.ads.internal;

import android.content.DialogInterface;
import android.content.DialogInterface$OnClickListener;

class k$a$1 implements DialogInterface$OnClickListener
{
    final /* synthetic */ k$a a;
    
    k$a$1(final k$a a) {
        this.a = a;
        super();
    }
    
    public void onClick(final DialogInterface dialogInterface, final int n) {
    }
}
