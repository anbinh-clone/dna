package com.google.ads.internal;

import com.google.ads.util.b;
import android.media.MediaPlayer;
import android.webkit.WebView;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.ViewGroup$LayoutParams;
import android.view.View;
import android.widget.FrameLayout$LayoutParams;
import android.content.Context;
import android.app.Activity;
import android.widget.VideoView;
import java.lang.ref.WeakReference;
import android.widget.MediaController;
import android.media.MediaPlayer$OnPreparedListener;
import android.media.MediaPlayer$OnErrorListener;
import android.media.MediaPlayer$OnCompletionListener;
import android.widget.FrameLayout;

public class AdVideoView extends FrameLayout implements MediaPlayer$OnCompletionListener, MediaPlayer$OnErrorListener, MediaPlayer$OnPreparedListener
{
    private static final a b;
    public MediaController a;
    private final WeakReference c;
    private final AdWebView d;
    private long e;
    private final VideoView f;
    private String g;
    
    static {
        b = (a)a.a.b();
    }
    
    public AdVideoView(final Activity activity, final AdWebView d) {
        super((Context)activity);
        this.c = new WeakReference(activity);
        this.d = d;
        this.addView((View)(this.f = new VideoView((Context)activity)), (ViewGroup$LayoutParams)new FrameLayout$LayoutParams(-1, -1, 17));
        this.a = null;
        this.g = null;
        this.e = 0L;
        this.a();
        this.f.setOnCompletionListener((MediaPlayer$OnCompletionListener)this);
        this.f.setOnPreparedListener((MediaPlayer$OnPreparedListener)this);
        this.f.setOnErrorListener((MediaPlayer$OnErrorListener)this);
    }
    
    protected void a() {
        new AdVideoView$a(this).a();
    }
    
    public void a(final int n) {
        this.f.seekTo(n);
    }
    
    public void a(final MotionEvent motionEvent) {
        this.f.onTouchEvent(motionEvent);
    }
    
    public void b() {
        if (!TextUtils.isEmpty((CharSequence)this.g)) {
            this.f.setVideoPath(this.g);
            return;
        }
        AdVideoView.b.a(this.d, "onVideoEvent", "{'event': 'error', 'what': 'no_src'}");
    }
    
    public void c() {
        this.f.pause();
    }
    
    public void d() {
        this.f.start();
    }
    
    public void e() {
        this.f.stopPlayback();
    }
    
    void f() {
        final long e = this.f.getCurrentPosition();
        if (this.e != e) {
            AdVideoView.b.a(this.d, "onVideoEvent", "{'event': 'timeupdate', 'time': " + e / 1000.0f + "}");
            this.e = e;
        }
    }
    
    public void onCompletion(final MediaPlayer mediaPlayer) {
        AdVideoView.b.a(this.d, "onVideoEvent", "{'event': 'ended'}");
    }
    
    public boolean onError(final MediaPlayer mediaPlayer, final int n, final int n2) {
        b.e("Video threw error! <what:" + n + ", extra:" + n2 + ">");
        AdVideoView.b.a(this.d, "onVideoEvent", "{'event': 'error', 'what': '" + n + "', 'extra': '" + n2 + "'}");
        return true;
    }
    
    public void onPrepared(final MediaPlayer mediaPlayer) {
        AdVideoView.b.a(this.d, "onVideoEvent", "{'event': 'canplaythrough', 'duration': '" + this.f.getDuration() / 1000.0f + "'}");
    }
    
    public void setMediaControllerEnabled(final boolean b) {
        final Activity activity = (Activity)this.c.get();
        if (activity == null) {
            b.e("adActivity was null while trying to enable controls on a video.");
            return;
        }
        if (b) {
            if (this.a == null) {
                this.a = new MediaController((Context)activity);
            }
            this.f.setMediaController(this.a);
            return;
        }
        if (this.a != null) {
            this.a.hide();
        }
        this.f.setMediaController((MediaController)null);
    }
    
    public void setSrc(final String g) {
        this.g = g;
    }
}
