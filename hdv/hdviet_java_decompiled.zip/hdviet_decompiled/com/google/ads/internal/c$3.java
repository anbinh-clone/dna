package com.google.ads.internal;

class c$3
{
    static {
        a = new int[c$d.values().length];
        while (true) {
            try {
                c$3.a[c$d.b.ordinal()] = 1;
                try {
                    c$3.a[c$d.a.ordinal()] = 2;
                    try {
                        c$3.a[c$d.c.ordinal()] = 3;
                        try {
                            c$3.a[c$d.d.ordinal()] = 4;
                        }
                        catch (NoSuchFieldError noSuchFieldError) {}
                    }
                    catch (NoSuchFieldError noSuchFieldError2) {}
                }
                catch (NoSuchFieldError noSuchFieldError3) {}
            }
            catch (NoSuchFieldError noSuchFieldError4) {
                continue;
            }
            break;
        }
    }
}
