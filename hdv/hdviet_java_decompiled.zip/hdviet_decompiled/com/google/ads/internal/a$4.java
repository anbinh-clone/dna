package com.google.ads.internal;

import com.google.ads.aa;
import com.google.ads.y;
import java.util.HashMap;

final class a$4 extends HashMap
{
    a$4() {
        super();
        this.put("/log", new y());
        this.put("/setNativeActivationOverlay", new aa());
    }
}
