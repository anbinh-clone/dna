package com.google.ads.internal;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import android.util.DisplayMetrics;
import com.google.ads.m$a;
import android.telephony.TelephonyManager;
import android.content.pm.PackageManager$NameNotFoundException;
import java.util.HashMap;
import com.google.ads.AdView;
import com.google.ads.ai;
import com.google.ads.al;
import android.content.Context;
import com.google.ads.ak;
import android.text.TextUtils;
import com.google.ads.util.AdUtil;
import java.util.Map;
import com.google.ads.searchads.SearchAdRequest;
import com.google.ads.m;
import android.os.Handler;
import java.util.regex.Matcher;
import java.util.Locale;
import java.util.regex.Pattern;
import com.google.ads.d;
import com.google.ads.c;
import com.google.ads.util.b;
import android.webkit.WebViewClient;
import com.google.ads.n;
import android.app.Activity;
import com.google.ads.AdRequest$ErrorCode;
import com.google.ads.AdSize;
import java.util.LinkedList;
import com.google.ads.l;
import android.webkit.WebView;
import com.google.ads.AdRequest;

public class c implements Runnable
{
    boolean a;
    private String b;
    private String c;
    private String d;
    private String e;
    private boolean f;
    private f g;
    private AdRequest h;
    private WebView i;
    private l j;
    private String k;
    private String l;
    private LinkedList m;
    private String n;
    private AdSize o;
    private boolean p;
    private volatile boolean q;
    private boolean r;
    private AdRequest$ErrorCode s;
    private boolean t;
    private int u;
    private Thread v;
    private boolean w;
    private c$d x;
    
    protected c() {
        super();
        this.p = false;
        this.x = c$d.b;
    }
    
    public c(final l j) {
        super();
        this.p = false;
        this.x = c$d.b;
        this.j = j;
        this.k = null;
        this.b = null;
        this.c = null;
        this.d = null;
        this.m = new LinkedList();
        this.s = null;
        this.t = false;
        this.u = -1;
        this.f = false;
        this.r = false;
        this.n = null;
        this.o = null;
        if (((n)j.a.a()).c.a() != null) {
            (this.i = new AdWebView((n)j.a.a(), null)).setWebViewClient((WebViewClient)i.a((d)((n)j.a.a()).b.a(), a.b, false, false));
            this.i.setVisibility(8);
            this.i.setWillNotDraw(true);
            this.g = new f(j);
            return;
        }
        this.i = null;
        this.g = null;
        b.e("activity was null while trying to create an AdLoader.");
    }
    
    static void a(final String s, final c c, final d d) {
        if (s != null && !s.contains("no-store") && !s.contains("no-cache")) {
            final Matcher matcher = Pattern.compile("max-age\\s*=\\s*(\\d+)").matcher(s);
            if (matcher.find()) {
                try {
                    final int int1 = Integer.parseInt(matcher.group(1));
                    d.a(c, int1);
                    b.c(String.format(Locale.US, "Caching gWhirl configuration for: %d seconds", int1));
                    return;
                }
                catch (NumberFormatException ex) {
                    b.b("Caught exception trying to parse cache control directive. Overflow?", ex);
                    return;
                }
            }
            b.c("Unrecognized cacheControlDirective: '" + s + "'. Not caching configuration.");
        }
    }
    
    private void b(final String s, final String s2) {
        ((Handler)m.a().c.a()).post((Runnable)new c$c(this, this.i, s2, s));
    }
    
    private String d() {
        if (this.h instanceof SearchAdRequest) {
            return "AFMA_buildAdURL";
        }
        return "AFMA_buildAdURL";
    }
    
    private String e() {
        if (this.h instanceof SearchAdRequest) {
            return "AFMA_getSdkConstants();";
        }
        return "AFMA_getSdkConstants();";
    }
    
    private String f() {
        if (this.h instanceof SearchAdRequest) {
            return "http://www.gstatic.com/safa/";
        }
        return "http://media.admob.com/";
    }
    
    private String g() {
        if (this.h instanceof SearchAdRequest) {
            return "<html><head><script src=\"http://www.gstatic.com/safa/sdk-core-v40.js\"></script><script>";
        }
        return "<html><head><script src=\"http://media.admob.com/sdk-core-v40.js\"></script><script>";
    }
    
    private String h() {
        if (this.h instanceof SearchAdRequest) {
            return "</script></head><body></body></html>";
        }
        return "</script></head><body></body></html>";
    }
    
    private void i() {
        final AdWebView l = ((d)((n)this.j.a.a()).b.a()).l();
        ((d)((n)this.j.a.a()).b.a()).m().c(true);
        ((d)((n)this.j.a.a()).b.a()).n().h();
        ((Handler)m.a().c.a()).post((Runnable)new c$c(this, l, this.b, this.c));
    }
    
    private void j() {
        ((Handler)m.a().c.a()).post((Runnable)new c$e(this, (d)((n)this.j.a.a()).b.a(), this.i, this.m, this.u, this.r, this.n, this.o));
    }
    
    public String a(final Map map, final Activity activity) {
        int i = 0;
        final Context applicationContext = activity.getApplicationContext();
        final g n = ((d)((n)this.j.a.a()).b.a()).n();
        final long m = n.m();
        if (m > 0L) {
            map.put("prl", m);
        }
        final long n2 = n.n();
        if (n2 > 0L) {
            map.put("prnl", n2);
        }
        final String l = n.l();
        if (l != null) {
            map.put("ppcl", l);
        }
        final String k = n.k();
        if (k != null) {
            map.put("pcl", k);
        }
        final long j = n.j();
        if (j > 0L) {
            map.put("pcc", j);
        }
        map.put("preqs", n.o());
        map.put("oar", n.p());
        map.put("bas_on", n.s());
        map.put("bas_off", n.v());
        if (n.y()) {
            map.put("aoi_timeout", "true");
        }
        if (n.A()) {
            map.put("aoi_nofill", "true");
        }
        final String d = n.D();
        if (d != null) {
            map.put("pit", d);
        }
        map.put("ptime", g.E());
        n.a();
        n.i();
        Label_1224: {
            if (!((n)this.j.a.a()).b()) {
                break Label_1224;
            }
            map.put("format", "interstitial_mb");
        Label_1001_Outer:
            while (true) {
                map.put("slotname", ((n)this.j.a.a()).h.a());
                map.put("js", "afma-sdk-a-v6.4.1");
                final String packageName = applicationContext.getPackageName();
                int versionCode;
                String f;
                String s;
                String d2;
                String e;
                DisplayMetrics a;
                n n3;
                ak a2;
                AdView adView;
                int[] array;
                int n4;
                int n5;
                DisplayMetrics displayMetrics;
                int widthPixels;
                int heightPixels;
                int n6;
                HashMap<String, Integer> hashMap;
                StringBuilder sb = null;
                AdSize[] array2;
                AdSize adSize;
                HashMap<String, Integer> hashMap2;
                AdSize c;
                Label_1395:Label_1293_Outer:
                while (true) {
                    Label_1814: {
                        try {
                            versionCode = applicationContext.getPackageManager().getPackageInfo(packageName, 0).versionCode;
                            f = AdUtil.f(applicationContext);
                            if (!TextUtils.isEmpty((CharSequence)f)) {
                                map.put("mv", f);
                            }
                            s = (String)m.a().a.a();
                            if (!TextUtils.isEmpty((CharSequence)s)) {
                                map.put("imbf", s);
                            }
                            map.put("msid", applicationContext.getPackageName());
                            map.put("app_name", versionCode + ".android." + applicationContext.getPackageName());
                            map.put("isu", AdUtil.a(applicationContext));
                            d2 = AdUtil.d(applicationContext);
                            if (d2 == null) {
                                d2 = "null";
                            }
                            map.put("net", d2);
                            e = AdUtil.e(applicationContext);
                            if (e != null && e.length() != 0) {
                                map.put("cap", e);
                            }
                            map.put("u_audio", AdUtil.g(applicationContext).ordinal());
                            a = AdUtil.a(activity);
                            map.put("u_sd", a.density);
                            map.put("u_h", AdUtil.a(applicationContext, a));
                            map.put("u_w", AdUtil.b(applicationContext, a));
                            map.put("hl", Locale.getDefault().getLanguage());
                            n3 = (n)this.j.a.a();
                            a2 = (ak)n3.r.a();
                            if (a2 == null) {
                                a2 = ak.a("afma-sdk-a-v6.4.1", (Context)activity);
                                n3.r.a(a2);
                                n3.s.a(new al(a2));
                            }
                            map.put("ms", a2.a(applicationContext));
                            if (((n)this.j.a.a()).j != null && ((n)this.j.a.a()).j.a() != null) {
                                adView = (AdView)((n)this.j.a.a()).j.a();
                                if (adView.getParent() != null) {
                                    array = new int[2];
                                    adView.getLocationOnScreen(array);
                                    n4 = array[0];
                                    n5 = array[1];
                                    displayMetrics = ((Context)((n)this.j.a.a()).f.a()).getResources().getDisplayMetrics();
                                    widthPixels = displayMetrics.widthPixels;
                                    heightPixels = displayMetrics.heightPixels;
                                    if (!adView.isShown() || n4 + adView.getWidth() <= 0 || n5 + adView.getHeight() <= 0 || n4 > widthPixels || n5 > heightPixels) {
                                        break Label_1814;
                                    }
                                    n6 = 1;
                                    hashMap = new HashMap<String, Integer>();
                                    hashMap.put("x", n4);
                                    hashMap.put("y", n5);
                                    hashMap.put("width", adView.getWidth());
                                    hashMap.put("height", adView.getHeight());
                                    hashMap.put("visible", n6);
                                    map.put("ad_pos", hashMap);
                                }
                            }
                            sb = new StringBuilder();
                            array2 = (AdSize[])((n)this.j.a.a()).n.a();
                            if (array2 != null) {
                                while (i < array2.length) {
                                    adSize = array2[i];
                                    if (sb.length() != 0) {
                                        sb.append("|");
                                    }
                                    sb.append(adSize.getWidth() + "x" + adSize.getHeight());
                                    ++i;
                                }
                                break Label_1395;
                            }
                            break;
                            Label_1319: {
                                hashMap2 = new HashMap<String, Integer>();
                            }
                            hashMap2.put("w", c.getWidth());
                            hashMap2.put("h", c.getHeight());
                            map.put("ad_frame", hashMap2);
                            continue Label_1001_Outer;
                            // iftrue(Label_1293:, !c.isAutoHeight())
                            // iftrue(Label_1272:, !c.isFullWidth())
                            // iftrue(Label_1319:, c.isCustomAdSize())
                        Block_36:
                            while (true) {
                                Block_35: {
                                    while (true) {
                                        map.put("smart_w", "full");
                                        Label_1272:
                                        break Block_35;
                                        c = ((h)((n)this.j.a.a()).g.a()).c();
                                        continue Label_1293_Outer;
                                    }
                                    break Block_36;
                                }
                                map.put("smart_h", "auto");
                                continue;
                            }
                            map.put("format", c.toString());
                            continue Label_1001_Outer;
                        }
                        catch (PackageManager$NameNotFoundException ex) {
                            throw new c$b(this, "NameNotFoundException");
                        }
                        break Label_1395;
                    }
                    n6 = 0;
                    continue;
                }
                map.put("sz", sb.toString());
                break;
            }
        }
        final TelephonyManager telephonyManager = (TelephonyManager)applicationContext.getSystemService("phone");
        final String networkOperator = telephonyManager.getNetworkOperator();
        if (!TextUtils.isEmpty((CharSequence)networkOperator)) {
            map.put("carrier", networkOperator);
        }
        map.put("pt", telephonyManager.getPhoneType());
        map.put("gnt", telephonyManager.getNetworkType());
        if (AdUtil.c()) {
            map.put("simulator", 1);
        }
        map.put("session_id", com.google.ads.b.a().b().toString());
        map.put("seq_num", com.google.ads.b.a().c().toString());
        if (((h)((n)this.j.a.a()).g.a()).b()) {
            map.put("swipeable", 1);
        }
        if (((n)this.j.a.a()).t.a()) {
            map.put("d_imp_hdr", 1);
        }
        final String a3 = AdUtil.a(map);
        String s2;
        if (((m$a)((m)((n)this.j.a.a()).d.a()).b.a()).o.a()) {
            s2 = this.g() + this.d() + "(" + a3 + ");" + this.h();
        }
        else {
            s2 = this.g() + this.e() + this.d() + "(" + a3 + ");" + this.h();
        }
        b.c("adRequestUrlHtml: " + s2);
        return s2;
    }
    
    protected void a() {
        b.a("AdLoader cancelled.");
        if (this.i != null) {
            this.i.stopLoading();
            this.i.destroy();
        }
        if (this.v != null) {
            this.v.interrupt();
            this.v = null;
        }
        if (this.g != null) {
            this.g.a();
        }
        this.q = true;
    }
    
    public void a(final int u) {
        synchronized (this) {
            this.u = u;
        }
    }
    
    public void a(final AdRequest$ErrorCode s) {
        synchronized (this) {
            this.s = s;
            this.notify();
        }
    }
    
    protected void a(final AdRequest$ErrorCode adRequest$ErrorCode, final boolean b) {
        ((Handler)m.a().c.a()).post((Runnable)new c$a((d)((n)this.j.a.a()).b.a(), this.i, this.g, adRequest$ErrorCode, b));
    }
    
    protected void a(final AdRequest h) {
        this.h = h;
        this.q = false;
        (this.v = new Thread(this)).start();
    }
    
    public void a(final AdSize o) {
        synchronized (this) {
            this.o = o;
        }
    }
    
    public void a(final c$d x) {
        synchronized (this) {
            this.x = x;
        }
    }
    
    protected void a(final String s) {
        synchronized (this) {
            this.m.add(s);
        }
    }
    
    protected void a(final String c, final String b) {
        synchronized (this) {
            this.b = b;
            this.c = c;
            this.notify();
        }
    }
    
    public void a(final boolean p) {
        synchronized (this) {
            this.p = p;
        }
    }
    
    protected void b() {
        try {
            if (TextUtils.isEmpty((CharSequence)this.e)) {
                b.b("Got a mediation response with no content type. Aborting mediation.");
                this.a(AdRequest$ErrorCode.INTERNAL_ERROR, false);
                return;
            }
            if (!this.e.startsWith("application/json")) {
                b.b("Got a mediation response with a content type: '" + this.e + "'. Expected something starting with 'application/json'. Aborting mediation.");
                this.a(AdRequest$ErrorCode.INTERNAL_ERROR, false);
                return;
            }
        }
        catch (a.a.b b) {
            b.b("AdLoader can't parse gWhirl server configuration.", b);
            this.a(AdRequest$ErrorCode.INTERNAL_ERROR, false);
            return;
        }
        final c a = c.a(this.c);
        a(this.d, a, ((d)((n)this.j.a.a()).b.a()).j());
        ((Handler)m.a().c.a()).post((Runnable)new c$2(this, a));
    }
    
    protected void b(final String e) {
        synchronized (this) {
            this.e = e;
        }
    }
    
    protected void b(final boolean f) {
        synchronized (this) {
            this.f = f;
        }
    }
    
    protected void c() {
        synchronized (this) {
            this.t = true;
            this.notify();
        }
    }
    
    protected void c(final String d) {
        synchronized (this) {
            this.d = d;
        }
    }
    
    public void c(final boolean r) {
        synchronized (this) {
            this.r = r;
        }
    }
    
    public void d(final String k) {
        synchronized (this) {
            this.k = k;
            this.notify();
        }
    }
    
    public void d(final boolean w) {
        synchronized (this) {
            this.w = w;
        }
    }
    
    public void e(final String l) {
        synchronized (this) {
            this.l = l;
        }
    }
    
    public void e(final boolean a) {
        synchronized (this) {
            this.a = a;
        }
    }
    
    public void f(final String n) {
        synchronized (this) {
            this.n = n;
        }
    }
    
    @Override
    public void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: aload_0        
        //     1: monitorenter   
        //     2: aload_0        
        //     3: getfield        com/google/ads/internal/c.i:Landroid/webkit/WebView;
        //     6: ifnull          16
        //     9: aload_0        
        //    10: getfield        com/google/ads/internal/c.g:Lcom/google/ads/internal/f;
        //    13: ifnonnull       33
        //    16: ldc_w           "adRequestWebView was null while trying to load an ad."
        //    19: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //    22: aload_0        
        //    23: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //    26: iconst_0       
        //    27: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //    30: aload_0        
        //    31: monitorexit    
        //    32: return         
        //    33: aload_0        
        //    34: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //    37: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //    40: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //    43: checkcast       Lcom/google/ads/n;
        //    46: getfield        com/google/ads/n.c:Lcom/google/ads/util/i$d;
        //    49: invokevirtual   com/google/ads/util/i$d.a:()Ljava/lang/Object;
        //    52: checkcast       Landroid/app/Activity;
        //    55: astore_3       
        //    56: aload_3        
        //    57: ifnonnull       82
        //    60: ldc_w           "activity was null while forming an ad request."
        //    63: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //    66: aload_0        
        //    67: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //    70: iconst_0       
        //    71: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //    74: aload_0        
        //    75: monitorexit    
        //    76: return         
        //    77: astore_2       
        //    78: aload_0        
        //    79: monitorexit    
        //    80: aload_2        
        //    81: athrow         
        //    82: aload_0        
        //    83: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //    86: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //    89: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //    92: checkcast       Lcom/google/ads/n;
        //    95: getfield        com/google/ads/n.b:Lcom/google/ads/util/i$b;
        //    98: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   101: checkcast       Lcom/google/ads/internal/d;
        //   104: invokevirtual   com/google/ads/internal/d.p:()J
        //   107: lstore          4
        //   109: invokestatic    android/os/SystemClock.elapsedRealtime:()J
        //   112: lstore          6
        //   114: aload_0        
        //   115: getfield        com/google/ads/internal/c.h:Lcom/google/ads/AdRequest;
        //   118: aload_0        
        //   119: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //   122: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //   125: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   128: checkcast       Lcom/google/ads/n;
        //   131: getfield        com/google/ads/n.f:Lcom/google/ads/util/i$b;
        //   134: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   137: checkcast       Landroid/content/Context;
        //   140: invokevirtual   com/google/ads/AdRequest.getRequestMap:(Landroid/content/Context;)Ljava/util/Map;
        //   143: astore          8
        //   145: aload           8
        //   147: ldc_w           "extras"
        //   150: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   155: astore          9
        //   157: aload           9
        //   159: instanceof      Ljava/util/Map;
        //   162: ifeq            351
        //   165: aload           9
        //   167: checkcast       Ljava/util/Map;
        //   170: astore          31
        //   172: aload           31
        //   174: ldc_w           "_adUrl"
        //   177: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   182: astore          32
        //   184: aload           32
        //   186: instanceof      Ljava/lang/String;
        //   189: ifeq            201
        //   192: aload_0        
        //   193: aload           32
        //   195: checkcast       Ljava/lang/String;
        //   198: putfield        com/google/ads/internal/c.b:Ljava/lang/String;
        //   201: aload           31
        //   203: ldc_w           "_requestUrl"
        //   206: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   211: astore          33
        //   213: aload           33
        //   215: instanceof      Ljava/lang/String;
        //   218: ifeq            230
        //   221: aload_0        
        //   222: aload           33
        //   224: checkcast       Ljava/lang/String;
        //   227: putfield        com/google/ads/internal/c.k:Ljava/lang/String;
        //   230: aload           31
        //   232: ldc_w           "_activationOverlayUrl"
        //   235: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   240: astore          34
        //   242: aload           34
        //   244: instanceof      Ljava/lang/String;
        //   247: ifeq            259
        //   250: aload_0        
        //   251: aload           34
        //   253: checkcast       Ljava/lang/String;
        //   256: putfield        com/google/ads/internal/c.l:Ljava/lang/String;
        //   259: aload           31
        //   261: ldc_w           "_orientation"
        //   264: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   269: astore          35
        //   271: aload           35
        //   273: instanceof      Ljava/lang/String;
        //   276: ifeq            295
        //   279: aload           35
        //   281: ldc_w           "p"
        //   284: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   287: ifeq            430
        //   290: aload_0        
        //   291: iconst_1       
        //   292: putfield        com/google/ads/internal/c.u:I
        //   295: aload           31
        //   297: ldc_w           "_norefresh"
        //   300: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   305: astore          36
        //   307: aload           36
        //   309: instanceof      Ljava/lang/String;
        //   312: ifeq            351
        //   315: aload           36
        //   317: ldc_w           "t"
        //   320: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   323: ifeq            351
        //   326: aload_0        
        //   327: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //   330: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //   333: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   336: checkcast       Lcom/google/ads/n;
        //   339: getfield        com/google/ads/n.b:Lcom/google/ads/util/i$b;
        //   342: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   345: checkcast       Lcom/google/ads/internal/d;
        //   348: invokevirtual   com/google/ads/internal/d.e:()V
        //   351: aload_0        
        //   352: getfield        com/google/ads/internal/c.b:Ljava/lang/String;
        //   355: ifnonnull       1564
        //   358: aload_0        
        //   359: getfield        com/google/ads/internal/c.k:Ljava/lang/String;
        //   362: astore          14
        //   364: aload           14
        //   366: ifnonnull       647
        //   369: aload_0        
        //   370: aload           8
        //   372: aload_3        
        //   373: invokevirtual   com/google/ads/internal/c.a:(Ljava/util/Map;Landroid/app/Activity;)Ljava/lang/String;
        //   376: astore          24
        //   378: aload_0        
        //   379: aload           24
        //   381: aload_0        
        //   382: invokespecial   com/google/ads/internal/c.f:()Ljava/lang/String;
        //   385: invokespecial   com/google/ads/internal/c.b:(Ljava/lang/String;Ljava/lang/String;)V
        //   388: invokestatic    android/os/SystemClock.elapsedRealtime:()J
        //   391: lstore          25
        //   393: lload           4
        //   395: lload           25
        //   397: lload           6
        //   399: lsub           
        //   400: lsub           
        //   401: lstore          27
        //   403: lload           27
        //   405: lconst_0       
        //   406: lcmp           
        //   407: ifle            416
        //   410: aload_0        
        //   411: lload           27
        //   413: invokevirtual   java/lang/Object.wait:(J)V
        //   416: aload_0        
        //   417: getfield        com/google/ads/internal/c.q:Z
        //   420: istore          29
        //   422: iload           29
        //   424: ifeq            528
        //   427: aload_0        
        //   428: monitorexit    
        //   429: return         
        //   430: aload           35
        //   432: ldc_w           "l"
        //   435: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   438: ifeq            295
        //   441: aload_0        
        //   442: iconst_0       
        //   443: putfield        com/google/ads/internal/c.u:I
        //   446: goto            295
        //   449: astore_1       
        //   450: ldc_w           "An unknown error occurred in AdLoader."
        //   453: aload_1        
        //   454: invokestatic    com/google/ads/util/b.b:(Ljava/lang/String;Ljava/lang/Throwable;)V
        //   457: aload_0        
        //   458: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //   461: iconst_1       
        //   462: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //   465: aload_0        
        //   466: monitorexit    
        //   467: return         
        //   468: astore          23
        //   470: new             Ljava/lang/StringBuilder;
        //   473: dup            
        //   474: ldc_w           "Caught internal exception: "
        //   477: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   480: aload           23
        //   482: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   485: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   488: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   491: aload_0        
        //   492: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //   495: iconst_0       
        //   496: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //   499: aload_0        
        //   500: monitorexit    
        //   501: return         
        //   502: astore          30
        //   504: new             Ljava/lang/StringBuilder;
        //   507: dup            
        //   508: ldc_w           "AdLoader InterruptedException while getting the URL: "
        //   511: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   514: aload           30
        //   516: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   519: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   522: invokestatic    com/google/ads/util/b.a:(Ljava/lang/String;)V
        //   525: aload_0        
        //   526: monitorexit    
        //   527: return         
        //   528: aload_0        
        //   529: getfield        com/google/ads/internal/c.s:Lcom/google/ads/AdRequest$ErrorCode;
        //   532: ifnull          547
        //   535: aload_0        
        //   536: aload_0        
        //   537: getfield        com/google/ads/internal/c.s:Lcom/google/ads/AdRequest$ErrorCode;
        //   540: iconst_0       
        //   541: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //   544: aload_0        
        //   545: monitorexit    
        //   546: return         
        //   547: aload_0        
        //   548: getfield        com/google/ads/internal/c.k:Ljava/lang/String;
        //   551: ifnonnull       592
        //   554: new             Ljava/lang/StringBuilder;
        //   557: dup            
        //   558: ldc_w           "AdLoader timed out after "
        //   561: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   564: lload           4
        //   566: invokevirtual   java/lang/StringBuilder.append:(J)Ljava/lang/StringBuilder;
        //   569: ldc_w           "ms while getting the URL."
        //   572: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   575: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   578: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   581: aload_0        
        //   582: getstatic       com/google/ads/AdRequest$ErrorCode.NETWORK_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //   585: iconst_0       
        //   586: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //   589: aload_0        
        //   590: monitorexit    
        //   591: return         
        //   592: aload_0        
        //   593: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //   596: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //   599: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   602: checkcast       Lcom/google/ads/n;
        //   605: getfield        com/google/ads/n.g:Lcom/google/ads/util/i$b;
        //   608: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   611: checkcast       Lcom/google/ads/internal/h;
        //   614: invokevirtual   com/google/ads/internal/h.b:()Z
        //   617: ifeq            647
        //   620: aload_0        
        //   621: getfield        com/google/ads/internal/c.l:Ljava/lang/String;
        //   624: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   627: ifeq            647
        //   630: ldc_w           "AdLoader doesn't have a URL for the activation overlay"
        //   633: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   636: aload_0        
        //   637: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //   640: iconst_0       
        //   641: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //   644: aload_0        
        //   645: monitorexit    
        //   646: return         
        //   647: aload_0        
        //   648: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //   651: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //   654: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   657: checkcast       Lcom/google/ads/n;
        //   660: getfield        com/google/ads/n.b:Lcom/google/ads/util/i$b;
        //   663: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   666: checkcast       Lcom/google/ads/internal/d;
        //   669: invokevirtual   com/google/ads/internal/d.n:()Lcom/google/ads/internal/g;
        //   672: astore          15
        //   674: getstatic       com/google/ads/internal/c$3.a:[I
        //   677: aload_0        
        //   678: getfield        com/google/ads/internal/c.x:Lcom/google/ads/internal/c$d;
        //   681: invokevirtual   com/google/ads/internal/c$d.ordinal:()I
        //   684: iaload         
        //   685: tableswitch {
        //                2: 914
        //                3: 938
        //                4: 952
        //                5: 971
        //          default: 716
        //        }
        //   716: aload_0        
        //   717: getfield        com/google/ads/internal/c.a:Z
        //   720: ifne            1077
        //   723: ldc_w           "Not using loadUrl()."
        //   726: invokestatic    com/google/ads/util/b.a:(Ljava/lang/String;)V
        //   729: aload_0        
        //   730: getfield        com/google/ads/internal/c.g:Lcom/google/ads/internal/f;
        //   733: aload_0        
        //   734: getfield        com/google/ads/internal/c.w:Z
        //   737: invokevirtual   com/google/ads/internal/f.a:(Z)V
        //   740: aload_0        
        //   741: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //   744: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //   747: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   750: checkcast       Lcom/google/ads/n;
        //   753: getfield        com/google/ads/n.g:Lcom/google/ads/util/i$b;
        //   756: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   759: checkcast       Lcom/google/ads/internal/h;
        //   762: invokevirtual   com/google/ads/internal/h.b:()Z
        //   765: ifeq            1558
        //   768: aload_0        
        //   769: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //   772: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //   775: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   778: checkcast       Lcom/google/ads/n;
        //   781: getfield        com/google/ads/n.e:Lcom/google/ads/util/i$b;
        //   784: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   787: checkcast       Lcom/google/ads/internal/ActivationOverlay;
        //   790: invokevirtual   com/google/ads/internal/ActivationOverlay.e:()Lcom/google/ads/internal/i;
        //   793: astore          21
        //   795: aload           21
        //   797: iconst_1       
        //   798: invokevirtual   com/google/ads/internal/i.c:(Z)V
        //   801: invokestatic    com/google/ads/m.a:()Lcom/google/ads/m;
        //   804: getfield        com/google/ads/m.c:Lcom/google/ads/util/i$b;
        //   807: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   810: checkcast       Landroid/os/Handler;
        //   813: new             Lcom/google/ads/internal/c$1;
        //   816: dup            
        //   817: aload_0        
        //   818: invokespecial   com/google/ads/internal/c$1.<init>:(Lcom/google/ads/internal/c;)V
        //   821: invokevirtual   android/os/Handler.post:(Ljava/lang/Runnable;)Z
        //   824: pop            
        //   825: aload           21
        //   827: astore          16
        //   829: aload_0        
        //   830: getfield        com/google/ads/internal/c.g:Lcom/google/ads/internal/f;
        //   833: aload_0        
        //   834: getfield        com/google/ads/internal/c.k:Ljava/lang/String;
        //   837: invokevirtual   com/google/ads/internal/f.a:(Ljava/lang/String;)V
        //   840: aload_0        
        //   841: getfield        com/google/ads/internal/c.q:Z
        //   844: ifne            999
        //   847: aload_0        
        //   848: getfield        com/google/ads/internal/c.s:Lcom/google/ads/AdRequest$ErrorCode;
        //   851: ifnonnull       999
        //   854: aload_0        
        //   855: getfield        com/google/ads/internal/c.c:Ljava/lang/String;
        //   858: ifnonnull       999
        //   861: lload           4
        //   863: invokestatic    android/os/SystemClock.elapsedRealtime:()J
        //   866: lload           6
        //   868: lsub           
        //   869: lsub           
        //   870: lstore          19
        //   872: lload           19
        //   874: lconst_0       
        //   875: lcmp           
        //   876: ifle            999
        //   879: aload_0        
        //   880: lload           19
        //   882: invokevirtual   java/lang/Object.wait:(J)V
        //   885: goto            840
        //   888: astore          17
        //   890: new             Ljava/lang/StringBuilder;
        //   893: dup            
        //   894: ldc_w           "AdLoader InterruptedException while getting the ad server's response: "
        //   897: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   900: aload           17
        //   902: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   905: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   908: invokestatic    com/google/ads/util/b.a:(Ljava/lang/String;)V
        //   911: aload_0        
        //   912: monitorexit    
        //   913: return         
        //   914: aload           15
        //   916: invokevirtual   com/google/ads/internal/g.r:()V
        //   919: aload           15
        //   921: invokevirtual   com/google/ads/internal/g.u:()V
        //   924: aload           15
        //   926: invokevirtual   com/google/ads/internal/g.x:()V
        //   929: ldc_w           "Request scenario: Online server request."
        //   932: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   935: goto            716
        //   938: aload           15
        //   940: invokevirtual   com/google/ads/internal/g.t:()V
        //   943: ldc_w           "Request scenario: Online using buffered ads."
        //   946: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   949: goto            716
        //   952: aload           15
        //   954: invokevirtual   com/google/ads/internal/g.w:()V
        //   957: aload           15
        //   959: invokevirtual   com/google/ads/internal/g.q:()V
        //   962: ldc_w           "Request scenario: Offline using buffered ads."
        //   965: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   968: goto            716
        //   971: aload           15
        //   973: invokevirtual   com/google/ads/internal/g.q:()V
        //   976: ldc_w           "Request scenario: Offline with no buffered ads."
        //   979: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   982: ldc_w           "Network is unavailable.  Aborting ad request."
        //   985: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   988: aload_0        
        //   989: getstatic       com/google/ads/AdRequest$ErrorCode.NETWORK_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //   992: iconst_0       
        //   993: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //   996: aload_0        
        //   997: monitorexit    
        //   998: return         
        //   999: aload_0        
        //  1000: getfield        com/google/ads/internal/c.q:Z
        //  1003: istore          18
        //  1005: iload           18
        //  1007: ifeq            1013
        //  1010: aload_0        
        //  1011: monitorexit    
        //  1012: return         
        //  1013: aload_0        
        //  1014: getfield        com/google/ads/internal/c.s:Lcom/google/ads/AdRequest$ErrorCode;
        //  1017: ifnull          1032
        //  1020: aload_0        
        //  1021: aload_0        
        //  1022: getfield        com/google/ads/internal/c.s:Lcom/google/ads/AdRequest$ErrorCode;
        //  1025: iconst_0       
        //  1026: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //  1029: aload_0        
        //  1030: monitorexit    
        //  1031: return         
        //  1032: aload_0        
        //  1033: getfield        com/google/ads/internal/c.c:Ljava/lang/String;
        //  1036: ifnonnull       1551
        //  1039: new             Ljava/lang/StringBuilder;
        //  1042: dup            
        //  1043: ldc_w           "AdLoader timed out after "
        //  1046: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1049: lload           4
        //  1051: invokevirtual   java/lang/StringBuilder.append:(J)Ljava/lang/StringBuilder;
        //  1054: ldc_w           "ms while waiting for the ad server's response."
        //  1057: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1060: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1063: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //  1066: aload_0        
        //  1067: getstatic       com/google/ads/AdRequest$ErrorCode.NETWORK_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //  1070: iconst_0       
        //  1071: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //  1074: aload_0        
        //  1075: monitorexit    
        //  1076: return         
        //  1077: aload_0        
        //  1078: aload_0        
        //  1079: getfield        com/google/ads/internal/c.k:Ljava/lang/String;
        //  1082: putfield        com/google/ads/internal/c.b:Ljava/lang/String;
        //  1085: new             Ljava/lang/StringBuilder;
        //  1088: dup            
        //  1089: ldc_w           "Using loadUrl.  adBaseUrl: "
        //  1092: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1095: aload_0        
        //  1096: getfield        com/google/ads/internal/c.b:Ljava/lang/String;
        //  1099: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1102: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1105: invokestatic    com/google/ads/util/b.a:(Ljava/lang/String;)V
        //  1108: goto            1564
        //  1111: aload_0        
        //  1112: getfield        com/google/ads/internal/c.a:Z
        //  1115: ifne            1366
        //  1118: aload_0        
        //  1119: getfield        com/google/ads/internal/c.f:Z
        //  1122: ifeq            1158
        //  1125: aload_0        
        //  1126: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //  1129: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //  1132: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1135: checkcast       Lcom/google/ads/n;
        //  1138: getfield        com/google/ads/n.b:Lcom/google/ads/util/i$b;
        //  1141: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1144: checkcast       Lcom/google/ads/internal/d;
        //  1147: iconst_1       
        //  1148: invokevirtual   com/google/ads/internal/d.b:(Z)V
        //  1151: aload_0        
        //  1152: invokevirtual   com/google/ads/internal/c.b:()V
        //  1155: aload_0        
        //  1156: monitorexit    
        //  1157: return         
        //  1158: aload_0        
        //  1159: getfield        com/google/ads/internal/c.e:Ljava/lang/String;
        //  1162: ifnull          1231
        //  1165: aload_0        
        //  1166: getfield        com/google/ads/internal/c.e:Ljava/lang/String;
        //  1169: ldc_w           "application/json"
        //  1172: invokevirtual   java/lang/String.startsWith:(Ljava/lang/String;)Z
        //  1175: ifne            1191
        //  1178: aload_0        
        //  1179: getfield        com/google/ads/internal/c.e:Ljava/lang/String;
        //  1182: ldc_w           "text/javascript"
        //  1185: invokevirtual   java/lang/String.startsWith:(Ljava/lang/String;)Z
        //  1188: ifeq            1231
        //  1191: new             Ljava/lang/StringBuilder;
        //  1194: dup            
        //  1195: ldc_w           "Expected HTML but received "
        //  1198: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1201: aload_0        
        //  1202: getfield        com/google/ads/internal/c.e:Ljava/lang/String;
        //  1205: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1208: ldc_w           "."
        //  1211: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1214: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1217: invokestatic    com/google/ads/util/b.b:(Ljava/lang/String;)V
        //  1220: aload_0        
        //  1221: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //  1224: iconst_0       
        //  1225: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //  1228: aload_0        
        //  1229: monitorexit    
        //  1230: return         
        //  1231: aload_0        
        //  1232: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //  1235: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //  1238: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1241: checkcast       Lcom/google/ads/n;
        //  1244: getfield        com/google/ads/n.n:Lcom/google/ads/util/i$c;
        //  1247: invokevirtual   com/google/ads/util/i$c.a:()Ljava/lang/Object;
        //  1250: ifnull          1348
        //  1253: aload_0        
        //  1254: getfield        com/google/ads/internal/c.o:Lcom/google/ads/AdSize;
        //  1257: ifnonnull       1277
        //  1260: ldc_w           "Multiple supported ad sizes were specified, but the server did not respond with a size."
        //  1263: invokestatic    com/google/ads/util/b.b:(Ljava/lang/String;)V
        //  1266: aload_0        
        //  1267: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //  1270: iconst_0       
        //  1271: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //  1274: aload_0        
        //  1275: monitorexit    
        //  1276: return         
        //  1277: aload_0        
        //  1278: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //  1281: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //  1284: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1287: checkcast       Lcom/google/ads/n;
        //  1290: getfield        com/google/ads/n.n:Lcom/google/ads/util/i$c;
        //  1293: invokevirtual   com/google/ads/util/i$c.a:()Ljava/lang/Object;
        //  1296: checkcast       [Ljava/lang/Object;
        //  1299: invokestatic    java/util/Arrays.asList:([Ljava/lang/Object;)Ljava/util/List;
        //  1302: aload_0        
        //  1303: getfield        com/google/ads/internal/c.o:Lcom/google/ads/AdSize;
        //  1306: invokeinterface java/util/List.contains:(Ljava/lang/Object;)Z
        //  1311: ifne            1366
        //  1314: new             Ljava/lang/StringBuilder;
        //  1317: dup            
        //  1318: ldc_w           "The ad server did not respond with a supported AdSize: "
        //  1321: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1324: aload_0        
        //  1325: getfield        com/google/ads/internal/c.o:Lcom/google/ads/AdSize;
        //  1328: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //  1331: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1334: invokestatic    com/google/ads/util/b.b:(Ljava/lang/String;)V
        //  1337: aload_0        
        //  1338: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //  1341: iconst_0       
        //  1342: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //  1345: aload_0        
        //  1346: monitorexit    
        //  1347: return         
        //  1348: aload_0        
        //  1349: getfield        com/google/ads/internal/c.o:Lcom/google/ads/AdSize;
        //  1352: ifnull          1366
        //  1355: ldc_w           "adSize was expected to be null in AdLoader."
        //  1358: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //  1361: aload_0        
        //  1362: aconst_null    
        //  1363: putfield        com/google/ads/internal/c.o:Lcom/google/ads/AdSize;
        //  1366: aload_0        
        //  1367: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //  1370: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //  1373: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1376: checkcast       Lcom/google/ads/n;
        //  1379: getfield        com/google/ads/n.b:Lcom/google/ads/util/i$b;
        //  1382: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1385: checkcast       Lcom/google/ads/internal/d;
        //  1388: iconst_0       
        //  1389: invokevirtual   com/google/ads/internal/d.b:(Z)V
        //  1392: aload_0        
        //  1393: invokespecial   com/google/ads/internal/c.i:()V
        //  1396: aload_0        
        //  1397: getfield        com/google/ads/internal/c.q:Z
        //  1400: ifne            1499
        //  1403: aload_0        
        //  1404: getfield        com/google/ads/internal/c.t:Z
        //  1407: ifeq            1446
        //  1410: aload_0        
        //  1411: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //  1414: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //  1417: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1420: checkcast       Lcom/google/ads/n;
        //  1423: getfield        com/google/ads/n.g:Lcom/google/ads/util/i$b;
        //  1426: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1429: checkcast       Lcom/google/ads/internal/h;
        //  1432: invokevirtual   com/google/ads/internal/h.b:()Z
        //  1435: ifeq            1499
        //  1438: aload           10
        //  1440: invokevirtual   com/google/ads/internal/i.a:()Z
        //  1443: ifeq            1499
        //  1446: lload           4
        //  1448: invokestatic    android/os/SystemClock.elapsedRealtime:()J
        //  1451: lload           6
        //  1453: lsub           
        //  1454: lsub           
        //  1455: lstore          12
        //  1457: lload           12
        //  1459: lconst_0       
        //  1460: lcmp           
        //  1461: ifle            1499
        //  1464: aload_0        
        //  1465: lload           12
        //  1467: invokevirtual   java/lang/Object.wait:(J)V
        //  1470: goto            1396
        //  1473: astore          11
        //  1475: new             Ljava/lang/StringBuilder;
        //  1478: dup            
        //  1479: ldc_w           "AdLoader InterruptedException while loading the HTML: "
        //  1482: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1485: aload           11
        //  1487: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //  1490: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1493: invokestatic    com/google/ads/util/b.a:(Ljava/lang/String;)V
        //  1496: aload_0        
        //  1497: monitorexit    
        //  1498: return         
        //  1499: aload_0        
        //  1500: getfield        com/google/ads/internal/c.t:Z
        //  1503: ifeq            1513
        //  1506: aload_0        
        //  1507: invokespecial   com/google/ads/internal/c.j:()V
        //  1510: goto            465
        //  1513: new             Ljava/lang/StringBuilder;
        //  1516: dup            
        //  1517: ldc_w           "AdLoader timed out after "
        //  1520: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1523: lload           4
        //  1525: invokevirtual   java/lang/StringBuilder.append:(J)Ljava/lang/StringBuilder;
        //  1528: ldc_w           "ms while loading the HTML."
        //  1531: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1534: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1537: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //  1540: aload_0        
        //  1541: getstatic       com/google/ads/AdRequest$ErrorCode.NETWORK_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //  1544: iconst_1       
        //  1545: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //  1548: goto            465
        //  1551: aload           16
        //  1553: astore          10
        //  1555: goto            1111
        //  1558: aconst_null    
        //  1559: astore          16
        //  1561: goto            829
        //  1564: aconst_null    
        //  1565: astore          10
        //  1567: goto            1111
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  2      16     449    465    Ljava/lang/Throwable;
        //  2      16     77     82     Any
        //  16     30     449    465    Ljava/lang/Throwable;
        //  16     30     77     82     Any
        //  30     32     77     82     Any
        //  33     56     449    465    Ljava/lang/Throwable;
        //  33     56     77     82     Any
        //  60     74     449    465    Ljava/lang/Throwable;
        //  60     74     77     82     Any
        //  74     76     77     82     Any
        //  82     201    449    465    Ljava/lang/Throwable;
        //  82     201    77     82     Any
        //  201    230    449    465    Ljava/lang/Throwable;
        //  201    230    77     82     Any
        //  230    259    449    465    Ljava/lang/Throwable;
        //  230    259    77     82     Any
        //  259    295    449    465    Ljava/lang/Throwable;
        //  259    295    77     82     Any
        //  295    351    449    465    Ljava/lang/Throwable;
        //  295    351    77     82     Any
        //  351    364    449    465    Ljava/lang/Throwable;
        //  351    364    77     82     Any
        //  369    378    468    502    Lcom/google/ads/internal/c$b;
        //  369    378    449    465    Ljava/lang/Throwable;
        //  369    378    77     82     Any
        //  378    393    449    465    Ljava/lang/Throwable;
        //  378    393    77     82     Any
        //  410    416    502    528    Ljava/lang/InterruptedException;
        //  410    416    449    465    Ljava/lang/Throwable;
        //  410    416    77     82     Any
        //  416    422    449    465    Ljava/lang/Throwable;
        //  416    422    77     82     Any
        //  427    429    77     82     Any
        //  430    446    449    465    Ljava/lang/Throwable;
        //  430    446    77     82     Any
        //  450    465    77     82     Any
        //  465    467    77     82     Any
        //  470    499    449    465    Ljava/lang/Throwable;
        //  470    499    77     82     Any
        //  499    501    77     82     Any
        //  504    525    449    465    Ljava/lang/Throwable;
        //  504    525    77     82     Any
        //  525    527    77     82     Any
        //  528    544    449    465    Ljava/lang/Throwable;
        //  528    544    77     82     Any
        //  544    546    77     82     Any
        //  547    589    449    465    Ljava/lang/Throwable;
        //  547    589    77     82     Any
        //  589    591    77     82     Any
        //  592    644    449    465    Ljava/lang/Throwable;
        //  592    644    77     82     Any
        //  644    646    77     82     Any
        //  647    716    449    465    Ljava/lang/Throwable;
        //  647    716    77     82     Any
        //  716    825    449    465    Ljava/lang/Throwable;
        //  716    825    77     82     Any
        //  829    840    449    465    Ljava/lang/Throwable;
        //  829    840    77     82     Any
        //  840    872    888    914    Ljava/lang/InterruptedException;
        //  840    872    449    465    Ljava/lang/Throwable;
        //  840    872    77     82     Any
        //  879    885    888    914    Ljava/lang/InterruptedException;
        //  879    885    449    465    Ljava/lang/Throwable;
        //  879    885    77     82     Any
        //  890    911    449    465    Ljava/lang/Throwable;
        //  890    911    77     82     Any
        //  911    913    77     82     Any
        //  914    935    449    465    Ljava/lang/Throwable;
        //  914    935    77     82     Any
        //  938    949    449    465    Ljava/lang/Throwable;
        //  938    949    77     82     Any
        //  952    968    449    465    Ljava/lang/Throwable;
        //  952    968    77     82     Any
        //  971    996    449    465    Ljava/lang/Throwable;
        //  971    996    77     82     Any
        //  996    998    77     82     Any
        //  999    1005   449    465    Ljava/lang/Throwable;
        //  999    1005   77     82     Any
        //  1010   1012   77     82     Any
        //  1013   1029   449    465    Ljava/lang/Throwable;
        //  1013   1029   77     82     Any
        //  1029   1031   77     82     Any
        //  1032   1074   449    465    Ljava/lang/Throwable;
        //  1032   1074   77     82     Any
        //  1074   1076   77     82     Any
        //  1077   1108   449    465    Ljava/lang/Throwable;
        //  1077   1108   77     82     Any
        //  1111   1155   449    465    Ljava/lang/Throwable;
        //  1111   1155   77     82     Any
        //  1155   1157   77     82     Any
        //  1158   1191   449    465    Ljava/lang/Throwable;
        //  1158   1191   77     82     Any
        //  1191   1228   449    465    Ljava/lang/Throwable;
        //  1191   1228   77     82     Any
        //  1228   1230   77     82     Any
        //  1231   1274   449    465    Ljava/lang/Throwable;
        //  1231   1274   77     82     Any
        //  1274   1276   77     82     Any
        //  1277   1345   449    465    Ljava/lang/Throwable;
        //  1277   1345   77     82     Any
        //  1345   1347   77     82     Any
        //  1348   1366   449    465    Ljava/lang/Throwable;
        //  1348   1366   77     82     Any
        //  1366   1396   449    465    Ljava/lang/Throwable;
        //  1366   1396   77     82     Any
        //  1396   1446   1473   1499   Ljava/lang/InterruptedException;
        //  1396   1446   449    465    Ljava/lang/Throwable;
        //  1396   1446   77     82     Any
        //  1446   1457   1473   1499   Ljava/lang/InterruptedException;
        //  1446   1457   449    465    Ljava/lang/Throwable;
        //  1446   1457   77     82     Any
        //  1464   1470   1473   1499   Ljava/lang/InterruptedException;
        //  1464   1470   449    465    Ljava/lang/Throwable;
        //  1464   1470   77     82     Any
        //  1475   1496   449    465    Ljava/lang/Throwable;
        //  1475   1496   77     82     Any
        //  1496   1498   77     82     Any
        //  1499   1510   449    465    Ljava/lang/Throwable;
        //  1499   1510   77     82     Any
        //  1513   1548   449    465    Ljava/lang/Throwable;
        //  1513   1548   77     82     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index: 669, Size: 669
        //     at java.util.ArrayList.rangeCheck(ArrayList.java:635)
        //     at java.util.ArrayList.get(ArrayList.java:411)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(Unknown Source)
        //     at com.strobel.decompiler.ast.AstBuilder.build(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     0: aload_0        
        //     1: monitorenter   
        //     2: aload_0        
        //     3: getfield        com/google/ads/internal/c.i:Landroid/webkit/WebView;
        //     6: ifnull          16
        //     9: aload_0        
        //    10: getfield        com/google/ads/internal/c.g:Lcom/google/ads/internal/f;
        //    13: ifnonnull       33
        //    16: ldc_w           "adRequestWebView was null while trying to load an ad."
        //    19: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //    22: aload_0        
        //    23: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //    26: iconst_0       
        //    27: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //    30: aload_0        
        //    31: monitorexit    
        //    32: return         
        //    33: aload_0        
        //    34: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //    37: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //    40: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //    43: checkcast       Lcom/google/ads/n;
        //    46: getfield        com/google/ads/n.c:Lcom/google/ads/util/i$d;
        //    49: invokevirtual   com/google/ads/util/i$d.a:()Ljava/lang/Object;
        //    52: checkcast       Landroid/app/Activity;
        //    55: astore_3       
        //    56: aload_3        
        //    57: ifnonnull       82
        //    60: ldc_w           "activity was null while forming an ad request."
        //    63: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //    66: aload_0        
        //    67: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //    70: iconst_0       
        //    71: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //    74: aload_0        
        //    75: monitorexit    
        //    76: return         
        //    77: astore_2       
        //    78: aload_0        
        //    79: monitorexit    
        //    80: aload_2        
        //    81: athrow         
        //    82: aload_0        
        //    83: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //    86: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //    89: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //    92: checkcast       Lcom/google/ads/n;
        //    95: getfield        com/google/ads/n.b:Lcom/google/ads/util/i$b;
        //    98: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   101: checkcast       Lcom/google/ads/internal/d;
        //   104: invokevirtual   com/google/ads/internal/d.p:()J
        //   107: lstore          4
        //   109: invokestatic    android/os/SystemClock.elapsedRealtime:()J
        //   112: lstore          6
        //   114: aload_0        
        //   115: getfield        com/google/ads/internal/c.h:Lcom/google/ads/AdRequest;
        //   118: aload_0        
        //   119: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //   122: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //   125: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   128: checkcast       Lcom/google/ads/n;
        //   131: getfield        com/google/ads/n.f:Lcom/google/ads/util/i$b;
        //   134: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   137: checkcast       Landroid/content/Context;
        //   140: invokevirtual   com/google/ads/AdRequest.getRequestMap:(Landroid/content/Context;)Ljava/util/Map;
        //   143: astore          8
        //   145: aload           8
        //   147: ldc_w           "extras"
        //   150: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   155: astore          9
        //   157: aload           9
        //   159: instanceof      Ljava/util/Map;
        //   162: ifeq            351
        //   165: aload           9
        //   167: checkcast       Ljava/util/Map;
        //   170: astore          31
        //   172: aload           31
        //   174: ldc_w           "_adUrl"
        //   177: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   182: astore          32
        //   184: aload           32
        //   186: instanceof      Ljava/lang/String;
        //   189: ifeq            201
        //   192: aload_0        
        //   193: aload           32
        //   195: checkcast       Ljava/lang/String;
        //   198: putfield        com/google/ads/internal/c.b:Ljava/lang/String;
        //   201: aload           31
        //   203: ldc_w           "_requestUrl"
        //   206: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   211: astore          33
        //   213: aload           33
        //   215: instanceof      Ljava/lang/String;
        //   218: ifeq            230
        //   221: aload_0        
        //   222: aload           33
        //   224: checkcast       Ljava/lang/String;
        //   227: putfield        com/google/ads/internal/c.k:Ljava/lang/String;
        //   230: aload           31
        //   232: ldc_w           "_activationOverlayUrl"
        //   235: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   240: astore          34
        //   242: aload           34
        //   244: instanceof      Ljava/lang/String;
        //   247: ifeq            259
        //   250: aload_0        
        //   251: aload           34
        //   253: checkcast       Ljava/lang/String;
        //   256: putfield        com/google/ads/internal/c.l:Ljava/lang/String;
        //   259: aload           31
        //   261: ldc_w           "_orientation"
        //   264: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   269: astore          35
        //   271: aload           35
        //   273: instanceof      Ljava/lang/String;
        //   276: ifeq            295
        //   279: aload           35
        //   281: ldc_w           "p"
        //   284: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   287: ifeq            430
        //   290: aload_0        
        //   291: iconst_1       
        //   292: putfield        com/google/ads/internal/c.u:I
        //   295: aload           31
        //   297: ldc_w           "_norefresh"
        //   300: invokeinterface java/util/Map.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   305: astore          36
        //   307: aload           36
        //   309: instanceof      Ljava/lang/String;
        //   312: ifeq            351
        //   315: aload           36
        //   317: ldc_w           "t"
        //   320: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   323: ifeq            351
        //   326: aload_0        
        //   327: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //   330: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //   333: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   336: checkcast       Lcom/google/ads/n;
        //   339: getfield        com/google/ads/n.b:Lcom/google/ads/util/i$b;
        //   342: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   345: checkcast       Lcom/google/ads/internal/d;
        //   348: invokevirtual   com/google/ads/internal/d.e:()V
        //   351: aload_0        
        //   352: getfield        com/google/ads/internal/c.b:Ljava/lang/String;
        //   355: ifnonnull       1564
        //   358: aload_0        
        //   359: getfield        com/google/ads/internal/c.k:Ljava/lang/String;
        //   362: astore          14
        //   364: aload           14
        //   366: ifnonnull       647
        //   369: aload_0        
        //   370: aload           8
        //   372: aload_3        
        //   373: invokevirtual   com/google/ads/internal/c.a:(Ljava/util/Map;Landroid/app/Activity;)Ljava/lang/String;
        //   376: astore          24
        //   378: aload_0        
        //   379: aload           24
        //   381: aload_0        
        //   382: invokespecial   com/google/ads/internal/c.f:()Ljava/lang/String;
        //   385: invokespecial   com/google/ads/internal/c.b:(Ljava/lang/String;Ljava/lang/String;)V
        //   388: invokestatic    android/os/SystemClock.elapsedRealtime:()J
        //   391: lstore          25
        //   393: lload           4
        //   395: lload           25
        //   397: lload           6
        //   399: lsub           
        //   400: lsub           
        //   401: lstore          27
        //   403: lload           27
        //   405: lconst_0       
        //   406: lcmp           
        //   407: ifle            416
        //   410: aload_0        
        //   411: lload           27
        //   413: invokevirtual   java/lang/Object.wait:(J)V
        //   416: aload_0        
        //   417: getfield        com/google/ads/internal/c.q:Z
        //   420: istore          29
        //   422: iload           29
        //   424: ifeq            528
        //   427: aload_0        
        //   428: monitorexit    
        //   429: return         
        //   430: aload           35
        //   432: ldc_w           "l"
        //   435: invokevirtual   java/lang/Object.equals:(Ljava/lang/Object;)Z
        //   438: ifeq            295
        //   441: aload_0        
        //   442: iconst_0       
        //   443: putfield        com/google/ads/internal/c.u:I
        //   446: goto            295
        //   449: astore_1       
        //   450: ldc_w           "An unknown error occurred in AdLoader."
        //   453: aload_1        
        //   454: invokestatic    com/google/ads/util/b.b:(Ljava/lang/String;Ljava/lang/Throwable;)V
        //   457: aload_0        
        //   458: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //   461: iconst_1       
        //   462: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //   465: aload_0        
        //   466: monitorexit    
        //   467: return         
        //   468: astore          23
        //   470: new             Ljava/lang/StringBuilder;
        //   473: dup            
        //   474: ldc_w           "Caught internal exception: "
        //   477: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   480: aload           23
        //   482: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   485: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   488: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   491: aload_0        
        //   492: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //   495: iconst_0       
        //   496: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //   499: aload_0        
        //   500: monitorexit    
        //   501: return         
        //   502: astore          30
        //   504: new             Ljava/lang/StringBuilder;
        //   507: dup            
        //   508: ldc_w           "AdLoader InterruptedException while getting the URL: "
        //   511: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   514: aload           30
        //   516: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   519: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   522: invokestatic    com/google/ads/util/b.a:(Ljava/lang/String;)V
        //   525: aload_0        
        //   526: monitorexit    
        //   527: return         
        //   528: aload_0        
        //   529: getfield        com/google/ads/internal/c.s:Lcom/google/ads/AdRequest$ErrorCode;
        //   532: ifnull          547
        //   535: aload_0        
        //   536: aload_0        
        //   537: getfield        com/google/ads/internal/c.s:Lcom/google/ads/AdRequest$ErrorCode;
        //   540: iconst_0       
        //   541: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //   544: aload_0        
        //   545: monitorexit    
        //   546: return         
        //   547: aload_0        
        //   548: getfield        com/google/ads/internal/c.k:Ljava/lang/String;
        //   551: ifnonnull       592
        //   554: new             Ljava/lang/StringBuilder;
        //   557: dup            
        //   558: ldc_w           "AdLoader timed out after "
        //   561: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   564: lload           4
        //   566: invokevirtual   java/lang/StringBuilder.append:(J)Ljava/lang/StringBuilder;
        //   569: ldc_w           "ms while getting the URL."
        //   572: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   575: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   578: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   581: aload_0        
        //   582: getstatic       com/google/ads/AdRequest$ErrorCode.NETWORK_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //   585: iconst_0       
        //   586: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //   589: aload_0        
        //   590: monitorexit    
        //   591: return         
        //   592: aload_0        
        //   593: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //   596: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //   599: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   602: checkcast       Lcom/google/ads/n;
        //   605: getfield        com/google/ads/n.g:Lcom/google/ads/util/i$b;
        //   608: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   611: checkcast       Lcom/google/ads/internal/h;
        //   614: invokevirtual   com/google/ads/internal/h.b:()Z
        //   617: ifeq            647
        //   620: aload_0        
        //   621: getfield        com/google/ads/internal/c.l:Ljava/lang/String;
        //   624: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   627: ifeq            647
        //   630: ldc_w           "AdLoader doesn't have a URL for the activation overlay"
        //   633: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   636: aload_0        
        //   637: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //   640: iconst_0       
        //   641: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //   644: aload_0        
        //   645: monitorexit    
        //   646: return         
        //   647: aload_0        
        //   648: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //   651: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //   654: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   657: checkcast       Lcom/google/ads/n;
        //   660: getfield        com/google/ads/n.b:Lcom/google/ads/util/i$b;
        //   663: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   666: checkcast       Lcom/google/ads/internal/d;
        //   669: invokevirtual   com/google/ads/internal/d.n:()Lcom/google/ads/internal/g;
        //   672: astore          15
        //   674: getstatic       com/google/ads/internal/c$3.a:[I
        //   677: aload_0        
        //   678: getfield        com/google/ads/internal/c.x:Lcom/google/ads/internal/c$d;
        //   681: invokevirtual   com/google/ads/internal/c$d.ordinal:()I
        //   684: iaload         
        //   685: tableswitch {
        //                2: 914
        //                3: 938
        //                4: 952
        //                5: 971
        //          default: 716
        //        }
        //   716: aload_0        
        //   717: getfield        com/google/ads/internal/c.a:Z
        //   720: ifne            1077
        //   723: ldc_w           "Not using loadUrl()."
        //   726: invokestatic    com/google/ads/util/b.a:(Ljava/lang/String;)V
        //   729: aload_0        
        //   730: getfield        com/google/ads/internal/c.g:Lcom/google/ads/internal/f;
        //   733: aload_0        
        //   734: getfield        com/google/ads/internal/c.w:Z
        //   737: invokevirtual   com/google/ads/internal/f.a:(Z)V
        //   740: aload_0        
        //   741: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //   744: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //   747: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   750: checkcast       Lcom/google/ads/n;
        //   753: getfield        com/google/ads/n.g:Lcom/google/ads/util/i$b;
        //   756: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   759: checkcast       Lcom/google/ads/internal/h;
        //   762: invokevirtual   com/google/ads/internal/h.b:()Z
        //   765: ifeq            1558
        //   768: aload_0        
        //   769: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //   772: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //   775: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   778: checkcast       Lcom/google/ads/n;
        //   781: getfield        com/google/ads/n.e:Lcom/google/ads/util/i$b;
        //   784: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   787: checkcast       Lcom/google/ads/internal/ActivationOverlay;
        //   790: invokevirtual   com/google/ads/internal/ActivationOverlay.e:()Lcom/google/ads/internal/i;
        //   793: astore          21
        //   795: aload           21
        //   797: iconst_1       
        //   798: invokevirtual   com/google/ads/internal/i.c:(Z)V
        //   801: invokestatic    com/google/ads/m.a:()Lcom/google/ads/m;
        //   804: getfield        com/google/ads/m.c:Lcom/google/ads/util/i$b;
        //   807: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //   810: checkcast       Landroid/os/Handler;
        //   813: new             Lcom/google/ads/internal/c$1;
        //   816: dup            
        //   817: aload_0        
        //   818: invokespecial   com/google/ads/internal/c$1.<init>:(Lcom/google/ads/internal/c;)V
        //   821: invokevirtual   android/os/Handler.post:(Ljava/lang/Runnable;)Z
        //   824: pop            
        //   825: aload           21
        //   827: astore          16
        //   829: aload_0        
        //   830: getfield        com/google/ads/internal/c.g:Lcom/google/ads/internal/f;
        //   833: aload_0        
        //   834: getfield        com/google/ads/internal/c.k:Ljava/lang/String;
        //   837: invokevirtual   com/google/ads/internal/f.a:(Ljava/lang/String;)V
        //   840: aload_0        
        //   841: getfield        com/google/ads/internal/c.q:Z
        //   844: ifne            999
        //   847: aload_0        
        //   848: getfield        com/google/ads/internal/c.s:Lcom/google/ads/AdRequest$ErrorCode;
        //   851: ifnonnull       999
        //   854: aload_0        
        //   855: getfield        com/google/ads/internal/c.c:Ljava/lang/String;
        //   858: ifnonnull       999
        //   861: lload           4
        //   863: invokestatic    android/os/SystemClock.elapsedRealtime:()J
        //   866: lload           6
        //   868: lsub           
        //   869: lsub           
        //   870: lstore          19
        //   872: lload           19
        //   874: lconst_0       
        //   875: lcmp           
        //   876: ifle            999
        //   879: aload_0        
        //   880: lload           19
        //   882: invokevirtual   java/lang/Object.wait:(J)V
        //   885: goto            840
        //   888: astore          17
        //   890: new             Ljava/lang/StringBuilder;
        //   893: dup            
        //   894: ldc_w           "AdLoader InterruptedException while getting the ad server's response: "
        //   897: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   900: aload           17
        //   902: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   905: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   908: invokestatic    com/google/ads/util/b.a:(Ljava/lang/String;)V
        //   911: aload_0        
        //   912: monitorexit    
        //   913: return         
        //   914: aload           15
        //   916: invokevirtual   com/google/ads/internal/g.r:()V
        //   919: aload           15
        //   921: invokevirtual   com/google/ads/internal/g.u:()V
        //   924: aload           15
        //   926: invokevirtual   com/google/ads/internal/g.x:()V
        //   929: ldc_w           "Request scenario: Online server request."
        //   932: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   935: goto            716
        //   938: aload           15
        //   940: invokevirtual   com/google/ads/internal/g.t:()V
        //   943: ldc_w           "Request scenario: Online using buffered ads."
        //   946: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   949: goto            716
        //   952: aload           15
        //   954: invokevirtual   com/google/ads/internal/g.w:()V
        //   957: aload           15
        //   959: invokevirtual   com/google/ads/internal/g.q:()V
        //   962: ldc_w           "Request scenario: Offline using buffered ads."
        //   965: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   968: goto            716
        //   971: aload           15
        //   973: invokevirtual   com/google/ads/internal/g.q:()V
        //   976: ldc_w           "Request scenario: Offline with no buffered ads."
        //   979: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   982: ldc_w           "Network is unavailable.  Aborting ad request."
        //   985: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //   988: aload_0        
        //   989: getstatic       com/google/ads/AdRequest$ErrorCode.NETWORK_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //   992: iconst_0       
        //   993: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //   996: aload_0        
        //   997: monitorexit    
        //   998: return         
        //   999: aload_0        
        //  1000: getfield        com/google/ads/internal/c.q:Z
        //  1003: istore          18
        //  1005: iload           18
        //  1007: ifeq            1013
        //  1010: aload_0        
        //  1011: monitorexit    
        //  1012: return         
        //  1013: aload_0        
        //  1014: getfield        com/google/ads/internal/c.s:Lcom/google/ads/AdRequest$ErrorCode;
        //  1017: ifnull          1032
        //  1020: aload_0        
        //  1021: aload_0        
        //  1022: getfield        com/google/ads/internal/c.s:Lcom/google/ads/AdRequest$ErrorCode;
        //  1025: iconst_0       
        //  1026: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //  1029: aload_0        
        //  1030: monitorexit    
        //  1031: return         
        //  1032: aload_0        
        //  1033: getfield        com/google/ads/internal/c.c:Ljava/lang/String;
        //  1036: ifnonnull       1551
        //  1039: new             Ljava/lang/StringBuilder;
        //  1042: dup            
        //  1043: ldc_w           "AdLoader timed out after "
        //  1046: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1049: lload           4
        //  1051: invokevirtual   java/lang/StringBuilder.append:(J)Ljava/lang/StringBuilder;
        //  1054: ldc_w           "ms while waiting for the ad server's response."
        //  1057: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1060: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1063: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //  1066: aload_0        
        //  1067: getstatic       com/google/ads/AdRequest$ErrorCode.NETWORK_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //  1070: iconst_0       
        //  1071: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //  1074: aload_0        
        //  1075: monitorexit    
        //  1076: return         
        //  1077: aload_0        
        //  1078: aload_0        
        //  1079: getfield        com/google/ads/internal/c.k:Ljava/lang/String;
        //  1082: putfield        com/google/ads/internal/c.b:Ljava/lang/String;
        //  1085: new             Ljava/lang/StringBuilder;
        //  1088: dup            
        //  1089: ldc_w           "Using loadUrl.  adBaseUrl: "
        //  1092: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1095: aload_0        
        //  1096: getfield        com/google/ads/internal/c.b:Ljava/lang/String;
        //  1099: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1102: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1105: invokestatic    com/google/ads/util/b.a:(Ljava/lang/String;)V
        //  1108: goto            1564
        //  1111: aload_0        
        //  1112: getfield        com/google/ads/internal/c.a:Z
        //  1115: ifne            1366
        //  1118: aload_0        
        //  1119: getfield        com/google/ads/internal/c.f:Z
        //  1122: ifeq            1158
        //  1125: aload_0        
        //  1126: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //  1129: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //  1132: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1135: checkcast       Lcom/google/ads/n;
        //  1138: getfield        com/google/ads/n.b:Lcom/google/ads/util/i$b;
        //  1141: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1144: checkcast       Lcom/google/ads/internal/d;
        //  1147: iconst_1       
        //  1148: invokevirtual   com/google/ads/internal/d.b:(Z)V
        //  1151: aload_0        
        //  1152: invokevirtual   com/google/ads/internal/c.b:()V
        //  1155: aload_0        
        //  1156: monitorexit    
        //  1157: return         
        //  1158: aload_0        
        //  1159: getfield        com/google/ads/internal/c.e:Ljava/lang/String;
        //  1162: ifnull          1231
        //  1165: aload_0        
        //  1166: getfield        com/google/ads/internal/c.e:Ljava/lang/String;
        //  1169: ldc_w           "application/json"
        //  1172: invokevirtual   java/lang/String.startsWith:(Ljava/lang/String;)Z
        //  1175: ifne            1191
        //  1178: aload_0        
        //  1179: getfield        com/google/ads/internal/c.e:Ljava/lang/String;
        //  1182: ldc_w           "text/javascript"
        //  1185: invokevirtual   java/lang/String.startsWith:(Ljava/lang/String;)Z
        //  1188: ifeq            1231
        //  1191: new             Ljava/lang/StringBuilder;
        //  1194: dup            
        //  1195: ldc_w           "Expected HTML but received "
        //  1198: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1201: aload_0        
        //  1202: getfield        com/google/ads/internal/c.e:Ljava/lang/String;
        //  1205: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1208: ldc_w           "."
        //  1211: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1214: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1217: invokestatic    com/google/ads/util/b.b:(Ljava/lang/String;)V
        //  1220: aload_0        
        //  1221: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //  1224: iconst_0       
        //  1225: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //  1228: aload_0        
        //  1229: monitorexit    
        //  1230: return         
        //  1231: aload_0        
        //  1232: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //  1235: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //  1238: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1241: checkcast       Lcom/google/ads/n;
        //  1244: getfield        com/google/ads/n.n:Lcom/google/ads/util/i$c;
        //  1247: invokevirtual   com/google/ads/util/i$c.a:()Ljava/lang/Object;
        //  1250: ifnull          1348
        //  1253: aload_0        
        //  1254: getfield        com/google/ads/internal/c.o:Lcom/google/ads/AdSize;
        //  1257: ifnonnull       1277
        //  1260: ldc_w           "Multiple supported ad sizes were specified, but the server did not respond with a size."
        //  1263: invokestatic    com/google/ads/util/b.b:(Ljava/lang/String;)V
        //  1266: aload_0        
        //  1267: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //  1270: iconst_0       
        //  1271: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //  1274: aload_0        
        //  1275: monitorexit    
        //  1276: return         
        //  1277: aload_0        
        //  1278: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //  1281: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //  1284: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1287: checkcast       Lcom/google/ads/n;
        //  1290: getfield        com/google/ads/n.n:Lcom/google/ads/util/i$c;
        //  1293: invokevirtual   com/google/ads/util/i$c.a:()Ljava/lang/Object;
        //  1296: checkcast       [Ljava/lang/Object;
        //  1299: invokestatic    java/util/Arrays.asList:([Ljava/lang/Object;)Ljava/util/List;
        //  1302: aload_0        
        //  1303: getfield        com/google/ads/internal/c.o:Lcom/google/ads/AdSize;
        //  1306: invokeinterface java/util/List.contains:(Ljava/lang/Object;)Z
        //  1311: ifne            1366
        //  1314: new             Ljava/lang/StringBuilder;
        //  1317: dup            
        //  1318: ldc_w           "The ad server did not respond with a supported AdSize: "
        //  1321: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1324: aload_0        
        //  1325: getfield        com/google/ads/internal/c.o:Lcom/google/ads/AdSize;
        //  1328: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //  1331: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1334: invokestatic    com/google/ads/util/b.b:(Ljava/lang/String;)V
        //  1337: aload_0        
        //  1338: getstatic       com/google/ads/AdRequest$ErrorCode.INTERNAL_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //  1341: iconst_0       
        //  1342: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //  1345: aload_0        
        //  1346: monitorexit    
        //  1347: return         
        //  1348: aload_0        
        //  1349: getfield        com/google/ads/internal/c.o:Lcom/google/ads/AdSize;
        //  1352: ifnull          1366
        //  1355: ldc_w           "adSize was expected to be null in AdLoader."
        //  1358: invokestatic    com/google/ads/util/b.e:(Ljava/lang/String;)V
        //  1361: aload_0        
        //  1362: aconst_null    
        //  1363: putfield        com/google/ads/internal/c.o:Lcom/google/ads/AdSize;
        //  1366: aload_0        
        //  1367: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //  1370: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //  1373: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1376: checkcast       Lcom/google/ads/n;
        //  1379: getfield        com/google/ads/n.b:Lcom/google/ads/util/i$b;
        //  1382: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1385: checkcast       Lcom/google/ads/internal/d;
        //  1388: iconst_0       
        //  1389: invokevirtual   com/google/ads/internal/d.b:(Z)V
        //  1392: aload_0        
        //  1393: invokespecial   com/google/ads/internal/c.i:()V
        //  1396: aload_0        
        //  1397: getfield        com/google/ads/internal/c.q:Z
        //  1400: ifne            1499
        //  1403: aload_0        
        //  1404: getfield        com/google/ads/internal/c.t:Z
        //  1407: ifeq            1446
        //  1410: aload_0        
        //  1411: getfield        com/google/ads/internal/c.j:Lcom/google/ads/l;
        //  1414: getfield        com/google/ads/l.a:Lcom/google/ads/util/i$b;
        //  1417: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1420: checkcast       Lcom/google/ads/n;
        //  1423: getfield        com/google/ads/n.g:Lcom/google/ads/util/i$b;
        //  1426: invokevirtual   com/google/ads/util/i$b.a:()Ljava/lang/Object;
        //  1429: checkcast       Lcom/google/ads/internal/h;
        //  1432: invokevirtual   com/google/ads/internal/h.b:()Z
        //  1435: ifeq            1499
        //  1438: aload           10
        //  1440: invokevirtual   com/google/ads/internal/i.a:()Z
        //  1443: ifeq            1499
        //  1446: lload           4
        //  1448: invokestatic    android/os/SystemClock.elapsedRealtime:()J
        //  1451: lload           6
        //  1453: lsub           
        //  1454: lsub           
        //  1455: lstore          12
        //  1457: lload           12
        //  1459: lconst_0       
        //  1460: lcmp           
        //  1461: ifle            1499
        //  1464: aload_0        
        //  1465: lload           12
        //  1467: invokevirtual   java/lang/Object.wait:(J)V
        //  1470: goto            1396
        //  1473: astore          11
        //  1475: new             Ljava/lang/StringBuilder;
        //  1478: dup            
        //  1479: ldc_w           "AdLoader InterruptedException while loading the HTML: "
        //  1482: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1485: aload           11
        //  1487: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //  1490: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1493: invokestatic    com/google/ads/util/b.a:(Ljava/lang/String;)V
        //  1496: aload_0        
        //  1497: monitorexit    
        //  1498: return         
        //  1499: aload_0        
        //  1500: getfield        com/google/ads/internal/c.t:Z
        //  1503: ifeq            1513
        //  1506: aload_0        
        //  1507: invokespecial   com/google/ads/internal/c.j:()V
        //  1510: goto            465
        //  1513: new             Ljava/lang/StringBuilder;
        //  1516: dup            
        //  1517: ldc_w           "AdLoader timed out after "
        //  1520: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1523: lload           4
        //  1525: invokevirtual   java/lang/StringBuilder.append:(J)Ljava/lang/StringBuilder;
        //  1528: ldc_w           "ms while loading the HTML."
        //  1531: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1534: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1537: invokestatic    com/google/ads/util/b.c:(Ljava/lang/String;)V
        //  1540: aload_0        
        //  1541: getstatic       com/google/ads/AdRequest$ErrorCode.NETWORK_ERROR:Lcom/google/ads/AdRequest$ErrorCode;
        //  1544: iconst_1       
        //  1545: invokevirtual   com/google/ads/internal/c.a:(Lcom/google/ads/AdRequest$ErrorCode;Z)V
        //  1548: goto            465
        //  1551: aload           16
        //  1553: astore          10
        //  1555: goto            1111
        //  1558: aconst_null    
        //  1559: astore          16
        //  1561: goto            829
        //  1564: aconst_null    
        //  1565: astore          10
        //  1567: goto            1111
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  2      16     449    465    Ljava/lang/Throwable;
        //  2      16     77     82     Any
        //  16     30     449    465    Ljava/lang/Throwable;
        //  16     30     77     82     Any
        //  30     32     77     82     Any
        //  33     56     449    465    Ljava/lang/Throwable;
        //  33     56     77     82     Any
        //  60     74     449    465    Ljava/lang/Throwable;
        //  60     74     77     82     Any
        //  74     76     77     82     Any
        //  82     201    449    465    Ljava/lang/Throwable;
        //  82     201    77     82     Any
        //  201    230    449    465    Ljava/lang/Throwable;
        //  201    230    77     82     Any
        //  230    259    449    465    Ljava/lang/Throwable;
        //  230    259    77     82     Any
        //  259    295    449    465    Ljava/lang/Throwable;
        //  259    295    77     82     Any
        //  295    351    449    465    Ljava/lang/Throwable;
        //  295    351    77     82     Any
        //  351    364    449    465    Ljava/lang/Throwable;
        //  351    364    77     82     Any
        //  369    378    468    502    Lcom/google/ads/internal/c$b;
        //  369    378    449    465    Ljava/lang/Throwable;
        //  369    378    77     82     Any
        //  378    393    449    465    Ljava/lang/Throwable;
        //  378    393    77     82     Any
        //  410    416    502    528    Ljava/lang/InterruptedException;
        //  410    416    449    465    Ljava/lang/Throwable;
        //  410    416    77     82     Any
        //  416    422    449    465    Ljava/lang/Throwable;
        //  416    422    77     82     Any
        //  427    429    77     82     Any
        //  430    446    449    465    Ljava/lang/Throwable;
        //  430    446    77     82     Any
        //  450    465    77     82     Any
        //  465    467    77     82     Any
        //  470    499    449    465    Ljava/lang/Throwable;
        //  470    499    77     82     Any
        //  499    501    77     82     Any
        //  504    525    449    465    Ljava/lang/Throwable;
        //  504    525    77     82     Any
        //  525    527    77     82     Any
        //  528    544    449    465    Ljava/lang/Throwable;
        //  528    544    77     82     Any
        //  544    546    77     82     Any
        //  547    589    449    465    Ljava/lang/Throwable;
        //  547    589    77     82     Any
        //  589    591    77     82     Any
        //  592    644    449    465    Ljava/lang/Throwable;
        //  592    644    77     82     Any
        //  644    646    77     82     Any
        //  647    716    449    465    Ljava/lang/Throwable;
        //  647    716    77     82     Any
        //  716    825    449    465    Ljava/lang/Throwable;
        //  716    825    77     82     Any
        //  829    840    449    465    Ljava/lang/Throwable;
        //  829    840    77     82     Any
        //  840    872    888    914    Ljava/lang/InterruptedException;
        //  840    872    449    465    Ljava/lang/Throwable;
        //  840    872    77     82     Any
        //  879    885    888    914    Ljava/lang/InterruptedException;
        //  879    885    449    465    Ljava/lang/Throwable;
        //  879    885    77     82     Any
        //  890    911    449    465    Ljava/lang/Throwable;
        //  890    911    77     82     Any
        //  911    913    77     82     Any
        //  914    935    449    465    Ljava/lang/Throwable;
        //  914    935    77     82     Any
        //  938    949    449    465    Ljava/lang/Throwable;
        //  938    949    77     82     Any
        //  952    968    449    465    Ljava/lang/Throwable;
        //  952    968    77     82     Any
        //  971    996    449    465    Ljava/lang/Throwable;
        //  971    996    77     82     Any
        //  996    998    77     82     Any
        //  999    1005   449    465    Ljava/lang/Throwable;
        //  999    1005   77     82     Any
        //  1010   1012   77     82     Any
        //  1013   1029   449    465    Ljava/lang/Throwable;
        //  1013   1029   77     82     Any
        //  1029   1031   77     82     Any
        //  1032   1074   449    465    Ljava/lang/Throwable;
        //  1032   1074   77     82     Any
        //  1074   1076   77     82     Any
        //  1077   1108   449    465    Ljava/lang/Throwable;
        //  1077   1108   77     82     Any
        //  1111   1155   449    465    Ljava/lang/Throwable;
        //  1111   1155   77     82     Any
        //  1155   1157   77     82     Any
        //  1158   1191   449    465    Ljava/lang/Throwable;
        //  1158   1191   77     82     Any
        //  1191   1228   449    465    Ljava/lang/Throwable;
        //  1191   1228   77     82     Any
        //  1228   1230   77     82     Any
        //  1231   1274   449    465    Ljava/lang/Throwable;
        //  1231   1274   77     82     Any
        //  1274   1276   77     82     Any
        //  1277   1345   449    465    Ljava/lang/Throwable;
        //  1277   1345   77     82     Any
        //  1345   1347   77     82     Any
        //  1348   1366   449    465    Ljava/lang/Throwable;
        //  1348   1366   77     82     Any
        //  1366   1396   449    465    Ljava/lang/Throwable;
        //  1366   1396   77     82     Any
        //  1396   1446   1473   1499   Ljava/lang/InterruptedException;
        //  1396   1446   449    465    Ljava/lang/Throwable;
        //  1396   1446   77     82     Any
        //  1446   1457   1473   1499   Ljava/lang/InterruptedException;
        //  1446   1457   449    465    Ljava/lang/Throwable;
        //  1446   1457   77     82     Any
        //  1464   1470   1473   1499   Ljava/lang/InterruptedException;
        //  1464   1470   449    465    Ljava/lang/Throwable;
        //  1464   1470   77     82     Any
        //  1475   1496   449    465    Ljava/lang/Throwable;
        //  1475   1496   77     82     Any
        //  1496   1498   77     82     Any
        //  1499   1510   449    465    Ljava/lang/Throwable;
        //  1499   1510   77     82     Any
        //  1513   1548   449    465    Ljava/lang/Throwable;
        //  1513   1548   77     82     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index: 669, Size: 669
        //     at java.util.ArrayList.rangeCheck(ArrayList.java:635)
        //     at java.util.ArrayList.get(ArrayList.java:411)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(Unknown Source)
        //     at com.strobel.decompiler.ast.AstBuilder.build(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(Unknown Source)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(Unknown Source)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(Unknown Source)
        //     at a.l.a(Unknown Source)
        //     at gui.b$1.a(Unknown Source)
        //     at a.k.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at a.m.a(Unknown Source)
        //     at gui.b.call(Unknown Source)
        //     at javafx.concurrent.Task$TaskCallable.call(Task.java:1259)
        //     at java.util.concurrent.FutureTask.run(FutureTask.java:262)
        //     at java.lang.Thread.run(Thread.java:744)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
