package com.google.ads.internal;

import android.view.ViewGroup;
import com.google.ads.AdRequest$ErrorCode;
import android.webkit.WebView;

class c$a implements Runnable
{
    private final d a;
    private final WebView b;
    private final f c;
    private final AdRequest$ErrorCode d;
    private final boolean e;
    
    public c$a(final d a, final WebView b, final f c, final AdRequest$ErrorCode d, final boolean e) {
        super();
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    @Override
    public void run() {
        if (this.b != null) {
            this.b.stopLoading();
            this.b.destroy();
        }
        if (this.c != null) {
            this.c.a();
        }
        if (this.e) {
            this.a.l().stopLoading();
            if (this.a.i().i.a() != null) {
                ((ViewGroup)this.a.i().i.a()).setVisibility(8);
            }
        }
        this.a.a(this.d);
    }
}
