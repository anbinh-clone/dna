package com.google.ads.internal;

import android.util.DisplayMetrics;
import com.google.ads.m$a;
import android.telephony.TelephonyManager;
import android.content.pm.PackageManager$NameNotFoundException;
import java.util.HashMap;
import com.google.ads.AdView;
import com.google.ads.ai;
import com.google.ads.al;
import android.content.Context;
import com.google.ads.ak;
import android.text.TextUtils;
import com.google.ads.util.AdUtil;
import java.util.Map;
import com.google.ads.searchads.SearchAdRequest;
import com.google.ads.m;
import android.os.Handler;
import java.util.regex.Matcher;
import java.util.Locale;
import java.util.regex.Pattern;
import com.google.ads.d;
import com.google.ads.c;
import com.google.ads.util.b;
import android.webkit.WebViewClient;
import android.app.Activity;
import com.google.ads.AdRequest$ErrorCode;
import com.google.ads.AdSize;
import java.util.LinkedList;
import com.google.ads.l;
import android.webkit.WebView;
import com.google.ads.AdRequest;
import com.google.ads.n;

class c$1 implements Runnable
{
    final /* synthetic */ c a;
    
    c$1(final c a) {
        this.a = a;
        super();
    }
    
    @Override
    public void run() {
        ((ActivationOverlay)((n)this.a.j.a.a()).e.a()).loadUrl(this.a.l);
    }
}
