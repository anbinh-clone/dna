package com.google.ads.internal;

import android.util.DisplayMetrics;
import com.google.ads.m$a;
import android.telephony.TelephonyManager;
import android.content.pm.PackageManager$NameNotFoundException;
import java.util.HashMap;
import com.google.ads.AdView;
import com.google.ads.ai;
import com.google.ads.al;
import android.content.Context;
import com.google.ads.ak;
import android.text.TextUtils;
import com.google.ads.util.AdUtil;
import java.util.Map;
import com.google.ads.searchads.SearchAdRequest;
import com.google.ads.m;
import android.os.Handler;
import java.util.regex.Matcher;
import java.util.Locale;
import java.util.regex.Pattern;
import com.google.ads.d;
import com.google.ads.util.b;
import android.webkit.WebViewClient;
import android.app.Activity;
import com.google.ads.AdRequest$ErrorCode;
import com.google.ads.AdSize;
import java.util.LinkedList;
import com.google.ads.l;
import android.webkit.WebView;
import com.google.ads.AdRequest;
import com.google.ads.n;
import com.google.ads.c;

class c$2 implements Runnable
{
    final /* synthetic */ c a;
    final /* synthetic */ c b;
    
    c$2(final c b, final c a) {
        this.b = b;
        this.a = a;
        super();
    }
    
    @Override
    public void run() {
        if (this.b.i != null) {
            this.b.i.stopLoading();
            this.b.i.destroy();
        }
        ((d)((n)this.b.j.a.a()).b.a()).a(this.b.n);
        if (this.b.o != null) {
            ((h)((n)this.b.j.a.a()).g.a()).b(this.b.o);
        }
        ((d)((n)this.b.j.a.a()).b.a()).a(this.a);
    }
}
