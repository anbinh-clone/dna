package com.google.ads.internal;

import com.google.ads.o;
import com.google.ads.util.AdUtil;
import a.a.c;
import android.webkit.WebView;
import com.google.ads.util.b;
import java.util.HashMap;
import android.net.Uri;
import java.util.Collections;
import java.util.Map;
import com.google.ads.util.f;

final class a$2 implements f
{
    public final a a() {
        return a.e;
    }
}
