package com.google.ads.internal;

import java.io.Serializable;
import android.os.Bundle;
import java.util.HashMap;

public class e
{
    private final String a;
    private HashMap b;
    
    public e(final Bundle bundle) {
        super();
        this.a = bundle.getString("action");
        this.b = this.a(bundle.getSerializable("params"));
    }
    
    public e(final String a) {
        super();
        this.a = a;
    }
    
    public e(final String s, final HashMap b) {
        this(s);
        this.b = b;
    }
    
    private HashMap a(final Serializable s) {
        if (s instanceof HashMap) {
            return (HashMap)s;
        }
        return null;
    }
    
    public Bundle a() {
        final Bundle bundle = new Bundle();
        bundle.putString("action", this.a);
        bundle.putSerializable("params", (Serializable)this.b);
        return bundle;
    }
    
    public String b() {
        return this.a;
    }
    
    public HashMap c() {
        return this.b;
    }
}
