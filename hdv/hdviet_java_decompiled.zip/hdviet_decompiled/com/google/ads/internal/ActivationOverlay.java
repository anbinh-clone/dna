package com.google.ads.internal;

import android.os.Handler;
import android.webkit.WebViewClient;
import com.google.ads.util.b;
import com.google.ads.m;
import com.google.ads.m$a;
import com.google.ads.util.AdUtil;
import com.google.ads.AdSize;
import com.google.ads.n;

public class ActivationOverlay extends AdWebView
{
    private volatile boolean b;
    private boolean c;
    private int d;
    private int e;
    private final i f;
    
    public ActivationOverlay(final n n) {
        super(n, null);
        this.b = true;
        this.c = true;
        this.d = 0;
        this.e = 0;
        if (AdUtil.a < (int)((m$a)((m)n.d.a()).b.a()).c.a()) {
            b.a("Disabling hardware acceleration for an activation overlay.");
            this.g();
        }
        this.setWebViewClient((WebViewClient)(this.f = i.a((d)n.b.a(), a.c, true, true)));
    }
    
    public boolean a() {
        return this.b;
    }
    
    public boolean b() {
        return this.c;
    }
    
    public int c() {
        return this.e;
    }
    
    public boolean canScrollHorizontally(final int n) {
        return false;
    }
    
    public boolean canScrollVertically(final int n) {
        return false;
    }
    
    public int d() {
        return this.d;
    }
    
    public i e() {
        return this.f;
    }
    
    public void setOverlayActivated(final boolean c) {
        this.c = c;
    }
    
    public void setOverlayEnabled(final boolean b) {
        if (!b) {
            ((Handler)m.a().c.a()).post((Runnable)new ActivationOverlay$1(this, this));
        }
        this.b = b;
    }
    
    public void setXPosition(final int d) {
        this.d = d;
    }
    
    public void setYPosition(final int e) {
        this.e = e;
    }
}
