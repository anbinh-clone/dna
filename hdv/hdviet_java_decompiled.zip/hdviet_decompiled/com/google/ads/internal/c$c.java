package com.google.ads.internal;

import android.util.DisplayMetrics;
import com.google.ads.m$a;
import android.telephony.TelephonyManager;
import android.content.pm.PackageManager$NameNotFoundException;
import java.util.HashMap;
import com.google.ads.AdView;
import com.google.ads.ai;
import com.google.ads.al;
import android.content.Context;
import com.google.ads.ak;
import android.text.TextUtils;
import com.google.ads.util.AdUtil;
import java.util.Map;
import com.google.ads.searchads.SearchAdRequest;
import com.google.ads.m;
import android.os.Handler;
import java.util.regex.Matcher;
import java.util.Locale;
import java.util.regex.Pattern;
import com.google.ads.d;
import com.google.ads.c;
import com.google.ads.util.b;
import android.webkit.WebViewClient;
import android.app.Activity;
import com.google.ads.AdRequest$ErrorCode;
import com.google.ads.AdSize;
import java.util.LinkedList;
import com.google.ads.l;
import com.google.ads.AdRequest;
import com.google.ads.n;
import android.webkit.WebView;

class c$c implements Runnable
{
    final /* synthetic */ c a;
    private final String b;
    private final String c;
    private final WebView d;
    
    public c$c(final c a, final WebView d, final String b, final String c) {
        this.a = a;
        super();
        this.d = d;
        this.b = b;
        this.c = c;
    }
    
    @Override
    public void run() {
        this.a.j.c.a(this.a.p);
        ((d)((n)this.a.j.a.a()).b.a()).l().a(this.a.p);
        if (((n)this.a.j.a.a()).e.a() != null) {
            ((ActivationOverlay)((n)this.a.j.a.a()).e.a()).setOverlayEnabled(!this.a.p);
        }
        if (this.c != null) {
            this.d.loadDataWithBaseURL(this.b, this.c, "text/html", "utf-8", (String)null);
            return;
        }
        this.d.loadUrl(this.b);
    }
}
