package com.google.ads.internal;

import android.view.MotionEvent;
import android.view.View;
import android.view.View$OnTouchListener;

class AdWebView$2 implements View$OnTouchListener
{
    final /* synthetic */ AdWebView a;
    
    AdWebView$2(final AdWebView a) {
        this.a = a;
        super();
    }
    
    public boolean onTouch(final View view, final MotionEvent motionEvent) {
        return motionEvent.getAction() == 2;
    }
}
