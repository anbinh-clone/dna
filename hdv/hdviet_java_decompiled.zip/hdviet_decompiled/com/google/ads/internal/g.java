package com.google.ads.internal;

import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Iterator;
import com.google.ads.g$a;
import com.google.ads.util.b;
import android.os.SystemClock;
import java.util.LinkedList;

public class g
{
    private static long f;
    private static long g;
    private static long h;
    private static long i;
    private static long j;
    private final LinkedList a;
    private long b;
    private long c;
    private long d;
    private final LinkedList e;
    private boolean k;
    private boolean l;
    private String m;
    private long n;
    private final LinkedList o;
    private final LinkedList p;
    
    static {
        g.f = 0L;
        g.g = 0L;
        g.h = 0L;
        g.i = 0L;
        g.j = -1L;
    }
    
    public g() {
        super();
        this.k = false;
        this.l = false;
        this.a = new LinkedList();
        this.e = new LinkedList();
        this.o = new LinkedList();
        this.p = new LinkedList();
        this.a();
    }
    
    public static long E() {
        if (g.j == -1L) {
            g.j = SystemClock.elapsedRealtime();
            return 0L;
        }
        return SystemClock.elapsedRealtime() - g.j;
    }
    
    protected boolean A() {
        return this.l;
    }
    
    protected void B() {
        b.d("Interstitial no fill.");
        this.l = true;
    }
    
    public void C() {
        b.d("Landing page dismissed.");
        this.e.add(SystemClock.elapsedRealtime());
    }
    
    protected String D() {
        return this.m;
    }
    
    protected void a() {
        synchronized (this) {
            this.a.clear();
            this.b = 0L;
            this.c = 0L;
            this.d = 0L;
            this.e.clear();
            this.n = -1L;
            this.o.clear();
            this.p.clear();
            this.k = false;
            this.l = false;
        }
    }
    
    public void a(final g$a g$a) {
        synchronized (this) {
            this.o.add(SystemClock.elapsedRealtime() - this.n);
            this.p.add(g$a);
        }
    }
    
    public void a(final String m) {
        b.d("Prior impression ticket = " + m);
        this.m = m;
    }
    
    public void b() {
        synchronized (this) {
            this.o.clear();
            this.p.clear();
        }
    }
    
    public void c() {
        synchronized (this) {
            this.n = SystemClock.elapsedRealtime();
        }
    }
    
    public String d() {
        final StringBuilder sb;
        synchronized (this) {
            sb = new StringBuilder();
            for (final long longValue : this.o) {
                if (sb.length() > 0) {
                    sb.append(",");
                }
                sb.append(longValue);
            }
        }
        // monitorexit(this)
        // monitorexit(this)
        return sb.toString();
    }
    
    public String e() {
        final StringBuilder sb;
        synchronized (this) {
            sb = new StringBuilder();
            for (final g$a g$a : this.p) {
                if (sb.length() > 0) {
                    sb.append(",");
                }
                sb.append(g$a.ordinal());
            }
        }
        // monitorexit(this)
        // monitorexit(this)
        return sb.toString();
    }
    
    protected void f() {
        b.d("Ad clicked.");
        this.a.add(SystemClock.elapsedRealtime());
    }
    
    protected void g() {
        b.d("Ad request loaded.");
        this.b = SystemClock.elapsedRealtime();
    }
    
    protected void h() {
        synchronized (this) {
            b.d("Ad request before rendering.");
            this.c = SystemClock.elapsedRealtime();
        }
    }
    
    protected void i() {
        b.d("Ad request started.");
        this.d = SystemClock.elapsedRealtime();
        g.f += 1L;
    }
    
    protected long j() {
        if (this.a.size() != this.e.size()) {
            return -1L;
        }
        return this.a.size();
    }
    
    protected String k() {
        if (this.a.isEmpty() || this.a.size() != this.e.size()) {
            return null;
        }
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.a.size(); ++i) {
            if (i != 0) {
                sb.append(",");
            }
            sb.append(Long.toString((long)this.e.get(i) - (long)this.a.get(i)));
        }
        return sb.toString();
    }
    
    protected String l() {
        if (this.a.isEmpty()) {
            return null;
        }
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.a.size(); ++i) {
            if (i != 0) {
                sb.append(",");
            }
            sb.append(Long.toString((long)this.a.get(i) - this.b));
        }
        return sb.toString();
    }
    
    protected long m() {
        return this.b - this.d;
    }
    
    protected long n() {
        synchronized (this) {
            return this.c - this.d;
        }
    }
    
    protected long o() {
        return g.f;
    }
    
    protected long p() {
        synchronized (this) {
            return g.g;
        }
    }
    
    protected void q() {
        synchronized (this) {
            b.d("Ad request network error");
            g.g += 1L;
        }
    }
    
    protected void r() {
        synchronized (this) {
            g.g = 0L;
        }
    }
    
    protected long s() {
        synchronized (this) {
            return g.h;
        }
    }
    
    protected void t() {
        synchronized (this) {
            g.h += 1L;
        }
    }
    
    protected void u() {
        synchronized (this) {
            g.h = 0L;
        }
    }
    
    protected long v() {
        synchronized (this) {
            return g.i;
        }
    }
    
    protected void w() {
        synchronized (this) {
            g.i += 1L;
        }
    }
    
    protected void x() {
        synchronized (this) {
            g.i = 0L;
        }
    }
    
    protected boolean y() {
        return this.k;
    }
    
    protected void z() {
        b.d("Interstitial network error.");
        this.k = true;
    }
}
