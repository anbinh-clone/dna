package com.google.ads.internal;

import java.util.Iterator;
import java.util.ArrayList;
import android.content.DialogInterface$OnClickListener;
import android.content.Context;
import android.app.AlertDialog$Builder;
import com.google.ads.util.b;
import android.gesture.Prediction;
import android.gesture.Gesture;
import android.gesture.GestureOverlayView;
import android.app.Activity;
import android.gesture.GestureStore;
import android.gesture.GestureOverlayView$OnGesturePerformedListener;

public class k$a implements GestureOverlayView$OnGesturePerformedListener
{
    private final GestureStore a;
    private Activity b;
    private d c;
    
    public k$a(final Activity b, final d c, final GestureStore a) {
        super();
        this.b = b;
        this.c = c;
        this.a = a;
    }
    
    public void onGesturePerformed(final GestureOverlayView gestureOverlayView, final Gesture gesture) {
        final ArrayList recognize = this.a.recognize(gesture);
        for (final Prediction prediction : recognize) {
            b.a("Gesture: '" + prediction.name + "' = " + prediction.score);
        }
        if (recognize.size() == 0) {
            b.a("Gesture: No remotely reasonable predictions");
        }
        else if (recognize.get(0).score > 2.0 && "debug".equals(recognize.get(0).name) && this.c != null) {
            String c;
            if (this.c.c() == null) {
                c = "[No diagnostics available]";
            }
            else {
                c = this.c.c();
            }
            new AlertDialog$Builder((Context)this.b).setMessage((CharSequence)c).setTitle((CharSequence)"Ad Information").setPositiveButton((CharSequence)"Share", (DialogInterface$OnClickListener)new k$a$3(this, c)).setNeutralButton((CharSequence)"Report", (DialogInterface$OnClickListener)new k$a$2(this)).setNegativeButton((CharSequence)"Close", (DialogInterface$OnClickListener)new k$a$1(this)).create().show();
        }
    }
}
