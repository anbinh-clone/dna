package com.google.ads.internal;

import java.net.HttpURLConnection;
import java.net.URL;

public interface f$a
{
    HttpURLConnection a(URL p0);
}
