package com.google.ads.internal;

public enum c$d
{
    a("ONLINE_USING_BUFFERED_ADS", 0, "online_buffered"), 
    b("ONLINE_SERVER_REQUEST", 1, "online_request"), 
    c("OFFLINE_USING_BUFFERED_ADS", 2, "offline_buffered"), 
    d("OFFLINE_EMPTY", 3, "offline_empty");
    
    public String e;
    
    static {
        f = new c$d[] { c$d.a, c$d.b, c$d.c, c$d.d };
    }
    
    private c$d(final String s, final int n, final String e) {
        this.e = e;
    }
}
