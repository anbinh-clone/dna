package com.google.ads.internal;

import java.net.HttpURLConnection;
import java.net.URL;

class f$1 implements f$a
{
    @Override
    public HttpURLConnection a(final URL url) {
        return (HttpURLConnection)url.openConnection();
    }
}
