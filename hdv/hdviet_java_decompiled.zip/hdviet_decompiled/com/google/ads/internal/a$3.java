package com.google.ads.internal;

import com.google.ads.y;
import com.google.ads.x;
import com.google.ads.w;
import com.google.ads.v;
import java.util.HashMap;

final class a$3 extends HashMap
{
    a$3() {
        super();
        this.put("/invalidRequest", new v());
        this.put("/loadAdURL", new w());
        this.put("/loadSdkConstants", new x());
        this.put("/log", new y());
    }
}
