package com.google.ads.internal;

import com.google.ads.util.b;
import com.google.ads.m;
import android.os.Handler;
import java.lang.ref.WeakReference;

class AdVideoView$a implements Runnable
{
    private final WeakReference a;
    
    public AdVideoView$a(final AdVideoView adVideoView) {
        super();
        this.a = new WeakReference(adVideoView);
    }
    
    public void a() {
        ((Handler)m.a().c.a()).postDelayed((Runnable)this, 250L);
    }
    
    @Override
    public void run() {
        final AdVideoView adVideoView = (AdVideoView)this.a.get();
        if (adVideoView == null) {
            b.d("The video must be gone, so cancelling the timeupdate task.");
            return;
        }
        adVideoView.f();
        ((Handler)m.a().c.a()).postDelayed((Runnable)this, 250L);
    }
}
