package com.google.ads.internal;

class c$b extends Exception
{
    final /* synthetic */ c a;
    
    public c$b(final c a, final String s) {
        this.a = a;
        super(s);
    }
}
