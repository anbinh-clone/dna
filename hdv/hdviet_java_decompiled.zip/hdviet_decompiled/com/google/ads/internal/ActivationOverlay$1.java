package com.google.ads.internal;

import android.view.View;
import com.google.ads.AdView;

class ActivationOverlay$1 implements Runnable
{
    final /* synthetic */ ActivationOverlay a;
    final /* synthetic */ ActivationOverlay b;
    
    ActivationOverlay$1(final ActivationOverlay b, final ActivationOverlay a) {
        this.b = b;
        this.a = a;
        super();
    }
    
    @Override
    public void run() {
        ((AdView)this.b.a.j.a()).removeView((View)this.a);
    }
}
