package com.google.ads.internal;

import com.google.ads.util.b;
import a.a.c;

public class j$a
{
    private final String a;
    
    public j$a(final String a) {
        super();
        this.a = a;
    }
    
    public c a() {
        final c c = new c();
        try {
            c.a("debugHeader", (Object)this.a);
            return c;
        }
        catch (a.a.b b) {
            b.b("Could not build ReportAdJson from inputs.", b);
            return c;
        }
    }
}
