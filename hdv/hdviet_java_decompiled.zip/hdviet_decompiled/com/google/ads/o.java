package com.google.ads;

import android.webkit.WebView;
import java.util.HashMap;
import com.google.ads.internal.d;

public interface o
{
    void a(d p0, HashMap p1, WebView p2);
}
