package com.google.ads.mediation.admob;

import com.google.ads.mediation.MediationServerParameters;
import android.view.View;
import com.google.ads.AdSize;
import android.content.Context;
import com.google.ads.util.AdUtil;
import com.google.ads.mediation.NetworkExtras;
import com.google.ads.AdRequest;
import com.google.ads.mediation.MediationAdRequest;
import android.app.Activity;
import com.google.ads.InterstitialAd;
import com.google.ads.AdView;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.AdRequest$ErrorCode;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.Ad;
import com.google.ads.AdListener;

class AdMobAdapter$b implements AdListener
{
    final /* synthetic */ AdMobAdapter a;
    
    private AdMobAdapter$b(final AdMobAdapter a) {
        this.a = a;
        super();
    }
    
    @Override
    public void onDismissScreen(final Ad ad) {
        this.a.b.onDismissScreen(this.a);
    }
    
    @Override
    public void onFailedToReceiveAd(final Ad ad, final AdRequest$ErrorCode adRequest$ErrorCode) {
        this.a.b.onFailedToReceiveAd(this.a, adRequest$ErrorCode);
    }
    
    @Override
    public void onLeaveApplication(final Ad ad) {
        this.a.b.onLeaveApplication(this.a);
    }
    
    @Override
    public void onPresentScreen(final Ad ad) {
        this.a.b.onPresentScreen(this.a);
    }
    
    @Override
    public void onReceiveAd(final Ad ad) {
        this.a.b.onReceivedAd(this.a);
    }
}
