package com.google.ads.mediation.admob;

import com.google.ads.mediation.MediationServerParameters;

public final class AdMobAdapterServerParameters extends MediationServerParameters
{
    public String adUnitId;
    public String allowHouseAds;
    
    public AdMobAdapterServerParameters() {
        super();
        this.allowHouseAds = null;
    }
}
