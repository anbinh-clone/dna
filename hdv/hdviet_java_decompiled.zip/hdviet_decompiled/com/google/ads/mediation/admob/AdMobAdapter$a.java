package com.google.ads.mediation.admob;

import com.google.ads.mediation.MediationServerParameters;
import android.view.View;
import com.google.ads.AdSize;
import android.content.Context;
import com.google.ads.util.AdUtil;
import com.google.ads.mediation.NetworkExtras;
import com.google.ads.AdRequest;
import com.google.ads.mediation.MediationAdRequest;
import android.app.Activity;
import com.google.ads.InterstitialAd;
import com.google.ads.AdView;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.AdRequest$ErrorCode;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.Ad;
import com.google.ads.AdListener;

class AdMobAdapter$a implements AdListener
{
    final /* synthetic */ AdMobAdapter a;
    
    private AdMobAdapter$a(final AdMobAdapter a) {
        this.a = a;
        super();
    }
    
    @Override
    public void onDismissScreen(final Ad ad) {
        this.a.a.onDismissScreen(this.a);
    }
    
    @Override
    public void onFailedToReceiveAd(final Ad ad, final AdRequest$ErrorCode adRequest$ErrorCode) {
        this.a.a.onFailedToReceiveAd(this.a, adRequest$ErrorCode);
    }
    
    @Override
    public void onLeaveApplication(final Ad ad) {
        this.a.a.onLeaveApplication(this.a);
    }
    
    @Override
    public void onPresentScreen(final Ad ad) {
        this.a.a.onClick(this.a);
        this.a.a.onPresentScreen(this.a);
    }
    
    @Override
    public void onReceiveAd(final Ad ad) {
        this.a.a.onReceivedAd(this.a);
    }
}
