package com.google.ads.mediation.admob;

class AdMobAdapter$1
{
}
