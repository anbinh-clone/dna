package com.google.ads.mediation;

import com.google.ads.AdSize;
import android.app.Activity;
import android.view.View;

public interface MediationBannerAdapter extends MediationAdapter
{
    View getBannerView();
    
    void requestBannerAd(MediationBannerListener p0, Activity p1, MediationServerParameters p2, AdSize p3, MediationAdRequest p4, NetworkExtras p5);
}
