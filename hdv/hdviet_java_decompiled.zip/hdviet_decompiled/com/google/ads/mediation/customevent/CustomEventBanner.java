package com.google.ads.mediation.customevent;

import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.AdSize;
import android.app.Activity;

public interface CustomEventBanner extends CustomEvent
{
    void requestBannerAd(CustomEventBannerListener p0, Activity p1, String p2, String p3, AdSize p4, MediationAdRequest p5, Object p6);
}
