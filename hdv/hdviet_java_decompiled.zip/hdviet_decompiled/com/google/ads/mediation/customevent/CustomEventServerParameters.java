package com.google.ads.mediation.customevent;

import com.google.ads.mediation.MediationServerParameters;

public class CustomEventServerParameters extends MediationServerParameters
{
    public String className;
    public String label;
    public String parameter;
    
    public CustomEventServerParameters() {
        super();
        this.parameter = null;
    }
}
