package com.google.ads.mediation.customevent;

public interface CustomEventInterstitialListener extends CustomEventListener
{
    void onReceivedAd();
}
