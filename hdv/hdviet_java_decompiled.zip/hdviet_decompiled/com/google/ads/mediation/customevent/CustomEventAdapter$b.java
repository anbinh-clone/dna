package com.google.ads.mediation.customevent;

import com.google.ads.mediation.NetworkExtras;
import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.AdSize;
import com.google.ads.mediation.MediationServerParameters;
import android.app.Activity;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.util.a;
import android.view.View;
import com.google.ads.g;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.AdRequest$ErrorCode;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.util.b;
import com.google.ads.mediation.MediationInterstitialListener;

class CustomEventAdapter$b implements CustomEventInterstitialListener
{
    final /* synthetic */ CustomEventAdapter a;
    private final MediationInterstitialListener b;
    
    public CustomEventAdapter$b(final CustomEventAdapter a, final MediationInterstitialListener b) {
        this.a = a;
        super();
        this.b = b;
    }
    
    private String a() {
        return "Interstitial custom event labeled '" + this.a.a + "'";
    }
    
    @Override
    public void onDismissScreen() {
        b.a(this.a() + " called onDismissScreen().");
        this.b.onDismissScreen(this.a);
    }
    
    @Override
    public void onFailedToReceiveAd() {
        b.a(this.a() + " called onFailedToReceiveAd().");
        this.b.onFailedToReceiveAd(this.a, AdRequest$ErrorCode.NO_FILL);
    }
    
    @Override
    public void onLeaveApplication() {
        synchronized (this) {
            b.a(this.a() + " called onLeaveApplication().");
            this.b.onLeaveApplication(this.a);
        }
    }
    
    @Override
    public void onPresentScreen() {
        b.a(this.a() + " called onPresentScreen().");
        this.b.onPresentScreen(this.a);
    }
    
    @Override
    public void onReceivedAd() {
        b.a(this.a() + " called onReceivedAd.");
        this.b.onReceivedAd(this.a);
    }
}
