package com.google.ads.mediation.customevent;

import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.AdRequest$ErrorCode;
import com.google.ads.mediation.NetworkExtras;
import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.AdSize;
import com.google.ads.mediation.MediationServerParameters;
import android.app.Activity;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.util.a;
import android.view.View;
import com.google.ads.util.b;
import com.google.ads.g;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationBannerAdapter;

public class CustomEventAdapter implements MediationBannerAdapter, MediationInterstitialAdapter
{
    private String a;
    private CustomEventBanner b;
    private CustomEventAdapter$a c;
    private CustomEventInterstitial d;
    
    public CustomEventAdapter() {
        super();
        this.b = null;
        this.c = null;
        this.d = null;
    }
    
    private Object a(final String s, final Class clazz, final String s2) {
        try {
            return g.a(s, clazz);
        }
        catch (ClassNotFoundException ex) {
            this.a("Make sure you created a visible class named: " + s + ". ", ex);
        }
        catch (ClassCastException ex2) {
            this.a("Make sure your custom event implements the " + clazz.getName() + " interface.", ex2);
            goto Label_0039;
        }
        catch (IllegalAccessException ex3) {
            this.a("Make sure the default constructor for class " + s + " is visible. ", ex3);
            goto Label_0039;
        }
        catch (InstantiationException ex4) {
            this.a("Make sure the name " + s + " does not denote an abstract class or an interface.", ex4);
            goto Label_0039;
        }
        catch (Throwable t) {
            this.a("", t);
            goto Label_0039;
        }
    }
    
    private void a(final String s, final Throwable t) {
        b.b("Error during processing of custom event with label: '" + this.a + "'. Skipping custom event. " + s, t);
    }
    
    @Override
    public void destroy() {
        if (this.b != null) {
            this.b.destroy();
        }
        if (this.d != null) {
            this.d.destroy();
        }
    }
    
    @Override
    public Class getAdditionalParametersType() {
        return CustomEventExtras.class;
    }
    
    @Override
    public View getBannerView() {
        a.b(this.c);
        return this.c.a();
    }
    
    @Override
    public Class getServerParametersType() {
        return CustomEventServerParameters.class;
    }
    
    public void requestBannerAd(final MediationBannerListener mediationBannerListener, final Activity activity, final CustomEventServerParameters customEventServerParameters, final AdSize adSize, final MediationAdRequest mediationAdRequest, final CustomEventExtras customEventExtras) {
        a.a((Object)this.a);
        this.a = customEventServerParameters.label;
        final String className = customEventServerParameters.className;
        final String parameter = customEventServerParameters.parameter;
        this.b = (CustomEventBanner)this.a(className, CustomEventBanner.class, this.a);
        if (this.b == null) {
            mediationBannerListener.onFailedToReceiveAd(this, AdRequest$ErrorCode.INTERNAL_ERROR);
            return;
        }
        while (true) {
            a.a(this.c);
            this.c = new CustomEventAdapter$a(this, mediationBannerListener);
            while (true) {
                try {
                    final CustomEventBanner b = this.b;
                    final CustomEventAdapter$a c = this.c;
                    final String a = this.a;
                    if (customEventExtras == null) {
                        final Object extra = null;
                        b.requestBannerAd(c, activity, a, parameter, adSize, mediationAdRequest, extra);
                        return;
                    }
                }
                catch (Throwable t) {
                    this.a("", t);
                    mediationBannerListener.onFailedToReceiveAd(this, AdRequest$ErrorCode.INTERNAL_ERROR);
                    return;
                }
                final Object extra = customEventExtras.getExtra(this.a);
                continue;
            }
        }
    }
    
    public void requestInterstitialAd(final MediationInterstitialListener mediationInterstitialListener, final Activity activity, final CustomEventServerParameters customEventServerParameters, final MediationAdRequest mediationAdRequest, final CustomEventExtras customEventExtras) {
        a.a((Object)this.a);
        this.a = customEventServerParameters.label;
        final String className = customEventServerParameters.className;
        final String parameter = customEventServerParameters.parameter;
        this.d = (CustomEventInterstitial)this.a(className, CustomEventInterstitial.class, this.a);
        if (this.d == null) {
            mediationInterstitialListener.onFailedToReceiveAd(this, AdRequest$ErrorCode.INTERNAL_ERROR);
            return;
        }
        while (true) {
            while (true) {
                try {
                    final CustomEventInterstitial d = this.d;
                    final CustomEventAdapter$b customEventAdapter$b = new CustomEventAdapter$b(this, mediationInterstitialListener);
                    final String a = this.a;
                    if (customEventExtras == null) {
                        final Object extra = null;
                        d.requestInterstitialAd(customEventAdapter$b, activity, a, parameter, mediationAdRequest, extra);
                        return;
                    }
                }
                catch (Throwable t) {
                    this.a("", t);
                    mediationInterstitialListener.onFailedToReceiveAd(this, AdRequest$ErrorCode.INTERNAL_ERROR);
                    return;
                }
                final Object extra = customEventExtras.getExtra(this.a);
                continue;
            }
        }
    }
    
    @Override
    public void showInterstitial() {
        a.b(this.d);
        try {
            this.d.showInterstitial();
        }
        catch (Throwable t) {
            b.b("Exception when showing custom event labeled '" + this.a + "'.", t);
        }
    }
}
