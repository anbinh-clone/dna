package com.google.ads.mediation.customevent;

import java.util.HashMap;
import com.google.ads.mediation.NetworkExtras;

public class CustomEventExtras implements NetworkExtras
{
    private final HashMap a;
    
    public CustomEventExtras() {
        super();
        this.a = new HashMap();
    }
    
    public CustomEventExtras addExtra(final String s, final Object o) {
        this.a.put(s, o);
        return this;
    }
    
    public CustomEventExtras clearExtras() {
        this.a.clear();
        return this;
    }
    
    public Object getExtra(final String s) {
        return this.a.get(s);
    }
    
    public Object removeExtra(final String s) {
        return this.a.remove(s);
    }
}
