package com.google.ads.mediation.customevent;

import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.NetworkExtras;
import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.AdSize;
import com.google.ads.mediation.MediationServerParameters;
import android.app.Activity;
import com.google.ads.util.a;
import com.google.ads.g;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.AdRequest$ErrorCode;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.util.b;
import com.google.ads.mediation.MediationBannerListener;
import android.view.View;

class CustomEventAdapter$a implements CustomEventBannerListener
{
    final /* synthetic */ CustomEventAdapter a;
    private View b;
    private final MediationBannerListener c;
    
    public CustomEventAdapter$a(final CustomEventAdapter a, final MediationBannerListener c) {
        this.a = a;
        super();
        this.c = c;
    }
    
    private String b() {
        return "Banner custom event labeled '" + this.a.a + "'";
    }
    
    public View a() {
        synchronized (this) {
            return this.b;
        }
    }
    
    @Override
    public void onClick() {
        b.a(this.b() + " called onClick().");
        this.c.onClick(this.a);
    }
    
    @Override
    public void onDismissScreen() {
        b.a(this.b() + " called onDismissScreen().");
        this.c.onDismissScreen(this.a);
    }
    
    @Override
    public void onFailedToReceiveAd() {
        b.a(this.b() + " called onFailedToReceiveAd().");
        this.c.onFailedToReceiveAd(this.a, AdRequest$ErrorCode.NO_FILL);
    }
    
    @Override
    public void onLeaveApplication() {
        synchronized (this) {
            b.a(this.b() + " called onLeaveApplication().");
            this.c.onLeaveApplication(this.a);
        }
    }
    
    @Override
    public void onPresentScreen() {
        b.a(this.b() + " called onPresentScreen().");
        this.c.onPresentScreen(this.a);
    }
    
    @Override
    public void onReceivedAd(final View b) {
        synchronized (this) {
            b.a(this.b() + " called onReceivedAd.");
            this.b = b;
            this.c.onReceivedAd(this.a);
        }
    }
}
