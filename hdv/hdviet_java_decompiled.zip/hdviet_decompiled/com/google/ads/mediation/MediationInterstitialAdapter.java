package com.google.ads.mediation;

import android.app.Activity;

public interface MediationInterstitialAdapter extends MediationAdapter
{
    void requestInterstitialAd(MediationInterstitialListener p0, Activity p1, MediationServerParameters p2, MediationAdRequest p3, NetworkExtras p4);
    
    void showInterstitial();
}
