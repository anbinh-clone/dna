package com.google.ads.mediation;

public class MediationServerParameters$MappingException extends Exception
{
    public MediationServerParameters$MappingException(final String s) {
        super(s);
    }
}
