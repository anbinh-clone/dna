package com.google.ads.mediation;

import java.util.Iterator;
import com.google.ads.util.b;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public abstract class MediationServerParameters
{
    protected void a() {
    }
    
    public void load(final Map map) {
        final HashMap<Object, Field> hashMap = new HashMap<Object, Field>();
        for (final Field field : this.getClass().getFields()) {
            final MediationServerParameters$Parameter mediationServerParameters$Parameter = field.getAnnotation(MediationServerParameters$Parameter.class);
            if (mediationServerParameters$Parameter != null) {
                hashMap.put(mediationServerParameters$Parameter.name(), field);
            }
        }
        if (hashMap.isEmpty()) {
            b.e("No server options fields detected.  To suppress this message either add a field with the @Parameter annotation, or override the load() method");
        }
        for (final Map.Entry<Object, V> entry : map.entrySet()) {
            final Field field2 = hashMap.remove(entry.getKey());
            if (field2 != null) {
                try {
                    field2.set(this, entry.getValue());
                }
                catch (IllegalAccessException ex) {
                    b.b("Server Option '" + entry.getKey() + "' could not be set: Illegal Access");
                }
                catch (IllegalArgumentException ex2) {
                    b.b("Server Option '" + entry.getKey() + "' could not be set: Bad Type");
                }
            }
            else {
                b.e("Unexpected Server Option: " + entry.getKey() + " = '" + (String)entry.getValue() + "'");
            }
        }
        String s = null;
        for (final Field field3 : hashMap.values()) {
            String string2;
            if (field3.getAnnotation(MediationServerParameters$Parameter.class).required()) {
                b.b("Required Server Option missing: " + field3.getAnnotation(MediationServerParameters$Parameter.class).name());
                final StringBuilder sb = new StringBuilder();
                String string;
                if (s == null) {
                    string = "";
                }
                else {
                    string = s + ", ";
                }
                string2 = sb.append(string).append(field3.getAnnotation(MediationServerParameters$Parameter.class).name()).toString();
            }
            else {
                string2 = s;
            }
            s = string2;
        }
        if (s != null) {
            throw new MediationServerParameters$MappingException("Required Server Option(s) missing: " + s);
        }
        this.a();
    }
}
