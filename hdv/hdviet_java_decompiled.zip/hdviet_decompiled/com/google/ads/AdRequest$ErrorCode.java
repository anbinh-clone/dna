package com.google.ads;

public enum AdRequest$ErrorCode
{
    INTERNAL_ERROR("INTERNAL_ERROR", 3, "There was an internal error."), 
    INVALID_REQUEST("INVALID_REQUEST", 0, "Invalid Ad request."), 
    NETWORK_ERROR("NETWORK_ERROR", 2, "A network error occurred."), 
    NO_FILL("NO_FILL", 1, "Ad request successful, but no ad returned due to lack of ad inventory.");
    
    private final String a;
    
    static {
        b = new AdRequest$ErrorCode[] { AdRequest$ErrorCode.INVALID_REQUEST, AdRequest$ErrorCode.NO_FILL, AdRequest$ErrorCode.NETWORK_ERROR, AdRequest$ErrorCode.INTERNAL_ERROR };
    }
    
    private AdRequest$ErrorCode(final String s, final int n, final String a) {
        this.a = a;
    }
    
    @Override
    public final String toString() {
        return this.a;
    }
}
