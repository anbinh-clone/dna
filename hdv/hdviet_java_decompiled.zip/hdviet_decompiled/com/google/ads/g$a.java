package com.google.ads;

public enum g$a
{
    a("AD", 0), 
    b("NO_FILL", 1), 
    c("ERROR", 2), 
    d("TIMEOUT", 3), 
    e("NOT_FOUND", 4), 
    f("EXCEPTION", 5);
    
    static {
        g = new g$a[] { g$a.a, g$a.b, g$a.c, g$a.d, g$a.e, g$a.f };
    }
}
