package com.google.ads;

import com.google.ads.util.a;
import java.util.List;

public class f
{
    private final String a;
    private final String b;
    private final String c;
    private final List d;
    private final List e;
    private final List f;
    
    public f(final String a, final String b, final String c, final List d, final List e, final List f) {
        super();
        a.a(b);
        if (a != null) {
            a.a(a);
        }
        a.a(c);
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    public String a() {
        return this.a;
    }
    
    public String b() {
        return this.b;
    }
    
    public String c() {
        return this.c;
    }
    
    public List d() {
        return this.d;
    }
    
    public List e() {
        return this.e;
    }
}
