package com.google.ads;

import java.util.Iterator;
import java.util.List;
import android.os.Handler;
import android.os.SystemClock;
import java.util.HashMap;
import android.app.Activity;
import com.google.ads.internal.h;
import com.google.ads.util.a;
import com.google.ads.internal.d;
import com.google.ads.util.b;
import android.view.View;

class e$8 implements Runnable
{
    final /* synthetic */ h a;
    final /* synthetic */ View b;
    final /* synthetic */ f c;
    final /* synthetic */ e d;
    
    e$8(final e d, final h a, final View b, final f c) {
        this.d = d;
        this.a = a;
        this.b = b;
        this.c = c;
        super();
    }
    
    @Override
    public void run() {
        if (this.d.e(this.a)) {
            b.a("Trying to switch GWAdNetworkAmbassadors, but GWController().destroy() has been called. Destroying the new ambassador and terminating mediation.");
            return;
        }
        this.d.a.a(this.b, this.a, this.c, false);
    }
}
