package com.google.ads;

public interface AppEventListener
{
    void onAppEvent(Ad p0, String p1, String p2);
}
