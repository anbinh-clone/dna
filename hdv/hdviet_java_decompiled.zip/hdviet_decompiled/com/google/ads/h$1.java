package com.google.ads;

import com.google.ads.mediation.MediationInterstitialAdapter;
import android.os.Handler;
import android.app.Activity;
import android.text.TextUtils;
import java.util.HashMap;
import android.view.View;
import com.google.ads.mediation.MediationAdapter;
import com.google.ads.internal.h;
import com.google.ads.util.b;
import com.google.ads.util.a;

class h$1 implements Runnable
{
    final /* synthetic */ h a;
    
    h$1(final h a) {
        this.a = a;
        super();
    }
    
    @Override
    public void run() {
        if (!this.a.l()) {
            return;
        }
        a.b(this.a.g);
        try {
            this.a.g.destroy();
            b.a("Called destroy() for adapter with class: " + this.a.g.getClass().getName());
        }
        catch (Throwable t) {
            b.b("Error while destroying adapter (" + this.a.h() + "):", t);
        }
    }
}
