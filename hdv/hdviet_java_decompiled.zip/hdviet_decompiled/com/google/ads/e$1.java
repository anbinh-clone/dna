package com.google.ads;

import java.util.Iterator;
import java.util.List;
import android.view.View;
import android.os.Handler;
import android.os.SystemClock;
import java.util.HashMap;
import android.app.Activity;
import com.google.ads.internal.h;
import com.google.ads.util.b;
import com.google.ads.util.a;
import com.google.ads.internal.d;

class e$1 implements Runnable
{
    final /* synthetic */ c a;
    final /* synthetic */ AdRequest b;
    final /* synthetic */ e c;
    
    e$1(final e c, final c a, final AdRequest b) {
        this.c = c;
        this.a = a;
        this.b = b;
        super();
    }
    
    @Override
    public void run() {
        this.c.b(this.a, this.b);
        synchronized (this.c.e) {
            this.c.d = null;
        }
    }
}
