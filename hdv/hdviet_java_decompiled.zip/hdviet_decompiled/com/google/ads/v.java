package com.google.ads;

import com.google.ads.internal.c;
import com.google.ads.util.b;
import android.webkit.WebView;
import java.util.HashMap;
import com.google.ads.internal.d;

public class v implements o
{
    @Override
    public void a(final d d, final HashMap hashMap, final WebView webView) {
        b.e("Invalid " + hashMap.get("type") + " request error: " + hashMap.get("errors"));
        final c k = d.k();
        if (k != null) {
            k.a(AdRequest$ErrorCode.INVALID_REQUEST);
        }
    }
}
