package com.google.ads;

public final class g
{
    public static Object a(final String s, final Class clazz) {
        return clazz.cast(Class.forName(s).newInstance());
    }
    
    public static String a(final String s, final String s2, final Boolean b, final String s3, final String s4, final String s5, final String s6, final String s7, final String s8, final String s9, final String s10) {
        String s11 = s.replaceAll("@gw_adlocid@", s2).replaceAll("@gw_qdata@", s6).replaceAll("@gw_sdkver@", "afma-sdk-a-v6.4.1").replaceAll("@gw_sessid@", s7).replaceAll("@gw_seqnum@", s8).replaceAll("@gw_devid@", s3);
        if (s5 != null) {
            s11 = s11.replaceAll("@gw_adnetid@", s5);
        }
        if (s4 != null) {
            s11 = s11.replaceAll("@gw_allocid@", s4);
        }
        if (s9 != null) {
            s11 = s11.replaceAll("@gw_adt@", s9);
        }
        if (s10 != null) {
            s11 = s11.replaceAll("@gw_aec@", s10);
        }
        if (b != null) {
            String s12;
            if (b) {
                s12 = "1";
            }
            else {
                s12 = "0";
            }
            return s11.replaceAll("@gw_adnetrefresh@", s12);
        }
        return s11;
    }
}
