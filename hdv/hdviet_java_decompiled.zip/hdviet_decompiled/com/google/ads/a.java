package com.google.ads;

import com.google.ads.util.a;
import java.util.HashMap;
import java.util.List;

public class a
{
    private final String a;
    private final String b;
    private final List c;
    private final List d;
    private final HashMap e;
    
    public a(final String a, final String b, final List c, final List d, final HashMap e) {
        super();
        a.a(b);
        if (a != null) {
            a.a(a);
        }
        this.a = a;
        this.b = b;
        this.c = c;
        this.e = e;
        this.d = d;
    }
    
    public String a() {
        return this.a;
    }
    
    public String b() {
        return this.b;
    }
    
    public List c() {
        return this.c;
    }
    
    public List d() {
        return this.d;
    }
    
    public HashMap e() {
        return this.e;
    }
}
