package com.google.ads;

import java.security.MessageDigest;
import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.io.OutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import android.content.Context;
import java.io.ByteArrayOutputStream;
import android.util.DisplayMetrics;
import android.view.MotionEvent;

public abstract class aj implements ai
{
    protected MotionEvent a;
    protected DisplayMetrics b;
    private au c;
    private ByteArrayOutputStream d;
    
    protected aj(final Context context) {
        super();
        this.c = null;
        this.d = null;
        this.a = null;
        this.b = null;
        try {
            this.b = context.getResources().getDisplayMetrics();
        }
        catch (UnsupportedOperationException ex) {
            this.b = new DisplayMetrics();
            this.b.density = 1.0f;
        }
    }
    
    private String a(final Context context, final String s, final boolean b) {
        try {
            this.a();
            if (b) {
                this.c(context);
            }
            else {
                this.b(context);
            }
            if (this.b().length == 0) {
                return Integer.toString(5);
            }
            goto Label_0046;
        }
        catch (NoSuchAlgorithmException ex) {
            return Integer.toString(7);
        }
        catch (UnsupportedEncodingException ex2) {
            return Integer.toString(7);
        }
        catch (IOException ex3) {
            return Integer.toString(3);
        }
    }
    
    private void a() {
        this.d = new ByteArrayOutputStream();
        this.c = au.a(this.d);
    }
    
    private byte[] b() {
        this.c.a();
        return this.d.toByteArray();
    }
    
    @Override
    public String a(final Context context) {
        return this.a(context, null, false);
    }
    
    @Override
    public String a(final Context context, final String s) {
        return this.a(context, s, true);
    }
    
    String a(byte[] b, final String s) {
        if (b.length > 239) {
            this.a();
            this.a(20, 1L);
            b = this.b();
        }
        byte[] array2;
        if (b.length < 239) {
            final byte[] array = new byte[239 - b.length];
            new SecureRandom().nextBytes(array);
            array2 = ByteBuffer.allocate(240).put((byte)b.length).put(b).put(array).array();
        }
        else {
            array2 = ByteBuffer.allocate(240).put((byte)b.length).put(b).array();
        }
        final MessageDigest instance = MessageDigest.getInstance("MD5");
        instance.update(array2);
        final byte[] array3 = ByteBuffer.allocate(256).put(instance.digest()).put(array2).array();
        final byte[] array4 = new byte[256];
        new ag().a(array3, array4);
        if (s != null && s.length() > 0) {
            this.a(s, array4);
        }
        return aq.a(array4, false);
    }
    
    public void a(final int n, final int n2, final int n3) {
        if (this.a != null) {
            this.a.recycle();
        }
        this.a = MotionEvent.obtain(0L, (long)n3, 1, n * this.b.density, n2 * this.b.density, 0.0f, 0.0f, 0, 0.0f, 0.0f, 0, 0);
    }
    
    protected void a(final int n, final long n2) {
        this.c.a(n, n2);
    }
    
    protected void a(final int n, final String s) {
        this.c.a(n, s);
    }
    
    public void a(final MotionEvent motionEvent) {
        if (motionEvent.getAction() == 1) {
            if (this.a != null) {
                this.a.recycle();
            }
            this.a = MotionEvent.obtain(motionEvent);
        }
    }
    
    void a(String substring, final byte[] array) {
        if (substring.length() > 32) {
            substring = substring.substring(0, 32);
        }
        new ar(substring.getBytes("UTF-8")).a(array);
    }
    
    protected abstract void b(final Context p0);
    
    protected abstract void c(final Context p0);
}
