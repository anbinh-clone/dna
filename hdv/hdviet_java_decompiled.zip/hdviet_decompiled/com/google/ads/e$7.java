package com.google.ads;

import java.util.Iterator;
import java.util.List;
import android.view.View;
import android.os.Handler;
import android.os.SystemClock;
import java.util.HashMap;
import android.app.Activity;
import com.google.ads.internal.h;
import com.google.ads.util.b;
import com.google.ads.util.a;
import com.google.ads.internal.d;

class e$7 implements Runnable
{
    final /* synthetic */ c a;
    final /* synthetic */ e b;
    
    e$7(final e b, final c a) {
        this.b = b;
        this.a = a;
        super();
    }
    
    @Override
    public void run() {
        this.b.a.b(this.a);
    }
}
