package com.google.android.gms.analytics.internal;

import android.os.Parcel;
import android.os.Parcelable$Creator;
import android.os.Parcelable;

public class Command implements Parcelable
{
    public static final String APPEND_CACHE_BUSTER = "appendCacheBuster";
    public static final String APPEND_QUEUE_TIME = "appendQueueTime";
    public static final String APPEND_VERSION = "appendVersion";
    public static final Parcelable$Creator CREATOR;
    private String a;
    private String b;
    private String c;
    
    static {
        CREATOR = new a();
    }
    
    public Command() {
        super();
    }
    
    Command(final Parcel parcel) {
        super();
        this.a = parcel.readString();
        this.b = parcel.readString();
        this.c = parcel.readString();
    }
    
    public int describeContents() {
        return 0;
    }
    
    public void writeToParcel(final Parcel parcel, final int n) {
        parcel.writeString(this.a);
        parcel.writeString(this.b);
        parcel.writeString(this.c);
    }
}
