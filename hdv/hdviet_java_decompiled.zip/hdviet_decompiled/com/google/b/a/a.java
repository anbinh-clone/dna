package com.google.b.a;

public final class a extends IllegalArgumentException
{
    public a() {
        super();
    }
    
    public a(final String s) {
        super(s);
    }
}
