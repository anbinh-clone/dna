package com.google.b.a;

public final class b
{
    private static final char[] a;
    private static final byte[] b;
    
    static {
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
        a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".toCharArray();
        b = new byte[] { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, -9, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -9, -9, -9, -1, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, -9, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9, -9 };
        final byte[] array = { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -9, -9, -9, -1, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, 63, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9, -9 };
    }
    
    private static int a(final char[] array, final byte[] array2, final int n, final byte[] array3) {
        if (array[2] == '=') {
            array2[n] = (byte)((array3[array[0]] << 24 >>> 6 | array3[array[1]] << 24 >>> 12) >>> 16);
            return 1;
        }
        if (array[3] == '=') {
            final int n2 = array3[array[0]] << 24 >>> 6 | array3[array[1]] << 24 >>> 12 | array3[array[2]] << 24 >>> 18;
            array2[n] = (byte)(n2 >>> 16);
            array2[n + 1] = (byte)(n2 >>> 8);
            return 2;
        }
        final int n3 = array3[array[0]] << 24 >>> 6 | array3[array[1]] << 24 >>> 12 | array3[array[2]] << 24 >>> 18 | array3[array[3]] << 24 >>> 24;
        array2[n] = (byte)(n3 >> 16);
        array2[n + 1] = (byte)(n3 >> 8);
        array2[n + 2] = (byte)n3;
        return 3;
    }
    
    @Deprecated
    public static String a(final byte[] array) {
        final int length = array.length;
        final char[] a = b.a;
        final int n = 4 * ((length + 2) / 3);
        final char[] array2 = new char[n + n / Integer.MAX_VALUE];
        final int n2 = length - 2;
        int n3 = 0;
        int n4;
        int i;
        int n6;
        for (n4 = 0, i = 0; i < n2; i += 3, n4 += 4, n3 = n6) {
            final int n5 = array[i + 0] << 24 >>> 8 | array[0 + (i + 1)] << 24 >>> 16 | array[0 + (i + 2)] << 24 >>> 24;
            array2[n4] = a[n5 >>> 18];
            array2[n4 + 1] = a[0x3F & n5 >>> 12];
            array2[n4 + 2] = a[0x3F & n5 >>> 6];
            array2[n4 + 3] = a[n5 & 0x3F];
            n6 = n3 + 4;
            if (n6 == Integer.MAX_VALUE) {
                array2[n4 + 4] = '\n';
                ++n4;
                n6 = 0;
            }
        }
        if (i < length) {
            final int n7 = i + 0;
            final int n8 = length - i;
            int n9;
            if (n8 > 0) {
                n9 = array[n7] << 24 >>> 8;
            }
            else {
                n9 = 0;
            }
            int n10;
            if (n8 > 1) {
                n10 = array[n7 + 1] << 24 >>> 16;
            }
            else {
                n10 = 0;
            }
            final int n11 = n9 | n10;
            int n12;
            if (n8 > 2) {
                n12 = array[n7 + 2] << 24 >>> 24;
            }
            else {
                n12 = 0;
            }
            final int n13 = n12 | n11;
            switch (n8) {
                case 3: {
                    array2[n4] = a[n13 >>> 18];
                    array2[n4 + 1] = a[0x3F & n13 >>> 12];
                    array2[n4 + 2] = a[0x3F & n13 >>> 6];
                    array2[n4 + 3] = a[n13 & 0x3F];
                    break;
                }
                case 2: {
                    array2[n4] = a[n13 >>> 18];
                    array2[n4 + 1] = a[0x3F & n13 >>> 12];
                    array2[n4 + 2] = a[0x3F & n13 >>> 6];
                    array2[n4 + 3] = '=';
                    break;
                }
                case 1: {
                    array2[n4] = a[n13 >>> 18];
                    array2[n4 + 1] = a[0x3F & n13 >>> 12];
                    array2[n4 + 3] = (array2[n4 + 2] = '=');
                    break;
                }
            }
            if (n3 + 4 == Integer.MAX_VALUE) {
                array2[n4 + 4] = '\n';
            }
        }
        int length2;
        for (length2 = array2.length; length2 > 0 && array2[length2 - 1] == '='; --length2) {}
        return new String(array2, 0, length2);
    }
    
    @Deprecated
    public static byte[] a(final String s) {
        final char[] charArray = s.toCharArray();
        final int length = charArray.length;
        final byte[] b = b.b;
        final byte[] array = new byte[2 + length * 3 / 4];
        int n = 0;
        final char[] array2 = new char[4];
        int n2 = 0;
        int i = 0;
        int n3 = 0;
    Label_0219_Outer:
        while (i < length) {
            final char c = charArray[i + 0];
            final char c2 = (char)(c & '\u007f');
            final byte b2 = b[c2];
            if (c2 == c && b2 < -5) {
                throw new a("Bad Base64 input character at " + i + ": " + (int)charArray[i + 0] + "(decimal)");
            }
            while (true) {
                Label_0389: {
                    if (b2 < -1) {
                        break Label_0389;
                    }
                    int n4;
                    if (c2 == '=') {
                        if (n2 != 0) {
                            break Label_0389;
                        }
                        if (i < 2) {
                            throw new a("Invalid padding char found in position " + i);
                        }
                        n2 = 1;
                        final char c3 = (char)('\u007f' & charArray[0 + (length - 1)]);
                        if (c3 != '=' && c3 != '\n') {
                            throw new a("encoded value has invalid trailing char");
                        }
                        n4 = n;
                    }
                    else {
                        if (n2 != 0) {
                            throw new a("Data found after trailing padding char at index " + i);
                        }
                        final int n5 = n3 + 1;
                        array2[n3] = c2;
                        if (n5 == 4) {
                            n4 = n + a(array2, array, n, b);
                            n3 = 0;
                        }
                        else {
                            n3 = n5;
                            n4 = n;
                        }
                    }
                    ++i;
                    n = n4;
                    continue Label_0219_Outer;
                }
                int n4 = n;
                continue;
            }
        }
        if (n3 != 0) {
            if (n3 == 1) {
                throw new a("single trailing character at offset " + (length - 1));
            }
            array2[n3] = '=';
            n += a(array2, array, n, b);
        }
        final byte[] array3 = new byte[n];
        System.arraycopy(array, 0, array3, 0, n);
        return array3;
    }
}
