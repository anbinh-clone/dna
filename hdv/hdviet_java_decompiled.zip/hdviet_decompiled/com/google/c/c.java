package com.google.c;

public final class c
{
    static final int a;
    static final int b;
    static final int c;
    static final int d;
    
    static {
        a = 11;
        b = 12;
        c = 16;
        d = 26;
    }
    
    static int a(final int n, final int n2) {
        return n2 | n << 3;
    }
}
