package com.google.c;

import java.io.IOException;

public final class b extends IOException
{
    b() {
        super("CodedOutputStream was writing to a flat byte array and ran out of space.");
    }
}
