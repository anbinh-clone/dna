package com.google.c;

import java.io.OutputStream;

public final class a
{
    public final byte[] a;
    public final int b;
    public int c;
    public int d;
    public final OutputStream e;
    
    public a(final OutputStream e, final byte[] a) {
        super();
        this.d = 0;
        this.e = e;
        this.a = a;
        this.c = 0;
        this.b = a.length;
    }
    
    public void a() {
        if (this.e == null) {
            throw new b();
        }
        this.e.write(this.a, 0, this.c);
        this.c = 0;
    }
    
    public final void a(final int n) {
        final byte b = (byte)n;
        if (this.c == this.b) {
            this.a();
        }
        this.a[this.c++] = b;
        this.d += 1;
    }
    
    public final void a(final int n, final int n2) {
        this.b(c.a(n, n2));
    }
    
    public final void b(int n) {
        while ((n & 0xFFFFFF80) != 0x0) {
            this.a(0x80 | (n & 0x7F));
            n >>>= 7;
        }
        this.a(n);
    }
}
