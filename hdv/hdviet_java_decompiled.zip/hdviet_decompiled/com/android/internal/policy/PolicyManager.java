package com.android.internal.policy;

import android.view.WindowManagerPolicy;
import android.view.Window;
import android.view.LayoutInflater;
import android.content.Context;

public final class PolicyManager
{
    private static final String POLICY_IMPL_CLASS_NAME = "com.android.internal.policy.impl.Policy";
    private static final IPolicy sPolicy;
    
    static {
        try {
            sPolicy = (IPolicy)Class.forName("com.android.internal.policy.impl.Policy").newInstance();
        }
        catch (ClassNotFoundException ex) {
            throw new RuntimeException("com.android.internal.policy.impl.Policy could not be loaded", ex);
        }
        catch (InstantiationException ex2) {
            throw new RuntimeException("com.android.internal.policy.impl.Policy could not be instantiated", ex2);
        }
        catch (IllegalAccessException ex3) {
            throw new RuntimeException("com.android.internal.policy.impl.Policy could not be instantiated", ex3);
        }
    }
    
    public static LayoutInflater makeNewLayoutInflater(final Context context) {
        return PolicyManager.sPolicy.makeNewLayoutInflater(context);
    }
    
    public static Window makeNewWindow(final Context context) {
        return PolicyManager.sPolicy.makeNewWindow(context);
    }
    
    public static WindowManagerPolicy makeNewWindowManager() {
        return PolicyManager.sPolicy.makeNewWindowManager();
    }
}
